package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;
import com.optum.synergy.reference.ui.pageobjects.ServeYouUnauthenticatedHomePage;

import cucumber.api.java.en.Given;

public class ServeYouUnauthenticatedHomePageStepDefinition {

	private ServeYouUnauthenticatedHomePage page;

	public ServeYouUnauthenticatedHomePageStepDefinition() {
		page = new ServeYouUnauthenticatedHomePage();
	}

	@Given("^I am at ServeYou unauthenticated home page$")
	public void i_am_at_ServeYou_unauthenticated_home_page() {
		page.openServeYouHomePage();
		Assert.assertTrue("Issue while loading the ServeYou Unauthenticated page", page.isPageLoaded());
	}

	@Given("^I should be at ServeYou unauthenticated home page$")
	public void i_shouldbeat_ServeYou_unauthenticated_home_page() {
		Assert.assertTrue("Issue while loading the ServeYou Unauthenticated page", page.isPageLoaded() && page.isLogoDisplayed());
	}
}