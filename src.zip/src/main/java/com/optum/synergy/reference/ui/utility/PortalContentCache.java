package com.optum.synergy.reference.ui.utility;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.jsoup.Jsoup;
import org.junit.Assert;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.security.GeneralSecurityException;
import java.security.cert.X509Certificate;
import java.util.*;

public class PortalContentCache extends AbstractCache<String> {

    private static final Logger log = LogManager.getLogger(PortalContentCache.class.getName());
    private static final Properties portals;

    private static final Map<String, String> externalUrls;

    static {
        // Create a trust manager that does not validate certificate chains
        TrustManager[] trustAllCerts = new TrustManager[]{
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() {
                        return new X509Certificate[0];
                    }

                    public void checkClientTrusted(
                            X509Certificate[] certs, String authType) {
                    }

                    public void checkServerTrusted(
                            X509Certificate[] certs, String authType) {
                    }
                }
        };

        // Install the all-trusting trust manager
        try {
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (GeneralSecurityException e) {
        }
    }

    static {
        portals = new Properties();

        try {
            final String env = System.getProperty("ExecutionEnv");
            portals.load(new FileInputStream(String.format("Configs/%s/portals.properties", env)));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    static {
        externalUrls = new HashMap<>();
        externalUrls.put("Language Assistance", "LanguageAssistanceURL");
        externalUrls.put("Disclosures (UnitedHealthcare Medicare Plans)", "DisclosuresMedicarePlansURL");
        externalUrls.put("Disclosures (AARP Medicare Plans)", "DisclosuresAARPMedicarePlansURL");
    }

    public String get(String portalName, String key) {

        final String portalId = portals.getProperty("portal." + portalName);
        //final String portalId ="LAWW";
        // final String lang = portals.getProperty("lang." + DataStorage.getLanguage());
        final String lang="en";
        return get(portalId, () -> {
                    final List<String> files = new ArrayList();

                    if (StringUtils.isNotBlank(portalId)) {
                        files.add(String.format(portals.getProperty("url.hsid2"), portalId, lang));
                        files.add(String.format(portals.getProperty("url.emails"), portalId, lang));
                        files.add(String.format(portals.getProperty("url.signin"), portalId, lang));
                        files.add(String.format(portals.getProperty("url.register"), portalId, lang));
                        files.add(String.format(portals.getProperty("url.legal"), portalId, lang));
                    }
                    return files;
                },
                key,
                lang);
    }

    @Override
    protected Map<String, String> loadCache(String resourceLocator) {

        Map<String, String> cacheItem = null;

        try {
            String jsonString = IOUtils.toString(new URL(resourceLocator), "UTF-8");
            cacheItem = new ObjectMapper().readValue(jsonString, HashMap.class);
            cacheItem.remove("Logo");
            cacheItem.remove("DefaultLogo");
            cacheItem.replaceAll((key, value) -> StringEscapeUtils.unescapeHtml4(value));
            handleFooterURLs(cacheItem);
            cacheItem.replaceAll((key, value) -> value.replaceAll("[\\\\]*\\\"", "\\\\\\\""));
        } catch (FileNotFoundException e) {
            log.warn("FILE/URL NOT FOUND: {} (OK IF NOT NEEDED)", resourceLocator);
        } catch (IOException e) {
            log.error("PROBLEM LOADING: {}", resourceLocator, e);
        }

        return cacheItem;
    }

    private void handleFooterURLs(Map<String, String> cacheItem) {

        String value = cacheItem.get("LblA11yInfo");

        if (StringUtils.isNotBlank(value)) {
            value = Jsoup.parse(value).childNode(0).childNode(1).childNode(0).attr("href");
            value = value.replaceAll("\\\\\"", "");
            cacheItem.put("LblA11yInfoURL", value);
        }

        value = cacheItem.get("ExtraFooterLinks");

        if (StringUtils.isNotBlank(value) && !"undefined".equalsIgnoreCase(value)) {
            value = value.replaceAll("\\\\\"", "\"");
            try {
                JSONParser parser = new JSONParser();
                JSONArray json = (JSONArray) parser.parse(value);
                Iterator i = json.iterator();
                while (i.hasNext()) {
                    JSONObject item = (JSONObject) i.next();
                    String label = (String) item.get("label");
                    String urlKey = externalUrls.get(label);
                    if (StringUtils.isNotBlank(urlKey)) {
                        cacheItem.put(urlKey, (String) item.get("url"));
                    }
                }
            } catch (ParseException e) {
                e.printStackTrace();
                Assert.fail("String to JSON object parsing error");
            }
        }
    }
}
