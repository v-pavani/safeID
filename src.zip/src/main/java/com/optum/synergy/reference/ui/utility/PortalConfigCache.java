package com.optum.synergy.reference.ui.utility;

import org.apache.commons.io.IOUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.*;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public class PortalConfigCache extends AbstractCache<String> {

    private static final String LOCAL_SUFFIX = ".local";
    private static final Properties portals;
    private static List<String> excludedPortals = null;

    static {
        portals = new Properties();
        try {
            final String env = System.getProperty("ExecutionEnv");
            portals.load(new FileInputStream(String.format("Configs/%s/portals.properties", env)));
            excludedPortals = Arrays.stream(portals.getProperty("portal.config.exclude").split(",")).collect(Collectors.toList());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String get(String portalName, String key) {
        String portalId = portals.getProperty("portal." + portalName);

        return this.get(portalId, () ->
                        Arrays.asList("Locator".equalsIgnoreCase(portalName) ?
                                "Configs/LocatorConfig.properties" :
                                "Configs/" + System.getProperty("ExecutionEnv") + "/" + portalName + "Config.properties"),
                key);
    }

    protected String get(String cacheKey, Supplier<List<String>> locator, String key) {

        // load configs from API
        Map<String, String> cacheItem = Optional.ofNullable(cache.get(cacheKey)).orElseGet(() -> {
                    Map<String, Map<String, String>> apiPortalConfigs = loadFromConfigAPI.get();
                    cache.putAll(apiPortalConfigs);

                    return Optional.ofNullable(cache.get(cacheKey)).orElseGet(() -> new HashMap<>());
                }
        );

        // load configs from local file
        locator.get().stream().forEach((resourceLocator) -> {
            Map<String, String> cacheData = loadCache(resourceLocator);
            cacheData.entrySet().stream().forEach((e) -> {
                cacheItem.put(e.getKey() + LOCAL_SUFFIX, e.getValue());
            });
        });

        // local config overrides config API values
        String apiKey = portals.getProperty("portal.config.property." + key);
        String value = Optional.ofNullable(cacheItem.get(key + LOCAL_SUFFIX)).orElseGet(() -> cacheItem.get(apiKey));

        if (value == null) {
            System.out.println("PORTAL CONFIG: " + cacheKey + ", VALUE FOR KEY: " + key + " IS NULL");
            System.out.println(key + " = " + cacheItem.get(key));
            System.out.println(key + LOCAL_SUFFIX + " = " + cacheItem.get(key + LOCAL_SUFFIX));
        }

        return value;
    }

    private Function<JSONArray, Map<String, String>> handleUiIdTypes = (uiIdTypes) -> {
        final HashMap<String, String> uiIdTypesMap = new HashMap<>();
        uiIdTypesMap.put("identificationType1", "NA");
        uiIdTypesMap.put("identificationType2", "NA");
        uiIdTypesMap.put("identificationType3", "NA");

        int idTypeIndex = 1;

        for (Object uiIdType : uiIdTypes) {
            JSONArray uiIdTypesElements = (JSONArray) ((JSONObject) uiIdType).get("elements");
            List<String> uiIdTypeIds = new ArrayList<>();
            for (Object uiIdTypesElement : uiIdTypesElements) {
                String uiIdTypesId = (String) ((JSONObject) uiIdTypesElement).get("id");
                if (uiIdTypesId != null) {
                    uiIdTypeIds.add(uiIdTypesId.toLowerCase());
                }
            }
            Collections.reverse(uiIdTypeIds);
            uiIdTypesMap.put("identificationType" + idTypeIndex++, String.join("_", uiIdTypeIds));
        }
        return uiIdTypesMap;
    };

    private Function<JSONObject, Map<String, String>> handleLocales = (locales) -> {
        final HashMap<String, String> urlsMap = new HashMap<>();

        final Set<Map.Entry<String, JSONObject>> localeEntries = locales.entrySet();
        for (Map.Entry<String, JSONObject> localeEntry : localeEntries) {
            // some configs use 'xx-language', so strip off suffix and use 'xx'
            final String localeKey = localeEntry.getKey().split("-")[0];
            final JSONObject urls = localeEntry.getValue();
            final Set<Map.Entry<String, String>> urlSet = urls.entrySet();
            for (final Map.Entry<String, String> urlEntry : urlSet) {
                final String urlKey = urlEntry.getKey();
                final String urlValue = urlEntry.getValue();
                urlsMap.put(urlKey + "_" + localeKey, urlValue);
            }
        }
        return urlsMap;
    };

    @SuppressWarnings("unchecked")
    private Supplier<Map<String, Map<String, String>>> loadFromConfigAPI = () -> {

        final Map<String, Map<String, String>> cacheItem = new HashMap<>();

        try {
            final String configUrl = portals.getProperty("portal.config.url");
            final String jsonString = IOUtils.toString(new URL(configUrl), "UTF-8");
            final JSONParser jsonParser = new JSONParser();
            final JSONArray portalConfigs = (JSONArray) jsonParser.parse(jsonString);

            Iterator iterator = portalConfigs.iterator();
            while (iterator.hasNext()) {
                final JSONObject portalConfig = (JSONObject) iterator.next();
                final String portalName = (String) portalConfig.get("portalName");
                if (portalName != null && !excludedPortals.contains(portalName)) {
                    final JSONObject uiConfigs = (JSONObject) portalConfig.get("uiConfig");
                    final HashMap<String, String> portalConfigMap = new HashMap<>();
                    if (uiConfigs != null) {
                        final Set<Map.Entry<String, Object>> uiConfigSet = uiConfigs.entrySet();
                        for (Map.Entry<String, Object> uiConfig : uiConfigSet) {
                            final String uiConfigKey = uiConfig.getKey();
                            final Object uiConfigValue = uiConfig.getValue();
                            if ("uiidentificationtypes".equalsIgnoreCase(uiConfigKey)) {
                                final Map<String, String> uiIdTypes = handleUiIdTypes.apply((JSONArray) uiConfig.getValue());
                                portalConfigMap.putAll(uiIdTypes);
                            } else if ("locales".equalsIgnoreCase(uiConfigKey)) {
                                final Map<String, String> locales = handleLocales.apply((JSONObject) uiConfig.getValue());
                                portalConfigMap.putAll(locales);
                            } else if ("features".equalsIgnoreCase(uiConfigKey)) {
                                Boolean isSDKPortal = (Boolean) ((JSONObject) uiConfigValue).get("isSDKPortal");
                                portalConfigMap.put("isSDKPortal", isSDKPortal != null ? Boolean.toString(isSDKPortal) : Boolean.FALSE.toString());
                                Boolean isNativeApp = (Boolean) ((JSONObject) uiConfigValue).get("isNativeApp");
                                portalConfigMap.put("isNativeApp", isNativeApp != null ? Boolean.toString(isNativeApp) : Boolean.FALSE.toString());
                            } else {
                                portalConfigMap.put(uiConfigKey, uiConfigValue.toString());
                            }
                        }
                    }
                    cacheItem.put(portalName, portalConfigMap);
                }
            }
        } catch (ParseException | IOException e) {
            e.printStackTrace();
        }
        return cacheItem;
    };
}
