package com.optum.synergy.reference.ui.stepDefinitions;

import java.util.List;

import com.optum.synergy.reference.ui.pageobjects.PageObjectBase;
import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.Registration_CreateAccountSectionPage;
import com.optum.synergy.reference.ui.utility.DataStorage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Registration_CreateAccountSectionPageStepDefinition {
	private Registration_CreateAccountSectionPage page;
	
	public Registration_CreateAccountSectionPageStepDefinition() {
		page = new Registration_CreateAccountSectionPage();
	}

	@Then("^I should be at Create account section page$")
	public void i_should_be_at_Create_account_section_page() throws Throwable {
		Thread.sleep(2000);
		Assert.assertTrue("Issue while loading the Create account page", page.verifyIfPageLoaded());
	}
	
	@Then("^I should see a Username label with textbox$")
	public void i_should_see_a_Username_label_with_textbox() {
	    Assert.assertTrue("Issue while displaying the Username label with textbox", page.verifyIfUsernameLabelExistWithTextbox());
	}

	@Then("^I enter valid \"(.*)\" into Username field$")
	public void i_enter_valid_into_Username_field(String userName) {
		page.enterUserName(userName);
	}
	
	@Then("^I enter Invalid \"([^\"]*)\" into Username field$")
	public void i_enter_Invalid_into_Username_field(String userName) {
		page.enterUserName(userName);
	}

	@Then("^I enter valid username into Username field for registration$")
	public void i_enter_valid_username_into_Username_field() {
		page.enterUserName(DataStorage.getUserName());
		DataStorage.setCustomErrmsg("username:::"+ DataStorage.getUserName());
	}
	
	@Then("^I should see the Username Suggestion dropdown$")
	public void i_shuld_see_the_username_suggestion_dropdown() {
		Assert.assertTrue("Username Suggestion dropdown not found in Create account page", page.verifyIfUsernameSuggestionDropdownDisplayed());
	}
	
	@Then("^I should see checkbox for terms and conditions$")
	public void i_shuld_see_checkbox_for_terms_and_conditions() {
		Assert.assertTrue("Terms and conditions checkbox not found in Create account page", page.verifyVisibilityOfTermsOfUseCheckBox());
	}
	
	@Then("^I enter valid username \"([^\"]*)\" into Username field for bulk registration$")
	public void i_enter_valid_username_into_Username_field(String arg1) {
		String username= DataStorage.getUserName();
		username=username+arg1;// adding special symbol 		
        DataStorage.setUserName(username);// setting up new user name
		page.enterUserName(username);
		DataStorage.setCustomErrmsg("username:::"+ DataStorage.getUserName());
	}
	
	@Then("^I enter valid \"([^\"]*)\" into Password field$")
	public void i_enter_valid_into_Password_field(String password) {
		page.enterPassword(password);
	}

	@Then("^I enter valid \"([^\"]*)\" into Confirm password field$")
	public void i_enter_valid_into_Confirm_password_field(String password) {
		page.enterConfirmPassword(password);
	}

	@Then("^I enter valid \"([^\"]*)\" into Email field$")
	public void i_enter_valid_into_Email_field(String email) {
		page.enterEmail(email);
	}
	
	@Then("^I enter valid email into Email field$")
	public void i_enter_valid_email_into_Email_field() {
		page.enterEmail(DataStorage.getEmailId());
	}
	
	@Then("^I enter valid \"([^\"]*)\" into Confirm email field$")
	public void i_enter_valid_into_Confirm_email_field(String email) {
		page.confirmEmail(email);
	}
	
	@Then("^I enter valid email into Confirm email field$")
	public void i_enter_valid_email_into_Confirm_email_field() {
		page.confirmEmail(DataStorage.getEmailId());
	}

	@Then("^I enter valid email with characters \"([^\"]*)\" into Email field$")
	public void i_enter_valid_email_with_char(String spclChars){
		String email = DataStorage.getEmailId();
		String[] emailArr = email.split("\\+",2);
		email = emailArr[0]+"+"+spclChars+emailArr[1];
		page.enterEmail(email);
		DataStorage.setEmailId(email);
	}

	@Then("^I select the security type as \"([^\"]*)\"$")
	public void i_select_the_security_type_as(String securityType) throws Throwable {
		if("LAWW".equalsIgnoreCase(DataStorage.getPortalName())){
			String securityType1 = PageObjectBase.getAEMContent(DataStorage.getPortalName(), "PageContent", securityType);
			page.selectSecurityType(securityType1);
			Thread.sleep(1000);
		}else{
			page.selectSecurityType(securityType);
			Thread.sleep(1000);
		}
	}
	
	@Then("^I enter valid phone number from phone number pool")
	public void i_enter_valid_phone_number_from_phone_number_pool() throws Throwable {
		page.enterPhoneNumberFromPool(); 
		Thread.sleep(1000);
	}

	@Then("^I select security question1 as \"([^\"]*)\"$")
	public void i_select_security_question1_as(String questionName1) {
		page.selectSecurityQuestion1(questionName1);
	}

	@Then("^I select security answer1 as \"([^\"]*)\"$")
	public void i_select_security_answer1_as(String securityAnswer1) {
		page.enterSecurityAnswer1(securityAnswer1);
	}

	@Then("^I select security question2 as \"([^\"]*)\"$")
	public void i_select_security_question2_as(String questionName2) {
		page.selectSecurityQuestion2(questionName2);
	}

	@Then("^I select security answer2 as \"([^\"]*)\"$")
	public void i_select_security_answer2_as(String securityAnswer2) {
		page.enterSecurityAnswer2(securityAnswer2);
	}

	@Then("^I select security question3 as \"([^\"]*)\"$")
	public void i_select_security_question3_as(String questionName3) {
		page.selectSecurityQuestion3(questionName3);
	}

	@Then("^I select security answer3 as \"([^\"]*)\"$")
	public void i_select_security_answer3_as(String securityAnswer3) {
		page.enterSecurityAnswer3(securityAnswer3);
	}

	@Then("^I check the Remember this device check box$")
	public void i_check_the_Remember_this_device_check_box() {
		page.clickRememberThisDeviceCheckBox();
	}

	@Then("^I check the Agree to terms of use check box$")
	public void i_check_the_Agree_to_terms_of_use_check_box() {
		page.clicktermsOfUseCheckBox();
	}
	
	@Then("^I Uncheck the Agree to terms of use check box$")
	public void i_Uncheck_the_Agree_to_terms_of_use_check_box() {
		page.clicktermsOfUseCheckBox();
	}

	@Then("^I enter valid \"([^\"]*)\" into confirm email field$")
	public void i_enter_valid_into_confirm_email_field(String email) {
		page.updateEmail(email);
	}

	@Then("^I enter phone number \"([^\"]*)\"$")
	public void iEnterPhoneNumber(String phoneNumber) {
		page.enterPhoneNumber(phoneNumber);
	}
	
	@Then("^I enter Confirm phone number \"([^\"]*)\"$")
	public void iEnterConfirmPhoneNumber(String phoneNumber) {
		page.enterConfirmPhoneNumber(phoneNumber);
	}

	@Then("^I select Phone Type as \"([^\"]*)\"$")
	public void iSelectPhoneTypeAs(String phoneType) {
		page.selectPhoneType(phoneType);
	}

	@Then("^I should select the Confirm your phone number with option \"([^\"]*)\"$")
	public void iShouldSelectTheConfirmYourPhoneNumberWithOption(String optionName) {
		page.clickConfirmYourPhoneNumberWithRadioButton(optionName);
	}

	@When("^I enter Username with \"([^\"]*)\"$")
	public void iEnterUsernameWith(String userName) {
		page.enterUserName(userName);
	}

	@Then("^I should see an error message \"([^\"]*)\" for Username$")
	public void iShouldSeeAnErrorMessageForUsername(String message) {
		Assert.assertTrue("Username error is displaying the error message " + message,
				page.verifyErrorMessageOnUserName(message));
	}
	
	@Then("^I should see an error message \"([^\"]*)\"$")
	public void iShouldSeeAnErrorMessage(String message) {
		Assert.assertTrue("Error is displaying for field validation" + message,
				page.verifyErrorMessageOnConfirmPhoneNumber(message));
	}
	
	@Then("^I should see an error message \"([^\"]*)\" for Code$")
	public void iShouldSeeAnErrorMessageForCode(String message) {
		Assert.assertTrue("Code field is displaying the error message " + message,
				page.verifyErrorMessageOnCode(message));
	}
	
	@Then("^I should see an error message \"([^\"]*)\" for Confirmation Option$")
	public void iShouldSeeAnErrorMessageForConfirmationOption(String message) {
		Assert.assertTrue("Confirmation Option is displaying the error message " + message,
				page.verifyErrorMessageOnConfirmationOption(message));
	}

	@Then("^I should an error alert message \"([^\"]*)\" under Create username and password section$")
	public void iShouldAnErrorAlertMessageUnderCreateUsernameAndPasswordSection(String message) {
		Assert.assertTrue("error in displaying the error message " + message,
				page.verifyErrorMessageInErrorBox(message));
	}

	@Then("^I should see a Remember this device check box in Create Account page$")
	public void i_should_see_a_Remember_this_device_check_box_in_Create_Account_page() {
		Assert.assertTrue("Issue while displaying the Remember this device checkbox",
				page.verifyForRememberThisDeviceCheckBox());
	}

	@Then("^I should see the Create account form header as \"([^\"]*)\"$")
	public void i_should_see_the_Create_account_form_header_as(String header) {
		Assert.assertTrue("\""+header+"\" heading is not displaying on the Create account form", page.verifyFormHeader(header));
	}
	
	@Then("^I should see the Confirm your phone number input field$")
	public void i_should_see_the_Confirm_your_phone_number_input_field() {
		Assert.assertTrue("Confirm your phone number input field not displayed", page.verifyConfirmphoneNo());
	}
	
	@When("^I enter Code \"([^\"]*)\"$")
	public void iEnterCode(String userName) {
		page.enterCode(userName);
	}
	
	@When("^I click on Edit link$")
	public void iClickOnEditLink() {
		page.editlinkClick();
	}
	
	@Then("^I should see the \"([^\"]*)\" label in recovery section$")
	public void i_should_see_the_label_in_recovery_section(String label) {
		Assert.assertTrue("\""+label+"\" label is not displaying on the Create account recovery_section", page.verifyRecoverySectionlabel(label));
	}
	
	@Then("^I should see that the Consumer Communications Notice link points to \"([^\"]*)\"$")
	public void iShouldSeeThatTheConsumerCommunicationsNoticeLinkPointsTo(String hrefValue) {
		Assert.assertTrue("Incorrect URL " + page.getConsumerCommunicationsNoticeLink().getAttribute("href"),
				page.getConsumerCommunicationsNoticeLink().getAttribute("href").endsWith(hrefValue));
	}

	@Then("^I should see that the Terms of Use link points to \"([^\"]*)\"$")
	public void iShouldSeeThatTheTermsOfUseLinkPointsTo(String hrefValue) {
		Assert.assertTrue("Incorrect URL " + page.getTermsOfUseLink().getAttribute("href"),
		   page.getTermsOfUseLink().getAttribute("href").endsWith(hrefValue));
	}

	@Then("^I should see that the Privacy Policy link points to \"([^\"]*)\"$")
	public void iShouldSeeThatThePrivacyPolicyLinkPointsTo(String hrefValue) {
		Assert.assertTrue("Incorrect URL " + page.getPrivacyPolicyLink().getAttribute("href"),
				page.getPrivacyPolicyLink().getAttribute("href").endsWith(hrefValue));
	}
	
	@Then("^I should see the Phone number label$")
	public void iShouldSeeThePhoneNumberLabel() {
	    Assert.assertTrue(page.getPhoneNumberLabel().isDisplayed());
	}	

	@Then("^I should see that the Texting Terms and Conditions link points to \"([^\"]*)\"$")
	public void iShouldSeeThatTheTextingTermsAndConditionsLinkPointsTo(String hrefValue) {
		Assert.assertTrue("Incorrect URL " + page.getTextingTermsAndConditionsLink().getAttribute("href"),
			      page.getTextingTermsAndConditionsLink().getAttribute("href").endsWith(hrefValue));
	}
	
	@Then("^I should see the \"([^\"]*)\" label for username$")
	public void iShouldSeeTheLabelForUsername(String arg1) {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyusernameLabel(arg1));
	}

	@Then("^I should see the \"([^\"]*)\"  label for existing username$")
	public void i_should_see_the_for_existing_username_label(String arg1) {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyExistingUsernameLabel(arg1));
	}
	
	@Then("^I should see the \"([^\"]*)\" label for password$")
	public void i_should_see_the_label_for_password(String arg1) {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyPasswordLabel(arg1));
	}
	
	@Then("^I should see the \"([^\"]*)\" label for confirm password$")
	public void i_should_see_the_label_for_confirm_password(String arg1) {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyConfirmpasswordError(arg1));
	}	
	
	@Then("^I should see the \"([^\"]*)\" label for invalid confirm password$")
	public void i_should_see_the_label_for_invalid_confirm_password(String arg1) {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyConfirmpasswordError(arg1));
	}
	
	@Then("^I should see the \"([^\"]*)\" label for special confirm password$")
	public void i_should_see_the_label_for_special_confirm_password(String arg1) {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyConfirmpasswordError(arg1));
	}
	
	@Then("^I should see the \"([^\"]*)\" label for different confirm password$")
	public void i_should_see_the_label_for_different_confirm_password(String arg1) {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyConfirmpasswordError(arg1));
	}	
	 
	@Then("^I should see the \"([^\"]*)\" label for email$")
	public void iShouldSeeTheLabelForEmail(String arg1) {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyEmailLabel(arg1));
	}

	@Then("^I should see the \"([^\"]*)\" label for confirm email$")
	public void iShouldSeeTheLabelForConfirmEmail(String arg1) {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyConfirmEmailLabel(arg1));
	}
	
	@Then("^I should see the \"([^\"]*)\" label for security dropdown$")
	public void i_should_see_the_label_for_security_dropdown(String arg1) {
		Assert.assertEquals("\""+arg1+"\" error message is not displaying on the Registration Page", 
				page.getSecurityDropdownError(),
				arg1);
	}
	
	@Then("^I should see the \"([^\"]*)\" label for security phone number$")
	public void i_should_see_the_label_for_security_phone_number(String arg1) {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifySecurityPhoneNumberLabel(arg1));
	}
	
	@Then("^I should see the \"([^\"]*)\" label for security phone type$")
	public void i_should_see_the_label_for_security_phone_type(String arg1) {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifySecurityPhoneTypeLabel(arg1));
	}
	
	@Then("^I should see the \"([^\"]*)\" label for invalid security phone number$")
	public void iShouldSeeTheLabelForInvalidSecurityPhoneNumber(String arg1) {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyInvalidSecurityPhoneNumberLabel(arg1));
	}
	
	@Then("^I should see the \"([^\"]*)\" label for question 1$")
	public void iShouldSeeTheLabelForquestion1(String arg1) {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyquestion1(arg1));
	}
	
	@Then("^I should see the \"([^\"]*)\" label for question 2$")
	public void iShouldSeeTheLabelForquestion2(String arg1) {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyquestion2(arg1));
	}
	
	@Then("^I should see the \"([^\"]*)\" label for question 3$")
	public void iShouldSeeTheLabelForquestion3(String arg1) {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyquestion3(arg1));
	}  
	
	@Then("^I should see the \"([^\"]*)\" label for answer 1$")
	public void iShouldSeeTheLabelForAnswer1(String arg1) {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyAnswer1(arg1));
	} 
	
	@Then("^I should see the \"([^\"]*)\" label for answer 2$")
	public void iShouldSeeTheLabelForAnswer2(String arg1) {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyAnswer2(arg1));
	} 
	
	@Then("^I should see the \"([^\"]*)\" label for answer 3$")
	public void iShouldSeeTheLabelForAnswer3(String arg1) {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyAnswer3(arg1));
	}  
	
	@Then("^I should see the \"([^\"]*)\" label for agree terms of validation$")
	public void iShouldSeeTheLabelForAgreeTermsOfValidations(String arg1) {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyAgreeTermsOfValidations(arg1));
	}
	
	@Then("^I should see the following content in \"([^\"]*)\" tooltip$")
	public void iShouldSeeTheFollowingContentInTooltip(String arg1, List<String> contentList) {
		for (String content : contentList) {
			content = content.trim();

			Assert.assertTrue("\"" + content + "\" content is not displaying on the tooltip",
					page.verifyTooltipContent(arg1, content));
		}
	}
	
	@When("^I mouse hover over on email tooltip$")
	public void iMouseHoverOverOnEmailTooltip() {
		page.mouseHoverOnEmailIdToolTip();
	}
	
	@Then("^I should see the page header of HSID Create Account as \"([^\"]*)\"$")
	public void iShouldSeeThePageHeaderOfHSIDCreateAccountAs(String arg1) {
	   Assert.assertTrue("Create HSID header not displayed.", page.verifyCreateHsidHeaderContent(arg1));
	}
	
	@Then("^I should see the field \"([^\"]*)\" with label \"([^\"]*)\"$")
	public void iShouldSeeTheFieldWithLabel(String arg1, String arg2) throws Throwable {
		String actualLabelText = page.verifyLabels(arg1);
		Assert.assertTrue("Failed to find expected text [" + arg2
		 		+ "] in label text [" + actualLabelText	+ "]", 
		 		actualLabelText.contains(arg2));
	}
	
	@Then("^I should see autocomplete for security answer \"([^\"]*)\" is turned \"([^\"]*)\"$")
	public void iShouldSeeAutocompleteForSecurityAnswerIsTurned(int index, String value) {
		 Assert.assertEquals(value, page.verifyAutoCompleteForSecurityAnswers(index));
	}
	
	@Then("^I enter password as \"([^\"]*)\" and I click on the eye icon on \"([^\"]*)\" field$")
	public void iEnterPasswordandIClickOnEyeIcon(String arg1, String arg2) throws Throwable {
		 page.enterPasswordAndClickOnEyeIcon(arg1,arg2);	  
	}
	
	@Then("^I should see \"([^\"]*)\" data presents in the \"([^\"]*)\" field$")
	public void iShouldSeePasswordIsNotMaskedAndDataIsDisplaying(String arg1, String arg2) {
		Assert.assertEquals(arg1, page.getPasswordFieldValue(arg2));	  
	}

	@Then("^I should see a \"([^\"]*)\" error on top of White section$")
	public void iShouldSeeAErrorOnTopOfWhiteSection(String errorMsg) {
		Assert.assertEquals("Incorrect error message for Username field", errorMsg, page.getWhiteSectionErrorText() ) ;
	}

	@Then("^I should see the \"([^\"]*)\" error for myUhc username$")
	public void iShouldSeeErrorForMyUhcUsername(String errorMsg) {
	                Assert.assertEquals("Incorrect error message for Username field", errorMsg, page.getUsernameErrorText() ) ;
	}

	@Then("^I should see the \"([^\"]*)\" message for myUhc existing username$")
	public void iShouldSeeTheMessageForMyUhcExistingUsername(String arg1) {
		Assert.assertTrue("\""+arg1+"\" error message is not displaying on the Registration Page", page.verifyMyUhcExistingUsernameMessage(arg1));
	}
	
	@Then("^I should see the \"([^\"]*)\" error for myUhc password$")
	public void iShouldSeeErrorForMyUhcPassword(String errorMsg) {
	                Assert.assertEquals("Incorrect error message for Password field", errorMsg, page.getPasswordErrorText() ) ;
	}
	
	@Then("^I should see the \"([^\"]*)\" below phone number security option$")
	public void iShouldSeeTheBelowPhoneNumberSecurityOption(String message) {
		Assert.assertEquals("Incorrect phone message displayed on the Create account section page",
				message, page.getPhoneMsg());
	}
	
	@When("^I mouse hover over on Why we need your email toolTip for Email Id$")
    public void iMouseHoverOverOnToolTipForMemberId() {
		 page.mouseHoverOnEmailIdToolTip();
    }
	
	@Then("^I should see \"([^\"]*)\" message in email toolTip$")
    public void i_should_see_message_on_ToolTip(String message) {
     Assert.assertTrue(page.validateEmailToolTipMessage(message));
    } 

	@Then("^I should see the Username field is empty$")
	public void iShouldSeeTheUsernameFieldIsEmpty() {
	    Assert.assertTrue(page.verifyIfUserNameFieldisEmpty());
	}
	
	@Then("^I should see the Password field is empty$")
	public void iShouldSeeThePasswordFieldIsEmpty() {
	    Assert.assertTrue(page.verifyIfPasswordFieldisEmpty());
	}
	
	@Then("^I should see the ReEnter Password field is empty$")
	public void iShouldSeeTheReEnterPasswordFieldIsEmpty() {
	    Assert.assertTrue(page.verifyIfReEnterPasswordFieldisEmpty());
	}
	
	@Then("^I should see the Email field is empty$")
	public void iShouldSeeTheEmailFieldIsEmpty() {
	    Assert.assertTrue(page.verifyIfEmailFieldisEmpty());
	}
	
	@Then("^I should see the ReEnterEmail field is empty$")
	public void iShouldSeeTheReEnterEmailFieldIsEmpty() {
	    Assert.assertTrue(page.verifyIfReEnterEmailFieldisEmpty());
	}
	
	@Then("^I should see the page header of Upgrade to HSID contains \"([^\"]*)\"$")
	public void iShouldSeeThePageHeaderOfUpgradeToHSIDContains(String content) {
		Assert.assertTrue("Content not present in header", page.verifyUpgradeToHsidHeaderContent(content));
	}
	
	@Then("^I should see the username autopopulated into New username field$")
	public void iShouldSeeTheUsernameAutopopulatedIntoNewUsernameField() {
	    Assert.assertTrue(DataStorage.getUserName().trim().equalsIgnoreCase(page.verifyUsernameAutoPopulated().trim()));
	}

	@Then("^I should see auto populated email field$")
	public void iShouldSeeAutoPopulatedEmailField() {
		String expectedEmail = DataStorage.getEmail();
		String actualEmail = page.getEmailValue();
		Assert.assertNotNull("Null value returned for email field on page",actualEmail);
		Assert.assertEquals(expectedEmail.toUpperCase(), actualEmail.toUpperCase());
	}
	
	@Then("^I should see auto populated email field on modal$")
	public void iShouldSeeAutoPopulatedEmailFieldModal() {
		String expectedEmail = DataStorage.getEmail();
		String actualEmail = page.getEmailValueOnModal();
		Assert.assertNotNull("Null value returned for email field on page",actualEmail);
		Assert.assertEquals(expectedEmail.toUpperCase(), actualEmail.toUpperCase());
	}
	
	@Then("^I should see generated email populated in the email field$")
	public void iShouldSeeGeneratedEmailPopulatedInTheEmailField() {
		String expectedEmail = DataStorage.getEmailId();
		String actualEmail = page.getEmailValue();

		Assert.assertNotNull("Null value returned for email field on page",actualEmail);
		Assert.assertEquals(expectedEmail.toUpperCase(), actualEmail.toUpperCase());
	}
	
	@When("^I click on 'X' CloseICON in PopUP Window$")
	public void IclickonCloseICONinPopUP() {
		page.CloseICONinPopUPClick();
	}
	
	@Then("^I should see the Answer1 textbox is masked and editable$")
	public void i_should_see_the_Answer1_as_masked_and_editable() {
		page.VerifySecurityAnswerismaskedandeditable();
	}
	
    @Then("^I should see the following rules marked with green tick in Password field tool tip for \"([^\"]*)\"$")
    public void iShouldSeeTheFollowingRulesMarkedWithGreenInPasswordFieldTooltip(String pwd,List<String> contentList) throws Throwable {
            page.enterInPasswordField(pwd);
            Thread.sleep(1000);
            Assert.assertEquals(contentList.size(),page.returnNumberOfRulesMarkedAsGreenInTooltip());
            
            for (String content : contentList) {
                    content = content.trim();
                    Assert.assertTrue("\"" + content + "\" content is not displaying on the Tool tip",
                                    page.returnToolTipRulesMarkedAsGreen().contains(content));
            }
    }
    
    @Then("^I should see the following rules marked with green tick in Username field tool tip for \"([^\"]*)\"$")
    public void iShouldSeeTheFollowingRulesMarkedWithGreenInUsernameFieldTooltip(String usrname,List<String> contentList) throws Throwable {
            page.enterInUsernameField(usrname);
            Thread.sleep(1000);
            Assert.assertEquals(contentList.size(),page.returnNumberOfRulesMarkedAsGreenInTooltip());
            
            for (String content : contentList) {
                    content = content.trim();
                    Assert.assertTrue("\"" + content + "\" content is not displaying on the Tool tip",
                                    page.returnToolTipRulesMarkedAsGreen().contains(content));
            }
    }
    
    @Then("^I should see the Consumer Communications Notice link$")
	public void i_should_see_the_consumer_communications_notice_link() {
		Assert.assertTrue("Consumer Communications Notice link is not displayed", page.getConsumerCommunicationsNoticeLink().isDisplayed());
	}
    
    @Then("^I should see the Terms of Use link$")
   	public void i_should_see_the_terms_of_use_link() {
   		Assert.assertTrue("Terms of User link is not displayed", page.getTermsOfUseLink().isDisplayed());
   	}
    
    @Then("^I should see the Privacy Policy link$")
   	public void i_should_see_the_privacy_policy_link() {
   		Assert.assertTrue("Privacy Policy link is not displayed", page.getPrivacyPolicyLink().isDisplayed());
   	}
    
    @Then("^I click Consumer Communications Notice link$")
   	public void i_click_consumer_communications_notice_link() {
   		page.getConsumerCommunicationsNoticeLink().click();
   	}
       
    @Then("^I click Terms of Use link$")
    public void i_click_terms_of_use_link() {
    	page.getTermsOfUseLink().click();
    }
       
    @Then("^I click Privacy Policy link$")
    public void i_click_privacy_policy_link() {
    	page.getPrivacyPolicyLink().click();
    }
    
    @Then("^I should see exclamation symbol with error message \"([^\"]*)\" on top$")
	public void iShouldSeeErrorMessageOnTop(String errorMessage) {
    	Assert.assertTrue("Error message is not correct", page.verifyErrorMessageOnTop(errorMessage));
	}
    
    @When("^I click on HSID Analytics Opt Out link$")
	public void IclickonHSIDAnalyticsOptOutlink() {
		page.clickHSIDAnalyticsOptOutLink();
	}
    
    @When("^I should see the following text on the HSID Analytics Opt-Out page$")
    public void iShouldSeeTheFollowingContentInTheHSIDAnalyticsOptOutPage(List<String> contentList) {
    	for (String content : contentList) {
			content = content.trim();
			Assert.assertTrue("\"" + content + "\" content is not displaying HSID Analytics opt out page",
					page.getHSIDAnalyticsOptOutPageContent().contains(content));
		}
				
	}
    
    @When("^I should see the following text on the HSID Analytics Re-Enable page$")
    public void iShouldSeeTheFollowingContentInTheHSIDAnalyticsReEnablePage(List<String> contentList) {
    	for (String content : contentList) {
			content = content.trim();
			Assert.assertTrue("\"" + content + "\" content is not displaying HSID Analytics opt out page",
					page.getHSIDAnalyticsReEnablePageContent().contains(content));
		}
				
	}
    
    @Then("^I should see an exclusion error message \"([^\"]*)\"$")
    public void i_should_see_an_exclusion_error_message(String expexctedExclusionErrorMessage){
         page.validateExclusionErrorMessage(expexctedExclusionErrorMessage);
    }

	@Then("^I should see Registration Method tool tip$")
	public void iShouldSeeRegistrationMethodToolTip() {
		Assert.assertTrue(page.validateRegistrationMethodToolTipLabel());
	}

	@Then("^I mouse hover the Registration Method tool tip to validate contents$")
	public void iMouseHoverTheRegistrationMethodToolTipToValidateContents() {
		page.mouseHoverOnRegistrationMethodToolTipLabel();
	}
	@When("^I should see an hsid \"([^\"]*)\" icon$")
	public void iShouldSeeAnHsidIcon(String iconName) {

		Assert.assertTrue("Failed to display the HSID icon \"" + iconName + "\"", page.isHSIDIconDisplayed(iconName));
	}
}
