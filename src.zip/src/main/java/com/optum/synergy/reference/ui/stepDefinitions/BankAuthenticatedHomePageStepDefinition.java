package com.optum.synergy.reference.ui.stepDefinitions;

import com.optum.synergy.reference.ui.pageobjects.BankAuthenticatedHomePage;
import com.optum.synergy.reference.ui.utility.DataStorage;

import cucumber.api.java.en.Then;
import org.junit.Assert;

public class BankAuthenticatedHomePageStepDefinition {

	private BankAuthenticatedHomePage page;

	public BankAuthenticatedHomePageStepDefinition() {
		page = new BankAuthenticatedHomePage();
	}
	
	@Then("^I should be at (Disney|UHCHA|UHCRA|OptumBank|Bank-AARP) authenticated home page$")
	public void iShouldBeAtBankAuthenticatedHomePage(String portalName) {
		if(portalName.equals("Disney"))
		Assert.assertTrue("Issue while loading the Disney authenticated page", page.verifyIfDisneyAuthPageIsDisplayed());
		else if(portalName.equals("UHCHA"))
			Assert.assertTrue("Issue while loading the UHCHA authenticated page", page.verifyIfUHCHAAuthPageIsDisplayed());
		else if(portalName.equals("UHCRA"))
			Assert.assertTrue("Issue while loading the UHCRA authenticated page", page.verifyIfUHCRAAuthPageIsDisplayed());
		else if(portalName.equals("OptumBank"))
			Assert.assertTrue("Issue while loading the Optum Bank authenticated page", page.verifyIfBankAuthPageIsDisplayed());
		else
			Assert.assertTrue("Issue while loading the Bank-AARP authenticated page", page.verifyBankAARPAuthenticatedPageDisplayed());
	}

	@Then("^I manage the Bank security verification page$")
    public void iManageTheBankSecurityVerificationPage() {
            if(page.verifyBankSecurityVerificationPageLoaded()) {
                    	page.enterAccNumber(DataStorage.getAccountNumber());
                    	page.clickElementById("submit-button");
             }   
    }

	@Then("^I click on \"([^\"]*)\" on Terms and Conditions Page$")
	public void iClickOnOnTermsAndConditionsPage(String arg0) {
		if(page.verifyBankTermsAndConditionsPageLoaded()) {
			page.clickButtonBySubmitTypeAndName(arg0);
		}
	}

	@Then("^I click on Close button on Take the Tour$")
	public void iClickOnCloseButtonOnTakeTheTour() {
		if(page.verifyTakeTheTourPageLoaded()) {
			page.clickTakeTheTourCloseButton();
		}
	}
	
}