package com.optum.synergy.reference.ui.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

import com.optum.synergy.reference.ui.pageobjects.PageObjectBase;
import org.junit.Assert;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriverException;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.deps.com.thoughtworks.xstream.InitializationException;

public class HookDefinition {

	static Set<String> uniqueTags = new HashSet<String>();
	static String failedTags= "";

	@Before
	public void beforehook(Scenario scn) {
		PageObjectBase.OTPFoundStatus.set(0);
		PageObjectBase.DataFailureStatus.set(0);
		
		Collection<String> Tags = scn.getSourceTagNames();
		String tagsclcnton = Tags.toString();

		if (tagsclcnton.toUpperCase().contains("@LAWW")) {
			DataStorage.setPortalName("LAWW");
			DataStorage.setSubPortalName("LAWW");
			DataStorage.setCustomErrmsg("LAWW PORTAL URL : ["+ ReadXMLData.getTestData("LAWW", "AppURL")+"]");
		}
		// Identify MyUHC portal and sub-portal
		else if (tagsclcnton.toUpperCase().contains("@BSCA")) {
			DataStorage.setPortalName("BSCA");
			DataStorage.setSubPortalName("BSCA");
			DataStorage.setCustomErrmsg("BSCA PORTAL URL : ["+ ReadXMLData.getTestData("BSCA", "AppURL")+"]");
		}
		// Identify Bank portal and sub-portal
		else if (tagsclcnton.toUpperCase().contains("@BANKAARP")) {
			DataStorage.setPortalName("CAP");
			DataStorage.setSubPortalName("BANK-AARP");
			DataStorage.setCustomErrmsg("Bank-AARP PORTAL URL : ["+ ReadXMLData.getTestData("CAP", "BankAARPURL")+"]");
		} else if (tagsclcnton.toUpperCase().contains("@DISNEY")) {
			DataStorage.setPortalName("CAP");
			DataStorage.setSubPortalName("Disney");
			DataStorage.setCustomErrmsg("Bank-Disney PORTAL URL : ["+ ReadXMLData.getTestData("CAP", "DisneyURL")+"]");
		} else if (tagsclcnton.toUpperCase().contains("@CAP")) {
			DataStorage.setPortalName("CAP");
			DataStorage.setSubPortalName("CAP");
			DataStorage.setCustomErrmsg("Optum Bank PORTAL URL : ["+ ReadXMLData.getTestData("CAP", "OptumBankURL")+"]");
		} else if (tagsclcnton.toUpperCase().contains("@UHCRA")) {
			DataStorage.setPortalName("CAP");
			DataStorage.setSubPortalName("UHCRA");
			DataStorage.setCustomErrmsg("Bank-UHCRA PORTAL URL : ["+ ReadXMLData.getTestData("CAP", "UHCRAURL")+"]");
		} else if (tagsclcnton.toUpperCase().contains("@UHCHA")) {
			DataStorage.setPortalName("CAP");
			DataStorage.setSubPortalName("UHCHA");
			DataStorage.setCustomErrmsg("Bank-UHCHA PORTAL URL : ["+ ReadXMLData.getTestData("CAP", "UHCHAURL")+"]");
		} else if (tagsclcnton.toUpperCase().contains("@UHCRAF")) {
			DataStorage.setPortalName("CAP");
			DataStorage.setSubPortalName("UHCRAF");
		} else if (tagsclcnton.toUpperCase().contains("@GESSO")) {
			DataStorage.setPortalName("GESSO");
			DataStorage.setSubPortalName("GESSO");
		} else if (tagsclcnton.toUpperCase().contains("@OPTUMRXAARP")) {
			DataStorage.setPortalName("OptumRx");
			DataStorage.setSubPortalName("OptumRx-AARP");
			DataStorage.setCustomErrmsg("OptumRx-AARP PORTAL URL : ["+ ReadXMLData.getTestData("OptumRx", "OptumRxAARPURL")+"]");
		}  else if (tagsclcnton.toUpperCase().contains("@OPTUMRX")) {
			DataStorage.setPortalName("OptumRx");
			DataStorage.setSubPortalName("OptumRx");
			DataStorage.setCustomErrmsg("OptumRx PORTAL URL : ["+ ReadXMLData.getTestData("OptumRx", "AppURL")+"]");
		}  else if (tagsclcnton.toUpperCase().contains("@BAZ")) {
			DataStorage.setPortalName("BAZ");
			DataStorage.setSubPortalName("BAZ");
			DataStorage.setCustomErrmsg("OptumRx-BAZ PORTAL URL : ["+ ReadXMLData.getTestData("BAZ", "AppURL")+"]");
		} else if (tagsclcnton.toUpperCase().contains("@BRIOVARX")) {
			DataStorage.setPortalName("BRIOVARX");
			DataStorage.setSubPortalName("BriovaRx");
			DataStorage.setCustomErrmsg("BriovaRx PORTAL URL : ["+ ReadXMLData.getTestData("BRIOVARX", "AppURL")+"]");
		} else if (tagsclcnton.toUpperCase().contains("@SERVEYOU")) {
			DataStorage.setPortalName("ServeYou");
			DataStorage.setSubPortalName("ServeYou");
			DataStorage.setCustomErrmsg("OptumRx-ServeYou PORTAL URL : ["+ ReadXMLData.getTestData("ServeYou", "AppURL")+"]");
		} else if (tagsclcnton.toUpperCase().contains("@AHC")) {
			DataStorage.setPortalName("AHC");
			DataStorage.setSubPortalName("AHC");
			DataStorage.setCustomErrmsg("OptumRx-AHC PORTAL URL : ["+ ReadXMLData.getTestData("AHC", "AppURL")+"]");
		} else if(tagsclcnton.toUpperCase().contains("@PHP")){
			DataStorage.setPortalName("PHP");
			DataStorage.setSubPortalName("PHP");
			DataStorage.setCustomErrmsg("OptumRx-PHP PORTAL URL : ["+ ReadXMLData.getTestData("PHP", "AppURL")+"]");
		} else if(tagsclcnton.toUpperCase().contains("@BCBSSC")) {
			DataStorage.setPortalName("OptumRx");
			DataStorage.setSubPortalName("BCBSSC");
			DataStorage.setCustomErrmsg("OptumRx-BCBSSC URL : [This is a mobile app and is launched via Test Harness]");
		} else if (tagsclcnton.toUpperCase().contains("@AHA")) {
			DataStorage.setPortalName("OptumRx");
			DataStorage.setSubPortalName("AHA");
			DataStorage.setCustomErrmsg("OptumRx-AHA PORTAL URL : ["+ ReadXMLData.getTestData("OptumRx", "AHAURL")+"]");
		} else if(tagsclcnton.toUpperCase().contains("@AMERIHEALTH")) {
			DataStorage.setPortalName("OptumRx");
			DataStorage.setSubPortalName("AMERIHEALTH");
			DataStorage.setCustomErrmsg("OptumRx-AmeriHealth PORTAL URL : ["+ ReadXMLData.getTestData("OptumRx", "AMERIHEALTHURL")+"]");
		}
		//// Identify PHS portal and sub-portal
		else if(tagsclcnton.toUpperCase().contains("@PHS")){
			DataStorage.setPortalName("PHS");
			DataStorage.setPortalNumber(1291);
			DataStorage.setSubPortalName("PHS");
			DataStorage.setCustomErrmsg("PHS PORTAL URL : ["+ ReadXMLData.getTestData("PHS", "AppURL")+"]");
		} else if(tagsclcnton.toUpperCase().contains("@OPTUMPHS")){
			DataStorage.setPortalName("PHS");
			DataStorage.setPortalNumber(1291);
			DataStorage.setSubPortalName("PHS-OPTUM");
			DataStorage.setCustomErrmsg("PHS-Optum PORTAL URL : ["+ ReadXMLData.getTestData("PHS", "PHSOPTUMAPPURL")+"]");
		}
		// Identify MNR portal and sub-portal
		else if (tagsclcnton.toUpperCase().contains("@AARP")) {
			DataStorage.setPortalName("MNR");
			DataStorage.setSubPortalName("MNR-AARP");
			DataStorage.setCustomErrmsg("MNR-AARP PORTAL URL : ["+ ReadXMLData.getTestData("MNR", "AarpPortalURL")+"]");
		} else if (tagsclcnton.toUpperCase().contains("@MEDICARE")) {
			DataStorage.setPortalName("MNR");
			DataStorage.setSubPortalName("Medicare");
			DataStorage.setCustomErrmsg("MNR-Medicare PORTAL URL : ["+ ReadXMLData.getTestData("MNR", "MedicarePortalURL")+"]");
		} else if (tagsclcnton.toUpperCase().contains("@RETIREE")) {
			DataStorage.setPortalName("MNR");
			DataStorage.setSubPortalName("Retiree");
			DataStorage.setCustomErrmsg("MNR-Retiree PORTAL URL : ["+ ReadXMLData.getTestData("MNR", "RetireePortalURL")+"]");
		} else if (tagsclcnton.toUpperCase().contains("@MEDICA")) {
			DataStorage.setPortalName("MNR");
			DataStorage.setSubPortalName("Medica");
			DataStorage.setCustomErrmsg("MNR-Medica PORTAL URL : ["+ ReadXMLData.getTestData("MNR", "MedicaPortalURL")+"]");
		} else if (tagsclcnton.toUpperCase().contains("@PCP")) {
			DataStorage.setPortalName("MNR");
			DataStorage.setSubPortalName("PCP");
			DataStorage.setCustomErrmsg("MNR-PCP PORTAL URL : ["+ ReadXMLData.getTestData("MNR", "PcpPortalURL")+"]");
		} else if (tagsclcnton.toUpperCase().contains("@MYOPTUM")) {
			DataStorage.setPortalName("MyOptum");
			DataStorage.setSubPortalName("MyOptum");
			DataStorage.setCustomErrmsg("MyOptum PORTAL URL : ["+ ReadXMLData.getTestData("MyOptum", "AppURL")+"]");
		} else if (tagsclcnton.toUpperCase().contains("@RALLYDHP")) {
			DataStorage.setPortalName("RallyDhp");
			DataStorage.setSubPortalName("RallyDhp");
			DataStorage.setCustomErrmsg("RallyDhp URL : [This is a mobile app and is launched via Test Harness]");
		} else if (tagsclcnton.toUpperCase().contains("@WHUHC")) {
			DataStorage.setPortalName("WomensHealth");
			DataStorage.setSubPortalName("WomensHealth-UHC");
			DataStorage.setCustomErrmsg("WomensHealth-UHC URL : [This is a mobile app and is launched via Test Harness]");
		} else if (tagsclcnton.toUpperCase().contains("@WHOPTUM")) {
			DataStorage.setPortalName("WomensHealth");
			DataStorage.setSubPortalName("WomensHealth-OPTUM");
			DataStorage.setCustomErrmsg("WomensHealth-Optum URL : [This is a mobile app and is launched via Test Harness]");
		} else if (tagsclcnton.toUpperCase().contains("@SSOMYUHC")) {
			DataStorage.setPortalName("SSOMYUHC");
			DataStorage.setSubPortalName("SSOMYUHC");
			DataStorage.setCustomErrmsg("MyUHC-SSO PORTAL URL : ["+ ReadXMLData.getTestData("SSOMYUHC", "AppURL")+"]");
		} else if (tagsclcnton.toUpperCase().contains("@HARVARDPILGRIMSSO")) {
			DataStorage.setPortalName("SSOMYUHC");
			DataStorage.setSubPortalName("HarvardPilgrimSSO");
			DataStorage.setCustomErrmsg("HarvardPilgrim-SSO PORTAL URL : ["+ ReadXMLData.getTestData("SSOMYUHC", "LoginSSOUrl")+"]");
		} else if (tagsclcnton.toUpperCase().contains("@RAILROADSSO")) {
			DataStorage.setPortalName("RailRoadSSO");
			DataStorage.setSubPortalName("RailRoadSSO");
			DataStorage.setCustomErrmsg("RailRoadSSO PORTAL URL : ["+ ReadXMLData.getTestData("RailRoadSSO", "LoginSSOUrl")+"]");
		} else if (tagsclcnton.toUpperCase().contains("@TCC")) {
			DataStorage.setPortalName("TCC");
			DataStorage.setSubPortalName("TCC");
			DataStorage.setCustomErrmsg("OptumRx-TCC PORTAL URL : ["+ ReadXMLData.getTestData("TCC", "AppURL")+"]");
		} else if (tagsclcnton.toUpperCase().contains("@PAI")) {
			DataStorage.setPortalName("PAI");
			DataStorage.setSubPortalName("PAI");
			DataStorage.setCustomErrmsg("OptumRx-PAI PORTAL URL : ["+ ReadXMLData.getTestData("PAI", "AppURL")+"]");
		} else if (tagsclcnton.toUpperCase().contains("@IBX")) {
			DataStorage.setPortalName("OptumRx");
			DataStorage.setSubPortalName("IBX");
			DataStorage.setCustomErrmsg("OptumRx-IBX PORTAL URL : ["+ ReadXMLData.getTestData("OptumRx", "IBXURL")+"]");
		} else {
			DataStorage.setCustomErrmsg("Feature file is missing proper portal tag. Please make necessary updates");
			Assert.fail("Feature file is not having proper portal tag. In case of new portal make sure that tag code is added to Hooks file.");
		}
		/*
		To ensure that @US tag is added in the feature file to avoid retry execution issues.
		 */
		if(!tagsclcnton.contains("@US")) {
			DataStorage.setCustomErrmsg("Feature file is missing proper User story tag");
			Assert.fail("Feature file is missing proper User story tag. Please make necessary updates");
		}

		if(tagsclcnton.toUpperCase().contains("@HSID11_SMOKE")){
			DataStorage.setTagName("@HSID11_SMOKE");
		}
	}
 
	@After("~@EnvCheck")
	public void afterhook(Scenario scn) throws WebDriverException, IOException {

		// Wrap in try/finally block in case something is broken with driver
		// object
		// Want to ensure that is closed and nulled out for future use.
		try {
			
			synchronized(this){		
			 String status;
			 if (scn.isFailed()){
				 status="Fail";
			 }else{
				 status="Pass";
			 }
			 String mdulename = DataStorage.getSubPortalName();

			 File foo = new File(HTMLReport.testResultTextFile);
				 FileWriter fw =new FileWriter(foo,true);
				 fw.write("\r\n"+mdulename+","+status);
				 fw.close();
			}
			scn.write(DataStorage.getCustomErrmsg());
			
			try {
				final byte[] screenshot = ((TakesScreenshot) DriverFactory.getDeviceDriver())
						.getScreenshotAs(OutputType.BYTES);
				scn.embed(screenshot, "image/png"); // ... and embed it in
			} catch ( InitializationException e ) {
				//no-op if driver not initialized, skip screenshotting
			}
		} finally {
			// Reset DataStorage values for next test using this thread
			// and return any ResourcePool data
			DataStorage.resetAllDataStorage();
			DriverFactory.closeDeviceDriver();
		}
	}

	@After
	public void afterhookGetFailedTags(Scenario scn) {

		synchronized (this) {
			if (scn.isFailed()) {
				List<String> tagsToRemove = new ArrayList<String>();
				Collection<String> tagcollection = scn.getSourceTagNames();
				tagcollection.removeIf(p -> !p.startsWith("@US"));

				for (String tag : tagcollection) {
					if (tag.contains("_")) {
						int endIndex = tag.indexOf("_");
						tagsToRemove.add(tag.substring(0, endIndex));
					}
				}

				for (String rmvTag : tagsToRemove) {
					tagcollection.removeIf(p -> p.toString().equals(rmvTag));
				}

				tagcollection.stream().collect(Collectors.joining(","));
				String tagString = tagcollection.toString();
				tagString = tagString.replace(" ", "");
				tagString = tagString.replace("[", "");
				tagString = tagString.replace("]", "");

				File failedTagListFile = new File("target/failedTagList.txt");
				File OTPFailedTagListFile = new File("target/OTPFailedTagList.txt");
				File DataFailedTagListFile = new File("target/DataFailedTagList.txt");
				boolean flag = false;

				if(PageObjectBase.OTPFoundStatus.get() == 1)
					flag = true;
				try {
					FileWriter fileWriter = new FileWriter(failedTagListFile, false);
					FileWriter fileWriter_OTPTags = new FileWriter(OTPFailedTagListFile, true);
					FileWriter fileWriter_DataTags = new FileWriter(DataFailedTagListFile,true);

					BufferedReader br = new BufferedReader(new FileReader(failedTagListFile));
					BufferedReader br_OTPTags = new BufferedReader(new FileReader(OTPFailedTagListFile));
					BufferedReader br_DataTags = new BufferedReader(new FileReader(DataFailedTagListFile));

					if (br_OTPTags.readLine() != null && flag )
						fileWriter_OTPTags.write(",");

					if (br_DataTags.readLine() != null && PageObjectBase.DataFailureStatus.get() ==1 )
						fileWriter_DataTags.write(",");

					boolean isAdded = uniqueTags.add(tagString);

					if(isAdded) {
						if(failedTags.isEmpty())
							failedTags = tagString;
						else
							failedTags = failedTags + "," + tagString;
					}

					fileWriter.write(failedTags);

					fileWriter.close();
					br.close();

					if(PageObjectBase.OTPFoundStatus.get() == 1)
						fileWriter_OTPTags.write(tagString);


					fileWriter_OTPTags.close();
					br_OTPTags.close();

					if(PageObjectBase.DataFailureStatus.get()==1)
						fileWriter_DataTags.write(tagString);
					fileWriter_DataTags.close();
					br_DataTags.close();

				} catch (Exception e) {
					scn.write("EXCEPTION Writing failedTags to file [" + e + "]");
				}
			}
		}
	}

	@After("@EnvCheck")
	public void afterhookForEnvironmentHealth(Scenario scn) throws IOException {

		try {

			synchronized (this) {
				String status;
				if (scn.isFailed()) {
					status = "Fail";
				} else {
					status = "Pass";
				}

				Collection<String> tagcollection = scn.getSourceTagNames();
				String mdulename = null;
				if (tagcollection.toString().toUpperCase().contains("@CLIENTTOKEN")) {
					mdulename = "Service_ClientToken";
				} else if (tagcollection.toString().toUpperCase().contains("@LAWWELIGIBILITY")) {
					mdulename = "Service_LAWWEligibility";
				} else if (tagcollection.toString().toUpperCase().contains("@OPTUMRXELIGIBILITY")) {
					mdulename = "Service_OptumRxEligibility";
				} else if (tagcollection.toString().toUpperCase().contains("@MYUHCELIGIBILITY")) {
					mdulename = "Service_MyUhcValidMember";
				} else if (tagcollection.toString().toUpperCase().contains("@MDMSERVICECHECK")) {
					mdulename = "Service_MDM";
				} else if (tagcollection.toString().toUpperCase().contains("@RBA")) {
					mdulename = "Service_RBA";
				} else if (tagcollection.toString().toUpperCase().contains("@ESSO")) {
					mdulename = "Service_ESSO";
				} else if (tagcollection.toString().toUpperCase().contains("@HSIDPDBSTATUS")) {
					mdulename = "DB_HSID-PDB";
				} else if (tagcollection.toString().toUpperCase().contains("@ISECDBSTATUS")) {
					mdulename = "DB_ISEC-DB";
				} else if (tagcollection.toString().toUpperCase().contains("@MYUHCDBSTATUS")) {
					mdulename = "DB_MyUHC-DB";
				} else if (tagcollection.toString().toUpperCase().contains("@OPTUMRXDBSTATUS")) {
					mdulename = "DB_OptumRx-PDB";
				} else if (tagcollection.toString().toUpperCase().contains("@LAWW-UI")) {
					mdulename = "UI_LAWW-UI";
				} else if (tagcollection.toString().toUpperCase().contains("@MYUHC-UI")) {
					mdulename = "UI_MyUHC-UI";
				} else if (tagcollection.toString().toUpperCase().contains("@OPTUMRX-UI")) {
					mdulename = "UI_OptumRx-UI";
				} else if (tagcollection.toString().toUpperCase().contains("@SERVEYOU-UI")) {
					mdulename = "UI_ServeYou-UI";
				} else if (tagcollection.toString().toUpperCase().contains("@PHP-UI")) {
					mdulename = "UI_PHP-UI";
				} else if (tagcollection.toString().toUpperCase().contains("@BAZ-UI")) {
					mdulename = "UI_BAZ-UI";
				} else if (tagcollection.toString().toUpperCase().contains("@AARP-UI")) {
					mdulename = "UI_MNR-UI";
				} else if (tagcollection.toString().toUpperCase().contains("@PHS-UI")) {
					mdulename = "UI_PHS-UI";
				} else if (tagcollection.toString().toUpperCase().contains("@AHC-UI")) {
					mdulename = "UI_AHC-UI";
				} else if (tagcollection.toString().toUpperCase().contains("@WCP-UI")) {
					mdulename = "UI_WCP-UI";
				} else if (tagcollection.toString().toUpperCase().contains("@DIME-UI")) {
					mdulename = "UI_DIME-UI";
				} else if (tagcollection.toString().toUpperCase().contains("@MYOPTUM-UI")) {
					mdulename = "UI_MyOptum-UI";
				} else if (tagcollection.toString().toUpperCase().contains("@BRIOVARX-UI")) {
					mdulename = "UI_BriovaRx-UI";
				} else if (tagcollection.toString().toUpperCase().contains("@BANK-UI")) {
					mdulename = "UI_Bank-UI";
				} else if (tagcollection.toString().toUpperCase().contains("@TCC-UI")) {
					mdulename = "UI_TCC-UI";
				} else if (tagcollection.toString().toUpperCase().contains("@PAI-UI")) {
					mdulename = "UI_PAI-UI";
				}
				File testResultFile = new File(HTMLReport.testResultTextFile);
				FileWriter fw = new FileWriter(testResultFile, true);
				fw.write("\r\n" + mdulename + "," + status);
				fw.close();
			}

			scn.write(DataStorage.getCustomErrmsg());
			try {
				if (DataStorage.getPortalName() != null) {
					final byte[] screenshot = ((TakesScreenshot) DriverFactory.getDeviceDriver())
							.getScreenshotAs(OutputType.BYTES);
					scn.embed(screenshot, "image/png"); // ... and embed it in
				}
			} catch (InitializationException e ) {
				//no-op, ignore screenshotting for browserless tests.
			}

		} finally {
			// Reset DataStorage values for next test using this thread
			// and return any ResourcePool data
			DataStorage.resetAllDataStorage();
			DriverFactory.closeDeviceDriver();
		}
	}

}
