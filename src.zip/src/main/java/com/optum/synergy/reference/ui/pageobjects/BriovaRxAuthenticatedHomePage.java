package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class BriovaRxAuthenticatedHomePage extends PageObjectBase {
	
	@FindBy (how = How.XPATH, using = "//*[@id='userName']")
	private WebElement homePageContent;
	
	public boolean verifyIfHomePageContentIsDisplayed()	{
		return longWait.get().until(ExpectedConditions.visibilityOf(homePageContent)).isDisplayed();
	}

}
