package com.optum.synergy.reference.ui.pageobjects;

import java.security.SecureRandom;
import java.security.cert.X509Certificate;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.ws.rs.core.MediaType;

import com.optum.synergy.reference.ui.utility.DataStorage;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import org.junit.Assert;

public class SSOService {


    private Client createClient() {
        Client client = Client.create();

        TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
            public X509Certificate[] getAcceptedIssuers() {
                return null;
            }

            public void checkClientTrusted(X509Certificate[] certs, String authType) {
            }

            public void checkServerTrusted(X509Certificate[] certs, String authType) {
            }
        } };

        try {
            SSLContext sc = SSLContext.getInstance("TLSv1.2");
            sc.init(null, trustAllCerts, new SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (Exception e) {

        }
        return client;
    }

    public int getSSOServiceStatus(String portalName) {

        Client client = createClient();

        WebResource webResource = client.resource("https://hsid11-st1.optum.com");
        String path = "/protected/SSO/authenticate/";

        String actor = "actor";
        String scope = "read";
        String data = "";

        if(portalName.equalsIgnoreCase("OptumRx")) {
            data = "{\"firstName\":\""+ DataStorage.getFirstName() +
                    "\",\"lastName\":\""+DataStorage.getLastName()+
                    "\",\"dob\":\""+DataStorage.getDOB()+
                    "\",\"id\":\""+DataStorage.getSubscriberID()+
                    "\",\"idType\":\"MEMBERID\",\"zip\":\""+DataStorage.getZip()+
                    "\",\"targetPortal\":\"RX\"," +
                    "\"eligibility\":\"P\"," +
                    "\"email\":\"prashant_chaudhary@optum.com\"," +
                    "\"customer\":\"RALLY\"}";

        } else if (portalName.equalsIgnoreCase("LAWW")) {
            data = "{\"firstName\":\""+DataStorage.getFirstName()+
                    "\",\"lastName\":\""+DataStorage.getLastName()+
                    "\",\"dob\":\""+DataStorage.getDOB()+
                    "\",\"id\":\""+DataStorage.getSubscriberID()+
                    "\",\"idType\":\"MEMBERID\"," +
                    "\"targetPortal\":\"LAWW\"," +
                    "\"eligibility\":\"P\"," +
                    "\"email\":\"prashant_chaudhary@optum.com\"}";

        } else if(portalName.equalsIgnoreCase("GESSO")) {
            data = "{\"firstName\":\""+DataStorage.getFirstName()+
                    "\",\"lastName\":\""+DataStorage.getLastName()+
                    "\",\"id\":\""+DataStorage.getSSOID()+
                    "\",\"idType\":\"SSOID\"," +
                    "\"targetPortal\":\"GEHUB\"," +
                    "\"Customer\":\"GE\"," +
                    "\"email\":\"HeadlessCnv_GESSOID_MNRRegistration@mailinator.com/\"}";

        } else if(portalName.equalsIgnoreCase("MNR")) {
             data = "{\n" +
                    "    \"memberIdentifiers\": \n" +
                    "    {\n" +
                    "        \"firstName\": \""+DataStorage.getFirstName()+"\",\n" +
                    "        \"lastName\": \""+DataStorage.getLastName()+"\",\n" +
                    "        \"dob\": \""+new PageObjectBase().getDateInYYYY_MM_DDFormat(DataStorage.getDOB())+"\",\n" +
                    "        \"zipCode\": \""+DataStorage.getZip()+"\",\n" +
                    "        \"memberId\":\""+DataStorage.getSubscriberID()+"\",\n" +
                    "        \"email\":\"ABC@OPTUM.COM\"\n" +
                    "    }\n" +
                    "}";
            webResource = client.resource("https://process-engine-hsid-ms-stage-00.origin-elr-core.optum.com");
            path = "/mnr/headlesssso";

        } else if(portalName.equalsIgnoreCase("MyUHC")) {
            data = "{\n" +
                    "\"memberIdentifiers\":{\n" +
                    "\"firstName\":\""+DataStorage.getFirstName()+"\",\n" +
                    "\"lastName\":\""+DataStorage.getLastName()+"\",\n" +
                    "\"dob\":\""+new PageObjectBase().getDateInYYYY_MM_DDFormat(DataStorage.getDOB())+"\",\n" +
                    "\"memberId\":\""+DataStorage.getSubscriberID()+"\",\n" +
                    "\"policyNumber\":\""+DataStorage.getGroupNumber()+"\",\n" +
                    "\"email\":\"US3283439_vinee_hphdlscnvg@mailinator.com\"\n" +
                    "}\n" +
                    "}";
            webResource = client.resource("https://hsidms-stg.optum.com/process-engine");
            path = "/myuhc/headlesssso";

        }else if(portalName.equalsIgnoreCase("PHS")) {
            data = "{\n" +
                    "\"memberIdentifiers\":{\n" +
                    "\"firstName\":\""+DataStorage.getFirstName()+"\",\n" +
                    "\"lastName\":\""+DataStorage.getLastName()+"\",\n" +
                    "\"dob\":\""+new PageObjectBase().getDateInYYYY_MM_DDFormat(DataStorage.getDOB())+"\",\n" +
                    "\"memberId\":\""+DataStorage.getSubscriberID()+"\",\n" +
                    "\"policyNumber\":\""+DataStorage.getGroupNumber()+"\",\n" +
                    "\"email\":\"praveena.atturu@optum.com\"\n" +
                    "}\n" +
                    "}";
            webResource = client.resource("https://hsidms-stg.optum.com/process-engine");
            path = "/phs/headlesssso";

        } else {
            Assert.fail("["+portalName+"] is not listed for Headless ID creation. Please check the portal name or update the existing implementation");
        }

        ClientResponse response = webResource.path(path).accept(MediaType.APPLICATION_JSON)
                .type(MediaType.APPLICATION_JSON).header("scope", scope).header("actor", actor)
                .post(ClientResponse.class, data);

        return response.getStatus();

    }

}