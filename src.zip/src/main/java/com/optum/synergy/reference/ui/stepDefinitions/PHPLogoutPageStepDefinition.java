package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.PHPLogoutPage;

import cucumber.api.java.en.Then;

public class PHPLogoutPageStepDefinition {
	private PHPLogoutPage page;
	
	public PHPLogoutPageStepDefinition() {
		page= new PHPLogoutPage();
	}
	
	@Then("^I should be at PHP logout page$")
	public void iShouldBeAtPHPLogoutPage() {
		Assert.assertTrue(page.isPageDisplayed());
	}
	
	@Then("^I should see PHP logout form content \"([^\"]*)\"$")
	public void iShouldSeePHPLogoutFormContent(String content) {
	    Assert.assertTrue("\""+content+"\""+ " content is not diplaying on PHP logout page", page.getFormContent().contains(content));
	}
}
