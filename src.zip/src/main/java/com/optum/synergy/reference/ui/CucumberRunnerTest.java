package com.optum.synergy.reference.ui;


import java.io.File;

import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import com.optum.synergy.reference.ui.utility.HTMLReport;

import cucumber.api.junit.Cucumber;
import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;

@RunWith(Cucumber.class)
@CucumberOptions(
	    plugin = { "html:target/cucumber-html-report",
	            "json:target/testresult/cucumber.json", "pretty:target/cucumber-pretty.txt",
	             "junit:target/cucumber-results.xml" }, 
		features = { "src/main/resources/ui/features" },
		monochrome = true,
		tags ={"@MyTest"},
		snippets = SnippetType.CAMELCASE
)
public class CucumberRunnerTest {
	
	/**
	 * Define runtime properties for test execution
	 */
	@BeforeClass
	public static void setupProperties() {
		
		// Application's environment to execute against
		System.setProperty("ExecutionEnv", "Stage");
		// Set to 'saucelab' to run browser in SauceLabs, anything else to run local browser
		System.setProperty("BrowserEnv", "saucelab");
		
		// Define browser type to use.  
		// Supported local browsers are "ie" and "firefox" (default) 
		 
		/* Default FireFox install */
		System.setProperty("BrowserType", "Chrome");
		System.setProperty("BrowserVersion", "Latest");

		/* Firefox version older than 48
			System.setProperty("BrowserType", "firefox");
			System.setProperty("webdriver.firefox.bin", "C:/FireFox45/firefox.exe");
			System.setProperty("BrowserVersion", "45");
		 */
  
		//Clean up testResultsForReport.txt to keep it clean per local run
		File resultFile = new File(HTMLReport.testResultTextFile);
		resultFile.delete();
		
	}
}
