package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.ConfirmAccountInformationPage;
import com.optum.synergy.reference.ui.pageobjects.Hooks;

import cucumber.api.java.en.Then;

public class ConfirmAccountInformationPageStepDefinition {
	
	private ConfirmAccountInformationPage page;
	public ConfirmAccountInformationPageStepDefinition() {		
		page = new ConfirmAccountInformationPage();
	}

	@Then("^I should be at Confirm account information page$")
	public void i_should_be_at_Confirm_account_information_page() {
	   Assert.assertTrue("Issue while loading the Confirm account information page", page.verifyIfPageLoaded());
	}

	@Then("^I should see the Confirm account information form contains the email \"([^\"]*)\"$")
	public void i_should_see_the_Confirm_account_information_form_contains_the_email(String email) throws Throwable {
		Thread.sleep(2000);
		email=new Hooks().getNewEmailId();
		   Assert.assertTrue("\""+email+"\" mail is not displaying on the Confirm account information form", page.verifyFormContent(email));
	}
	
	@Then("^I should see the \"([^\"]*)\" label on Confirm account information screen$")
	public void I_should_see_the_label_on_Confirm_account_information(String label) {
		String lblText = "";
		if (label.toUpperCase().contains("EMAIL")){
			lblText = page.getLabelforEmail();
			
		} else if (label.toUpperCase().contains("CALL")){
			lblText = page.getLabelforCall();
		} else if (label.toUpperCase().contains("TEXT")){
			lblText = page.getLabelforSMS();
		} else {
			Assert.fail("Unknown label type [" + label
					+ "] for Confirm account information screen");
		}
		Assert.assertNotNull("Failed to find expected [" + label
				+ "], found null", lblText);
		Assert.assertTrue("Failed to find expected [" + label
				+ "], found [" + lblText
				+ "]", lblText.contains(label));
		
		   
	}
	
	@Then("^I should be at custom landing page having uhc logo$")
	public void i_should_be_at_custom_landing_page_having_uhc_logo() throws Throwable {
		 Assert.assertTrue("Issue while loading the Confirm account information page",page.getCustomConfirmEmailPage());
	}
	@Then("^I should see the message \"([^\"]*)\" on custom page of confirm account email Page$")
	public void i_should_see_the_message_on_custom_page_of_confirm_account_email_Page(String message) throws Throwable {
			Thread.sleep(1000);
		   Assert.assertTrue("\""+message+"\" message is not displaying on the Confirm account information page", page.getCustomPageMessage(message));
		}
	
	@Then("^I should be at custom landing page having optum logo$")
	public void i_should_be_at_custom_landing_page_having_optum_logo() {
		Assert.assertTrue("Issue while loading the Confirm account information page",page.getCustomConfirmEmailPageforOptum());
	}


    @Then("^I should see the pre-selected confirmation type as \"([^\"]*)\"$")
    public void iShouldSeeThePreSelectedConfirmationTypeAs(String confirmationType) {
		Assert.assertEquals("Confirmation type ["+page.getSelectedItem()+"] is pre-selected",confirmationType,page.getSelectedItem());
    }
}

