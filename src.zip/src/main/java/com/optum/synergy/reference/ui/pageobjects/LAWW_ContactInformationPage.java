package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LAWW_ContactInformationPage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'subnav content')]")
	private WebElement frameContent;
	
	@FindBy(how = How.CSS, using = "iframe[title='Contact']")
	private WebElement iframe;
	
	@FindBy(how = How.XPATH, using = "//a[@id='emailview']")
	private WebElement emailBox;
	
	public void switchToContentFrame() {
		driver.switchTo().frame(mediumWait.get().until(ExpectedConditions.visibilityOf(iframe)));
	}

	public String getContactInformation() {
		return longWait.get().until(ExpectedConditions.visibilityOf(frameContent)).getText().trim();
	}
	
	public WebElement getEmailBox()	{
		return longWait.get().until(ExpectedConditions.visibilityOf(emailBox));
	}
}
