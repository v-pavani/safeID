package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LAWWAdminPortalAuthenticatedHomePage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//button[text()='Member Account Search']")
	private WebElement searchForAUserLink;
	
	@FindBy(how = How.XPATH, using = "//button[text()='Delete a Member Account']")
	private WebElement deleteAUserIDLink;
	
	@FindBy(how = How.XPATH, using = "//*[@class='sidebar-heading']")
	private WebElement portalOptionsHeading;
	
	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(portalOptionsHeading)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public void clickSearchForAUserLink() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(searchForAUserLink));
		searchForAUserLink.click();
	}
	
	public void clickDeleteAUserIDLink() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(deleteAUserIDLink));
		deleteAUserIDLink.click();
	}
}
