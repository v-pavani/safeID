package com.optum.synergy.reference.ui.stepDefinitions;

import java.util.List;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.BSCAUnauthenticatedHomePage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class BSCAUnauthenticatedHomePageStepDefinition {

	private BSCAUnauthenticatedHomePage page;

	public BSCAUnauthenticatedHomePageStepDefinition() {
		page = new BSCAUnauthenticatedHomePage();
	}

	@Given("^I am at BSCA unauthenticated home page$")
	public void iAmAtBSCAUnauthenticatedHomePage() {
		page.openBSCAHomePage();
		Assert.assertTrue("Issue while loading the BSCA unauthenticated page", page.verifyIfPageLoaded());
	}

	@Then("^I should be at BSCA unauthenticated home page$")
	public void iAmAtBSCAUnauthenticatedSignInPage() {
		Assert.assertTrue("Issue while loading the BSCA unauthenticated page", page.verifyIfPageLoaded());
	}
	
	@Then("^I should be at BSCA legacy unauthenticated page$")
	public void iAmAtBSCALegcyUnauthenticatedPage() {
		Assert.assertTrue("Issue while loading the BSCA legacy unauthenticated page", page.verifyIfBscaLegacyPageLoaded());
	}

	@Then("^I should see the following content in Sign In Widget$")
	public void iShouldSeeTheFollowingContentInSignInWidget(List<String> contentList) {
		for (String content : contentList) {
			content = content.trim();
			Assert.assertTrue("\"" + content + "\" content is not displaying in the Unauthenticated Page",
					page.getSignInWidgetContent().contains(content));
		}
	}
		
	}

