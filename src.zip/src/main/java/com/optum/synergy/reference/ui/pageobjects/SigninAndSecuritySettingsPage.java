package com.optum.synergy.reference.ui.pageobjects;


import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.optum.synergy.reference.ui.utility.DataStorage;
import com.optum.synergy.reference.ui.utility.DriverFactory;
import com.optum.synergy.reference.ui.utility.ReadXMLData;

public class SigninAndSecuritySettingsPage extends PageObjectBase {
	
	@FindBy(how=How.XPATH, using ="//h1[text()='Sign in and security settings']|//span[text()='Sign in & security settings']")
	private WebElement signInSecurityHeader;
	
	@FindBy(how=How.XPATH, using ="//span[text()='Username']/../following-sibling::flex-content/p|//*[@class='SettingsGroupItem_value__12vsb']/p")
	private WebElement userName;
	
	@FindBy(how=How.XPATH, using ="//*[contains(@ng-if,'passwordView')]//span[text()='Edit']|//button[@id='password_id']")
	private WebElement lnkEditPwd;
	
	@FindBy(how=How.ID, using ="currentPassword")
	private WebElement txtcurrentPassword;
	
	@FindBy(how=How.ID, using ="password")
	private WebElement txtNewPassword;
	
	@FindBy(how=How.ID, using ="confirmPassword")
	private WebElement txtCnfrmNewPassword;
	
	@FindBy(how=How.XPATH, using ="//p[@ng-show='!passwordLoading']/a[text()='Cancel']|//button[@class='rds-tertiary-button is-rds-fullwidth']")
	private WebElement btnCancelPwd;
	
	@FindBy(how=How.XPATH, using ="//p[@ng-show='!passwordLoading']/button[text()='Save']")
	private WebElement btnSavePwd;
	
	@FindBy(how=How.XPATH, using ="//*[@ng-bind-html='currentPasswordError']")
	private WebElement errMsgCurrentPwd;
	
	@FindBy(how=How.XPATH, using ="//*[@ng-bind-html='newPasswordError']")
	private WebElement errMsgNewPwd;
	
	@FindBy(how=How.XPATH, using ="//*[@ng-bind-html='confirmPasswordError']")
	private WebElement errMsgConfrmNewPwd;
	
	@FindBy(how=How.XPATH, using ="//flex-content[contains(.,'Recovery email')]/following-sibling::flex-content/div/p|//flex-content[contains(.,'Email')]/following-sibling::flex-content/div/p|//*[@id='email_view']//p|(//*[@class='SettingsGroupItem_value__12vsb'])[3]/p")
	private WebElement emailId;
	
	@FindBy(how=How.XPATH, using ="//div[contains(@ng-if,'isEmailVerified')]/span[contains(@class,'error')]")
	private WebElement emailUnconfirmedIcon;
	
	@FindBy(how=How.XPATH, using ="//*[contains(@ng-if,'emailView')]//span[text()='Edit']|//*[contains(@ng-if,'emailView')]//a[contains(.,'Edit')]|//button[@id='emailaddress_id']")
	private WebElement lnkEditEmailRecovery;
	
	@FindBy(how=How.XPATH, using="//label[@for='newEmail']/span[contains(@class,'strong')]|//label[@for='updateEmailInput'][contains(text(),'Email Address')]")
	private WebElement newEmailLabel;
	
	@FindBy(how=How.XPATH, using ="//*[@id='newEmail']|//*[@id='step3ConfirmEditedEmail']|//*[@id='updateEmailInput']")
	private WebElement txtNewEmail;

	@FindBy(how=How.XPATH, using="//form[@name='EditEmailForm']/p[@class='ng-binding']|//div[@ng-if='!$parent.isEmailVerified && (!checkF1() || checkU2())']|//span[contains(text(),'To keep your account safe')]")
	private WebElement editEmailFormMessage;
	
	@FindBy(how=How.XPATH, using ="//p[@ng-show='!emailLoading']/a[text()='Cancel']")
	private WebElement btnCancelEmailUpdate;

	@FindBy(how=How.XPATH, using ="//p[@ng-show='!emailLoading']/button[text()='Save']|//button[@id='submitBtn']")
	private WebElement btnSaveEmailUpdate;
	
	@FindBy(how=How.XPATH, using="//div[contains(@ng-show,'emailErrorX')]|//div[starts-with(@ng-if,'emailError')]")
	private WebElement errMsgHeaderForEmail;
	
	@FindBy(how=How.XPATH, using ="//span[@class='error']/span[@ng-bind-html='emailErrorX']")
	private WebElement errMsgForEmail;
	
	@FindBy(how=How.XPATH, using ="//*[contains(@ng-if,'recoveryView')]//span[text()='Edit']|//button[@id='accountverification_id']")
	private WebElement lnkEditAccountRecovery;

	@FindBy(how=How.XPATH, using ="//select[@id='verificationType_input']|//select[@id='secOption']")
	private WebElement slctSecurityOption;
	
	@FindBy(how=How.ID, using ="q0")
	private WebElement slctSecurityQuestionOne;
	
	@FindBy(how=How.ID, using ="q1")
	private WebElement slctSecurityQuestionTwo;
	
	@FindBy(how=How.ID, using ="q2")
	private WebElement slctSecurityQuestionThree;
	
	@FindBy(how=How.ID, using ="a0")
	private WebElement txtAnswerOne;
	
	@FindBy(how=How.ID, using ="a1")
	private WebElement txtAnswerTwo;
	
	@FindBy(how=How.ID, using ="a2")
	private WebElement txtAnswerThree;

	@FindBy(how=How.XPATH, using ="//span[@ng-bind-html='answerErrors[0]']|//span[@ng-bind-html='answer0Error']")  
	private WebElement errMsgForAnswerOne;

	@FindBy(how=How.XPATH, using ="//span[@ng-bind-html='answerErrors[1]']|//span[@ng-bind-html='answer1Error']")
	private WebElement errMsgForAnswerTwo;

	@FindBy(how=How.XPATH, using ="//span[@ng-bind-html='answerErrors[2]']|//span[@ng-bind-html='answer2Error']")
	private WebElement errMsgForAnswerThree;
	
	@FindBy(how=How.XPATH, using ="//a[contains(@ng-if,'recoveryTopError')]|//span[contains(@ng-if,'recoveryTopError')]")
	private WebElement topErrMsgForSecurityAnswer;
	
	@FindBy(how=How.XPATH, using ="//div[contains(@ng-show,'questions') and @aria-hidden='false']//a[text()='Cancel']")
	private WebElement btnCancelSecurityAnswer;
	
	@FindBy(how=How.XPATH, using ="//div[contains(@ng-show,'questions') and @aria-hidden='false']//button[text()='Save']|//div[@aria-live='polite']//button[text()='Save']")
	private WebElement btnSaveSecurityAnswer;
	
	@FindBy(how=How.XPATH, using ="//div[contains(@ng-show,'phone') and @aria-hidden='false']//a[text()='Cancel']")
	private WebElement btnCancelPhoneNumberUpdate;
	
	@FindBy(how=How.XPATH, using ="//div[contains(@ng-show,'phone') and @aria-hidden='false']//button[text()='Save']")
	private WebElement btnSavePhoneNumberUpdate;
	
	@FindBy(how=How.ID, using ="phoneNo")
	private WebElement phoneNumber;
	
	@FindBy(how=How.ID, using ="phoneType")
	private WebElement slctPhoneType;
	
	@FindBy(how=How.XPATH, using ="//p[@ng-bind-html='phoneNumberError']")
	private WebElement errMsgForPhoneNumber;
	
	@FindBy(how=How.XPATH, using ="//p[@ng-bind-html='phoneTypeError']")
	private WebElement errMsgForPhoneType;
	
	@FindBy(how=How.XPATH, using ="//h1[text()='Texting Terms and Conditions']/../p[2]")
	private WebElement modelViewTextingTermsConditions;
	
	@FindBy(how=How.XPATH, using ="//h1[text()='Consumer Communications Notice']/../p[3]")
	private WebElement modelViewConsumerCommunicationsNotice;

	@FindBy(how=How.XPATH, using ="//*[local-name()='svg' and contains(@class,'CloseButton')]")
	private WebElement btnCloseModelDialog;

	@FindBy(how=How.XPATH, using ="//div[@ng-if='$parent.isSecureQuestionsUpdated']/span[2]|//span[@class='is-rds-body-3 Banner_text__1OLev']")
	private WebElement successMessageSignInSecurityPage;
			
	@FindBy(how=How.XPATH, using ="//label[@for='currentPassword']/div[@class='password-field-container']/input[@id='currentPassword'][@type='password']|//input[@id='updatecurrentPasswordInput']")
	private WebElement currentPasswordTextboxWithLabel;
	
	@FindBy(how=How.XPATH, using ="//label[@for='password']/div[@class='tooltip']/div[@class='password-field-container']/input[@id='password'][@type='password']|//input[@id='updatenewPasswordInput']")
	private WebElement newPasswordTextboxWithLabel;
	
	@FindBy(how=How.XPATH, using ="//label[@for='confirmPassword']/div[@class='password-field-container']/input[@id='confirmPassword'][@name='newPassword'][@type='password']")
	private WebElement reEnterNewPasswordTextboxWithLabel;

	@FindBy(how=How.XPATH, using ="//div[contains(@ng-if,'passwordView')]/p[contains(text(),'**********')]|//div[contains(@class,'SettingsGroupItem_value__12vsb')]/p[contains(text(),'••••••••')]")
	private WebElement passwordUpdateSectionInDisplayMode;
	
	public boolean verifyCurrentPasswordLabelwithTextBox() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(currentPasswordTextboxWithLabel));
		return currentPasswordTextboxWithLabel.isDisplayed();
	}	
	
	public boolean verifyNewtPasswordLabelwithTextBox() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(newPasswordTextboxWithLabel));
		return newPasswordTextboxWithLabel.isDisplayed();
	}
	
	public boolean verifyreEnterNewPasswordLabelwithTextBox() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(reEnterNewPasswordTextboxWithLabel));
		return reEnterNewPasswordTextboxWithLabel.isDisplayed();
	}
	
	public boolean verifyIfEditLinkIsDisplayedForPassword() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(lnkEditPwd));
		return lnkEditPwd.isDisplayed();
	}
	
	public boolean verifyIfEditLinkIsDisplayedForEmail() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(lnkEditEmailRecovery));
		return lnkEditEmailRecovery.isDisplayed();
	}
	
	public boolean verifyIfEditLinkIsDisplayedForAcntRecovery() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(lnkEditAccountRecovery));
		return lnkEditAccountRecovery.isDisplayed();
	}

	public boolean verifyIfPasswordUpdateSectionIsInDisplayMode() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(lnkEditPwd));
		mediumWait.get().until(ExpectedConditions.visibilityOf(passwordUpdateSectionInDisplayMode));
		return (passwordUpdateSectionInDisplayMode.isDisplayed() &&  lnkEditPwd.isDisplayed());
	}
		
	public void clickOnTheNewPasswordField() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(newPasswordTextboxWithLabel)).clear();
		newPasswordTextboxWithLabel.click();
	}
	
	public int returnNumberOfRulesMarkedAsGreenForNewPassword() {
		List<WebElement> elems = mediumWait.get()
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//div[@class='tooltip-content ruletip']//span[@class='icon-checkmark_filled ng-scope']")));
		return elems.size();
	}
	
	public String returnPasswordRulesMarkedAsGreen() {
		String rulesContent = "";
		List<WebElement> elems = mediumWait.get()
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//div[@class='tooltip-content ruletip']//span[@class='icon-checkmark_filled ng-scope']/parent::p")));
		for (WebElement element : elems) {
			rulesContent = rulesContent+element.getText();				
		}
		return rulesContent;
	}
	
	public WebElement getGradientBarElement(String rgbColor1, String rgbColor2) {
		return mediumWait.get()
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='global-nav-header-component']/div[@class='gradientBorder' and contains(@style,'"+rgbColor1+", "+rgbColor2+"')]")));
	}

	public void openSignInAndSecurityPage() {
		String signInSecurityURL = null;
		signInSecurityURL = ReadXMLData.getTestData(DataStorage.getPortalName(), DataStorage.getSubPortalName()+"SignInAndSecurityURL");

		if(signInSecurityURL != null) {
		driver.get(signInSecurityURL);
		DataStorage.setCustomErrmsg("SIGN IN AND SECURITY DIRECT URL: ["+signInSecurityURL+"]");
		}
		else Assert.fail(DataStorage.getSubPortalName()+" SignInAndSecurityURL is null");
	}
	
	public boolean verifyIfPageLoaded(){
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(signInSecurityHeader)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}

	public String getdisplayedusername() {		
		return mediumWait.get().until(ExpectedConditions.visibilityOf(userName)).getText();
	}

	public void clickOnEditPassword() {
		longWait.get().until(ExpectedConditions.elementToBeClickable(lnkEditPwd)).click();
	}

	public void enterCurrentPwd(String pwd) {
         mediumWait.get().until(ExpectedConditions.visibilityOf(txtcurrentPassword)).clear();
         txtcurrentPassword.sendKeys(pwd);
	}

	public void enterNewPwd(String newpwd) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(txtNewPassword)).clear();
		txtNewPassword.sendKeys(newpwd);
	}

	public void enterConfirmNewPwd(String cnfrmNewPwd) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(txtCnfrmNewPassword)).clear();
		txtCnfrmNewPassword.sendKeys(cnfrmNewPwd);
	}

	public void clickonSaveButtontoSavepwd() {
		scrollElementIntoView(mediumWait.get().until(ExpectedConditions.visibilityOf(btnSavePwd)));
		btnSavePwd.click();
		mediumWait.get().until(ExpectedConditions.invisibilityOfElementLocated(By.className("spinner")));
	}

	public void clickonCancelButtonForPWd() {
		clickByJavaScript(btnCancelPwd);
	}
	
	public String getErrorMsgForConfirmPwd() {
		try {
			return smallWait.get().until(ExpectedConditions.visibilityOf(errMsgConfrmNewPwd)).getText();
		}catch(Exception e){
			
		}
		return null;
	} 
	
	public String getErrorMsgForNewPwd() {
		try {
			return smallWait.get().until(ExpectedConditions.visibilityOf(errMsgNewPwd)).getText();
		}catch(Exception e){
			
		}
		return null;
	}
	
	public String getErrorMsgForCurrentPwd() {
		try {
			return smallWait.get().until(ExpectedConditions.visibilityOf(errMsgCurrentPwd)).getText();
		}catch(Exception e){
			
		}
		return null;
	}

	public void clickonEditRecoveryEmail() {
		longWait.get().until(ExpectedConditions.elementToBeClickable(lnkEditEmailRecovery));  
		((JavascriptExecutor) DriverFactory.getDeviceDriver()).executeScript("arguments[0].click();", lnkEditEmailRecovery);
	}
	
	public boolean VerifyEditRecoveryEmailLink() {
		return mediumWait.get().until(ExpectedConditions.elementToBeClickable(lnkEditEmailRecovery)).isDisplayed();
	}
	
	public void enterNewEmail(String emailid) {
		 smallWait.get().until(ExpectedConditions.visibilityOf(txtNewEmail)).clear();
		 txtNewEmail.sendKeys(emailid);
	}
	
	public boolean verifyNewEmail(){
		 return mediumWait.get().until(ExpectedConditions.visibilityOf(txtNewEmail)).isDisplayed();
	}
	
	public void clickOnSaveBtnForEmailRecovery(){
		mediumWait.get().until(ExpectedConditions.visibilityOf(btnSaveEmailUpdate));
		scrollElementIntoView(btnSaveEmailUpdate);
		btnSaveEmailUpdate.click();
	}
	
    public void clickOnCancelBtnForEmailRecovery(){
    	clickByJavaScript(btnCancelEmailUpdate);
	}
	
    public String getErrorMsgHeaderForEmail() {
		try {
			return smallWait.get().until(ExpectedConditions.visibilityOf(errMsgHeaderForEmail)).getText();
		} catch (Exception e) {
			DataStorage.setCustomErrmsg("Error reading errMsgHeaderForEmail [" + e.toString() + "]");
		}
		return null;
	}
    
	public String getErrorMsgForEmail() {
		try {
			return smallWait.get().until(ExpectedConditions.visibilityOf(errMsgForEmail)).getText();
		} catch (Exception e) {
			DataStorage.setCustomErrmsg("Error reading errMsgForEmail [" + e.toString() + "]");
		}
		return null;
	}
	
	public String getEmailIdContent() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(emailId)).getText();
	}
	
	public boolean verifyEmailUnconfirmedIconDisplayed(){
		return mediumWait.get().until(ExpectedConditions.visibilityOf(emailUnconfirmedIcon)).isDisplayed();
	}
	
	public String getNewEmailLabel(){
		return mediumWait.get().until(ExpectedConditions.visibilityOf(newEmailLabel)).getText();
	}

	public String getEditEmailFormMessage() {
		try {
			String textContent = mediumWait.get().until(ExpectedConditions.visibilityOf(editEmailFormMessage)).getText().trim().replaceAll(String.valueOf((char) 160), " ");
			return textContent;
		} catch (StaleElementReferenceException e) {
			String textContent = mediumWait.get().until(ExpectedConditions.visibilityOf(editEmailFormMessage)).getText().trim().replaceAll(String.valueOf((char) 160), " ");
			return textContent;
		}
	}

	public void clickonEditAccountRecoverylink() {
		WebElement elm=longWait.get().until(ExpectedConditions.visibilityOf(lnkEditAccountRecovery));		
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", elm);
	}
	
	public void selectAccountRecoveryOption(String option){
		longWait.get().until(ExpectedConditions.visibilityOf(slctSecurityOption));
		Select dropdown = new Select(slctSecurityOption);
		dropdown.selectByVisibleText(option);
	}
	
	public void selectSecurityQuestionOne(String question){
		mediumWait.get().until(ExpectedConditions.textToBePresentInElement(slctSecurityQuestionOne, question));
		Select dropdown = new Select(slctSecurityQuestionOne);
		dropdown.selectByVisibleText(question);
	}

	public void selectSecurityQuestionTwo(String question) {
		mediumWait.get().until(ExpectedConditions.textToBePresentInElement(slctSecurityQuestionTwo, question));
		Select dropdown = new Select(slctSecurityQuestionTwo);
		dropdown.selectByVisibleText(question);
	}

	public void selectSecurityQuestionThree(String question) {
		mediumWait.get().until(ExpectedConditions.textToBePresentInElement(slctSecurityQuestionThree, question));
		Select dropdown = new Select(slctSecurityQuestionThree);
		dropdown.selectByVisibleText(question);
	}
	
	public void enterAnswerOne(String ans){
		smallWait.get().until(ExpectedConditions.visibilityOf(txtAnswerOne)).clear();
		txtAnswerOne.sendKeys(ans);
		clickTab();
	}

	public void enterAnswerTwo(String ans) {
		smallWait.get().until(ExpectedConditions.visibilityOf(txtAnswerTwo)).clear();
		txtAnswerTwo.sendKeys(ans);
		clickTab();
	}

	public void enterAnswerThree(String ans) {
		smallWait.get().until(ExpectedConditions.visibilityOf(txtAnswerThree)).clear();
		txtAnswerThree.sendKeys(ans);
		clickTab();
	}
	
	public String getTopErrorForAccountRecoveryThroughSecurityQuestion(){
		try {
			return smallWait.get().until(ExpectedConditions.visibilityOf(topErrMsgForSecurityAnswer)).getText();
		} catch (Exception e) {}
		return null;
	}
	
	public String getErrMsgForAnswerOne() {
		try {
			scrollElementIntoView(txtAnswerOne);
			return smallWait.get().until(ExpectedConditions.visibilityOf(errMsgForAnswerOne)).getText();
		} catch (Exception e) {}
		return null;
	}

	public String getErrMsgForAnswerTwo() {
		try {
			scrollElementIntoView(txtAnswerTwo);
			return smallWait.get().until(ExpectedConditions.visibilityOf(errMsgForAnswerTwo)).getText();
		} catch (Exception e) {}
		return null;
	}

	public String getErrMsgForAnswerThree() {
		try {
			scrollElementIntoView(txtAnswerThree);
			return smallWait.get().until(ExpectedConditions.visibilityOf(errMsgForAnswerThree)).getText();
		} catch (Exception e) {}
		return null;
	}
	
	public void clickOnSaveButtonAnswerUpdate(){
		scrollElementIntoView(smallWait.get().until(ExpectedConditions.visibilityOf(btnSaveSecurityAnswer)));
		try { Thread.sleep(250); } catch (Exception e ) {}
		btnSaveSecurityAnswer.click();
		mediumWait.get().until(ExpectedConditions.invisibilityOfElementLocated(By.className("spinner")));
	}
	
	public void clickOnCancelButtonAnswerUpdate(){
		try { Thread.sleep(250); } catch (Exception e ) {}
		clickByJavaScript(btnCancelSecurityAnswer);
	}
	
	public void enterPhoneNumber(String number) {
		smallWait.get().until(ExpectedConditions.visibilityOf(phoneNumber)).clear();
		phoneNumber.sendKeys(number);
	}

	public void selectPhoneType(String phonetype) {
		mediumWait.get().until(ExpectedConditions.textToBePresentInElement(slctPhoneType, phonetype));
		Select dropdown = new Select(slctPhoneType);
		dropdown.selectByVisibleText(phonetype);
	}

	public String getErrMsgForPhoneNumber() {
		try {
			return smallWait.get().until(ExpectedConditions.visibilityOf(errMsgForPhoneNumber)).getText();
		} catch (Exception e) {
		}
		return null;
	}

	public String getErrMsgForPhoneType() {
		try {
			return smallWait.get().until(ExpectedConditions.visibilityOf(errMsgForPhoneType)).getText();
		} catch (Exception e) {
		}
		return null;
	}
	
	public void clickOnSaveButtonPhoneNumber(){
		scrollElementIntoView(smallWait.get().until(ExpectedConditions.visibilityOf(btnSavePhoneNumberUpdate)));
		btnSavePhoneNumberUpdate.click();
		mediumWait.get().until(ExpectedConditions.invisibilityOfElementLocated(By.className("spinner")));
	}
	
	public void clickOnCancelButtonPhoneNumber(){
		smallWait.get().until(ExpectedConditions.visibilityOf(btnCancelPhoneNumberUpdate)).click();
	}
	
	public String getContentForConsumerCommunicationNotice(){
		return smallWait.get().until(ExpectedConditions.visibilityOf(modelViewConsumerCommunicationsNotice)).getText().trim();
	}
	
	public String getContentForTextingTermsConditions(){
		return smallWait.get().until(ExpectedConditions.visibilityOf(modelViewTextingTermsConditions)).getText().trim();
	}
	
	public boolean verifytextOnSigninndSecurityPage(String message) {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//*[contains(@class,'form__step3')]/h2[contains(.,'"+message+"')]|//div[@class='ng-scope']//p[contains(.,'"+message + "')]|//div[@class='form__step3']//h2[contains(.,'"+message + "')]|//span[contains(.,'"+message + "')]|//button[contains(.,'"+message + "')]|//h4[@class='font-weight--regular ng-scope']/strong[contains(.,'"+message + "')]|//*[contains(@class,'zeta')]/p[contains(.,'"+message+"')]|//*[contains(@ng-bind-html,'HowConfirmIdentity') and contains(text(),'"+message+"')]"))).isDisplayed();
	}
	
	public String getsuccessMessageFromSignInSecurityPage(){
		return smallWait.get().until(ExpectedConditions.visibilityOf(successMessageSignInSecurityPage)).getText().trim();
	}
	public void clickOnCloseButton(){
		Actions action = new Actions(driver);
		WebElement webElement = mediumWait.get().until(ExpectedConditions.visibilityOf(btnCloseModelDialog));

		action.moveToElement(webElement)
				.click()
				.build()
				.perform();
	}
}
