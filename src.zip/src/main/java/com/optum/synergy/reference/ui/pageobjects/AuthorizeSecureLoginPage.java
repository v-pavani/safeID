package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class AuthorizeSecureLoginPage extends PageObjectBase{
	
	@FindBy(how = How.XPATH, using = "//*[contains(@id,'authOobEmailSubmit') and @value='alternate']")
	private WebElement alternateEmailButton;
	
	@FindBy(how = How.XPATH, using = "//*[contains(@id,'authOobEmailSubmit') and @value='primary']/parent::div/following-sibling::div")
	private WebElement primaryEmailLabel;
	
	@FindBy(how = How.XPATH, using = "//*[contains(@id,'authOobEmailSubmit') and @value='alternate']/parent::div/following-sibling::div")
	private WebElement alternateEmailLabel;

	@FindBy(how = How.ID, using = "verifyAuthPasscodeInput")
	private WebElement secureCodeInput;
	
	@FindBy(how = How.ID, using = "verifyAuthSubmitButton")
	private WebElement authSubmitButton;
	
	@FindBy(how = How.NAME, using = "personalInfo")
	private WebElement personalInfoSection;
	
	@FindBy(how = How.CSS, using = ".strong.ng-binding")
	private WebElement labelMain;
	
	@FindBy(how = How.ID, using = "aaWebIframe")
	private WebElement authorizeSecureLoginFrame;
	
	private String secureLoginframeID = "aaWebIframe";
	
	public void clickAlternateEmailButton(){
		mediumWait.get().until(ExpectedConditions.visibilityOf(alternateEmailButton)).click();
	}
	
	public boolean verifyAuthorizeSecurityPageLoaded() throws InterruptedException{
		try{
		Thread.sleep(30000);
		return smallWait.get().until(ExpectedConditions.visibilityOf(authorizeSecureLoginFrame)).isDisplayed();
		}
		catch(TimeoutException e) {
			return false;
		}
	}
	
	public void enterSecureCodeInput(String secureCode){
		mediumWait.get().until(ExpectedConditions.visibilityOf(secureCodeInput)).sendKeys(secureCode);
	}
	
	public void clickAuthSubmitButton(){
		mediumWait.get().until(ExpectedConditions.visibilityOf(authSubmitButton)).click();
	}
	
	public String getSecureLoginFrameID(){
		return secureLoginframeID;
	}
}

