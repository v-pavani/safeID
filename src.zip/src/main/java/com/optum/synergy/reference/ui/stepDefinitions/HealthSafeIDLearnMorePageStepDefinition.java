package com.optum.synergy.reference.ui.stepDefinitions;

import java.util.List;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.HealthSafeIDLearnMorePage;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HealthSafeIDLearnMorePageStepDefinition {
	private HealthSafeIDLearnMorePage page;
	public HealthSafeIDLearnMorePageStepDefinition() {
		page = new HealthSafeIDLearnMorePage();
	}

	@Then("^I should be at HealthSafe ID learn more page$")
	public void i_should_be_at_HealthSafe_ID_learn_more_page() {
		Assert.assertTrue("Issue while loading learn more about HealthSafe ID page",page.verifyIfPageLoaded());
	}
	
	@When("^I should see following content in learnmore page$")
	public void iShouldSeeTheFollowingContentsinLearMorePage(List<String> contentList) {
		String actualPageContentAndHeader = page.getLearnmoreModalHeader().getText() + page.getLearnmoreFormContent().getText();
		for (String content : contentList) {
			content = content.trim();
			Assert.assertTrue("Content not found\nExpected Content: "+content+"\nActual Content: "+actualPageContentAndHeader,
					actualPageContentAndHeader.contains(content));
		}
	}
	
	@When("^I should see following content in learnmore modal window$")
	public void iShouldSeeTheFollowingContentsinLearMoreModalWindow(List<String> contentList) {
		String actualPageContentAndHeader = page.getLearnmoreModalHeader().getText() + page.getLearnmoreModalContent().getText();
		for (String content : contentList) {
			content = content.trim();
			Assert.assertTrue("Content not found\nExpected Content: "+content+"\nActual Content: "+actualPageContentAndHeader,
					actualPageContentAndHeader.contains(content));
		}

	}
	
}


