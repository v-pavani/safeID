package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class MyUHCAuthenticatedHomePage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//*[@id='homeprintContent'] | //*[@id='dashboard' or @id = 'covid-dashboard'] | //*[@id='subchannellist']")
	private WebElement homePageContent;
    
    @FindBy(how = How.LINK_TEXT, using = "Update Later")
    private WebElement updateLaterButton;
    
    @FindBy(how = How.XPATH, using = "//*[@class='cross-button']")
    private WebElement xmarkinVideoPrompt;
    
    @FindBy(how = How.XPATH, using = "//h1[contains(text(),'You Have More Than One plan')]")
    private WebElement multiPlanHeader;
    
    @FindBy(how = How.XPATH, using = "//h2[contains(text(),'Looks like you have more than one plan')]")  
    private WebElement multiPlanHeaderNew;  
    
    @FindBy(how = How.ID, using ="planId0")
    private WebElement plan1RadioButton;
    
    @FindBy(how = How.XPATH, using = "//*[@id='planvalId:0']")
    private WebElement planLink;
    
    @FindBy(how = How.ID, using = "continuebutton")
    private WebElement continueButton;
    
    @FindBy(how = How.XPATH, using = "//*[contains(text(),'Dental Explanation of Benefits')]")
    private WebElement dentalEOBForm;
	
	public String getMyUHCAuthenticatedPageTitle() {
		return getPageTitle();
	}
	
	public boolean verifyIfHomePageContentIsDisplayed()	{
		waitForPageLoad(driver);
		return longWait.get().until(ExpectedConditions.visibilityOf(homePageContent)).isDisplayed();
	}
	
	public boolean verifyUpdateLaterButtonDisplayed(){
		waitForPageLoad(driver);
		boolean visible = false;
		try {
			visible = smallWait.get().until(ExpectedConditions.visibilityOf(updateLaterButton)).isDisplayed();
		} catch (Exception e) {}
		return visible;
	}
	
	public boolean verifyCrossButtoninVideoPromptDisplayed(){
		waitForJavascriptToLoad(30000, 500);
		waitForPageLoad(driver);
		
		boolean visible = false;
		try {
			visible = mediumWait.get().until(ExpectedConditions.visibilityOf(xmarkinVideoPrompt)).isDisplayed();
		} catch (Exception e) {}
		return visible;	
	}
	
	public void clickUpdateLaterButton() {
		smallWait.get().until(ExpectedConditions.visibilityOf(updateLaterButton)).click();
	}
	
	public void clickCrossButtoninVideoPrompt(){
		smallWait.get().until(ExpectedConditions.visibilityOf(xmarkinVideoPrompt)).click();
	}

	public boolean verifyMyUHCPlanSelectionPageLoaded() {
		try {
		return longWait.get().until(ExpectedConditions.visibilityOf(multiPlanHeader)).isDisplayed();
		}
		catch(Exception e){
			return false;
		}
	}
	
	public boolean verifyMyUHCPlanSelectionNewPageLoaded() {  
	 		try {  
	 		return mediumWait.get().until(ExpectedConditions.visibilityOf(multiPlanHeaderNew)).isDisplayed();  
	   		}  
	   		catch(Exception e){  
		return false;  
	   		}
	}
	
	public void SelectFirstMyUHCPlan() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(plan1RadioButton)).click();
	}
	
	public void SelectFirstMyUHCPlanNew() {
		longWait.get().until(ExpectedConditions.visibilityOf(planLink)).click();
	}

	public void clickContinueButton() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(continueButton)).click();
	}

	public void signOut() {
		// Sign out procedure varies depending on version of dashboard.  Verify 
		// using @id attribute of homePageContent
		
		String idAttribute = homePageContent.getAttribute("id");
		if ( "homeprintContent".equals(idAttribute ) ) {
			// Old dashboard, logout with "Sign Out" link
			clickPartialLink("Sign Out");
		} else if ( "dashboard".equals(idAttribute ) ) {
			// New dashboard, logout with "Account/Profile" dropdown then "Logout" link
			clickButtonByText("Account / Profile");
			clickPartialLink("Logout");
		} else {
			throw new AssertionError("Unknown dashboard identifier [" + idAttribute + "]");
		}
		
		waitForJavascriptToLoad(15000, 500);
		
	}
	
	public boolean verifyIfDentalEOBFormIsDisplayed() {
		try{
			return mediumWait.get().until(ExpectedConditions.visibilityOf(dentalEOBForm)).isDisplayed();
		}catch(Exception e){
			return false;
		}
	}

}
