package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.optum.synergy.reference.ui.utility.ReadXMLData;

public class LAWWUnauthenticatedHomePage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//a[@id='gnav-signin-Sign_In']|//a[contains(@class,'signin')]|//div[@class='accessCodeLogin section']")
	private WebElement signInLink;

	public void openPage() {
		String page_url= ReadXMLData.getTestData("LAWW", "AppURL");
		openPage(page_url);
		
		// LAWW page has an odd triggered refresh that occasionally causes StaleElementException
		// Haven't found any solution besides a hard sleep
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {		}
		
	}

	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			waitForJavascriptToLoad(30000, 3000);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(signInLink)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
		
	}
	
}
