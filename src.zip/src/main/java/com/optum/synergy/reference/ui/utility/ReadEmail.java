package com.optum.synergy.reference.ui.utility;

import java.io.IOException;
import java.util.Properties;

import javax.mail.BodyPart;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Message.RecipientType;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.internet.MimeMultipart;
import javax.mail.search.AndTerm;
import javax.mail.search.FlagTerm;
import javax.mail.search.RecipientStringTerm;
import javax.mail.search.SearchTerm;
import javax.mail.search.SentDateTerm;
import javax.mail.search.SubjectTerm;

import com.optum.synergy.reference.ui.pageobjects.PageObjectBase;
import org.junit.Assert;

import cucumber.api.java.en.Then;

public class ReadEmail {
	private static final long EMAIL_SLEEP = 35000;
	
	public static String[] getConfirmRegistrationURLWithSubjectandEmailContent() {

		String username = (DataStorage.getEmail() == null) ? DataStorage.getEmailId() : DataStorage.getEmail();
		// If there is specific Email in Testdata.xml, use it. Otherwise use the
		// generated EmailId.

		retrieveMessage(username, "");
		
		String emailcontent = DataStorage.getEmailContent();
		String toberemoved = "This e-mail, including attachments, may include confidential and/or proprietary information, and may be used only by the person or entity to which it is addressed. If the reader of this e-mail is not the intended recipient or his or her authorized agent, the reader is hereby notified that any dissemination, distribution or copying of this e-mail is prohibited. If you have received this e-mail in error, please notify the sender by replying to this message and delete this e-mail immediately.";

		String linkurl;
		try {
			String[] tmparr_2;
			String[] tmparray = ((String) emailcontent).split("href=\"");
			if (DataStorage.getPortalName().contains("MyUHC")) {
			//	tmparr_2 = tmparray[1].split("\"><b>");
			// The <b> tags are not present in Confirm Update email pages.
				tmparr_2 = tmparray[1].split("\""); 
			} else {
				if (tmparray[1].contains("Confirme su direcci")) {
			//		tmparr_2 = tmparray[1].split("\"><b>");
			// The <b> tags are not present in Confirm Update email pages.
					tmparr_2 = tmparray[1].split("\"");
				}

				else {
			//		tmparr_2 = tmparray[1].split("\"><b></b></a>");
			// The <b> tags are not present in Confirm Update email pages.		
					tmparr_2 = tmparray[1].split("\"");
				}
			}

			linkurl = tmparr_2[0];
		} catch (Exception e) {
			e.printStackTrace();
			linkurl = "EXCEPTION_PARSING_URL";
		}

		String[] rtrnrarr = new String[] { linkurl, DataStorage.getEmailSubject(),
				DataStorage.getEmailContent().replace(toberemoved, "") };
		
		return rtrnrarr;
	}
		
	public static String getEmailContent() {
		return getEmailContent(DataStorage.getEmailId());
	}

	public static String getEmailContent(String mailBoxUsername) {
		
		retrieveMessage(mailBoxUsername, "");
		return DataStorage.getEmailContent();
	}

	public static String getAccesscodeForLegacyID(String userid) {
		String accesscode = null;
		String username = "hsidauto1+" + userid + "@gmail.com";

		retrieveMessage(username, "");

		String tmpstring = DataStorage.getEmailContent();
		String[] tmparr = tmpstring.split("one-time passcode");
		String[] tmparr_two = tmparr[1].split("to access your account");

		accesscode = tmparr_two[0].trim();
		return accesscode;
	}

	public static void retrieveMessage(String mailbox, String subject) {

		String pwd = "test123$";
		// Hack to resolve current issue with hsidauto1 account/password
		// TODO Need to consolidate account passwords. Made difficult
		// by UHC's network policy blocking gmail.com...
		if (mailbox.toUpperCase().startsWith("HSIDAUTO1") || 
				mailbox.toUpperCase().startsWith("HSIDAUTO.14") ||
				mailbox.toUpperCase().startsWith("HSIDAUTOMOBILETEXT1")	||
				mailbox.toUpperCase().startsWith("HSIDAUTO.7")	||
				mailbox.toUpperCase().startsWith("HSIDAUTO.8")|| mailbox.toUpperCase().startsWith("HSIDAUTO.99") ) {
		   	pwd = "test1234$";
		}else if(mailbox.toUpperCase().startsWith("HSIDAUTO.9") ||
				mailbox.toUpperCase().startsWith("HSIDAUTO.13") ||
				mailbox.toUpperCase().startsWith("HSIDAUTO.16") ||
				mailbox.toUpperCase().startsWith("HSIDAUTO.3")	||
				mailbox.toUpperCase().startsWith("HSIDAUTO.4") ||
				mailbox.toUpperCase().startsWith("HSIDAUTO4")){
			pwd = "hsid1234$";
		}
		// Make sure that email reached to inbox, 30 seconds time gap
		try { Thread.sleep(EMAIL_SLEEP); } catch (InterruptedException e) {}

		Properties props = System.getProperties();
		props.setProperty("mail.store.protocol", "imaps");
		Store store = null;
		Folder inbox = null;
		try {
			store = Session.getDefaultInstance(props, null).getStore("imaps");
			store.connect("imap.gmail.com", mailbox, pwd);
			inbox = store.getFolder("Inbox");

			inbox.open(Folder.READ_WRITE);
			//inbox.open(Folder.READ_ONLY);

			// Filter inbox messages by "UNSEEN" and "TO={username}"
			FlagTerm ft_unseen = new FlagTerm(new Flags(Flags.Flag.SEEN), false);
			RecipientStringTerm ft_toEmail = new RecipientStringTerm(RecipientType.TO, mailbox);
			SearchTerm st = null;
			
			if ( subject.length() > 0 ) {
				SubjectTerm ft_subject = new SubjectTerm(subject);
				SearchTerm[] terms = { ft_unseen, ft_toEmail, ft_subject };
//				SearchTerm[] terms = { ft_unseen, ft_subject };
				st = new AndTerm(terms);
			} else {
				SearchTerm[] terms = { ft_unseen, ft_toEmail};
//				SearchTerm[] terms = { ft_unseen};
				st = new AndTerm(terms);
			}
			
			Message msg[] = inbox.search(st);
//System.out.println("DEBUG:: Received [" + msg.length + "] messages in mailbox [" + mailbox + "] with subject [" + subject + "]");			
			if ( msg.length > 0 ) {
				
				Object contentObj = msg[msg.length-1].getContent();
				String contentStr = contentObj.toString();
				if (contentObj instanceof MimeMultipart) {
					MimeMultipart multipart = (MimeMultipart) contentObj;
					// will return the entire content of email body by recursively 
					// going through various bodypart of MIME message
					contentStr = getTextFromMimeMultipart(multipart);
				} 
				
				DataStorage.setEmailContent(contentStr);
				DataStorage.setEmailSubject(msg[msg.length-1].getSubject());
/*
String recipients = "";
for ( javax.mail.Address i : msg[msg.length-1].getAllRecipients() ) {
	recipients = recipients + "," + i.toString();
}
System.out.println("DEBUG::To address:: [" + recipients + "]");
System.out.println("DEBUG::Msg date:: [" + msg[msg.length-1].getSentDate() + "]");
*/			
				msg[msg.length-1].setFlag(Flags.Flag.DELETED, true);
				
			} else {
				DataStorage.setCustomErrmsg("NO MESSAGE FOUND FOR [" + mailbox + "] with subject ["
						+ subject + "]");
				DataStorage.resetEmail();
			}
		} catch ( MessagingException | IOException e) {
			DataStorage.setCustomErrmsg("EXCEPTION In retrieveMessage(" + mailbox + ","
					+ subject + ")\n" + e.getMessage());
		} finally {
			try {
				if (inbox != null) { inbox.close(true); }
				if (store != null) { store.close(); }
			} catch (MessagingException e) {	}
		}

		return;
	}	
	
	private static String getTextFromMimeMultipart(MimeMultipart mimeMultipart) throws MessagingException, IOException {
		String result = "";
		int count = mimeMultipart.getCount();
		for (int i = 0; i < count; i++) {
			BodyPart bodyPart = mimeMultipart.getBodyPart(i);
			if (bodyPart.isMimeType("text/plain")) {
				result = result + "\n" + bodyPart.getContent();
				break; // without break same text appears twice in my tests
			} else if (bodyPart.isMimeType("text/html")) {
				String html = (String) bodyPart.getContent();
				result = result + "\n" + org.jsoup.Jsoup.parse(html).text();
			} else if (bodyPart.getContent() instanceof MimeMultipart) {
				result = result + getTextFromMimeMultipart((MimeMultipart) bodyPart.getContent());
			}
		}
		return result;
	}
	
	public static String getOTPFromEmail() {
		String OTP  = null;
		try {
			Thread.sleep(10000);
			DataStorage.resetEmail();
			String mailBoxUsername = DataStorage.getEmailIDtoFetchOTP();
			if (mailBoxUsername == null) {
				mailBoxUsername = DataStorage.getEmail();
			}

			//Wait for Email to arrive in the Inbox
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e){}
			retrieveMessage(mailBoxUsername, "New text message from ");

			if (DataStorage.getEmailContent() == null) {
				PageObjectBase.OTPFoundStatus.set(1);
				Assert.fail("NO OTP EMAIL FOUND FOR [" + mailBoxUsername + "] with subject [New text message from ]");
			}
			String tmpstring = DataStorage.getEmailContent().replace(" ", "");
			String[] tmparr = tmpstring.split("Message/data");
			System.out.println(tmparr[0] + "testOTP");

			tmparr[0] = tmparr[0].replace("\n", "").trim();
			System.out.println(tmparr[0] + "testOTP");

			String[] arr = tmparr[0].split("YourHealthSafeIDverificationcodeis");

			OTP = tmparr[0].substring(62,69);

			DataStorage.setCustomErrmsg("HSID Phone Access One Time Password  is :" + OTP);
			return OTP;
		}
		catch(Exception ex)
		{

		}
		return OTP;
	}
	
	public static String getOptumIdOTPFromEmail(){
		String mailBoxUsername; 
				
		if ( DataStorage.getEmailIDtoFetchOTP() != null ) {
			mailBoxUsername = DataStorage.getEmailIDtoFetchOTP();
		} else if ( DataStorage.getEmailId() != null) {
			mailBoxUsername =  DataStorage.getEmailId();
		} else {
			mailBoxUsername =  DataStorage.getEmail();
		}

		//Takes longer time for email, double time so sleep here and in retrieveMessage
		try {Thread.sleep(EMAIL_SLEEP); } catch(Exception e) {} 

		String OTP=null;
		retrieveMessage(mailBoxUsername,"New text message from 67936");
		String tmpstring = DataStorage.getEmailContent().replace(" ", "");
		String[] tmparr=tmpstring.split("accesscode:");
		OTP=tmparr[1].substring(0, 10);
		DataStorage.setCustomErrmsg("Optum Id One Time Password  is :"+ OTP);

		return OTP;
	}
	
	/**
	 * Method to delete all messages for a given mailbox.
	 * 
	 * If using a "+" tagged address, only messages sent to that address are deleted
	 * If using a non-tagged address, all messages in that user's mailbox are deleted
	 * 
	 * @param mailbox
	 */
	@Then("^I delete all messages for mailbox \"([^\"]*)\"$")
	public static void deleteAllMessages(String mailbox) {

		String pwd = "test123$";
		// Hack to resolve current issue with hsidauto1 account/password
		// TODO Need to consolidate account passwords. Made difficult
		// by UHC's network policy blocking gmail.com...
		if (mailbox.toUpperCase().startsWith("HSIDAUTO1") ||
				mailbox.toUpperCase().startsWith("HSIDAUTOMOBILETEXT1") ||
				mailbox.toUpperCase().startsWith("HSIDAUTO.1")) {
			pwd = "test1234$";
		}
		Properties props = System.getProperties();
		props.setProperty("mail.store.protocol", "imaps");
		Store store = null;
		Folder inbox = null;
		try {
			store = Session.getDefaultInstance(props, null).getStore("imaps");
			store.connect("imap.gmail.com", mailbox, pwd);
			inbox = store.getFolder("Inbox");

			inbox.open(Folder.READ_WRITE);

			// Filter inbox messages by older than one hour
			SearchTerm st = new SentDateTerm(SentDateTerm.LT, new java.util.Date(System.currentTimeMillis()-60*60*1000));
			
			if ( mailbox.contains("+")) {
				RecipientStringTerm ft_toEmail = new RecipientStringTerm(RecipientType.TO, mailbox);
				st = new AndTerm(st,ft_toEmail);
			}
			
			Message msgs[] = inbox.search(st);
			inbox.setFlags(msgs, new Flags(Flags.Flag.DELETED), true);
			
		} catch ( Exception e) {
			e.printStackTrace();
			Assert.fail("Failure deleting messages for [" + mailbox
					+ "]: \n" + e.getMessage());
		} finally {
			try {
				if (inbox != null) { inbox.close(true); }
				if (store != null) { store.close(); }
			} catch (MessagingException e) {	}
		}

		return;
	}
	
	
}
