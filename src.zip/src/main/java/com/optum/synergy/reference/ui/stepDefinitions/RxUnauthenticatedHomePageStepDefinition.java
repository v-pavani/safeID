package com.optum.synergy.reference.ui.stepDefinitions;

import com.optum.synergy.reference.ui.pageobjects.Registration_PersonalInformationSectionPage;
import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.RxUnauthenticatedHomePage;
import com.optum.synergy.reference.ui.pageobjects.SignInPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RxUnauthenticatedHomePageStepDefinition {
	private RxUnauthenticatedHomePage page;
	private SignInPage pages;

	public RxUnauthenticatedHomePageStepDefinition() {
		page = new RxUnauthenticatedHomePage();
	}

	@Given("^I am at RX unauthenticated home page$")
	public void iAmAtRXUnauthenticatedHomePage() {
		page.openRXHomePage();
		//Assert.assertTrue("Issue while loading the RX Unauthenticated page", page..getOptumRxUnauthenticatedPageelement().isDisplayed() && new Registration_PersonalInformationSectionPage().VerifyOptumRxLogo());
		Assert.assertTrue("Failed to load Personal Information Page", page.verifyIfPageLoaded());
	}

	@Then("^I should be at OptumRx unauthenticated page$")
	public void iShouldAtRXUnauthenticatedPage() {
		Assert.assertTrue("Issue while loading the RX Unathenticated page", page.getOptumRxUnauthenticatedPageelement().isDisplayed());
	}

	@Then("^I should be at \"([^\"]*)\" returnToLogin page$")
	public void iShouldAtRXReturnToLoginPage(String portalName) {
		String portalText = "";
		if(portalName.equalsIgnoreCase("AHC"))
			portalText = "Thank you for using American Health Care.";
		else if(portalName.equalsIgnoreCase("BAZ"))
			portalText = "You have been logged out. For your security, we recommend closing this browser";
		else if(portalName.equalsIgnoreCase("ServeYou"))
			portalText = "Thank you for using Serve You Rx.";
		else if(portalName.equalsIgnoreCase("PHP"))
			portalText = "Thank you for using Presbyterian Health Services.";
		else if(portalName.equalsIgnoreCase("OptumRx"))
			portalText = "Thank you for using OptumRx.";
		else if(portalName.equalsIgnoreCase("PAI"))
			portalText = "Thank you for using the pharmacy portal.";
		else if(portalName.equalsIgnoreCase("TCC"))
			portalText = "Thank you for using the pharmacy portal.";
		else if(portalName.equalsIgnoreCase("IBX"))
			portalText = "Thank you for visiting the pharmacy portal.";
		else if(portalName.equalsIgnoreCase("AHA"))
			portalText = "Thank you for visiting the pharmacy portal.";
		else if(portalName.equalsIgnoreCase("AMERIHEALTH"))
			portalText = "Thank you for visiting the pharmacy portal.";
		else if(portalName.equalsIgnoreCase("RAILROADSSO"))
			portalText = "You have been logged out successfully...";
		else
		Assert.fail("Incorrect portal Name passed in the feature step:["+portalName+"]");
		Assert.assertTrue("Issue while loading the "+portalName+" returnToLogin page", page.getRxPortalsReturnToLoginPageElement(portalText).isDisplayed());
	}
	
	@Given("^I am at RX mobile unauthenticated home page$")
	public void iAmAtRXMobileUnauthenticatedHomePage() {
		page.openRXMobileHomePage();
		Assert.assertTrue("Issue while loading the RX mobile unauthenticated page", page.getRxMobileWelcomeMessage());
	}
	
	@Given("^I am at OptumRx-AARP Unauthenticated home page$")
	public void i_am_at_ORxAARP_Unauthenticated_home_page() {
		pages = new SignInPage();
		page.openORXAARPHomePage();
		Assert.assertTrue("Issue loading OptumRx-AARP Unauthenticated home page", pages.isHSIDSignPageDisplayed());
	}
}
