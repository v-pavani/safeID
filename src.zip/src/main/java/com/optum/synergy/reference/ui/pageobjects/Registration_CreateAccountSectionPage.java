package com.optum.synergy.reference.ui.pageobjects;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.optum.synergy.reference.ui.utility.DataStorage;

public class Registration_CreateAccountSectionPage extends PageObjectBase {
	
	@FindBy(how = How.ID, using = "header")
	private WebElement formHeader;

	@FindBy(how = How.ID, using = "confirmEmail2")
	private WebElement updateEmail;

	@FindBy(how = How.CLASS_NAME, using = "form__step2")
	private WebElement createAccountSection;

	@FindBy(how = How.NAME, using = "recovery")
	private WebElement recoverySection;

	@FindBy(how = How.ID, using = "username")
	private WebElement userNameTextBox;
	
	@FindBy(how = How.XPATH, using = "//select[@id='suggestion']")
	private WebElement userNameSuggestionDropdown;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Username')]/following-sibling::input[@id='username']")
	private WebElement userNameLabelWithTextBox;

	@FindBy(how = How.ID, using = "password")
	private WebElement passwordTextBox;
	
	@FindBy(how = How.XPATH, using = "//input[@id='password']/following-sibling::a[@class='password-show-icon']")
	private WebElement passwordTextBoxEyeIcon;

	@FindBy(how = How.ID, using = "confirmPassword")
	private WebElement confirmPasswordTextBox;
	
	@FindBy(how = How.XPATH, using = "//input[@id='confirmPassword']/following-sibling::a[@class='password-show-icon']")
	private WebElement confirmPasswordTextBoxEyeIcon;

	@FindBy(how = How.ID, using = "email")
	private WebElement emailTextBox;
	
	@FindBy(how = How.ID, using = "step3ConfirmEditedEmail")
	private WebElement emailTextBoxModal;
    
	@FindBy(how = How.ID, using = "confirmEmail")
	private WebElement confirmEmailTextBox;

	@FindBy(how = How.XPATH, using = "//select[@id='q0']|//select[@id='q0_input']")
	private WebElement securityQuestion1Select;

	@FindBy(how = How.XPATH, using = "//select[@id='q1']|//select[@id='q1_input']")
	private WebElement securityQuestion2Select;

	@FindBy(how = How.XPATH, using = "//select[@id='q2']|//select[@id='q2_input']")
	private WebElement securityQuestion3Select;

	@FindBy(how = How.XPATH, using = "//label[@for='q0']/span[1]")
	private WebElement securityQuestion1Label;
	
	@FindBy(how = How.XPATH, using = "//label[@for='q1']/span[1]")
	private WebElement securityQuestion2Label;
	
	@FindBy(how = How.XPATH, using = "//label[@for='q2']/span[1]")
	private WebElement securityQuestion3Label;
	
	@FindBy(how = How.XPATH, using = "//label[@for='a0']/span[1]")
	private WebElement securityAnswer1Label;
	
	@FindBy(how = How.XPATH, using = "//label[@for='a1']/span[1]")
	private WebElement securityAnswer2Label;
	
	@FindBy(how = How.XPATH, using = "//label[@for='a2']/span[1]")
	private WebElement securityAnswer3Label;
	
	@FindBy(how = How.XPATH, using = "//label[@for='remember']/span[1]"
				+ "|//label[@for='remember']"
				+ "|//*[@for='remembermydevice']"
				+ "|//*[@for='hsid-rememberMe']"
				+ "|//label[@for='rememberMe']"
				+ "|//label[@for='hsid-wdgt-rememberMe']")
	private WebElement rememberMeLabel;
	
	@FindBy(how = How.XPATH, using = "//label[@for='terms']")
	private WebElement termsOfUseLabel;

	@FindBy(how = How.XPATH, using = "//form[@name='recoveryPhoneInputStep1']/div[3]/p | //div[@id='securityOptions']/div/div[2]/p")
	private WebElement phoneDisclaimerLabel;

	@FindBy(how = How.XPATH, using = "//input[@id='a0']")
	private WebElement answer1TextBox;
	
	@FindBy(how = How.XPATH, using = "//input[@id='a1']")
	private WebElement answer2TextBox;

	@FindBy(how = How.XPATH, using = "//input[@id='a2']")
	private WebElement answer3TextBox;

	@FindBy(how = How.XPATH, using = "//input[@id='phoneNo']|//input[@id='phoneTextNumber']")
	private WebElement phoneNumberTextBox;

	@FindBy(how = How.ID, using = "remember")
	private WebElement rememberDeviceCheckBox;

	@FindBy(how = How.ID, using = "terms")
	private WebElement termsOfUseCheckBox;

	@FindBy(how = How.XPATH, using = "//h2[@class='delta ng-binding' and contains(.,'Create account')]")
	private WebElement CreateAccHeader;	
	
	//@FindBy(how = How.XPATH, using = "//*[@id='secOption' or @id ='verificationType_input']")
	@FindBy(how = How.XPATH, using = "//*[@id='secOption']|//select[@id='confirmationType_input']|//select[@id='verificationType_input']|//select[@id='undefined_input']|//select[@id='authOobSelect']|//select[@id='confirmation_type_input']|//select[@id='confirmationType_input']")
	private WebElement securityTypeDropdown;

	@FindBy(how = How.ID, using = "confirmPhoneno")
	private WebElement confirmPhoneno;
	
	@FindBy(how = How.ID, using = "code")
	private WebElement PhoneCode;
	
	@FindBy(how = How.XPATH, using = "//form/div/p[2]/a/i")
	private WebElement editlink;
	
	@FindBy(how = How.XPATH, using = "//div[@ng-bind-html='Phone']")
	private WebElement phoneNumberLabel;
	
	@FindBy(how = How.PARTIAL_LINK_TEXT, using = "Texting Terms and Conditions")
	private WebElement textingTermsAndConditionsLink;

	@FindBy(how = How.PARTIAL_LINK_TEXT, using = "Terms of Use")
	private WebElement termsOfUseLink;
	
	@FindBy(how = How.PARTIAL_LINK_TEXT, using = "Privacy Policy")
	private WebElement privacyPolicyLink;
	
	@FindBy(how = How.PARTIAL_LINK_TEXT, using = "Consumer Communications Notice")
	private WebElement consumerCommunicationsNoticeLink;
	
	@FindBy(how = How.XPATH, using = "//h3[2]/a[@class='milli edit-link ng-scope']")
	private WebElement recoveryEditLink;
		
	@FindBy(how = How.XPATH, using = "//div[@class='ng-binding ng-scope']/*[contains(.,'We’re sorry. This username is not available. Please choose a different one, or use one of our suggestions.')]|//*[@class='error']/span[contains(.,'Username already exists')]|//p[@class='ng-scope']/*[contains(.,'We’re sorry. This username is not available. Please choose a different one, or use one of our suggestions.')]")
	private WebElement verifyExistingUsernameLabel;

	@FindBy(how = How.XPATH, using = "//*[contains(text(),'Phone number is required')]|//*[@id='phoneNo']/..//p[contains(@class,'error')]")
	private WebElement securityPhoneNumberLabel;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Phone type is required')]|//*[@id='phoneType']/..//p[contains(@class,'error')]")
	private WebElement securityPhoneTypeLabel;
	
	@FindBy(how = How.XPATH, using = "//span[@ng-bind-html='errorsMsg.EMPhoneInvalid | trusted']")
	private WebElement invalidSecurityPhoneNumberLabel;
	
	@FindBy(how = How.XPATH, using = "//*[@id='q1']/..//span[@class='ng-binding']|//*[@class='error']/span[contains(.,'Security question 1 is required')]")
	private WebElement question1Label; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='q2']/..//span[@class='ng-binding']|//*[@class='error']/span[contains(.,'Security question 2 is required')]")
	private WebElement question2Label; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='q3']/..//span[@class='ng-binding']|//*[@class='error']/span[contains(.,'Security question 3 is required')]")
	private WebElement question3Label; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='a1']/..//span[@ng-bind-html='answerErrors[0] | trusted']|//label[@for='a0']/span[@class='error']")
	private WebElement ans1; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='a2']/..//span[@ng-bind-html='answerErrors[1] | trusted']|//label[@for='a1']/span[@class='error']")
	private WebElement ans2; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='a3']/..//span[@ng-bind-html='answerErrors[2] | trusted']|//label[@for='a2']/span[@class='error']")
	private WebElement ans3; 
	
	@FindBy(how = How.XPATH, using = "//p[contains(text(),'You must check the box indicating that you agree to the updated policies.')]|//span[@class='error']//span[@ng-bind-html='termsAndConditionsError']|//div[@class='error-text']")
	private WebElement agreeTermsAndValidation; 
	
	@FindBy(how = How.XPATH, using = "//label[@for='username']/span[@class='error']")
	private WebElement myUhcUsernameError;
	
	@FindBy(how = How.XPATH, using = "//p[@class='ng-scope']/*[contains(.,'We’re sorry. This username is not available. Please choose a different one, or use one of our suggestions.')]")
	private WebElement myUhcExistingUsernameMessage;
	
	@FindBy(how = How.XPATH, using = "//label[@for='password']/span[@class='error']")
	private WebElement myUhcPasswordError;
	
	@FindBy(how = How.XPATH, using = "//p[@class='ng-scope']//span[@class='ng-binding ng-scope']")
	private WebElement whiteSectionError;
	
	@FindBy(how = How.XPATH, using = "//form[@name='credentials']//span[@class='icon-alert_filled error']/parent::p")
	private WebElement FormSectionTopError;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'mb30')]")
	private WebElement createYourHsidHeader;
		
	@FindBy(how = How.XPATH, using = "//label[@for='username']//div[contains(@class,'tooltip-content')]")
	private WebElement userNameTooltip;
	
	@FindBy(how = How.XPATH, using = "//label[@for='password']//div[contains(@class,'tooltip-content')]")
	private WebElement passwordTooltip;
	
	@FindBy(how = How.XPATH, using = "//label[@for='email']//*[contains(@ng-mouseover,'toolTipOn')]/following-sibling::div/p")
	private WebElement emailTooltipContent;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'phone-disclaimer')]")
	private WebElement phoneMsg;

	@FindBy(how = How.XPATH, using = "//*[@id='username']/..//span[@class='ng-binding']")
	private WebElement userNameError;  
	
	@FindBy(how = How.XPATH, using = "//*[@id='password']/..//span[@class='ng-binding']|//*[@for='password']//*[contains(@class,'error')]")
	private WebElement passwordError;  

	@FindBy(how = How.XPATH, using = "//*[@for='confirmPassword']//*[contains(@class,'error')]")
	private WebElement confirmPasswordError;
	
	@FindBy(how = How.XPATH, using = "//label[@for='username']/span[1]")
	private WebElement usernameLabel; 
	
	@FindBy(how = How.XPATH, using = "//label[@for='password']/span[1]")
	private WebElement passwordLabel;
	
	@FindBy(how = How.XPATH, using = "//label[@for='confirmPassword']/span")
	private WebElement confirmPasswordLabel;
	
	@FindBy(how = How.XPATH, using = "//*[@id='email']/..//span[@class='ng-binding']")
	private WebElement emailError; 
	
	@FindBy(how = How.XPATH, using = "//label[@for='email']/span[1]")
	private WebElement emailLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='confirmEmail']/..//span[@class='ng-binding']")
	private WebElement confirmEmailError;
	
	@FindBy(how = How.XPATH, using = "//label[@for='confirmEmail']/span[1]")
	private WebElement confirmEmailLabel;
	
	@FindBy(how = How.XPATH, using = "//div[@id='securityOptions']//span[@class='error ng-binding ng-scope']|//span[@ng-bind-html='selectSecurityOptionError']")
	private WebElement securityDropdownError; 
	
	@FindBy(how = How.XPATH, using = "//div[@id='securityOptions']/preceding-sibling::*[1]")
	private WebElement securityDropdownLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@for='phoneNo']/span"
			+ " | //*[@for='Phone number (XXX-XXX-XXXX)']/span")
	private WebElement phoneNoLabel;
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'mb30')]")
	private WebElement upgradeToHsidHeader;
	
	@FindBy(how = How.XPATH, using = "//*[contains(@class,'modal__dialog')]//*[@class='icon-close']"
			+ "|//*[@id='closeModalIcon']//*[@class='icon-close']"
			+ "|//*[contains(@class,'modal')]//*[@class='icon-close']"
			+ "|//*[contains(@class,'modal-content')]//*[@class='modal-close btn btn--close']")
	private WebElement CloseICONinPopUp;
	
	@FindBy(how = How.XPATH, using = "//*[@id='hsid-wdgt-myModal-learnmore']//*[@class='icon-close']")
	private WebElement CloseIconLearnMore;
	
	@FindBy(how = How.XPATH, using = "//*[@id='pageErrors']//span[@class='icon-alert_filled error']/parent::p")
	private WebElement errorMsgOnTopStepUp;
	
	@FindBy(how = How.XPATH, using = "//li[contains(text(),'HSID Analytics')]//u")
	private WebElement HSIDAnalyticsOptOutLink;
	
	@FindBy(how = How.XPATH, using = "//div[@id='content1']|//div[@id='default-content']")
	private WebElement HSIDAnalyticsOptOutPageContent;
	
	@FindBy(how = How.XPATH, using = "//div[@id='content2']|//div[@id='default-content']")
	private WebElement HSIDAnalyticsReEnablePageContent;
	
	@FindBy(how = How.XPATH, using = "(//span[@class='ng-scope'])[1]")
	private WebElement ExclusionError;
	
	@FindBy(how = How.XPATH, using = "//label[@for='remember']"
			+ "|//label[@for='remembermydevice']"
			+ "|//label[@for='hsid-rememberMe']"
			+ "|//label[@for='rememberMe']"
			+ "|//label[@for='hsid-wdgt-rememberMe']")
	private WebElement remembermeElement;
	
	@FindBy(how = How.XPATH, using = "//label[@for='terms']")
	private WebElement termsAndConditionElement;
	
	@FindBy(how = How.ID, using = "errorsBoxCredentials")
	private WebElement errorMessageBox;
	
	public void editlinkClick(){
		mediumWait.get().until(ExpectedConditions.visibilityOf(editlink));
		editlink.click();
	}
	
	public void enterConfirmPhoneNumber(String password) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmPhoneno));
		confirmPhoneno.clear();
		confirmPhoneno.sendKeys(password);
	}
	
	public void enterCode(String password) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(PhoneCode));
		PhoneCode.clear();
		PhoneCode.sendKeys(password);
	}
	
	public boolean verifyConfirmphoneNo() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmPhoneno)).isDisplayed();
	}

	public boolean verifyIfPageLoaded() {
		try {
			waitForJavascriptToLoad(6000, 1000);
			return longWait.get().until(ExpectedConditions.visibilityOf(createAccountSection)).isDisplayed();
		} catch (TimeoutException e) {
		    DataFailureStatus.set(1);
			return false;
		}
	}
	
	public boolean verifyIfUsernameSuggestionDropdownDisplayed() {
		try {
			waitForPageLoad(driver);
			return longWait.get().until(ExpectedConditions.visibilityOf(userNameSuggestionDropdown)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public boolean verifyRecoverySectionlabel(String label) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(recoverySection));
		return recoverySection.getText().contains(label);
	}
	
	public boolean verifyIfUserNameFieldisEmpty() {
		return userNameTextBox.getAttribute("class").contains("ng-empty");
	}
	
	public boolean verifyIfPasswordFieldisEmpty() {
		return passwordTextBox.getAttribute("class").contains("ng-empty");
	}
	
	public boolean verifyIfReEnterPasswordFieldisEmpty() {
		return confirmPasswordTextBox.getAttribute("class").contains("ng-empty");				
	}
	
	public boolean verifyIfEmailFieldisEmpty() {
		return emailTextBox.getAttribute("class").contains("ng-empty");
	}
	
	public boolean verifyIfReEnterEmailFieldisEmpty() {
		return confirmEmailTextBox.getAttribute("class").contains("ng-empty");
	}

	public void enterUserName(String userName) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(userNameTextBox));
		userNameTextBox.clear();
		userNameTextBox.sendKeys(userName);
	}

	public void updateEmail(String text) {
		updateEmail.clear();
		updateEmail.sendKeys(text);
	}

	public void enterPassword(String password) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(passwordTextBox));
		passwordTextBox.clear();
		passwordTextBox.sendKeys(password);
	}

	public void enterConfirmPassword(String password) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmPasswordTextBox));
		confirmPasswordTextBox.clear();
		confirmPasswordTextBox.sendKeys(password);
	}

	public void enterEmail(String email) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(emailTextBox));
		emailTextBox.clear();
		emailTextBox.sendKeys(email);
	}
	
	public String getEmailValue() {
		longWait.get().until(ExpectedConditions.visibilityOf(emailTextBox));
		// Ensure emailTextBox value attribute to not be null, either empty string
		// or notEmpty
		mediumWait.get().until(ExpectedConditions.or(
				ExpectedConditions.attributeToBe(emailTextBox, "value", ""),
				ExpectedConditions.attributeToBeNotEmpty(emailTextBox, "value")
					));
		return emailTextBox.getAttribute("value");
	}
    
	public String getEmailValueOnModal() {
		longWait.get().until(ExpectedConditions.visibilityOf(emailTextBox));
		// Ensure emailTextBox value attribute to not be null, either empty string
		// or notEmpty
		mediumWait.get().until(ExpectedConditions.or(
				ExpectedConditions.attributeToBe(emailTextBoxModal, "value", ""),
				ExpectedConditions.attributeToBeNotEmpty(emailTextBoxModal, "value")
					));
		return emailTextBox.getAttribute("value");
	}
	
	public void confirmEmail(String email) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEmailTextBox));
		confirmEmailTextBox.clear();
		confirmEmailTextBox.sendKeys(email);
	}
	
	public void selectSecurityType(String securityType) {
		mediumWait.get().until(
				ExpectedConditions.textToBePresentInElement(securityTypeDropdown, securityType));
		Select dropdown = new Select(securityTypeDropdown);
		dropdown.selectByVisibleText(securityType);
	}

	public void selectSecurityQuestion1(String questionName) {		 
		mediumWait.get().until(
				ExpectedConditions.textToBePresentInElement(securityQuestion1Select, questionName));
		Select dropdown = new Select(securityQuestion1Select);
		dropdown.selectByVisibleText(questionName);		
	}
	
	public void selectSecurityQuestion2(String questionName) {
		mediumWait.get().until(
				ExpectedConditions.textToBePresentInElement(securityQuestion2Select, questionName));
		Select dropdown = new Select(securityQuestion2Select);
		dropdown.selectByVisibleText(questionName);		
	}

	public void selectSecurityQuestion3(String questionName) {
		mediumWait.get().until(
				ExpectedConditions.textToBePresentInElement(securityQuestion3Select, questionName));
		Select dropdown = new Select(securityQuestion3Select);
		dropdown.selectByVisibleText(questionName);		
	}

	public void selectPhoneType(String phoneType) {
		Select dropdown = new Select(mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.id("phoneType"))));
		dropdown.selectByVisibleText(phoneType);
	}

	public void clickConfirmYourPhoneNumberWithRadioButton(String optionName) {
		mediumWait.get().until(ExpectedConditions
				.presenceOfElementLocated(By.xpath("//div[@class='radio' and contains(.,'" + optionName + "')]/input|//div[@class='challengeResponseText0 radio' and contains(.,'" + optionName + "')]/input|//div[@class='challengeResponsePhone0 radio' and contains(.,'" + optionName + "')]/input[2]"))) 
				.click();
	}

	public void enterSecurityAnswer1(String securityAnswer) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(answer1TextBox));
		answer1TextBox.clear();
		answer1TextBox.sendKeys(securityAnswer);
	}

	public void enterSecurityAnswer2(String securityAnswer) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(answer2TextBox));
		answer2TextBox.clear();
		answer2TextBox.sendKeys(securityAnswer);
	}

	public void enterSecurityAnswer3(String securityAnswer) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(answer3TextBox));
		answer3TextBox.clear();
		answer3TextBox.sendKeys(securityAnswer);
	}

	public void enterPhoneNumber(String phoneNumber) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(phoneNumberTextBox));
		phoneNumberTextBox.clear();
		phoneNumberTextBox.sendKeys(phoneNumber);
	}

	public boolean verifyForRememberThisDeviceCheckBox() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(rememberDeviceCheckBox)).isDisplayed();
	}

	public void clickRememberThisDeviceCheckBox() {
		longWait.get().until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='remember']")));
		clickByJavaScript(rememberDeviceCheckBox);
	}

	public void clicktermsOfUseCheckBox() {
		mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='terms']")));
		clickByJavaScript(termsOfUseCheckBox);
	}

	public boolean verifyFormHeader(String headerName) {
		smallWait.get().until(ExpectedConditions.visibilityOf(formHeader));
		return formHeader.getText().equals(headerName);
	}

	public boolean verifyErrorMessageOnUserName(String message) {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//input[@id='username']/following-sibling::span[contains(@class,'error') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
	
	public boolean verifyErrorMessageOnConfirmPhoneNumber(String message) {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//span[contains(@class,'ng-binding') and contains(.,'"
						+ message + "')] | //span[contains(@class,'ng-scope') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
	
	public boolean verifyErrorMessageOnCode(String message) {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//span[contains(@class,'ng-binding') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
	
	public boolean verifyErrorMessageOnConfirmationOption(String message) {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//span[contains(@class,'ng-binding') and contains(.,'" + message + "')]")))
				.isDisplayed();
	}

	public boolean verifyErrorMessageInErrorBox(String message) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(errorMessageBox));
		return errorMessageBox.getText().contains(message);
	}

	public boolean verifyIfUsernameLabelExistWithTextbox() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(userNameLabelWithTextBox)).isDisplayed();
	}
	
	public WebElement getPhoneNumberLabel() {
		return phoneNumberLabel;
	}
	
	public WebElement getTextingTermsAndConditionsLink() {
		return textingTermsAndConditionsLink;
	}
	
	public WebElement getTermsOfUseLink() {
		return termsOfUseLink;
	}
	
	public WebElement getPrivacyPolicyLink() {
		return privacyPolicyLink;
	}
	
	public WebElement getConsumerCommunicationsNoticeLink() {
		return consumerCommunicationsNoticeLink;
	}
	
	public boolean verifyExistingUsernameLabel(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(verifyExistingUsernameLabel)).getText().contains(message);
	}

	public boolean verifyusernameLabel(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(userNameError)).getText().contains(message);
	}

	public boolean verifyPasswordLabel(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(passwordError)).getText().contains(message);
	}

	public boolean verifyConfirmpasswordError(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmPasswordError)).getText().contains(message);
	}

	public boolean verifyEmailLabel(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(emailError)).getText().contains(message);
	}

	public boolean verifyConfirmEmailLabel(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEmailError)).getText().contains(message);
	}
	
	public String getSecurityDropdownError() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(securityDropdownError)).getText().trim();
	}
	
	public boolean verifySecurityPhoneNumberLabel(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(securityPhoneNumberLabel)).getText().contains(message);
	} 
	
	public boolean verifySecurityPhoneTypeLabel(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(securityPhoneTypeLabel)).getText().contains(message);
	}
	
	public boolean verifyInvalidSecurityPhoneNumberLabel(String message) {
		return longWait.get().until(ExpectedConditions.visibilityOf(invalidSecurityPhoneNumberLabel)).getText().contains(message);
	}

	public boolean verifyquestion1(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(question1Label)).getText().contains(message);
	}
	
	public boolean verifyquestion2(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(question2Label)).getText().contains(message);
	}
	
	public boolean verifyquestion3(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(question3Label)).getText().contains(message);
	}

	public boolean verifyAnswer1(String message) {
		return longWait.get().until(ExpectedConditions.visibilityOf(ans1)).getText().contains(message);
	}
	
	public boolean verifyAnswer2(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(ans2)).getText().contains(message);
	}
	
	public boolean verifyAnswer3(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(ans3)).getText().contains(message);
	}

	public boolean verifyAgreeTermsOfValidations(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(agreeTermsAndValidation)).getText().contains(message);
	}

	public String getUsernameErrorText() {
		smallWait.get().until(ExpectedConditions.visibilityOf(myUhcUsernameError));
        return myUhcUsernameError.getText();
    }
	
	public boolean verifyMyUhcExistingUsernameMessage(String message) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(myUhcExistingUsernameMessage)).getText().contains(message);
	}

	public String getPasswordErrorText() {
		smallWait.get().until(ExpectedConditions.visibilityOf(myUhcPasswordError));
        return myUhcPasswordError.getText();
    }
	
	public Object getWhiteSectionErrorText() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(whiteSectionError));
        return whiteSectionError.getText();
	}
	
	public boolean verifyCreateHsidHeaderContent(String message) {
		String textContent = mediumWait.get().until(ExpectedConditions.visibilityOf(createYourHsidHeader)).getText().trim().replaceAll(String.valueOf((char)160)," ");
		return textContent.contains(message);
	}
	
	public boolean verifyUpgradeToHsidHeaderContent(String content) {
		String textContent = mediumWait.get().until(ExpectedConditions.visibilityOf(upgradeToHsidHeader)).getText().trim().replaceAll(String.valueOf((char)160)," ");
		return textContent.contains(content);
	}

	public String getPhoneMsg() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(phoneMsg)).getText();
	}

	public void mouseHoverOnEmailIdToolTip() {
		mouseHoverOnElement(mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@class='tooltip']/*[contains(.,'Why we need your email')]/a"))));
	}

	public boolean validateEmailToolTipMessage(String message) {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//*[@class='tooltip']/*[contains(.,'"+message + "')]"))).isDisplayed();
	}
	
	public boolean verifyTooltipContent(String tooltipType, String pgContent) {
		if(tooltipType.equalsIgnoreCase("username")){
			String usernameTooltipContent = mediumWait.get().until(ExpectedConditions.visibilityOf(userNameTooltip)).getText();
			return usernameTooltipContent.contains(pgContent);
		}
		else if(tooltipType.equalsIgnoreCase("password")){
			String passwordTooltipContent = mediumWait.get().until(ExpectedConditions.visibilityOf(passwordTooltip)).getText();
			return passwordTooltipContent.contains(pgContent);
		}
		else if(tooltipType.equalsIgnoreCase("email")){
			String actualEmailTooltipContent = mediumWait.get().until(ExpectedConditions.visibilityOf(emailTooltipContent)).getText();
			return actualEmailTooltipContent.contains(pgContent);
		}
		else
			return false;
		}
	
	public String verifyLabels(String field){
		switch(field) {
		case "username": if(userNameTextBox.isDisplayed()) return  mediumWait.get().until(ExpectedConditions.visibilityOf(usernameLabel)).getText();
		case "password": if(passwordTextBox.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(passwordLabel)).getText();
		case "confirmpassword": if(confirmPasswordTextBox.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmPasswordLabel)).getText();
		case "email": if(emailTextBox.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(emailLabel)).getText();
		case "confirmemail": if(confirmEmailTextBox.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEmailLabel)).getText();
		case "securityoption": if(securityTypeDropdown.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(securityDropdownLabel)).getText();
		case "securityquestion1": if(mediumWait.get().until(ExpectedConditions.visibilityOf(securityQuestion1Select)).isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(securityQuestion1Label)).getText();
		case "securityquestion2": if(securityQuestion2Select.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(securityQuestion2Label)).getText();
		case "securityquestion3": if(securityQuestion3Select.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(securityQuestion3Label)).getText();
		case "securityanswer1": if(answer1TextBox.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(securityAnswer1Label)).getText();
		case "securityanswer2": if(answer2TextBox.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(securityAnswer2Label)).getText();
		case "securityanswer3": if(answer3TextBox.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(securityAnswer3Label)).getText();
		case "phonenumber":  if(phoneNumberTextBox.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(phoneNoLabel)).getText();
		case "remember":  if(verifyVisibilityOfRememberMeCheckBox()) return mediumWait.get().until(ExpectedConditions.visibilityOf(rememberMeLabel)).getText();
		case "termsofuse": if(verifyVisibilityOfTermsOfUseCheckBox()) return mediumWait.get().until(ExpectedConditions.visibilityOf(termsOfUseLabel)).getText();
		case "phonedisclaimer":return mediumWait.get().until(ExpectedConditions.visibilityOf(phoneDisclaimerLabel)).getText();
		default: return "Either field or label not present.";
		}
	}
	
	public String verifyAutoCompleteForSecurityAnswers(int index){
		if(index==1)
			return mediumWait.get().until(ExpectedConditions.visibilityOf(answer1TextBox)).getAttribute("autocomplete");
		else if(index==2)
			return mediumWait.get().until(ExpectedConditions.visibilityOf(answer2TextBox)).getAttribute("autocomplete");
		else if(index==3)
			return mediumWait.get().until(ExpectedConditions.visibilityOf(answer3TextBox)).getAttribute("autocomplete");
		else
			return null;
	}
	
	public void enterPasswordAndClickOnEyeIcon(String data, String field) throws InterruptedException{
		switch(field) {
		case "password": if(passwordTextBox.isDisplayed()) 
			{
			passwordTextBox.clear();
			mediumWait.get().until(ExpectedConditions.visibilityOf(passwordTextBox)).sendKeys(data);
			Thread.sleep(500);
			mediumWait.get().until(ExpectedConditions.visibilityOf(passwordTextBoxEyeIcon)).click();
			break;
			}
		case "confirmPassword": if(confirmPasswordTextBox.isDisplayed()) 
			{
			confirmPasswordTextBox.clear();
			mediumWait.get().until(ExpectedConditions.visibilityOf(confirmPasswordTextBox)).sendKeys(data);
			Thread.sleep(500);
			mediumWait.get().until(ExpectedConditions.visibilityOf(confirmPasswordTextBoxEyeIcon)).click();
			break;
			}
		}
	}
	
	public void enterInPasswordField(String content) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(passwordTextBox)).clear();
		passwordTextBox.sendKeys(content);
	}
	
	public void enterInUsernameField(String content) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(userNameTextBox)).clear();
		userNameTextBox.sendKeys(content);
	}
	
	public String verifyUsernameAutoPopulated() {
		try {Thread.sleep(2000);
			mediumWait.get().until(ExpectedConditions.visibilityOf(userNameTextBox));
			String elementval = userNameTextBox.getAttribute("value");

			return elementval;
		} catch (Exception e) {
			return null;
		}
	}
	
	public String getPasswordFieldValue(String field) {
		try {
			switch (field) {
			case "password":
				if (passwordTextBox.isDisplayed()) {
					Thread.sleep(3000);
					scrollElementIntoView(passwordTextBox);
					return mediumWait.get().until(ExpectedConditions.visibilityOf(passwordTextBox)).getAttribute("value");
				}
			case "confirmPassword":
				if (confirmPasswordTextBox.isDisplayed()) {
					Thread.sleep(3000);
					scrollElementIntoView(confirmPasswordTextBox);
					return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmPasswordTextBox)).getAttribute("value");
				}
			default:
				return "Either field or label not present.";
			}
		} catch (Exception e) {
			return null;
		}
	}
	
	public void CloseICONinPopUPClick(){
		//Selector for CloseICONinPopUp may match multiple elements depending on which pop-ups are defined on the current page
		//Assume that the first visible one is the one to be operated on
		mediumWait.get().until(ExpectedConditions.or(
				ExpectedConditions.visibilityOf(CloseICONinPopUp),
				ExpectedConditions.visibilityOf(CloseIconLearnMore)
			));
		if ( CloseICONinPopUp.isDisplayed() ) { 
			CloseICONinPopUp.click();
		} else if ( CloseIconLearnMore.isDisplayed() ) { 
			CloseIconLearnMore.click();
		}
	}
	
	public boolean VerifySecurityAnswerismaskedandeditable() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(answer1TextBox));
		return answer1TextBox.getAttribute("class").contains("ng-not-empty");
	}


	public void enterPhoneNumberFromPool() {
		enterPhoneNumber(DataStorage.getOrSetPhoneNumber());
	}
	
	public boolean verifyErrorMessageOnTop(String content)	{
		String errorMessage = mediumWait.get().until(ExpectedConditions.visibilityOf(errorMsgOnTopStepUp)).getText();
		return content.equals(errorMessage);
	}
	
	public void clickHSIDAnalyticsOptOutLink() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(HSIDAnalyticsOptOutLink)).click();
	}
	
	public String getHSIDAnalyticsOptOutPageContent() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(HSIDAnalyticsOptOutPageContent)).getText();
	}
	
	public String getHSIDAnalyticsReEnablePageContent() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(HSIDAnalyticsReEnablePageContent)).getText();
	}
	
	public void validateExclusionErrorMessage(String expectedErrorMessage) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(ExclusionError));
		String actualErrorMessage = ExclusionError.getText();
		Boolean errorMessage = actualErrorMessage.equals(expectedErrorMessage);
		Assert.assertTrue("Error Message not valid", errorMessage);
	}
	
	public boolean verifyVisibilityOfRememberMeCheckBox() {
		String pixelValueOfRememerMeCheckBox = "px";
		String pixelContent = ((JavascriptExecutor) driver)
				.executeScript("return window.getComputedStyle(arguments[0],'::before').getPropertyValue('font-size');",
						remembermeElement)
				.toString();
		return pixelContent.contains(pixelValueOfRememerMeCheckBox);
	}

	public boolean verifyVisibilityOfTermsOfUseCheckBox() {
		String pixelValueOfTermsAndConditions = "px";
		String pixelContent = ((JavascriptExecutor) driver)
				.executeScript("return window.getComputedStyle(arguments[0],'::before').getPropertyValue('font-size');",
						termsAndConditionElement)
				.toString();
		return pixelContent.contains(pixelValueOfTermsAndConditions);
	}

	public boolean validateRegistrationMethodToolTipLabel() {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//label[@for='registerWithCap']//*[contains(@ng-mouseover,'toolTipOn')]"))).isDisplayed();
	}

	public void mouseHoverOnRegistrationMethodToolTipLabel () {
		mouseHoverOnElement(mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//*[@role='tooltip']/*[contains(.,'Only select employee ID as your registration method if directed to by your employer.')]"))));
	}
	public boolean isHSIDIconDisplayed(String iconName) {
		try {
			return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(@id,'Icons/HSID/" + iconName + "')]|//*[contains(@src,'hsid/Icons/" + iconName + "')]|//*[contains(@id,'" + iconName + "')]"))).isDisplayed();
		} catch (Exception e) {
			PageObjectBase.printDebugInformation(e);
			isLocatorFailure.set(true);
			Assert.fail("Error in verifying HSID Icon");
			return false;
		}
	}
}
