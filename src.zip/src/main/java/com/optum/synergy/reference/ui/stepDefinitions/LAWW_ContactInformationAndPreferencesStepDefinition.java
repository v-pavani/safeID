package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.LAWW_ContactInformationAndPreferencesPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class LAWW_ContactInformationAndPreferencesStepDefinition {
	
	private LAWW_ContactInformationAndPreferencesPage page;
	public LAWW_ContactInformationAndPreferencesStepDefinition()
	{
		page=new LAWW_ContactInformationAndPreferencesPage();
	}

	@Then("^I should be at Contact Information and Preferences page$")
	public void iShouldBeAtContactInformationandPreferencesPage() throws InterruptedException {
		Thread.sleep(5000);
		Assert.assertTrue("Expected page heading is: Contact Information & Preferences", page.verifythePageHeadingByH1Tag("Contact Information & Preferences")==true);
	}
	
	@Given("^I click on \"([^\"]*)\" link on Contact Information and Preferences page$")
	public void iClickOnLinkOnContactInformationAndPreferencesPage(String linkName) throws InterruptedException {
		page.getLink(linkName).click();   
		Thread.sleep(5000);
	}
}
