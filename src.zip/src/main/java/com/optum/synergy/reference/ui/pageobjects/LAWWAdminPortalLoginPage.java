package com.optum.synergy.reference.ui.pageobjects;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.optum.synergy.reference.ui.utility.ReadXMLData;

public class LAWWAdminPortalLoginPage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//input[@id='userId']")
	private WebElement userIdTextBox;

	@FindBy(how = How.ID, using = "password")
	private WebElement passwordTextBox;

	@FindBy(how = How.XPATH, using = "//button[@type = 'submit' and contains(text(),'Submit')]")
	private WebElement loginButton;

	public static String page_url;
	
	public void openPage() {
		page_url = ReadXMLData.getTestData("LAWW/AdminPortal", "url");
		openPage(page_url);
		try {
			Thread.sleep(4000); //Page was loading slow in saucelabs. May be reverted if it loads in time.
		} catch (InterruptedException e) {
			
		}
	}
	
	public void enterUserID(String userId) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(userIdTextBox));
		userIdTextBox.sendKeys(userId);
	}

	public void enterPassword(String password) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(passwordTextBox));
		passwordTextBox.sendKeys(password);
	}
	
	public void clickLoginButton() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(loginButton));
		loginButton.click();
	}
	
}
