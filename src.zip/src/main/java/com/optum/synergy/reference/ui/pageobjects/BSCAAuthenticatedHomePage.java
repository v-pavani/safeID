package com.optum.synergy.reference.ui.pageobjects;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.optum.synergy.reference.ui.utility.DataStorage;

public class BSCAAuthenticatedHomePage extends PageObjectBase {
	
	@FindBy(how = How.ID, using = "homeprintContent")
	private WebElement homePageContent;
	
	@FindBy(how = How.NAME, using = "updateEmailAddressForm")
	private WebElement updateEmailAdrressForm;
	
	@FindBy(how = How.LINK_TEXT, using = "Continue")
	private WebElement continueButton;
	
	public boolean verifyIfHomePageContentIsDisplayed()	{

		try {
			//Manage update Email form if it occurs, continue on otherwise
			mediumWait.get().until(ExpectedConditions.visibilityOf(updateEmailAdrressForm));
			try {
				smallWait.get().until(ExpectedConditions.visibilityOf(continueButton)).click();
				waitForPageLoad(driver);
			}
			catch(TimeoutException | NoSuchElementException e)	{
				DataStorage.setCustomErrmsg("Not able to find the continue button on update Email address form");
			}
		}
		catch(TimeoutException | NoSuchElementException e) {
			e.printStackTrace();
		}

		return longWait.get().until(ExpectedConditions.visibilityOf(homePageContent)).isDisplayed();
	}
}