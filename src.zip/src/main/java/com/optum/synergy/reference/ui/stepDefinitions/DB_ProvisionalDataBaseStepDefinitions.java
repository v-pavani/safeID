package com.optum.synergy.reference.ui.stepDefinitions;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.optum.synergy.reference.ui.pageobjects.PageObjectBase;
import org.json.JSONObject;
import org.junit.Assert;
import cucumber.api.java.en.And;

import com.optum.synergy.reference.ui.pageobjects.DB_ProvisionalDataBase;
import com.optum.synergy.reference.ui.utility.DataStorage;
import com.optum.synergy.reference.ui.utility.DBOperation;
import com.optum.synergy.reference.ui.utility.ReadXMLData;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DB_ProvisionalDataBaseStepDefinitions {
	private DB_ProvisionalDataBase page;

	public DB_ProvisionalDataBaseStepDefinitions() {
		page = new DB_ProvisionalDataBase();
	}

	@When("^I connected to Provisional data base$")
	public void i_connected_to_Provisional_data_base() throws SQLException {
		page.connectToDataBase();
	}

	@Then("^I should not see any records found in MBR table for the tier1 user with the following details$")
	public void i_should_not_see_any_records_found_in_MBR_table_for_the_tier1_user_with_the_following_details(
			Map<String, String> tableData) throws Exception {
		String Firstname = tableData.get("MDM_FST_NM");
		String Lastname = tableData.get("MDM_LST_NM");
		Assert.assertEquals(0, page.returnRecordsFromMBRTable(Firstname, Lastname));
	}

	@Then("^I should not see any records found in MBR_PRTL table for the tier1 user with the following details$")
	public void i_should_not_see_any_records_found_in_MBR_PRTL_table_for_the_tier1_user_with_the_following_details(
			Map<String, String> tableData) throws Exception {
		String Firstname = tableData.get("MBR_PRTL_FST_NM");
		String Lastname = tableData.get("MBR_PRTL_LST_NM");
		Assert.assertEquals(0, page.returnRecordsFromMBR_PRTLTable(Firstname, Lastname));
	}

	@Then("^I should not see any records found in MBR table for the tier2 user with the following details$")
	public void i_should_not_see_any_records_found_in_MBR_table_for_the_tier2_user_with_the_following_details()
			throws SQLException {
		String Firstname = DataStorage.getFirstName();
		String Lastname = DataStorage.getLastName();
		Assert.assertEquals(0, page.returnRecordsFromMBRTable(Firstname, Lastname));
	}

	@Then("^I should not see any records found in MBR_PRTL table for the tier2 user with the following details$")
	public void i_should_not_see_any_records_found_in_MBR_PRTL_table_for_the_tier2_user_with_the_following_details()
			throws SQLException {
		String Firstname = DataStorage.getFirstName();
		String Lastname = DataStorage.getLastName();
		Assert.assertEquals(0, page.returnRecordsFromMBR_PRTLTable(Firstname, Lastname));
	}

	@Then("^I closed the connection to provisional data base$")
	public void i_closed_the_connection_to_provisional_data_base() throws SQLException {
		page.closeConnectionToDataBase();
	}

	@Then("^I should see the record added in member portal table in PDB database$")
	public void I_should_see_the_record_added_in_member_portal_table_for_member() throws SQLException {
		String Firstname = DataStorage.getFirstName();
		String Lastname = DataStorage.getLastName();
		Assert.assertEquals(true, page.returnRecordsFromMBR_PRTLTable(Firstname, Lastname) > 0);

	}

	@Then("^I should see the record added in member table in PDB database$")
	public void I_should_see_the_record_added_in_member_table_for_member() throws SQLException {
		String Firstname = DataStorage.getFirstName();
		String Lastname = DataStorage.getLastName();
		Assert.assertEquals(true, page.returnRecordsFromMBRTable(Firstname, Lastname) > 0);

	}

	@Then("^I should see \"([^\"]*)\" records added in member portal table in PDB database$")
	public void I_should_see_all_records_added_in_member_portal_table_for_member(int numberOfRecords) throws SQLException {
		String Firstname = DataStorage.getFirstName();
		String Lastname = DataStorage.getLastName();
		Assert.assertEquals(numberOfRecords, page.returnRecordsFromMBR_PRTLTable(Firstname, Lastname));
	}
	
	@Then("^I updated the terms and conditions accepted date to \"([^\"]*)\" in PDB$")
	public void i_updated_the_terms_and_conditions_accepted_date_in_PDB(String newDate) throws SQLException {
		String Firstname = DataStorage.getFirstName();
		String Lastname = DataStorage.getLastName();
		Assert.assertEquals(1,page.updateTERM_AND_COND_ACPT_DTinMBRTableWithDate(newDate, Firstname, Lastname));
	}
	
	@Then("^I should see the terms and conditions accepted date to today's date in PDB$")
	public void i_should_see_the_terms_and_conditions_accepted_date_to_today_s_date_in_PDB() throws SQLException {
		String Firstname = DataStorage.getFirstName();
		String Lastname = DataStorage.getLastName();
		Assert.assertTrue(page.verifyIfTERM_AND_COND_ACPT_DTisUpdatedToCurrentDate(Firstname, Lastname));
	}

	@Given("^(member|login) \"([^\"]*)\" does not pre-exist in MyUHC backend system$")
	public void member_does_not_preexist_in_MyUHC_backend_system(String userDataType, String arg1) {
		String xmlNode = "";
		if (userDataType.equals("member")) {
			xmlNode = "/Users/";
		} else if (userDataType.equals("login")) {
			xmlNode = "/Logins/";
		}
		String FirstName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg1, "FirstName");
		String LastName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg1, "LastName");
		String DOB = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg1, "DOB");
		try {
			DBOperation.cleanupMyUHCmember(FirstName, LastName, DOB);
		} catch (Exception e) {
			DataStorage.setCustomErrmsg("Error in deleting the record  :" + e.toString());
			Assert.fail("Failed to delete the member for firstname: " + FirstName + " and lastname: " + LastName
					+ ":    " + e.toString());

		}

	}

	@Given("^(member|login) \"([^\"]*)\" does not pre-exist in PDB and Extremescale$")
	public void member_does_not_preexist_in_PDB_Extremescale(String userDataType, String arg1) {
		String xmlNode = "";
		if (userDataType.equals("member")) {
			xmlNode = "/Users/";
		} else if (userDataType.equals("login")) {
			xmlNode = "/Logins/";
		}
		String FirstName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg1, "FirstName");
		String LastName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg1, "LastName");
		String dateOfBirth = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg1, "DOB");
		String[] dob = dateOfBirth.split("/");
		String DOBWithPDBFormat = dob[2] + "-" + dob[0] + "-" + dob[1];

		try {
			DBOperation.deleterecordFromPDB(FirstName, LastName, DOBWithPDBFormat);
		} catch (Exception e) {
			DataStorage.setCustomErrmsg("Failed to Connect to PDB Data Base    :" + e.toString());
			Assert.fail("Failed to Connect to PDB Data Base    :" + e.toString());

		}
	}

	@Given("^I delete \"([^\"]*)\" record for \"([^\"]*)\" (member|login) registered from \"([^\"]*)\" portal$")
	public void member_does_not_preexist_in_mbrportal(String prtltodel, String datanode, String userDataType, String regprtl) {
		String FirstName = DataStorage.getFirstName();
		String LastName = DataStorage.getLastName();
		String dateOfBirth = DataStorage.getDOB();

		if(FirstName == null || LastName == null || dateOfBirth == null)
			Assert.fail("Some or all of the Firstname/Lastname/DOB are coming as null from the Test Data file. Please check test data or the data reading step");

		String[] dob = dateOfBirth.split("/");
		String DOBWithPDBFormat = dob[2] + "-" + dob[0] + "-" + dob[1];
		int mbrprtlid = DBOperation.getPortalIdBasedOnPortalName(prtltodel);
		int mbrregid = DBOperation.getPortalIdBasedOnPortalName(regprtl) ;

		try {
			DBOperation.deleterecordFrommbrprtl(FirstName, LastName, DOBWithPDBFormat, mbrprtlid, mbrregid);
		} catch (Exception e) {
			DataStorage.setCustomErrmsg("Failed to Connect to PDB Data Base    :" + e.toString());
			Assert.fail("Failed to Connect to PDB Data Base    :" + e.toString());
		}
	}
	
	@Given("^(member|login) \"([^\"]*)\" does not pre-exist in PDB and Extremescale for the current portal$")
	public void member_does_not_preexist_in_PDB_Extremescale_for_the_current_portal(String userDataType, String arg1) {
		String xmlNode = "";
		if (userDataType.equals("member")) {
			xmlNode = "/Users/";
		} else if (userDataType.equals("login")) {
			xmlNode = "/Logins/";
		}
		String FirstName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg1, "FirstName");
		String LastName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg1, "LastName");
		try {
			DBOperation.deletePortalSpecificRecordFromPDB(FirstName, LastName);
		} catch (Exception e) {
			DataStorage.setCustomErrmsg("Failed to Connect to PDB Data Base    :" + e.toString());
			Assert.fail("Failed to Connect to PDB Data Base    :" + e.toString());
		}
	}

    /*
     * Use this step def whenever you want to delete any user record by using firstname, lastname and SubscriberId/CardHolderId
     * (i.e. Use it when there are more than one users with the same firstname and lastname but different subscriber id.)
     */
	@Given("^(member|login) \"([^\"]*)\" does not pre-exist in PDB and Extremescale using id$")
	public void member_does_not_preexist_in_PDB_ExtremescaleUsingId(String userDataType, String arg1) {
		String env= System.getProperty("ExecutionEnv");
		String FinalId = null;

		String xmlNode = "";
		if (userDataType.equals("member")) {
			xmlNode = "/Users/";
		} else if (userDataType.equals("login")) {
			xmlNode = "/Logins/";
		}

		String FirstName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg1, "FirstName");
		String LastName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg1, "LastName");
		List<String> SubscriberId = ReadXMLData.getTestDataList(env+"/"+ DataStorage.getPortalName() + xmlNode + arg1, "SubscriberID");
		List<String> CardHolderId = ReadXMLData.getTestDataList(env+"/"+ DataStorage.getPortalName() + xmlNode + arg1, "CardholderID");

		FinalId = CardHolderId.size()==1 ? CardHolderId.get(0) : SubscriberId.get(0);

		try {
			DBOperation.deleterecordFromPDBUsingId(FirstName, LastName, FinalId);
		} catch (Exception e) {
			DataStorage.setCustomErrmsg("Failed to Connect to PDB Data Base    :" + e.toString());
			Assert.fail("Failed to Connect to PDB Data Base    :" + e.toString());
		}
	}

	@Given("^(member|login) \"([^\"]*)\" does not pre-exist in PDB and Extremescale using member provision ID$")
	public void member_does_not_preexist_in_PDB_ExtremescaleUsingMemberProvisionId(String userDataType, String arg1) {
		String xmlNode = "";
		if (userDataType.equals("member")) {
			xmlNode = "/Users/";
		} else if (userDataType.equals("login")) {
			xmlNode = "/Logins/";
		}
		String FirstName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg1, "FirstName");
		String LastName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg1, "LastName");
		try {
			DBOperation.deleterecordFromPDBUsingProvisionID(FirstName, LastName);
		} catch (Exception e) {
			DataStorage.setCustomErrmsg("Failed to Connect to PDB Data Base    :" + e.toString());
			Assert.fail("Failed to Connect to PDB Data Base    :" + e.toString());
		}
	}
    
    @Then("^I should see the record added in extreme scale$")
    public void I_should_see_the_record_added_in_extreme_scale() {
          String Firstname= DataStorage.getFirstName();
          String Lastname= DataStorage.getLastName();
          String DOB = DataStorage.getDOB();
        try {
        	  
           Assert.assertNotNull("Failed to find member [" + Firstname + " "+ Lastname
           		+ "] in extreme scale", DBOperation.getExtremeScaleDetailsFromExtremeScaleTable(Firstname, Lastname, DOB));
          }catch (Exception e) {
                 DataStorage.setCustomErrmsg("Exception while getting details from extreme scale::" + e.toString());
                 Assert.fail("Exception while getting extreme scale from PDB Data Base::" + e.toString());
          }
    }
    
    @Then("^I should see \"([^\"]*)\" node in extreme scale$")
    public void I_should_see_node_added_in_extreme_scale(String node) {
          String Firstname= DataStorage.getFirstName();
          String Lastname= DataStorage.getLastName();
          String DOB = DataStorage.getDOB();

		if(Firstname == null || DOB == null)
			Assert.fail("Some or all of the Firstname/Lastname/DOB are coming as null from the Test Data file. Please check test data or the data reading step");

          try {
           Assert.assertTrue("Fail,"+node +" node is not present in extreme scale", DBOperation.getExtremeScaleDetailsFromExtremeScaleTable(Firstname, Lastname, DOB).contains("\""+node+"\":{"));
          }catch (Exception e) {
                 DataStorage.setCustomErrmsg("Exception while getting details from extreme scale::" + e.toString());
                 Assert.fail("Exception while getting extreme scale from PDB Data Base::" + e.toString());
          }
    }
    
    @Then("^I should see the record added in epmp load$")
    public void I_should_see_the_record_added_in_epmp_load() {
          String Firstname= DataStorage.getFirstName();
          String Lastname= DataStorage.getLastName();
          String DOB = DataStorage.getDOB();

		if(Firstname == null || Lastname == null || DOB == null)
			Assert.fail("Some or all of the Firstname/Lastname/DOB are coming as null from the Test Data file. Please check test data or the data reading step");

          try {
          Assert.assertNotNull("Failed to find member [" + Firstname + " "+ Lastname+ "] in epmp load", DBOperation.getDetailsFromEpmpLoadTable(Firstname, Lastname, DOB));
         }catch (Exception e) {
                 DataStorage.setCustomErrmsg("Exception while getting details from epmp load::" + e.toString());
                 Assert.fail("Exception while getting details from PDB Data Base::" + e.toString());
          }
    }

    @Then("^I should see \"([^\"]*)\" in extreme scale$")    
    public void I_should_see_field_added_in_extreme_scale(String field) {
        String Firstname= DataStorage.getFirstName();
        String Lastname= DataStorage.getLastName();
        String DOB = DataStorage.getDOB();

		if(Firstname == null || Lastname == null || DOB == null)
			Assert.fail("Some or all of the Firstname/Lastname/DOB are coming as null from the Test Data file. Please check test data or the data reading step");

		Firstname = Firstname.toUpperCase();
		Lastname = Lastname.toUpperCase();

        try {
         Assert.assertTrue("Fail,"+field +"field is not present in extreme scale", DBOperation.getExtremeScaleDetailsFromExtremeScaleTable(Firstname, Lastname, DOB).contains("\""+field+"\":"));
         Assert.assertTrue("Fail, "+Firstname +" field is not present in extreme scale", DBOperation.getExtremeScaleDetailsFromExtremeScaleTable(Firstname, Lastname, DOB).toUpperCase().contains("\""+Firstname+"\""));
         Assert.assertTrue("Fail, "+Lastname +" field is not present in extreme scale", DBOperation.getExtremeScaleDetailsFromExtremeScaleTable(Firstname, Lastname, DOB).toUpperCase().contains("\""+Lastname+"\""));
        }catch (Exception e) {
               DataStorage.setCustomErrmsg("Exception while getting details from extreme scale::" + e.toString());
               Assert.fail("Exception while getting extreme scale from PDB Data Base::" + e.toString());
        }
  }
    
    @Then("^I should see \"([^\"]*)\" is set as \"([^\"]*)\" in extreme scale$")
    public void I_should_see_healthsafeIdFlagStatus_SetAs_True_extreme_scale(String node, String flagStatus) {
          String Firstname= DataStorage.getFirstName();
          String Lastname= DataStorage.getLastName();
          String DOB = DataStorage.getDOB();

		if(Firstname == null || Lastname == null || DOB == null)
			Assert.fail("Some or all of the Firstname/Lastname/DOB are coming as null from the Test Data file. Please check test data or the data reading step");

          try {
            Assert.assertTrue("Fail,"+node +" is not set "+ flagStatus+" in extreme scale", DBOperation.getExtremeScaleDetailsFromExtremeScaleTable(Firstname, Lastname, DOB).contains("\""+node+"\":"+flagStatus+""));
          }catch (Exception e) {
                 DataStorage.setCustomErrmsg("Exception while getting details from extreme scale::" + e.toString());
                 Assert.fail("Exception while getting extreme scale from PDB Data Base::" + e.toString());
          }
    }

	@Given("^I should see \"([^\"]*)\" as \"([^\"]*)\" in extreme scale$")
	public void iShouldSeeAsInExtremeScale(String nodeName, String nodeValue) {
		String Firstname= DataStorage.getFirstName();
		String Lastname= DataStorage.getLastName();
		String DOB = DataStorage.getDOB();

		if(Firstname == null || Lastname == null || DOB == null)
			Assert.fail("Some or all of the Firstname/Lastname/DOB are coming as null from the Test Data file. Please check test data or the data reading step");

		try {
			String extremeScaleDetail = DBOperation.getExtremeScaleDetailsFromExtremeScaleTable(Firstname, Lastname, DOB);
			if(extremeScaleDetail == null)
				Assert.fail("No extreme scale record found for the the user with FirstName: "+Firstname+", LastName: "+Lastname+", DOB: "+DOB);

			Assert.assertTrue("Fail, ["+nodeName+"] field value is incorrect in extreme scale", extremeScaleDetail.contains("\""+nodeName+"\":"+"\""+nodeValue+"\""));
		}catch (Exception e) {
			DataStorage.setCustomErrmsg("Exception while getting details from extreme scale::" + e.toString());
			Assert.fail("Exception while getting extreme scale from PDB Data Base::" + e.toString());
		}
	}

	@Given("^I verify \"([^\"]*)\" contains \"([^\"]*)\" in extreme scale$")
	public void verifyFieldContains(String nodeName, String nodeValue) {
		String Firstname= DataStorage.getFirstName();
		String Lastname= DataStorage.getLastName();
		String DOB = DataStorage.getDOB();

		if(Firstname == null || Lastname == null || DOB == null)
			Assert.fail("Some or all of the Firstname/Lastname/DOB are coming as null from the Test Data file. Please check test data or the data reading step");

		try {
			Assert.assertTrue("Fail,"+nodeName +" and "+nodeValue+" combination is not present in extreme scale", DBOperation.getExtremeScaleDetailsFromExtremeScaleTable(Firstname, Lastname, DOB).contains("\""+nodeName+"\":"+"\""+nodeValue));
		}catch (Exception e) {
			DataStorage.setCustomErrmsg("Exception while getting details from extreme scale::" + e.toString());
			Assert.fail("Exception while getting extreme scale from PDB Data Base::" + e.toString());
		}
	}

    @Then("^I should see portal ID as \"([^\"]*)\" in member portal table in PDB database$")
   	public void I_should_see_portalId_in_member_portal_table_for_member(int portalID) throws SQLException {
   		String Firstname = DataStorage.getFirstName();
   		String Lastname = DataStorage.getLastName();
   		Assert.assertEquals(portalID, page.returnPortalIDFromMBR_PRTLTable(Firstname, Lastname));
   	}
    
    @Then("^I should see Member Register ID as \"([^\"]*)\" in member table in PDB database$")
   	public void I_should_see_Member_Register_in_member_table_for_member(int typeID) throws SQLException {
   		String Firstname = DataStorage.getFirstName();
   		String Lastname = DataStorage.getLastName();
   		String DOB = DataStorage.getDOB();
   		Assert.assertEquals(typeID, page.returnMemRegisTypeIDFromMBRTable(Firstname, Lastname, DOB));
   	}
    
    @Then("^I should see Member Register ID as \"([^\"]*)\" in member table in PDB database for \"([^\"]*)\" portal$")
   	public void I_should_see_Member_Register_in_member_table_for_member(int typeID, String portalName) throws SQLException {
   		String Firstname = DataStorage.getFirstName();
   		String Lastname = DataStorage.getLastName();
   		String DOB = DataStorage.getDOB();
   		Assert.assertEquals(typeID, page.returnMemRegisTypeIDFromMBRTablePortalSpecific(Firstname, Lastname, DOB, portalName));
   	}

    
    // code implemented for member portal SSN validation
    @Given("^I should see the member portal dob as not null$")
    public void iShouldSeeThememberportaldobAsNotNull() throws SQLException, InterruptedException {
    	String firstName= DataStorage.getFirstName();
        String lastName= DataStorage.getLastName();
        int memberDob = DBOperation.returnMemPrtlDOB(firstName, lastName);
        Assert.assertNotEquals("Exception occured while connecting to PDB.", -1, memberDob);
        Assert.assertNotEquals(0, memberDob);
        Thread.sleep(1000);
    }
    
    @Given("^I should see the member portal provision mbr id as not null$")
    public void iShouldSeeThememberportalsubscriberidAsNotNull() throws Exception {
    	String firstName= DataStorage.getFirstName();
        String lastName= DataStorage.getLastName();
        int memberEid = DBOperation.returnMemPrtlPrvsMbrId(firstName, lastName);
        Assert.assertNotEquals("Exception occured while connecting to PDB.", -1, memberEid);
        Assert.assertNotEquals(0, memberEid);
    }
    
    @Given("^I should see the member portal zipCode as not null$")
    public void iShouldSeeThememberportalzipCodeAsNotNull() throws SQLException {
    	String firstName= DataStorage.getFirstName();
        String lastName= DataStorage.getLastName();
        int memberEid = DBOperation.returnMemPrtlPrvsMbrzipCode(firstName, lastName);
        Assert.assertNotEquals("Exception occured while connecting to PDB.", -1, memberEid);
        Assert.assertNotEquals(0, memberEid);
    }
    
    @Given("^I should see the member portal policy number as not null$")
    public void iShouldSeeThememberportalpolicynumberAsNotNull() throws SQLException {
    	String firstName= DataStorage.getFirstName();
        String lastName= DataStorage.getLastName();
        int memberEid = DBOperation.returnMemPrtlPrvsMbrPolicyNumber(firstName, lastName);
        Assert.assertNotEquals("Exception occured while connecting to PDB.", -1, memberEid);
        Assert.assertNotEquals(0, memberEid);
    }
    
    @Then("^I should see the subscriberid added in member portal table in PDB database$")
	public void I_should_see_the_subscriberid_added_in_member_portal_table_for_member() throws SQLException {
		String firstName = DataStorage.getFirstName();
		String lastName = DataStorage.getLastName();
		String subId = DBOperation.getPortalSubscriberIDFromPDB(firstName, lastName);
		Assert.assertNotEquals("Exception occured while connecting to PDB.", -1, subId);
		Assert.assertNotEquals(null, subId);

	}
    
    @Then("^I should see the ssn added in member portal table in PDB database$")
  	public void I_should_see_the_ssn_added_in_member_portal_table_for_member() throws SQLException, InterruptedException {
  		String firstName = DataStorage.getFirstName();
  		String lastName = DataStorage.getLastName();
  		String ssn = DBOperation.getPortalSSNFromPDB(firstName, lastName);
  		Assert.assertNotEquals("Exception occured while connecting to PDB.", -1, ssn);
  		Assert.assertNotEquals(null, ssn);
  		Thread.sleep(3000);

  	}
    
    @Then("^I should see the Encryptedssn added in member portal table in PDB database$")
  	public void I_should_see_the_Encryptedssn_added_in_member_portal_table_for_member() throws SQLException,InterruptedException {
  		String firstName = DataStorage.getFirstName();
  		String lastName = DataStorage.getLastName();
  		String enSsn = DBOperation.getPortalEnSSNFromPDB(firstName, lastName);
  		Assert.assertNotEquals("Exception occured while connecting to PDB.", -1, enSsn);
  		Assert.assertNotEquals(null, enSsn);
  		Thread.sleep(3000);
  	}

    @Given("^(member|login) \"([^\"]*)\" is updated by \"([^\"]*)\" in PDB to validate dupcheck scenarios$")
	public void member_is_updated_by_in_PDB_to_validate_dupcheck_scenarios(String userDataType, String arg1, String arg2) throws SQLException {
		String xmlNode = "";
		if (userDataType.equals("member")) {
			xmlNode = "/Users/";
		} else if (userDataType.equals("login")) {
			xmlNode = "/Logins/";
		}
		String FirstName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg1, "FirstName");
		String LastName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg1, "LastName");
		String U_FirstName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg2, "U_FirstName");
		String U_LastName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg2, "U_LastName");
		String U_DOB = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg2, "U_DOB");
		String U_Zip = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg2, "U_Zip");
		String U_SSN = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg2, "U_SSN");
		int provisionMbrId = DBOperation.provisionMbrId(FirstName, LastName);
		try {			
			DBOperation.updateRecordFromPDB(U_FirstName, U_LastName, U_DOB, U_Zip, U_SSN, provisionMbrId);
		} catch (Exception e) {
			DataStorage.setCustomErrmsg("Failed to Connect to PDB Data Base    :" + e.toString());
			Assert.fail("Failed to Connect to PDB Data Base    :" + e.toString());

		}
	}
    
    @Given("^(member|login) \"([^\"]*)\" is updated by \"([^\"]*)\" in member table in PDB for user having mbrId$")
	public void member_is_updated_by_in_member_table_in_PDB_for_member_having_memberId(String userDataType, String actual_data, String updated_data) throws Throwable {
		String xmlNode = "";
		if (userDataType.equals("member")) {
			xmlNode = "/Users/";
		} else if (userDataType.equals("login")) {
			xmlNode = "/Logins/";
		}
		String FirstName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + actual_data, "FirstName");
		String LastName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + actual_data, "LastName");
		String U_FirstName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + updated_data, "U_FirstName");
		String U_LastName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + updated_data, "U_LastName");
		String U_DOB = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + updated_data, "U_DOB");
		String U_Zip = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + updated_data, "U_Zip");
		String U_SubscriberID = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + updated_data, "U_SubscriberID");
		int provisionMbrId = DBOperation.provisionMbrId(FirstName, LastName);
		try {			
			DBOperation.updateRecordInMemberTable(U_FirstName, U_LastName, U_DOB, U_Zip, U_SubscriberID, provisionMbrId);
		} catch (Exception e) {
			DataStorage.setCustomErrmsg("Failed to Connect to PDB Data Base    :" + e.toString());
			Assert.fail("Failed to Connect to PDB Data Base    :" + e.toString());

		}
	}
    
    @Given("^(member|login) \"([^\"]*)\" is updated by \"([^\"]*)\" in member portal table in PDB for user having mbrId$")
	public void member_is_updated_by_in_member_portal_table_in_PDB_for_member_having_memberId(String userDataType, String actual_data, String updated_data) throws Throwable {
		String xmlNode = "";
		if (userDataType.equals("member")) {
			xmlNode = "/Users/";
		} else if (userDataType.equals("login")) {
			xmlNode = "/Logins/";
		}
		String FirstName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + actual_data, "FirstName");
		String LastName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + actual_data, "LastName");
		String U_FirstName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + updated_data, "U_FirstName");
		String U_LastName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + updated_data, "U_LastName");
		String U_DOB = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + updated_data, "U_DOB");
		String U_Zip = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + updated_data, "U_Zip");
		String U_SubscriberID = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + updated_data, "U_SubscriberID");
		int provisionMbrId = DBOperation.provisionMbrId(FirstName, LastName);
		try {			
			DBOperation.updateRecordInMemberPotalTable(U_FirstName, U_LastName, U_DOB, U_Zip, U_SubscriberID, provisionMbrId);
		} catch (Exception e) {
			DataStorage.setCustomErrmsg("Failed to Connect to PDB Data Base    :" + e.toString());
			Assert.fail("Failed to Connect to PDB Data Base    :" + e.toString());

		}
	}

	@Given("^I get the fields from xml file to update (member|login) \"([^\"]*)\" in (MBR|MBR_PRTL) Table$")
	public void update_mbr_table_By_Given_Fields(String userDataType, String update, String table) {
		String xmlNode = "";
		if (userDataType.equals("member")) {
			xmlNode = "/Users/";
		} else if (userDataType.equals("login")) {
			xmlNode = "/Logins/";
		}

		List<String> nodeList;
		nodeList = ReadXMLData.getNodeList(DataStorage.getPortalName() + xmlNode, update);

		Assert.assertNotNull("Failed to find the nodes in xml data", nodeList);

		for (String item : nodeList) {
			if (item.equals("PRVSN_MBR_ID")) {
				continue;
			}

			String field = null;

			if (item.equals("U_FirstName")) {
				field = table.equals("MBR") ? "MDM_FST_NM" : "MBR_PRTL_FST_NM";
			} else if (item.equals("U_LastName")) {
				field = table.equals("MBR") ? "MDM_LST_NM" : "MBR_PRTL_LST_NM";
			} else if (item.equals("U_DOB")) {
				field = table.equals("MBR") ? "MDM_MBR_DOB" : "MBR_PRTL_DOB";
			} else if (item.equals("U_Zip")) {
				field = table.equals("MBR") ? "MDM_MBR_ZIP_CD" : "MBR_PRTL_ZIP_CD";
			} else if (item.equals("U_SubscriberID")) {
				field = table.equals("MBR") ? "MDM_MBR_SBSCR_ID" : "MBR_PRTL_SBSCR_ID";
			} else if (item.equals("U_GroupNumber")) {
				field = table.equals("MBR") ? "MDM_MBR_POL_NBR" : "MBR_PRTL_POL_NBR";
			} else if (item.equals("U_SSN")) {
				field = table.equals("MBR") ? "MDM_MBR_SSN" : "MBR_PRTL_SSN";
			} else if (item.equals("U_AltId")) {
				Assert.assertEquals("Alt Id field is not present in mbr table","MBR_PRTL",table);
				field = "MBR_PRTL_SPC_MBR_ID";
			} else if (item.equals("U_HealthSafeId")) {
				Assert.assertEquals("HealthSafeId field is not present in mbr table","MBR",table);
				field = "HLTHSF_ID";
			} else {
				System.out.println("Check if you have used the correct node name");
			}
			Assert.assertNotNull("either the field is not present in MBR table or not implemented", field);

			String value = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + update, item);
			String provisionMbrId = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + update, "PRVSN_MBR_ID");

			try {
				if (table.equals("MBR")) {
					DBOperation.updateFieldInMemberTable(field, value, provisionMbrId);
				} else {
					DBOperation.updateFieldInMemberPortalTable(field, value, provisionMbrId);
				}

			} catch (Exception e) {
				DataStorage.setCustomErrmsg("Failed to Connect to PDB Data Base    :" + e.toString());
				Assert.fail("Failed to Connect to PDB Data Base    :" + e.toString());

			}
		}
	}
    
	@Then("^I should see \"([^\"]*)\" in extreme scale for apostrophe data$")
	public void I_should_see_field_added_in_extreme_scale_for_apostrophe_data(String field) {
		String Firstname = DataStorage.getFirstName();
		String Lastname = DataStorage.getLastName();
		try {
			Assert.assertTrue("Fail," + field + "field is not present in extreme scale",
					DBOperation.getExtremeScaleDetailsFromExtremeScaleTableForApostropheData(Firstname, Lastname)
							.contains("\"" + field + "\":"));
		} catch (Exception e) {
			DataStorage.setCustomErrmsg("Exception while getting details from extreme scale::" + e.toString());
			Assert.fail("Exception while getting extreme scale from PDB Data Base::" + e.toString());
		}
	}

	@Then("^I should see \"([^\"]*)\" node in extreme scale for apostrophe data$")
	public void I_should_see_node_added_in_extreme_scale_for_apostrophe_data(String node) {
		String Firstname = DataStorage.getFirstName();
		String Lastname = DataStorage.getLastName();
		try {
			Assert.assertTrue("Fail," + node + "node is not present in extreme scale",
					DBOperation.getExtremeScaleDetailsFromExtremeScaleTableForApostropheData(Firstname, Lastname)
							.contains("\"" + node + "\":{"));
		} catch (Exception e) {
			DataStorage.setCustomErrmsg("Exception while getting details from extreme scale::" + e.toString());
			Assert.fail("Exception while getting extreme scale from PDB Data Base::" + e.toString());
		}
	}
	
	@Given("^(member|login) \"([^\"]*)\" does not pre-exist in Extremescale$")
	public void member_does_not_preexist_in_Extremescale(String userDataType, String dataNode) {
		String xmlNode = "";
		if (userDataType.equals("member")) {
			xmlNode = "/Users/";
		} else if (userDataType.equals("login")) {
			xmlNode = "/Logins/";
		}
		String firstName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + dataNode, "FirstName");
		String lastName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + dataNode, "LastName");
		String DOB = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + dataNode, "DOB");

		String dbFormatDOB = new PageObjectBase().getDateInYYYY_MM_DDFormat(DOB);
		try {
			DBOperation.deleteRecordFromExtremeScale(firstName, lastName, dbFormatDOB);
		} catch (Exception e) {
			DataStorage.setCustomErrmsg("Failed to Connect to PDB Data Base    :" + e.toString());
			Assert.fail("Failed to Connect to PDB Data Base    :" + e.toString());

		}
	}
	
	@Given("^I should see valid values for below details in mbr table$")
	public void iShouldSeeValidValuesForBelowDetailsInMbrTable(List<String> inputKeys) throws SQLException {
		Map<String, String> userDetails = DBOperation.getRecordFromMBRTableByFN_LN_DOB_and_PortalID();
		for (String key : inputKeys) {
			Assert.assertTrue("Please check if you are looking for correct detail- "+key,userDetails.containsKey(key));
			if (key.equals("Zip") && userDetails.get(key)!=null) {
				Assert.assertTrue("Expected Zip value from testdata file is- "+ DataStorage.getZip()+", But actual value(MDM_MBR_ZIP_CD) from mbr table is- "+userDetails.get(key), userDetails.get(key).contains(DataStorage.getZip()));
			} else if(key.equals("Zip1") && userDetails.get(key)!=null) {
				Assert.assertTrue("Expected Zip1 value from testdata file is- "+ DataStorage.getZip1()+", But actual value(MDM_MBR_ZIP_CD) from mbr table is- "+userDetails.get(key), userDetails.get(key).contains(DataStorage.getZip1()));
			} else if (key.equals("EID") && userDetails.get(key)!=null) {
				Assert.assertTrue("Expected EID value from testdata file is- "+ DataStorage.getEID()+", But actual value(MDM_MBR_EID) from mbr table is- "+userDetails.get(key), userDetails.get(key).contains(DataStorage.getEID()));
			} else if (key.equals("MDMSubId") && userDetails.get(key)!=null) {
				Assert.assertTrue("Expected MDMSubId value from testdata file is- "+ DataStorage.getMDMSubId()+", But actual value(MDM_MBR_SBSCR_ID) from mbr table is- "+userDetails.get(key), userDetails.get(key).contains(DataStorage.getMDMSubId()));
			} else if (key.equals("GroupNumber") && userDetails.get(key)!=null) {
				Assert.assertTrue("Expected GroupNumber value from testdata file is- "+ DataStorage.getGroupNumber()+", But actual value(MDM_MBR_POL_NBR) from mbr table is- "+userDetails.get(key), userDetails.get(key).contains(DataStorage.getGroupNumber()));
			} else if (key.equals("Account") && userDetails.get(key)!=null) {
				Assert.assertTrue("Expected Account value from testdata file is- "+ DataStorage.getAccount()+", But actual value(MDM_MBR_ACCT_ID) from mbr table is- "+userDetails.get(key), userDetails.get(key).contains(DataStorage.getAccount()));
			} else if (key.equals("carrier") && userDetails.get(key)!=null) {
				Assert.assertTrue("Expected carrier value from testdata file is- "+ DataStorage.getcarrier()+", But actual value(MDM_MBR_CARR_ID) from mbr table is- "+userDetails.get(key), userDetails.get(key).contains(DataStorage.getcarrier()));
			} else if (key.equals("SSN")) {
					if(DataStorage.getSSNPDB().equalsIgnoreCase("Null"))
						Assert.assertNull("MDM_MBR_SSN is not null in member table",userDetails.get("SSN"));
					else
						Assert.assertNotNull("MDM_MBR_SSN is null in member table",userDetails.get("SSN"));
			} else if (key.equals("RgstPrtlID")){
			    Assert.assertTrue("Expected RGST_PRTL_ID value from testdata file is - "+ DataStorage.getRgstPrtlID()+", But actual value(MBR_RGST_PRTL_ID) from mbr table is- "+userDetails.get(key), userDetails.get(key).contains(DataStorage.getRgstPrtlID()));
            		} else	{
				Assert.fail("The value of "+key+ " is null in mbr table");
			}
		}
	}
	
	@Given("^I should see \"([^\"]*)\" as \"([^\"]*)\" in member table$")
    public void iShouldSeeAsInMemberTable(String columnName, String columnValue) {
           String Firstname= DataStorage.getFirstName();
           String Lastname= DataStorage.getLastName();
           String dob= DataStorage.getDOB();

           if(Firstname == null || Lastname == null || dob == null)
           	Assert.fail("Some or all of the Firstname/Lastname/DOB are coming as null from the Test Data file. Please check test data or the data reading step");

           try {
            Assert.assertTrue(""+columnName +" is not maching with value in member table", DBOperation.getColumnValueFromMemberTable(Firstname, Lastname, columnName, dob).equalsIgnoreCase(columnValue));
           }catch (Exception e) {
                  DataStorage.setCustomErrmsg("Exception while getting details from member table::" + e.toString());
                  Assert.fail("Exception while getting value from PDB Data Base::" + e.toString());
           }
     }

	@Given("^I should see valid values for below details in mbr portal table for \"([^\"]*)\" portal$")
	public void iShouldSeeValidValuesForBelowDetailsInMbrPortalTableForPortal(String portalName, List<String> inputKeys)
			throws Throwable {
		Map<String, String> userDetails = DBOperation.getRecordFromMBRPRTLTableByProvisionID(portalName);

		String dateOfBirth = new PageObjectBase().getDateInYYYY_MM_DDFormat(DataStorage.getDOB());

		Assert.assertTrue("Expected FirstName value from testdata file is- "+ DataStorage.getFirstName()+", But actual value(MBR_PRTL_FST_NM) from mbr_prtl table is- "+userDetails.get("FirstName"), userDetails.get("FirstName").equalsIgnoreCase(DataStorage.getFirstName()));
		Assert.assertTrue("Expected LastName value from testdata file is- "+ DataStorage.getLastName()+", But actual value(MBR_PRTL_LST_NM) from mbr_prtl table is- "+userDetails.get("LastName"), userDetails.get("LastName").equalsIgnoreCase(DataStorage.getLastName()));
		Assert.assertTrue("Expected DOB value from testdata file is- "+ DataStorage.getDOB()+", But actual value(MBR_PRTL_DOB) from mbr_prtl table is- "+userDetails.get("DOB"), userDetails.get("DOB").equalsIgnoreCase(dateOfBirth));

		if(DataStorage.getPortalName().equalsIgnoreCase(portalName)) {

			for (String key : inputKeys) {
				Assert.assertTrue("Please check if you are looking for correct detail- "+key,userDetails.containsKey(key));
					if (key.equals("Zip") && userDetails.get(key)!=null) {
						Assert.assertTrue("Expected Zip value from testdata file is- "+ DataStorage.getZip()+", But actual value(MBR_PRTL_ZIP_CD) from mbr_prtl table is- "+userDetails.get(key), userDetails.get(key).contains(DataStorage.getZip()));
					} else if(key.equals("Zip1") && userDetails.get(key)!=null) {
						Assert.assertTrue("Expected Zip1 value from testdata file is- "+ DataStorage.getZip1()+", But actual value(MBR_PRTL_ZIP_CD) from mbr_prtl table is- "+userDetails.get(key), userDetails.get(key).contains(DataStorage.getZip1()));
					} else if (key.equals("PrtlSubId") && userDetails.get(key)!=null) {
						Assert.assertTrue("Expected PrtlSubId value from testdata file is- "+ DataStorage.getPrtlSubId()+", But actual value(MBR_PRTL_SBSCR_ID) from mbr_prtl table is- "+userDetails.get(key), userDetails.get(key).contains(DataStorage.getPrtlSubId()));
					} else if (key.equals("AltId") && userDetails.get(key)!=null) {
						Assert.assertTrue("Expected AltId value from testdata file is- "+ DataStorage.getAltId()+", But actual value(MBR_PRTL_SPC_MBR_ID) from mbr_prtl table is- "+userDetails.get(key), userDetails.get(key).contains(DataStorage.getAltId()));
					} else if (key.equals("GroupNumber") && userDetails.get(key)!=null) {
						Assert.assertTrue("Expected GroupNumber value from testdata file is- "+ DataStorage.getGroupNumber()+", But actual value(MBR_PRTL_POL_NBR) from mbr_prtl table is- "+userDetails.get(key), userDetails.get(key).contains(DataStorage.getGroupNumber()));
					}else if (key.equals("PrtlSSN")) {
						if(DataStorage.getPrtlSSN().equalsIgnoreCase("Null"))
							Assert.assertNull("MBR_PRTL_SSN is not null in mbr_prtl table",userDetails.get("PrtlSSN"));
						else 
							Assert.assertNotNull("MBR_PRTL_SSN is null in mbr_prtl table",userDetails.get("PrtlSSN"));
					} else if (key.equals("SSN")) {
						if(DataStorage.getSSNPDB().equalsIgnoreCase("Null")) {
							Assert.assertNull("MBR_PRTL_SSN is not null in mbr_prtl table",userDetails.get("SSN"));
						}else {
							Assert.assertNotNull("MBR_PRTL_SSN is null in mbr_prtl table",userDetails.get("SSN"));
						}
					}
				}
		}
		else {
			for (String key : inputKeys) {
				if (key.contains("PrtlSubId") && userDetails.get("PrtlSubId")!=null) {
					Assert.assertTrue("Expected PrtlSubId value from testdata file is- "+ ReadXMLData.getTestData(DataStorage.getuserRootNode(), "PrtlSubId_"+portalName)+", But actual value(MBR_PRTL_SBSCR_ID) from mbr_prtl table is- "+userDetails.get("PrtlSubId"), userDetails.get("PrtlSubId").contains(ReadXMLData.getTestData(DataStorage.getuserRootNode(), "PrtlSubId_"+portalName)));
				} else if (key.contains("AltId") && userDetails.get("AltId")!=null) {
					Assert.assertTrue("Expected AltId value from testdata file is- "+ ReadXMLData.getTestData(DataStorage.getuserRootNode(), "AltId_"+portalName)+", But actual value(MBR_PRTL_SPC_MBR_ID) from mbr_prtl table is- "+userDetails.get("AltId"), userDetails.get("AltId").contains(ReadXMLData.getTestData(DataStorage.getuserRootNode(), "AltId_"+portalName)));
				} else if (key.contains("GroupNumber") && userDetails.get("GroupNumber")!=null) {
					Assert.assertTrue("Expected GroupNumber value from testdata file is- "+ ReadXMLData.getTestData(DataStorage.getuserRootNode(), "GroupNumber_"+portalName)+", But actual value(MBR_PRTL_POL_NBR) from mbr_prtl table is- "+userDetails.get("GroupNumber"), userDetails.get("GroupNumber").contains(ReadXMLData.getTestData(DataStorage.getuserRootNode(), "GroupNumber_"+portalName)));
				}else if (key.contains("SSN")) {
					if(DataStorage.getSSNPDB().equalsIgnoreCase("Null")) {
						Assert.assertNull("MBR_PRTL_SSN is not null in mbr_prtl table",userDetails.get("SSN"));
					}else {
						Assert.assertNotNull("MBR_PRTL_SSN is null in mbr_prtl table",userDetails.get("SSN"));
					}
				} else if(key.contains("Zip") && userDetails.get("Zip")!=null) {
					Assert.assertTrue("Expected Zip value from testdata file is- "+ ReadXMLData.getTestData(DataStorage.getuserRootNode(), "Zip_"+portalName)+", But actual value(MBR_PRTL_ZIP_CD) from mbr_prtl table is- "+userDetails.get("Zip"), userDetails.get("Zip").contains(ReadXMLData.getTestData(DataStorage.getuserRootNode(), "Zip_"+portalName)));
				} else	{
					Assert.fail("Not able to find "+key+"_"+portalName+" in mbr_prtl table or the value is null");
				}
			}
		}
	}

	@Then("^I should see valid values for below details under \"([^\"]*)\" node in extreme scale$")
	public void iShouldSeeValidValuesForBelowDetailsUnderNodeInExtremeScale(String nodeName, List<String> userDetails)
			throws SQLException {
		Map<String, Object> extremeScaledetails = DBOperation.getExtremescaledetailsAsMap();
		for (String key : userDetails) {
			if (key.equalsIgnoreCase("FirstName")) {
				if(extremeScaledetails.containsKey(nodeName + ".firstName") && extremeScaledetails.get(nodeName + ".firstName") != JSONObject.NULL ) {
					Assert.assertTrue("Expected FirstName value from testdata file is- "+ DataStorage.getFirstName()+", But actual value("+nodeName+".firstName) from extreme scale is- "+extremeScaledetails.get(nodeName + ".firstName"), DataStorage.getFirstName().equalsIgnoreCase((String) extremeScaledetails.get(nodeName + ".firstName")));
				} else {
					Assert.fail("Please check if "+nodeName+".firstName node doesn't find or returning as null in extreme scale response for FirstName");
				}
			} else if (key.equalsIgnoreCase("LastName")) {
				if(extremeScaledetails.containsKey(nodeName + ".lastName") && extremeScaledetails.get(nodeName + ".lastName") != JSONObject.NULL ) {
					Assert.assertTrue("Expected LastName value from testdata file is- "+ DataStorage.getLastName()+", But actual value("+nodeName+".lastName) from extreme scale is- "+extremeScaledetails.get(nodeName + ".lastName"), DataStorage.getLastName().equalsIgnoreCase((String) extremeScaledetails.get(nodeName + ".lastName"))||((String)extremeScaledetails.get(nodeName + ".lastName")).contains(DataStorage.getLastName().toUpperCase()));
				} else {
					Assert.fail("Please check if "+nodeName+".lastName node doesn't find or returning as null in extreme scale response for LastName");
				}
				
			} else if (key.equalsIgnoreCase("customerId")) {
				if(extremeScaledetails.containsKey(nodeName + ".customerId") && extremeScaledetails.get(nodeName + ".customerId") != JSONObject.NULL ) {
					Assert.assertTrue("Expected customerId value from testdata file is- "+ DataStorage.getcustomerId()+", But actual value("+nodeName+".customerId) from extreme scale is- "+extremeScaledetails.get(nodeName + ".customerId"), DataStorage.getcustomerId().equalsIgnoreCase((String) extremeScaledetails.get(nodeName + ".customerId")));
				} else {
					Assert.fail("Please ensure that "+nodeName+".customerId is present and is not null");
				}
				
			} else if (key.equalsIgnoreCase("DOB")) {
				if(extremeScaledetails.containsKey(nodeName + ".birthDate") && extremeScaledetails.get(nodeName + ".birthDate") != JSONObject.NULL ) {
					Assert.assertTrue("Expected DOB value from testdata file is- "+ DataStorage.getDOB()+", But actual value("+nodeName+".birthDate) is- "+(String)extremeScaledetails.get(nodeName + ".birthDate"),((String)extremeScaledetails.get(nodeName + ".birthDate")).contains(DataStorage.getDOB()));
				} else if(extremeScaledetails.containsKey(nodeName + ".dateOfBirth") && extremeScaledetails.get(nodeName + ".dateOfBirth") != JSONObject.NULL) {
					Assert.assertTrue("Expected DOB value from testdata file is- "+ DataStorage.getDOB()+", But actual value("+nodeName+".dateOfBirth) is- "+(String)extremeScaledetails.get(nodeName + ".dateOfBirth"),((String)extremeScaledetails.get(nodeName + ".dateOfBirth")).contains(DataStorage.getDOB()));
				} else if(extremeScaledetails.containsKey(nodeName + ".dob") && extremeScaledetails.get(nodeName + ".dob") != JSONObject.NULL) {
					Assert.assertTrue("Expected DOB value from testdata file is- " + DataStorage.getDOB() + ", But actual value(" + nodeName + ".dob) is- " + (String) extremeScaledetails.get(nodeName + ".dob"), ((String) extremeScaledetails.get(nodeName + ".dob")).contains(DataStorage.getDOB()));
				} else {
					Assert.fail("Please check if "+nodeName+".birthDate or "+nodeName+".dateOfBirth or "+nodeName+".dob nodes doesn't find or returning as null in extreme scale response for DOB");
				}
			} else if (key.equalsIgnoreCase("DOB1")) {
				if(extremeScaledetails.containsKey(nodeName + ".birthDate") && extremeScaledetails.get(nodeName + ".birthDate") != JSONObject.NULL ) {
					Assert.assertTrue("Expected DOB1 value from testdata file is- "+ DataStorage.getDOB1()+", But actual value("+nodeName+".birthDate) is- "+(String)extremeScaledetails.get(nodeName + ".birthDate"),((String)extremeScaledetails.get(nodeName + ".birthDate")).contains(DataStorage.getDOB1()));
				} else if(extremeScaledetails.containsKey(nodeName + ".dateOfBirth") && extremeScaledetails.get(nodeName + ".dateOfBirth") != JSONObject.NULL) {
					Assert.assertTrue("Expected DOB1 value from testdata file is- "+ DataStorage.getDOB1()+", But actual value("+nodeName+".dateOfBirth) is- "+(String)extremeScaledetails.get(nodeName + ".dateOfBirth"),((String)extremeScaledetails.get(nodeName + ".dateOfBirth")).contains(DataStorage.getDOB1()));
				} else if(extremeScaledetails.containsKey(nodeName + ".dob") && extremeScaledetails.get(nodeName + ".dob") != JSONObject.NULL) {
					Assert.assertTrue("Expected DOB1 value from testdata file is- " + DataStorage.getDOB1() + ", But actual value(" + nodeName + ".dob) is- " + (String) extremeScaledetails.get(nodeName + ".dob"), ((String) extremeScaledetails.get(nodeName + ".dob")).contains(DataStorage.getDOB1()));
				} else {
					Assert.fail("Please check if "+nodeName+".birthDate or "+nodeName+".dateOfBirth or "+nodeName+".dob nodes doesn't find or returning as null in extreme scale response for DOB1");
				}
			} else if (key.equalsIgnoreCase("Zip")) {
				if(extremeScaledetails.containsKey(nodeName + ".zip") && extremeScaledetails.get(nodeName + ".zip") != JSONObject.NULL ) {
					Assert.assertTrue("Expected Zip value from testdata file is- "+ DataStorage.getZip()+", But actual value("+nodeName+".zip) from extreme scale is- "+extremeScaledetails.get(nodeName + ".zip"), ((String)extremeScaledetails.get(nodeName + ".zip")).contains(DataStorage.getZip()));
				} else {
					Assert.fail("Please check if "+nodeName+".zip node doesn't find or returning as null in extreme scale response for Zip");
				}
			} else if (key.equalsIgnoreCase("Zip1")) {
				if (extremeScaledetails.containsKey(nodeName + ".zip") && extremeScaledetails.get(nodeName + ".zip") != JSONObject.NULL) {
					Assert.assertTrue("Expected Zip1 value from testdata file is- " + DataStorage.getZip1() + ", But actual value(" + nodeName + ".zip) from extreme scale is- " + extremeScaledetails.get(nodeName + ".zip"), ((String) extremeScaledetails.get(nodeName + ".zip")).contains(DataStorage.getZip1()));
				} else {
					Assert.fail("Please check if " + nodeName + ".zip node doesn't find or returning as null in extreme scale response for Zip1");
				}
			}  else if (key.equalsIgnoreCase("MDMSubId")) {
				if(extremeScaledetails.containsKey(nodeName + ".subscriberId") && extremeScaledetails.get(nodeName + ".subscriberId") != JSONObject.NULL ) {
					Assert.assertTrue("Expected MDMSubId value from testdata file is- "+ DataStorage.getMDMSubId()+", But actual value("+nodeName+".subscriberId) from extreme scale is- "+extremeScaledetails.get(nodeName + ".subscriberId"),((String)extremeScaledetails.get(nodeName + ".subscriberId")).contains(DataStorage.getMDMSubId()));
				} else if(extremeScaledetails.containsKey(nodeName + ".subscriberid") && extremeScaledetails.get(nodeName + ".subscriberid") != JSONObject.NULL) {
					Assert.assertTrue("Expected MDMSubId value from testdata file is- "+ DataStorage.getMDMSubId()+", But actual value("+nodeName+".subscriberid) is- "+(String)extremeScaledetails.get(nodeName + ".subscriberid"),((String)extremeScaledetails.get(nodeName + ".subscriberid")).equalsIgnoreCase(DataStorage.getMDMSubId()));
				} else {
					Assert.fail("Please check if "+nodeName+".subscriberId or "+nodeName+".subscriberid doesn't find or returning as null in extreme scale response for MDMSubId");
				}
			} else if (key.equalsIgnoreCase("irisId")) {
				if(extremeScaledetails.containsKey(nodeName + ".irisId") && extremeScaledetails.get(nodeName + ".irisId") != JSONObject.NULL ) {
					Assert.assertTrue("Expected irisId value from testdata file is- "+ DataStorage.getirisId()+", But actual value("+nodeName+".irisId) from extreme scale is- "+extremeScaledetails.get(nodeName + ".irisId"),((String)extremeScaledetails.get(nodeName + ".irisId")).contains(DataStorage.getirisId()));
				} else {
					Assert.fail("Please check if "+nodeName+".irisId node doesn't find or returning as null in extreme scale response for irisId");
				}
			} else if (key.equalsIgnoreCase("patientId")) {
				if(extremeScaledetails.containsKey(nodeName + ".patientId")){
				if(DataStorage.getpatientId().equalsIgnoreCase("NULL")) {
					Assert.assertTrue(nodeName+".patientId is not null in extreme scale",extremeScaledetails.get(nodeName + ".patientId") == JSONObject.NULL);
				}
				else {
				 	Assert.assertTrue("Expected patientId value from testdata file is- "+ DataStorage.getpatientId()+", But actual value("+nodeName+".patientId) from extreme scale is- "+extremeScaledetails.get(nodeName + ".patientId"),((String)extremeScaledetails.get(nodeName + ".patientId")).contains(DataStorage.getpatientId()));
				}
				} else {
					Assert.fail("Please check if "+nodeName+".patientId node doesn't find in extreme scale response for patientId");
				}
		
			} else if (key.equalsIgnoreCase("migrationFlag")) {
				if(extremeScaledetails.containsKey(nodeName + ".migrationFlag") && extremeScaledetails.get(nodeName + ".migrationFlag").toString()!=null ) {
					Assert.assertTrue("Expected migrationFlag value from testdata file is- "+ DataStorage.getmigrationFlag()+", But actual value("+nodeName+".migrationFlag) from extreme scale is- "+extremeScaledetails.get(nodeName + ".migrationFlag"),(extremeScaledetails.get(nodeName + ".migrationFlag").toString()).contains(DataStorage.getmigrationFlag()));
				} else {
					Assert.fail("Please check if "+nodeName+".migrationFlag node doesn't find or returning as null in extreme scale response for migrationFlag");
				}
			} else if (key.equalsIgnoreCase("sourceCd")) {
				if(extremeScaledetails.containsKey(nodeName + ".sourceCd") && extremeScaledetails.get(nodeName + ".sourceCd") != JSONObject.NULL ) {
					Assert.assertTrue("Expected sourceCd value from testdata file is- "+ DataStorage.getsourceCd()+", But actual value("+nodeName+".sourceCd) from extreme scale is- "+extremeScaledetails.get(nodeName + ".sourceCd"),((String)extremeScaledetails.get(nodeName + ".sourceCd")).contains(DataStorage.getsourceCd()));
				} else {
					Assert.fail("Please check if "+nodeName+".sourceCd node doesn't find or returning as null in extreme scale response for sourceCd");
				}
			
			} else if (key.equalsIgnoreCase("carrier")) {
				if(extremeScaledetails.containsKey(nodeName + ".carrier") && extremeScaledetails.get(nodeName + ".carrier") != JSONObject.NULL ) {
					Assert.assertTrue("Expected group value from testdata file is- "+ DataStorage.getcarrier()+", But actual value("+nodeName+".carrier) from extreme scale is- "+extremeScaledetails.get(nodeName + ".carrier"),((String)extremeScaledetails.get(nodeName + ".carrier")).contains(DataStorage.getcarrier()));
				} else {
					Assert.fail("Please check if "+nodeName+".carrier node doesn't find or returning as null in extreme scale response for carrier");
				}
				
			} else if (key.equalsIgnoreCase("HealthSafeIdFlag")) {
				if(extremeScaledetails.containsKey(nodeName + ".healthSafeIdFlag") && extremeScaledetails.get(nodeName + ".healthSafeIdFlag").toString()!=null ) {
					Assert.assertTrue("Expected HealthSafeIdFlag value from testdata file is- "+ DataStorage.getHealthSafeIdFlag()+", But actual value("+nodeName+".healthSafeIdFlag) from extreme scale is- "+extremeScaledetails.get(nodeName + ".healthSafeIdFlag"),(extremeScaledetails.get(nodeName + ".healthSafeIdFlag").toString()).equalsIgnoreCase(DataStorage.getHealthSafeIdFlag()));
				} else {
					Assert.fail("Please check if "+nodeName+".healthSafeIdFlag node doesn't find or returning as null in extreme scale response for HealthSafeIdFlag");
				}
			} else if (key.equalsIgnoreCase("FaroId")) {
				if(extremeScaledetails.containsKey(nodeName + ".faroId") && extremeScaledetails.get(nodeName + ".faroId") != JSONObject.NULL ) {
					Assert.assertTrue("Expected FaroId value from testdata file is- "+ DataStorage.getFaroId()+", But actual value("+nodeName+".faroId) from extreme scale is- "+extremeScaledetails.get(nodeName + ".faroId"),((String)extremeScaledetails.get(nodeName + ".faroId")).equalsIgnoreCase(DataStorage.getFaroId()));
				} else {
					Assert.fail("Please check if "+nodeName+".faroId node doesn't find or returning as null in extreme scale response for FaroId");
				}	
			} else if (key.equalsIgnoreCase("Id")) {
				String id = ReadXMLData.getTestData(DataStorage.getuserRootNode(), "Id");
				if(extremeScaledetails.containsKey(nodeName + ".id") && extremeScaledetails.get(nodeName + ".id") != JSONObject.NULL ) {
					Assert.assertTrue("Expected id value from testdata file is- "+ id+", But actual value("+nodeName+".id) from extreme scale is- "+extremeScaledetails.get(nodeName + ".id"),((String)extremeScaledetails.get(nodeName + ".id")).equalsIgnoreCase(id));
				} else {
					Assert.fail("Please check if "+nodeName+".id node doesn't find or returning as null in extreme scale response for Id");
				}
			} else if (key.equalsIgnoreCase("Account")) {
				String account = ReadXMLData.getTestData(DataStorage.getuserRootNode(), "Account");
				if(extremeScaledetails.containsKey(nodeName + ".account") && extremeScaledetails.get(nodeName + ".account") != JSONObject.NULL ) {
					Assert.assertTrue("Expected Account value from testdata file is- "+ account+", But actual value("+nodeName+".account) from extreme scale is- "+extremeScaledetails.get(nodeName + ".account"),((String)extremeScaledetails.get(nodeName + ".account")).equalsIgnoreCase(account));
				} else if(extremeScaledetails.containsKey(nodeName + ".accountName") && extremeScaledetails.get(nodeName + ".accountName") != JSONObject.NULL) {
					Assert.assertTrue("Expected AccountName value from testdata file is- "+ account+", But actual value("+nodeName+".accountName) is- "+(String)extremeScaledetails.get(nodeName + ".accountName"),((String)extremeScaledetails.get(nodeName + ".accountName")).equalsIgnoreCase(account));

					} else {
						Assert.fail("Please check if "+nodeName+".account or "+nodeName+".AccountName nodes doesn't find or returning as null in extreme scale response for Account and AccountName");
					} 
			} else if (key.equalsIgnoreCase("AccountHolderId")) {
				String accountHolderId = ReadXMLData.getTestData(DataStorage.getuserRootNode(), "AccountHolderId");
				if(extremeScaledetails.containsKey(nodeName + ".accountHolderId") && extremeScaledetails.get(nodeName + ".accountHolderId") != JSONObject.NULL ) {
					Assert.assertTrue("Expected AccountHolderId value from testdata file is- "+ accountHolderId+", But actual value("+nodeName+".accountHolderId) from extreme scale is- "+extremeScaledetails.get(nodeName + ".accountHolderId"),((String)extremeScaledetails.get(nodeName + ".accountHolderId")).equalsIgnoreCase(accountHolderId));
				} else {
					Assert.fail("Please check if "+nodeName+".accountHolderId node doesn't find or returning as null in extreme scale response for AccountHolderId");
				}
			} else if (key.equalsIgnoreCase("RecType")) {
				if(extremeScaledetails.containsKey(nodeName) && extremeScaledetails.get(nodeName) != JSONObject.NULL ) {
					Assert.assertTrue("Expected RecType value from testdata file is- "+ DataStorage.getRecType()+", But actual value("+nodeName+") from extreme scale is- "+extremeScaledetails.get(nodeName), ((String)extremeScaledetails.get(nodeName)).equalsIgnoreCase(DataStorage.getRecType()));
				} else {
					Assert.fail("Please check if "+nodeName+" RecType doesn't find or returning as null in extreme scale response");
				}
			} else if (key.equalsIgnoreCase("PrtlSubId")) {
				if(extremeScaledetails.containsKey(nodeName + ".subscriberId") && extremeScaledetails.get(nodeName + ".subscriberId") != JSONObject.NULL) {
					Assert.assertTrue("Expected PrtlSubId value from testdata file is- "+ DataStorage.getPrtlSubId()+", But actual value("+nodeName+".subscriberId) is- "+(String)extremeScaledetails.get(nodeName + ".subscriberId"),((String)extremeScaledetails.get(nodeName + ".subscriberId")).contains(DataStorage.getPrtlSubId()));
				} else if(extremeScaledetails.containsKey(nodeName + ".subscriberid") && extremeScaledetails.get(nodeName + ".subscriberid") != JSONObject.NULL) {
					Assert.assertTrue("Expected PrtlSubId value from testdata file is- "+ DataStorage.getPrtlSubId()+", But actual value("+nodeName+".subscriberid) is- "+(String)extremeScaledetails.get(nodeName + ".subscriberid"),((String)extremeScaledetails.get(nodeName + ".subscriberid")).contains(DataStorage.getPrtlSubId()));
				} else if(extremeScaledetails.containsKey(nodeName + ".memberId") && extremeScaledetails.get(nodeName + ".memberId") != JSONObject.NULL) {
					Assert.assertTrue("Expected PrtlSubId value from testdata file is- "+ DataStorage.getPrtlSubId()+", But actual value("+nodeName+".memberId) is- "+(String)extremeScaledetails.get(nodeName + ".memberId"),((String)extremeScaledetails.get(nodeName + ".memberId")).contains(DataStorage.getPrtlSubId()));
				}
				else {
					Assert.fail("Please check if "+nodeName+".subscriberId or "+nodeName+".subscriberid or "+nodeName+".memberId nodes doesn't find or returning as null in extreme scale response for PrtlSubId");
				}
			} else if (key.equalsIgnoreCase("PrtlSubId1")) {
				if(extremeScaledetails.containsKey(nodeName + ".subscriberId") && extremeScaledetails.get(nodeName + ".subscriberId") != JSONObject.NULL) {
					Assert.assertTrue("Expected PrtlSubId1 value from testdata file is- "+ DataStorage.getPrtlSubId1()+", But actual value("+nodeName+".subscriberId) is- "+(String)extremeScaledetails.get(nodeName + ".subscriberId"),((String)extremeScaledetails.get(nodeName + ".subscriberId")).contains(DataStorage.getPrtlSubId1()));
				} else if(extremeScaledetails.containsKey(nodeName + ".subscriberid") && extremeScaledetails.get(nodeName + ".subscriberid") != JSONObject.NULL) {
					Assert.assertTrue("Expected PrtlSubId1 value from testdata file is- "+ DataStorage.getPrtlSubId1()+", But actual value("+nodeName+".subscriberid) is- "+(String)extremeScaledetails.get(nodeName + ".subscriberid"),((String)extremeScaledetails.get(nodeName + ".subscriberid")).contains(DataStorage.getPrtlSubId1()));
				} else if(extremeScaledetails.containsKey(nodeName + ".memberId") && extremeScaledetails.get(nodeName + ".memberId") != JSONObject.NULL) {
					Assert.assertTrue("Expected PrtlSubId1 value from testdata file is- "+ DataStorage.getPrtlSubId1()+", But actual value("+nodeName+".memberId) is- "+(String)extremeScaledetails.get(nodeName + ".memberId"),((String)extremeScaledetails.get(nodeName + ".memberId")).contains(DataStorage.getPrtlSubId1()));
				}
				else {
					Assert.fail("Please check if "+nodeName+".subscriberId or "+nodeName+".subscriberid or "+nodeName+".memberId nodes doesn't find or returning as null in extreme scale response for PrtlSubId1");
				}
			} else if (key.equalsIgnoreCase("AltId")) {
				if(extremeScaledetails.containsKey(nodeName + ".altSubscriberNbr") && extremeScaledetails.get(nodeName + ".altSubscriberNbr") != JSONObject.NULL) {
					Assert.assertTrue("Expected AltId value from testdata file is- "+ DataStorage.getAltId()+", But actual value("+nodeName+".altSubscriberNbr) is- "+(String)extremeScaledetails.get(nodeName + ".altSubscriberNbr"),((String)extremeScaledetails.get(nodeName + ".altSubscriberNbr")).contains(DataStorage.getAltId()));
				} else if(extremeScaledetails.containsKey(nodeName + ".alternateId") && extremeScaledetails.get(nodeName + ".alternateId") != JSONObject.NULL) {
					Assert.assertTrue("Expected AltId value from testdata file is- "+ DataStorage.getAltId()+", But actual value("+nodeName+".alternateId) is- "+(String)extremeScaledetails.get(nodeName + ".alternateId"),((String)extremeScaledetails.get(nodeName + ".alternateId")).contains(DataStorage.getAltId()));
				}else if(extremeScaledetails.containsKey(nodeName + ".altId") && extremeScaledetails.get(nodeName + ".altId") != JSONObject.NULL) {
					Assert.assertTrue("Expected AltId value from testdata file is- "+ DataStorage.getAltId()+", But actual value("+nodeName+".altId) is- "+(String)extremeScaledetails.get(nodeName + ".altId"),((String)extremeScaledetails.get(nodeName + ".altId")).contains(DataStorage.getAltId()));
				}  
				else {
					Assert.fail("Please check if "+nodeName+".altSubscriberNbr or "+nodeName+".alternateId nodes doesn't find or returning as null in extreme scale response for AltId");
				}
			} else if (key.equalsIgnoreCase("GroupNumber")) {
				if(extremeScaledetails.containsKey(nodeName + ".policy") && extremeScaledetails.get(nodeName + ".policy") != JSONObject.NULL) {
					Assert.assertTrue("Expected GroupNumber value from testdata file is- "+ DataStorage.getGroupNumber()+", But actual value("+nodeName+".policy) is- "+(String)extremeScaledetails.get(nodeName + ".policy"),((String)extremeScaledetails.get(nodeName + ".policy")).contains(DataStorage.getGroupNumber()));
				} else if(extremeScaledetails.containsKey(nodeName + ".groupId") && extremeScaledetails.get(nodeName + ".groupId") != JSONObject.NULL) {
					Assert.assertTrue("Expected GroupNumber value from testdata file is- "+ DataStorage.getGroupNumber()+", But actual value("+nodeName+".groupId) is- "+(String)extremeScaledetails.get(nodeName + ".groupId"),((String)extremeScaledetails.get(nodeName + ".groupId")).contains(DataStorage.getGroupNumber()));
				} else if(extremeScaledetails.containsKey(nodeName + ".group") && extremeScaledetails.get(nodeName + ".group") != JSONObject.NULL) {
					Assert.assertTrue("Expected GroupNumber value from testdata file is- "+ DataStorage.getGroupNumber()+", But actual value("+nodeName+".group) is- "+(String)extremeScaledetails.get(nodeName + ".group"),((String)extremeScaledetails.get(nodeName + ".group")).contains(DataStorage.getGroupNumber()));
				} else {
					Assert.fail("Please check if "+nodeName+".policy or "+nodeName+".groupId or "+nodeName+" .group nodes doesn't find or returning as null in extreme scale response for GroupNumber");
				}
			} else if (key.equalsIgnoreCase("GroupNumber1")) {
				if(extremeScaledetails.containsKey(nodeName + ".policy") && extremeScaledetails.get(nodeName + ".policy") != JSONObject.NULL) {
					Assert.assertTrue("Expected GroupNumber1 value from testdata file is- "+ DataStorage.getGroupNumber1()+", But actual value("+nodeName+".policy) is- "+(String)extremeScaledetails.get(nodeName + ".policy"),((String)extremeScaledetails.get(nodeName + ".policy")).contains(DataStorage.getGroupNumber1()));
				} else if(extremeScaledetails.containsKey(nodeName + ".groupId") && extremeScaledetails.get(nodeName + ".groupId") != JSONObject.NULL) {
					Assert.assertTrue("Expected GroupNumber1 value from testdata file is- "+ DataStorage.getGroupNumber1()+", But actual value("+nodeName+".groupId) is- "+(String)extremeScaledetails.get(nodeName + ".groupId"),((String)extremeScaledetails.get(nodeName + ".groupId")).contains(DataStorage.getGroupNumber1()));
				} else if(extremeScaledetails.containsKey(nodeName + ".group") && extremeScaledetails.get(nodeName + ".group") != JSONObject.NULL) {
					Assert.assertTrue("Expected GroupNumber1 value from testdata file is- "+ DataStorage.getGroupNumber1()+", But actual value("+nodeName+".group) is- "+(String)extremeScaledetails.get(nodeName + ".group"),((String)extremeScaledetails.get(nodeName + ".group")).contains(DataStorage.getGroupNumber1()));
				} else {
					Assert.fail("Please check if "+nodeName+".policy or "+nodeName+".groupId or "+nodeName+" .group nodes doesn't find or returning as null in extreme scale response for GroupNumber1");
				}
			} else if (key.equalsIgnoreCase("Email")) {
				if(extremeScaledetails.containsKey(nodeName + ".email") && extremeScaledetails.get(nodeName + ".email") != JSONObject.NULL) {
					Assert.assertTrue("Expected Email value from testdata file is- "+ DataStorage.getEmail()+", But actual value("+nodeName+".email) from extreme scale is- "+extremeScaledetails.get(nodeName + ".email"),(DataStorage.getEmail()).equalsIgnoreCase((String)extremeScaledetails.get(nodeName + ".email")));
				} else {
					Assert.fail("Please check if "+nodeName+".email nodes doesn't find or returning as null in extreme scale response for Email");
				}
			} else if (key.equalsIgnoreCase("UserName")) {
				if(extremeScaledetails.containsKey(nodeName + ".userId") && extremeScaledetails.get(nodeName + ".userId") != JSONObject.NULL) {
					Assert.assertEquals("Expected UserName value from testdata file is- "+ DataStorage.getUserName()+", But actual value("+nodeName+".userId) from extreme scale is- "+extremeScaledetails.get(nodeName + ".userId"), DataStorage.getUserName(),extremeScaledetails.get(nodeName + ".userId"));
				} else {
					Assert.fail("Please check if "+nodeName+".userId nodes doesn't find or returning as null in extreme scale response for UserName");
				}
			} else if (key.equalsIgnoreCase("EID")) {
				if(extremeScaledetails.containsKey(nodeName + ".enterpriseId") && extremeScaledetails.get(nodeName + ".enterpriseId") != JSONObject.NULL) {
					Assert.assertTrue("Expected EID value from testdata file is- "+ DataStorage.getEID()+", But actual value("+nodeName+".enterpriseId) from extreme scale is- "+extremeScaledetails.get(nodeName + ".enterpriseId"),((String)extremeScaledetails.get(nodeName + ".enterpriseId")).contains(DataStorage.getEID()));
				} else {
					Assert.fail("Please check if "+nodeName+".enterpriseId nodes doesn't find or returning as null in extreme scale response for EID");
				}
			} else if (key.equalsIgnoreCase("SSN")) {
				if(extremeScaledetails.containsKey(nodeName+".ssn")) {
					if(DataStorage.getSSNPDB().equalsIgnoreCase("Null"))
						Assert.assertTrue(nodeName+".ssn is not null in extreme scale",extremeScaledetails.get(nodeName + ".ssn") == JSONObject.NULL);
					else
						Assert.assertFalse(nodeName+".ssn is null in extreme scale",extremeScaledetails.get(nodeName + ".ssn") == JSONObject.NULL);
				}
				
				else if(extremeScaledetails.containsKey(nodeName+".memberSsn")) {
					if(DataStorage.getSSNPDB().equalsIgnoreCase("Null"))
						Assert.assertTrue(nodeName+".memberSsn is not null in extreme scale",extremeScaledetails.get(nodeName + ".memberSsn") == JSONObject.NULL);
					else
						Assert.assertFalse(nodeName+".memberSsn is null in extreme scale",extremeScaledetails.get(nodeName + ".memberSsn") == JSONObject.NULL);
				}
				else
					Assert.fail("The node "+nodeName+".ssn or "+nodeName+".memberSsn is not present in the extreme scale");
				
				
			} else if (key.equalsIgnoreCase("HealthSafeId")) {
				String actualHSID = (String)extremeScaledetails.get(nodeName + ".healthSafeId");
				Assert.assertTrue("HealthSafeId value is coming as null in the extreme scale node "+nodeName,actualHSID!=null);
				Assert.assertFalse("HealthSafeId value is coming as UserName in the extreme scale node", actualHSID.equalsIgnoreCase(DataStorage.getUserName()));
			
			} else if (key.equalsIgnoreCase("individualId_Gps")) {
				if(extremeScaledetails.containsKey(nodeName) && extremeScaledetails.get(nodeName) != JSONObject.NULL ) {
					Assert.assertTrue("Expected individualId value from testdata file is- "+ DataStorage.getIndividualId_Gps()+", But actual value("+nodeName+".individualId) from extreme scale is- "+extremeScaledetails.get(nodeName), ((String)extremeScaledetails.get(nodeName)).contains(DataStorage.getIndividualId_Gps()));
				} else if(extremeScaledetails.containsKey(nodeName))
					{
					Assert.assertTrue("individaulId_gps is not null", extremeScaledetails.get(nodeName) == JSONObject.NULL);
					}
				else {
					Assert.fail("Please check if "+nodeName+".individualId node doesn't find or returning as null in extreme scale response for individualId");
				} 
			} else if (key.equalsIgnoreCase("householdId_Gps")) {
				if(extremeScaledetails.containsKey(nodeName) && extremeScaledetails.get(nodeName) != JSONObject.NULL ) {
					Assert.assertTrue("Expected householdId value from testdata file is- "+ DataStorage.getHouseholdId_Gps()+", But actual value("+nodeName+".householdId) from extreme scale is- "+extremeScaledetails.get(nodeName), ((String)extremeScaledetails.get(nodeName)).contains(DataStorage.getHouseholdId_Gps()));
				} else if(extremeScaledetails.containsKey(nodeName))
					{
					Assert.assertTrue("householdId_gps is not null", extremeScaledetails.get(nodeName) == JSONObject.NULL);
					}
				else {
					Assert.fail("Please check if "+nodeName+".householdId node doesn't find or returning as null in extreme scale response for householdId");
				} 
			} else if (key.equalsIgnoreCase("individualId_Compass")) {
				if(extremeScaledetails.containsKey(nodeName) && extremeScaledetails.get(nodeName) != JSONObject.NULL ) {
					Assert.assertTrue("Expected individualId value from testdata file is- "+ DataStorage.getIndividualId_Compass()+", But actual value("+nodeName+".individualId) from extreme scale is- "+extremeScaledetails.get(nodeName), ((String)extremeScaledetails.get(nodeName)).contains(DataStorage.getIndividualId_Compass()));
				} else if(extremeScaledetails.containsKey(nodeName))
					{
					Assert.assertTrue("individualId_compass is not null", extremeScaledetails.get(nodeName) == JSONObject.NULL);
					}
				else {
					Assert.fail("Please check if "+nodeName+".individualId node doesn't find or returning as null in extreme scale response for individualId");
				} 
			}  else if (key.equalsIgnoreCase("PartitionId")) {
				if (extremeScaledetails.containsKey(nodeName + ".partitionId")) {
					Assert.assertFalse("partitionId value is null in extreme scale node - "+nodeName + ".partitionId", extremeScaledetails.get(nodeName + ".partitionId") == JSONObject.NULL);
				}
			} else if (key.equalsIgnoreCase("PopulationId")) {
				if (extremeScaledetails.containsKey(nodeName + ".populationId")) {
					Assert.assertFalse("populationId value is null in extreme scale node - "+nodeName + ".populationId", extremeScaledetails.get(nodeName + ".populationId") == JSONObject.NULL);
				} 	
			} else if (key.equalsIgnoreCase("XrefId")) {
				if (extremeScaledetails.containsKey(nodeName + ".xrefId")) {
					Assert.assertFalse("XrefId value is null in extreme scale node - "+nodeName + ".xrefId", extremeScaledetails.get(nodeName + ".xrefId") == JSONObject.NULL);
				}	
			} else if (key.equalsIgnoreCase("ProductId")) {
				if (extremeScaledetails.containsKey(nodeName+ ".productId")) {
					Assert.assertFalse("productId value is null in extreme scale node - "+nodeName + ".productId", extremeScaledetails.get(nodeName + ".productId") == JSONObject.NULL);
				}
			} else if (key.equalsIgnoreCase("SurrogateKey")) {
				if (extremeScaledetails.containsKey(nodeName+ ".surrogateKey")&& extremeScaledetails.get(nodeName+ ".surrogateKey") != JSONObject.NULL) {
					Assert.assertTrue("Expected surrogateKey value from testdata file is- " + DataStorage.getSurrogateKey() + ", But actual value(" + nodeName + ".surrogateKey) from extreme scale is- " + extremeScaledetails.get(nodeName + ".surrogateKey"), DataStorage.getSurrogateKey().equalsIgnoreCase((String) extremeScaledetails.get(nodeName + ".surrogateKey")));
				} else{
					Assert.fail("Please check if " + nodeName + ".surrogateKey node doesn't find or returning as null in extreme scale response for surrogateKey");
				}
			} else if (key.equalsIgnoreCase("PortalIndicator")) {
				if (extremeScaledetails.containsKey(nodeName + ".portalIndicator") && extremeScaledetails.get(nodeName + ".portalIndicator") != JSONObject.NULL) {
					Assert.assertTrue("Expected portalIndicator value from testdata file is- "+ DataStorage.getPortalIndicator()+", But actual value("+nodeName+".portalIndicator) from extreme scale is- "+extremeScaledetails.get(nodeName + ".portalIndicator"), DataStorage.getPortalIndicator().equalsIgnoreCase((String) extremeScaledetails.get(nodeName + ".portalIndicator")));
				} else {
					Assert.fail("Please check if " + nodeName + ".portalIndicator node doesn't find or returning as null in extreme scale response for portalIndicator");
				}

			}else if (key.equalsIgnoreCase("AccountId")) {
				String accountID = ReadXMLData.getTestData(DataStorage.getuserRootNode(), "AccountId");
				System.out.println("accountID  "+accountID);
				if(!JSONObject.NULL.equals(extremeScaledetails.get(nodeName + ".accountId"))) {
				if(extremeScaledetails.containsKey(nodeName + ".accountId") && extremeScaledetails.get(nodeName + ".accountId") != JSONObject.NULL ) {
					Assert.assertTrue("Expected accountId value from testdata file is- "+ accountID+", But actual value("+nodeName+".accountId) from extreme scale is- "+extremeScaledetails.get(nodeName + ".accountId"),((String)extremeScaledetails.get(nodeName + ".accountId")).equalsIgnoreCase(accountID));					
				} else {
					Assert.fail("Please check if "+nodeName+".accountId node doesn't find or returning as null in extreme scale response for AccountId");
				}
				}	
			} else if (key.equalsIgnoreCase("IndividualId")) {
				String IndividualID = ReadXMLData.getTestData(DataStorage.getuserRootNode(), "IndividualId");
				if(extremeScaledetails.containsKey(nodeName + ".individualId") && extremeScaledetails.get(nodeName + ".individualId") != JSONObject.NULL ) {
					Assert.assertTrue("Expected IndividualId value from testdata file is- "+ IndividualID+", But actual value("+nodeName+".individualId) from extreme scale is- "+extremeScaledetails.get(nodeName + ".individualId"),((String)extremeScaledetails.get(nodeName + ".individualId")).equalsIgnoreCase(IndividualID));
				}else {
						Assert.fail("Please check if "+nodeName+".individualId or "+nodeName+".IndividualId nodes doesn't find or returning as null in extreme scale response for IndividualId");
					} 
			} else if (key.equalsIgnoreCase("BusinessType")) {
				String BusinessTypeValue = ReadXMLData.getTestData(DataStorage.getuserRootNode(), "BusinessType");
				if(extremeScaledetails.containsKey(nodeName + ".businessType") && extremeScaledetails.get(nodeName + ".businessType") != JSONObject.NULL ) {
					Assert.assertTrue("Expected BusinessType value from testdata file is- "+ BusinessTypeValue+", But actual value("+nodeName+".businessType) from extreme scale is- "+extremeScaledetails.get(nodeName + ".businessType"),((String)extremeScaledetails.get(nodeName + ".businessType")).equalsIgnoreCase(BusinessTypeValue));
				} else {
					Assert.fail("Please check if "+nodeName+".businessType node doesn't find or returning as null in extreme scale response for BusinessType");
				}				
			} else if (key.equalsIgnoreCase("ActiveFlag")) {			
				if(extremeScaledetails.containsKey(nodeName + ".activeFlag") && extremeScaledetails.get(nodeName + ".activeFlag").toString()!=null) {
				Assert.assertTrue("Expected ActiveFlag value from testdata file is- "+ DataStorage.getactiveFlag()+", But actual value("+nodeName+".activeFlag) from extreme scale is- "+extremeScaledetails.get(nodeName + ".activeFlag"),(extremeScaledetails.get(nodeName + ".activeFlag").toString()).equalsIgnoreCase(DataStorage.getactiveFlag()));
			} else {
				Assert.fail("Please check if "+nodeName+".activeFlagnode doesn't find or returning as null in extreme scale response for activeFlag");
			} 
			}  else if (key.equalsIgnoreCase("GroupName")) {
			    if(extremeScaledetails.containsKey(nodeName + ".groupName") && extremeScaledetails.get(nodeName + ".groupName") != JSONObject.NULL ) {
				Assert.assertTrue("Expected GroupName value from testdata file is- "+ DataStorage.getgroupName()+", But actual value("+nodeName+".groupName) from extreme scale is- "+extremeScaledetails.get(nodeName + ".groupName"),((String)extremeScaledetails.get(nodeName + ".groupName")).contains(DataStorage.getgroupName()));
			} else {
				Assert.fail("Please check if "+nodeName+".groupNamenode doesn't find or returning as null in extreme scale response for groupName");
			}
			
			} else if (key.equalsIgnoreCase("lobDetails")) {
				if (extremeScaledetails.containsKey(nodeName + ".lobDetails")) {
					Assert.assertFalse("lobDetails value is null in extreme scale node - "+nodeName + ".lobDetails", extremeScaledetails.get(nodeName + ".lobDetails") == JSONObject.NULL);
				}	
			} 
			else	{
				Assert.fail("Please check if you are checking correct detail -"+key+" in extreme scale");
			}
		}

	}
	
	@Then("^I should see valid values for below details under \"([^\"]*)\" node in extreme scale details fetched by username$")
	public void iShouldSeeValidValuesForBelowDetailsUnderNodeInExtremeScaleDetailsFetchedByUsername(String nodeName, List<String> userDetails) throws SQLException {
		Map<String, Object> extremeScaledetails = DBOperation.getExtremescaledetailsAsMapByUsername();
		for (String key : userDetails) {
			if (key.equalsIgnoreCase("FirstName")) {
				if(extremeScaledetails.containsKey(nodeName + ".firstName") && extremeScaledetails.get(nodeName + ".firstName")!=JSONObject.NULL ) {
					Assert.assertEquals("Expected FirstName value from testdata file is- "+ DataStorage.getFirstName()+", But actual value("+nodeName+".firstName) from extreme scale is- "+extremeScaledetails.get(nodeName + ".firstName"), DataStorage.getFirstName().toUpperCase(),((String)extremeScaledetails.get(nodeName + ".firstName")).toUpperCase());
				} else {
					Assert.fail("Please check if "+nodeName+".firstName node doesn't find or returning as null in extreme scale response for FirstName");
				}
			} else if (key.equalsIgnoreCase("LastName")) {
				if(extremeScaledetails.containsKey(nodeName + ".lastName") && extremeScaledetails.get(nodeName + ".lastName")!=JSONObject.NULL ) {
					Assert.assertEquals("Expected LastName value from testdata file is- "+ DataStorage.getLastName()+", But actual value("+nodeName+".lastName) from extreme scale is- "+extremeScaledetails.get(nodeName + ".lastName"), DataStorage.getLastName().toUpperCase(),((String)extremeScaledetails.get(nodeName + ".lastName")).toUpperCase());
				} else {
					Assert.fail("Please check if "+nodeName+".lastName node doesn't find or returning as null in extreme scale response for LastName");
				}
			} else if (key.equalsIgnoreCase("DOB")) {
				if(extremeScaledetails.containsKey(nodeName + ".birthDate") && extremeScaledetails.get(nodeName + ".birthDate")!=JSONObject.NULL ) {
					Assert.assertEquals("Expected DOB value from testdata file is- "+ DataStorage.getDOB()+", But actual value("+nodeName+".birthDate) is- "+(String)extremeScaledetails.get(nodeName + ".birthDate"), DataStorage.getDOB(),extremeScaledetails.get(nodeName + ".birthDate"));
				} else {
					Assert.fail("Please check if "+nodeName+".birthDate node doesn't find or returning as null in extreme scale response for DOB");
				}
			} else if (key.equalsIgnoreCase("Email")) {
				if(extremeScaledetails.containsKey(nodeName + ".email") && extremeScaledetails.get(nodeName + ".email")!=JSONObject.NULL) {
					Assert.assertEquals("Expected Email value from testdata file is- "+ DataStorage.getEmail()+", But actual value("+nodeName+".email) from extreme scale is- "+extremeScaledetails.get(nodeName + ".email"), DataStorage.getEmail().toUpperCase(),((String)extremeScaledetails.get(nodeName + ".email")).toUpperCase());
				} else {
					Assert.fail("Please check if "+nodeName+".email node doesn't find or returning as null in extreme scale response for Email");
				}
			} else if (key.equalsIgnoreCase("UserName")) {
				if(extremeScaledetails.containsKey(nodeName + ".userId") && extremeScaledetails.get(nodeName + ".userId")!=JSONObject.NULL) {
					Assert.assertEquals("Expected UserName value from testdata file is- "+ DataStorage.getUserName()+", But actual value("+nodeName+".userId) from extreme scale is- "+extremeScaledetails.get(nodeName + ".userId"), DataStorage.getUserName().toUpperCase(),((String)extremeScaledetails.get(nodeName + ".userId")).toUpperCase());
				} else {
					Assert.fail("Please check if "+nodeName+".userId node doesn't find or returning as null in extreme scale response for UserName");
				}
			}
		}
	}

	@Given("^I delete (member|login) \"([^\"]*)\" from PDB using (FirstName|LastName|FirstAndLastName) as alias name$")
	public void deleteDataFromPDAUsingAliasNames(String userDataType, String arg1, String aliasName) {
		String xmlNode = "";
		String firstName = null;
		String lastName = null;
		String originalFirstName = null;
		String originalLastName = null;
		if (userDataType.equals("member")) {
			xmlNode = "/Users/";
		} else if (userDataType.equals("login")) {
			xmlNode = "/Logins/";
		}

		String dateOfBirth = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg1, "DOB");
		String DOBWithPDBFormat = new PageObjectBase().getDateInYYYY_MM_DDFormat(dateOfBirth);

		if (aliasName.equalsIgnoreCase("FirstName")) {
			firstName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg1, "FirstName_Alias");
			lastName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg1, "LastName");
		} else if (aliasName.equalsIgnoreCase("LastName")) {
			firstName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg1, "FirstName");
			lastName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg1, "LastName_Alias");
		} else {
			firstName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg1, "FirstName_Alias");
			lastName = ReadXMLData.getTestData(DataStorage.getPortalName() + xmlNode + arg1, "LastName_Alias");
		}

		if (firstName != null && lastName != null) {
				try {
					DBOperation.deleterecordFromPDB(firstName, lastName,DOBWithPDBFormat);
				} catch (Exception e) {
					DataStorage.setCustomErrmsg("Failed to Connect to PDB Data Base    :" + e.toString());
					Assert.fail("Failed to Connect to PDB Data Base    :" + e.toString());

				}
		} else {
			DataStorage.setCustomErrmsg("Getting null value for one of the name: firstName:"+firstName+", lastName:"+", originalFirstName:"+originalFirstName+", originalLastName:"+originalLastName);
			Assert.fail("Either of FirstName or LastName is Null");
		}
	}
	@And("^I should see valid values for below details in mbr table using (FirstName|LastName|FirstAndLastName) as alias name$")
	public void find_values_for_given_details_in_mbr_table_by_aliasName(String aliasName, List<String> inputKeys ) throws SQLException, ParseException {
		Map<String, String> userDetails = DBOperation.getRecordFromMBRTableByFN_LN_DOB_and_PortalID(aliasName);
		for (String key : inputKeys) {
			Assert.assertTrue("Please check if you are looking for correct detail- "+key,userDetails.containsKey(key));
			if (key.equals("Zip") && userDetails.get(key)!=null) {
				String zip = ReadXMLData.getTestData(DataStorage.getuserRootNode(), "Zip");
				Assert.assertNotNull("zip value is null in testdata file",zip);
				Assert.assertTrue("Expected Zip value from testdata file is- "+ zip +", But actual value(MDM_MBR_ZIP_CD) from  mbr table is- "+userDetails.get(key), userDetails.get(key).contains(zip));
			} else if (key.equals("EID") && userDetails.get(key)!=null) {
				String eid = ReadXMLData.getTestData(DataStorage.getuserRootNode(), "EID");
				Assert.assertNotNull("EID value is null in testdata file",eid);
				Assert.assertTrue("Expected EID value from testdata file is- "+ eid +", But actual value(MDM_MBR_EID) from  mbr table is- "+userDetails.get(key), userDetails.get(key).contains(eid));
			} else if (key.equals("MDMSubId") && userDetails.get(key)!=null) {
				String mdmSubId = ReadXMLData.getTestData(DataStorage.getuserRootNode(), "MDMSubId");
				Assert.assertNotNull("MDMSubId value is null in testdata file",mdmSubId);
				Assert.assertTrue("Expected MDMSubId value from testdata file is- "+ mdmSubId +", But actual value(MDM_MBR_SBSCR_ID) from  mbr table is- "+userDetails.get(key), userDetails.get(key).contains(mdmSubId));
			} else if (key.equals("GroupNumber") && userDetails.get(key)!=null) {
				String grpNum = ReadXMLData.getTestData(DataStorage.getuserRootNode(), "GroupNumber");
				Assert.assertNotNull("GroupNumber value is null in testdata file",grpNum);
				Assert.assertTrue("Expected GroupNumber value from testdata file is- "+ grpNum +", But actual value(MDM_MBR_POL_NBR) from  mbr table is- "+userDetails.get(key), userDetails.get(key).contains(grpNum));
			} else if (key.equals("SSN")) {
				if(DataStorage.getSSNPDB().equalsIgnoreCase("Null"))
					Assert.assertNull("MDM_MBR_SSN is not null in member table",userDetails.get("SSN"));
				else
					Assert.assertNotNull("MDM_MBR_SSN is null in member table",userDetails.get("SSN"));
			} else if (key.equals("RgstPrtlID")){
			    	Assert.assertTrue("Expected RgstPrtlID value from testdata file is - "+ DataStorage.getRgstPrtlID()+", But actual value(MBR_RGST_PRTL_ID) from mbr table is- "+userDetails.get(key), userDetails.get(key).contains(DataStorage.getRgstPrtlID()));
			} else {
				Assert.fail("The value of "+key+ " is null in mbr table");
			}
		}
	}
	@And("^I should see valid values for below details in mbr portal table for \"([^\"]*)\" portal using (FirstName|LastName|FirstAndLastName) as alias name$")
	public void find_values_for_given_details_in_mbr_portal_table_by_aliasName(String portalName,String aliasName,List<String> inputKeys) throws SQLException {

		Map<String, String> userDetails = DBOperation.getRecordFromMBRPRTLTableByProvisionId(portalName, aliasName);

		String dateOfBirth = new PageObjectBase().getDateInYYYY_MM_DDFormat(DataStorage.getDOB());

		Assert.assertTrue("Expected DOB value from testdata file is- " + DataStorage.getDOB() + ", But actual value(MBR_PRTL_DOB) from mbr_prtl table is- " + userDetails.get("DOB"), userDetails.get("DOB").equalsIgnoreCase(dateOfBirth));

		if (DataStorage.getPortalName().equalsIgnoreCase(portalName)) {

			if(aliasName.equalsIgnoreCase("FirstName")) {
				Assert.assertTrue("Expected FirstName value from testdata file is- "+ DataStorage.getFirstName_Prtl()+", But actual value(MBR_PRTL_FST_NM) from mbr_prtl table is- "+userDetails.get("FirstName"), userDetails.get("FirstName").equalsIgnoreCase(DataStorage.getFirstName_Prtl()));
				Assert.assertTrue("Expected LastName value from testdata file is- "+ DataStorage.getLastName()+", But actual value(MBR_PRTL_LST_NM) from mbr_prtl table is- "+userDetails.get("LastName"), userDetails.get("LastName").equalsIgnoreCase(DataStorage.getLastName()));
			} else if(aliasName.equalsIgnoreCase("LastName")) {
				Assert.assertTrue("Expected LastName value from testdata file is- "+ DataStorage.getLastName_Prtl()+", But actual value(MBR_PRTL_LST_NM) from mbr_prtl table is- "+userDetails.get("LastName"), userDetails.get("LastName").equalsIgnoreCase(DataStorage.getLastName_Prtl()));
				Assert.assertTrue("Expected FirstName value from testdata file is- "+ DataStorage.getFirstName()+", But actual value(MBR_PRTL_FST_NM) from mbr_prtl table is- "+userDetails.get("FirstName"), userDetails.get("FirstName").equalsIgnoreCase(DataStorage.getFirstName()));
			} else {
				Assert.assertTrue("Expected FirstName value from testdata file is- "+ DataStorage.getFirstName_Prtl()+", But actual value(MBR_PRTL_FST_NM) from mbr_prtl table is- "+userDetails.get("FirstName"), userDetails.get("FirstName").equalsIgnoreCase(DataStorage.getFirstName_Prtl()));
				Assert.assertTrue("Expected LastName value from testdata file is- "+ DataStorage.getLastName_Prtl()+", But actual value(MBR_PRTL_LST_NM) from mbr_prtl table is- "+userDetails.get("LastName"), userDetails.get("LastName").equalsIgnoreCase(DataStorage.getLastName_Prtl()));
			}

			for (String key : inputKeys) {
				Assert.assertTrue("Please check if you are looking for correct detail- " + key, userDetails.containsKey(key));
				if (key.equals("Zip") && userDetails.get(key) != null) {
					String zip= ReadXMLData.getTestData(DataStorage.getuserRootNode(), "Zip");
					Assert.assertNotNull("zip value is null in testdata file",zip);
					Assert.assertTrue("Expected Zip value from testdata file is- " + zip + ", But actual value(MBR_PRTL_ZIP_CD) from mbr_prtl table is- " + userDetails.get(key), userDetails.get(key).contains(zip));
				} else if (key.equals("PrtlSubId") && userDetails.get(key) != null) {
					String prtlSubId= ReadXMLData.getTestData(DataStorage.getuserRootNode(), "PrtlSubId");
					Assert.assertNotNull("PrtlSubId value is null in  testdata file",prtlSubId);
					Assert.assertTrue("Expected PrtlSubId value from testdata file is- " + prtlSubId + ", But actual value(MBR_PRTL_SBSCR_ID) from mbr_prtl table is- " + userDetails.get(key), userDetails.get(key).contains(prtlSubId));
				} else if (key.equals("AltId") && userDetails.get(key) != null) {
					String altId= ReadXMLData.getTestData(DataStorage.getuserRootNode(), "AltId");
					Assert.assertNotNull("AltId value is null in testdata file",altId);
					Assert.assertTrue("Expected AltId value from testdata file is- " + altId + ", But actual value(MBR_PRTL_SPC_MBR_ID) from mbr_prtl table is- " + userDetails.get(key), userDetails.get(key).contains(altId));
				} else if (key.equals("GroupNumber") && userDetails.get(key) != null) {
					String grpNum = ReadXMLData.getTestData(DataStorage.getuserRootNode(), "GroupNumber");
					Assert.assertNotNull("GroupNumber value is null in testdata file",grpNum);
					Assert.assertTrue("Expected GroupNumber value from testdata file is- "+ grpNum +", But actual value(MDM_MBR_POL_NBR) from  mbr table is- "+userDetails.get(key), userDetails.get(key).contains(grpNum));
				} else if (key.equals("SSN")) {
					Assert.assertNotNull("SSN value showing as null in mbr_prtl table", userDetails.get(key));
				} else {
					Assert.fail("The value of " + key + " is null in mbr_prtl table");
				}
			}
		} else {

			if(aliasName.equalsIgnoreCase("FirstName")) {
				Assert.assertTrue("Expected FirstName value from testdata file is- "+ ReadXMLData.getTestData(DataStorage.getuserRootNode(), "FirstName_" + portalName)+", But actual value(MBR_PRTL_FST_NM) from mbr_prtl table is- "+userDetails.get("FirstName"), userDetails.get("FirstName").equalsIgnoreCase(ReadXMLData.getTestData(DataStorage.getuserRootNode(), "FirstName_" + portalName)));
				Assert.assertTrue("Expected LastName value from testdata file is- "+ DataStorage.getLastName()+", But actual value(MBR_PRTL_LST_NM) from mbr_prtl table is- "+userDetails.get("LastName"), userDetails.get("LastName").equalsIgnoreCase(DataStorage.getLastName()));
			} else if(aliasName.equalsIgnoreCase("LastName")) {
				Assert.assertTrue("Expected LastName value from testdata file is- "+ ReadXMLData.getTestData(DataStorage.getuserRootNode(), "LastName_" + portalName)+", But actual value(MBR_PRTL_FST_NM) from mbr_prtl table is- "+userDetails.get("LastName"), userDetails.get("LastName").equalsIgnoreCase(ReadXMLData.getTestData(DataStorage.getuserRootNode(), "LastName_" + portalName)));
				Assert.assertTrue("Expected FirstName value from testdata file is- "+ DataStorage.getFirstName()+", But actual value(MBR_PRTL_FST_NM) from mbr_prtl table is- "+userDetails.get("FirstName"), userDetails.get("FirstName").equalsIgnoreCase(DataStorage.getFirstName()));
			} else {
				Assert.assertTrue("Expected FirstName value from testdata file is- "+ ReadXMLData.getTestData(DataStorage.getuserRootNode(), "FirstName_" + portalName)+", But actual value(MBR_PRTL_FST_NM) from mbr_prtl table is- "+userDetails.get("FirstName"), userDetails.get("FirstName").equalsIgnoreCase(ReadXMLData.getTestData(DataStorage.getuserRootNode(), "FirstName_" + portalName)));
				Assert.assertTrue("Expected LastName value from testdata file is- "+ ReadXMLData.getTestData(DataStorage.getuserRootNode(), "LastName_" + portalName)+", But actual value(MBR_PRTL_FST_NM) from mbr_prtl table is- "+userDetails.get("LastName"), userDetails.get("LastName").equalsIgnoreCase(ReadXMLData.getTestData(DataStorage.getuserRootNode(), "LastName_" + portalName)));
			}

			for (String key : inputKeys) {
				if (key.contains("PrtlSubId") && userDetails.get("PrtlSubId") != null) {
					String prtSubId= ReadXMLData.getTestData(DataStorage.getuserRootNode(), "PrtlSubId_" + portalName);
					Assert.assertNotNull("PrtlSubId_"+ portalName +" value is null in testdata file",prtSubId);
					Assert.assertTrue("Expected PrtlSubId value from testdata file is- " + prtSubId + ", But actual value(MBR_PRTL_SBSCR_ID) from mbr_prtl table is- " + userDetails.get("PrtlSubId"), userDetails.get("PrtlSubId").contains(prtSubId));
				} else if (key.contains("AltId") && userDetails.get("AltId") != null) {
					String altId= ReadXMLData.getTestData(DataStorage.getuserRootNode(), "AltId_" + portalName);
					Assert.assertNotNull("AltId_"+ portalName +" value is null in testdata file",altId);
					Assert.assertTrue("Expected AltId value from testdata file is- " + altId + ", But actual value(MBR_PRTL_SPC_MBR_ID) from mbr_prtl table is- " + userDetails.get("AltId"), userDetails.get("AltId").contains(altId));
				} else if (key.contains("GroupNumber") && userDetails.get("GroupNumber") != null) {
					String grpNum = ReadXMLData.getTestData(DataStorage.getuserRootNode(), "GroupNumber_" + portalName);
					Assert.assertNotNull("GroupNumber_"+ portalName +" value is null in testdata file",grpNum);
					Assert.assertTrue("Expected GroupNumber value from testdata file is- " + grpNum + ", But actual value(MBR_PRTL_POL_NBR) from mbr_prtl table is- " + userDetails.get("GroupNumber"), userDetails.get("GroupNumber").contains(grpNum));
				} else if (key.contains("SSN")) {
					if(DataStorage.getSSNPDB().equalsIgnoreCase("Null")) {
						Assert.assertNull("MBR_PRTL_SSN is not null in mbr_prtl table",userDetails.get("SSN"));
					}else {
						Assert.assertNotNull("MBR_PRTL_SSN is null in mbr_prtl table",userDetails.get("SSN"));
					}
				} else {
					Assert.fail("The value of " + key + " is null in mbr_prtl table");
				}
			}
		}
	}
	@Then("^I should see valid values for below details under \"([^\"]*)\" node in extreme scale using (FirstName|LastName|FirstAndLastName) as alias name$")
	public void iShouldSeeValidValuesForBelowDetailsUnderNodeInExtremeScaleuUingAliasName(String nodeName,String aliasName, List<String> userDetails)
			throws SQLException {
		Map<String, Object> extremeScaledetails = null;
		if (aliasName.equalsIgnoreCase("FirstName")) {			
			extremeScaledetails = DBOperation.getExtremescaledetailsAsMapForAlias(DataStorage.getFirstName_Alias(), DataStorage.getLastName());
		}else if (aliasName.equalsIgnoreCase("LastName"))
		{
			extremeScaledetails = DBOperation.getExtremescaledetailsAsMapForAlias(DataStorage.getFirstName(), DataStorage.getLastName_Alias());
		}else if (aliasName.equalsIgnoreCase("FirstAndLastName")) {
			extremeScaledetails = DBOperation.getExtremescaledetailsAsMapForAlias(DataStorage.getFirstName_Alias(), DataStorage.getLastName_Alias());
		}
		if (extremeScaledetails==null) {
			Assert.fail("No Record found in extremescale for member registered with alias name ("+aliasName +")");
		}
		
		for (String key : userDetails) {
			if (key.equalsIgnoreCase("FirstName")) {
				if(extremeScaledetails.containsKey(nodeName + ".firstName") && extremeScaledetails.get(nodeName + ".firstName") != JSONObject.NULL ) {
					Assert.assertTrue("Expected FirstName value from testdata file is- "+ DataStorage.getFirstName()+", But actual value("+nodeName+".firstName) from extreme scale is- "+extremeScaledetails.get(nodeName + ".firstName"), DataStorage.getFirstName().equalsIgnoreCase((String) extremeScaledetails.get(nodeName + ".firstName")));
					
				} else {
					Assert.fail("Please check if "+nodeName+".firstName node doesn't find or returning as null in extreme scale response for FirstName");
				}
			} else if(key.equalsIgnoreCase("FirstName_Alias")) {
				if(extremeScaledetails.containsKey(nodeName + ".firstName") && extremeScaledetails.get(nodeName + ".firstName") != JSONObject.NULL ) {
					Assert.assertTrue("Expected FirstName with alias value from testdata file is- "+ DataStorage.getFirstName_Alias()+", But actual value("+nodeName+".firstName) from extreme scale is- "+extremeScaledetails.get(nodeName + ".firstName"), DataStorage.getFirstName_Alias().equalsIgnoreCase((String) extremeScaledetails.get(nodeName + ".firstName")));
				} else {
					Assert.fail("Please check if "+nodeName+".firstName node doesn't find or returning as null in extreme scale response for FirstName with alias");
				}
			} else if(key.equalsIgnoreCase("FirstName_Prtl")) {
				if(extremeScaledetails.containsKey(nodeName + ".firstName") && extremeScaledetails.get(nodeName + ".firstName") != JSONObject.NULL ) {
					Assert.assertTrue("Expected FirstName_Prtl value from testdata file is- "+ DataStorage.getFirstName_Prtl()+", But actual value("+nodeName+".firstName) from extreme scale is- "+extremeScaledetails.get(nodeName + ".firstName"), DataStorage.getFirstName_Prtl().equalsIgnoreCase((String) extremeScaledetails.get(nodeName + ".firstName")));
				} else {
					Assert.fail("Please check if "+nodeName+".firstName node doesn't find or returning as null in extreme scale response for FirstName with Portal");
				}
			} else if(key.equalsIgnoreCase("FirstName_"+nodeName)) {
				if(extremeScaledetails.containsKey(nodeName + ".firstName") && extremeScaledetails.get(nodeName + ".firstName") != JSONObject.NULL ) {
					Assert.assertTrue("Expected FirstName_"+nodeName+" value from testdata file is- "+ ReadXMLData.getTestData(DataStorage.getuserRootNode(), "FirstName_" + nodeName)+", But actual value("+nodeName+".firstName) from extreme scale is- "+extremeScaledetails.get(nodeName + ".firstName"), ReadXMLData.getTestData(DataStorage.getuserRootNode(), "FirstName_" + nodeName).equalsIgnoreCase((String) extremeScaledetails.get(nodeName + ".firstName")));
				} else {
					Assert.fail("Please check if "+nodeName+".firstName node doesn't find or returning as null in extreme scale response for FirstName with Portal");
				}
			} else if (key.equalsIgnoreCase("LastName")) {
				if(extremeScaledetails.containsKey(nodeName + ".lastName") && extremeScaledetails.get(nodeName + ".lastName") != JSONObject.NULL ) {
					Assert.assertTrue("Expected LastName value from testdata file is- "+ DataStorage.getLastName()+", But actual value("+nodeName+".lastName) from extreme scale is- "+extremeScaledetails.get(nodeName + ".lastName"), DataStorage.getLastName().equalsIgnoreCase((String) extremeScaledetails.get(nodeName + ".lastName")));
				} else {
					Assert.fail("Please check if "+nodeName+".lastName node doesn't find or returning as null in extreme scale response for LastName");
				}			
			} else if(key.equalsIgnoreCase("LastName_Prtl")) {
				if(extremeScaledetails.containsKey(nodeName + ".lastName") && extremeScaledetails.get(nodeName + ".lastName") != JSONObject.NULL ) {
					Assert.assertTrue("Expected FirstName value from testdata file is- "+ DataStorage.getLastName_Prtl()+", But actual value("+nodeName+".lastName) from extreme scale is- "+extremeScaledetails.get(nodeName + ".lastName"), DataStorage.getLastName_Prtl().equalsIgnoreCase((String) extremeScaledetails.get(nodeName + ".lastName")));
				} else {
					Assert.fail("Please check if "+nodeName+".lastName node doesn't find or returning as null in extreme scale response for lastName with Portal");
				}
			} else if (key.equalsIgnoreCase("LastName_Alias")) {
				if(extremeScaledetails.containsKey(nodeName + ".lastName") && extremeScaledetails.get(nodeName + ".lastName") != JSONObject.NULL ) {
					Assert.assertTrue("Expected LastName with alias value from testdata file is- "+ DataStorage.getLastName_Alias()+", But actual value("+nodeName+".lastName) from extreme scale is- "+extremeScaledetails.get(nodeName + ".lastName"), DataStorage.getLastName_Alias().equalsIgnoreCase((String) extremeScaledetails.get(nodeName + ".lastName")));
				} else {
					Assert.fail("Please check if "+nodeName+".lastName node doesn't find or returning as null in extreme scale response for LastName with alias");
				}
				
			} else if(key.equalsIgnoreCase("LastName_"+nodeName)) {
				if(extremeScaledetails.containsKey(nodeName + ".lastName") && extremeScaledetails.get(nodeName + ".lastName") != JSONObject.NULL ) {
					Assert.assertTrue("Expected LastName_"+nodeName+" value from testdata file is- "+ ReadXMLData.getTestData(DataStorage.getuserRootNode(), "LastName_" + nodeName)+", But actual value("+nodeName+".lastName) from extreme scale is- "+extremeScaledetails.get(nodeName + ".lastName"), ReadXMLData.getTestData(DataStorage.getuserRootNode(), "LastName_" + nodeName).equalsIgnoreCase((String) extremeScaledetails.get(nodeName + ".lastName")));
				} else {
					Assert.fail("Please check if "+nodeName+".lastName node doesn't find or returning as null in extreme scale response for lastName with Portal");
				}
			} else if (key.equalsIgnoreCase("customerId")) {
				if(extremeScaledetails.containsKey(nodeName + ".customerId") && extremeScaledetails.get(nodeName + ".customerId") != JSONObject.NULL ) {
					Assert.assertTrue("Expected customerId value from testdata file is- "+ DataStorage.getcustomerId()+", But actual value("+nodeName+".customerId) from extreme scale is- "+extremeScaledetails.get(nodeName + ".customerId"), DataStorage.getcustomerId().equalsIgnoreCase((String) extremeScaledetails.get(nodeName + ".customerId")));
				} else {
					Assert.fail("Please ensure that "+nodeName+".customerId is present and is not null");
				}				
			} else if (key.equalsIgnoreCase("DOB")) {
				if(extremeScaledetails.containsKey(nodeName + ".birthDate") && extremeScaledetails.get(nodeName + ".birthDate") != JSONObject.NULL ) {
					Assert.assertTrue("Expected DOB value from testdata file is- "+ DataStorage.getDOB()+", But actual value("+nodeName+".birthDate) is- "+(String)extremeScaledetails.get(nodeName + ".birthDate"),((String)extremeScaledetails.get(nodeName + ".birthDate")).contains(DataStorage.getDOB()));
				} else if(extremeScaledetails.containsKey(nodeName + ".dateOfBirth") && extremeScaledetails.get(nodeName + ".dateOfBirth") != JSONObject.NULL) {
					Assert.assertTrue("Expected DOB value from testdata file is- "+ DataStorage.getDOB()+", But actual value("+nodeName+".dateOfBirth) is- "+(String)extremeScaledetails.get(nodeName + ".dateOfBirth"),((String)extremeScaledetails.get(nodeName + ".dateOfBirth")).contains(DataStorage.getDOB()));
				} else if(extremeScaledetails.containsKey(nodeName + ".dob") && extremeScaledetails.get(nodeName + ".dob") != JSONObject.NULL) {
					Assert.assertTrue("Expected DOB value from testdata file is- " + DataStorage.getDOB() + ", But actual value(" + nodeName + ".dob) is- " + (String) extremeScaledetails.get(nodeName + ".dob"), ((String) extremeScaledetails.get(nodeName + ".dob")).contains(DataStorage.getDOB()));
				} else {
					Assert.fail("Please check if "+nodeName+".birthDate or "+nodeName+".dateOfBirth or "+nodeName+".dob nodes doesn't find or returning as null in extreme scale response for DOB");
				}
			} else if (key.equalsIgnoreCase("DOB1")) {
				if(extremeScaledetails.containsKey(nodeName + ".birthDate") && extremeScaledetails.get(nodeName + ".birthDate") != JSONObject.NULL ) {
					Assert.assertTrue("Expected DOB1 value from testdata file is- "+ DataStorage.getDOB1()+", But actual value("+nodeName+".birthDate) is- "+(String)extremeScaledetails.get(nodeName + ".birthDate"),((String)extremeScaledetails.get(nodeName + ".birthDate")).contains(DataStorage.getDOB1()));
				} else if(extremeScaledetails.containsKey(nodeName + ".dateOfBirth") && extremeScaledetails.get(nodeName + ".dateOfBirth") != JSONObject.NULL) {
					Assert.assertTrue("Expected DOB1 value from testdata file is- "+ DataStorage.getDOB1()+", But actual value("+nodeName+".dateOfBirth) is- "+(String)extremeScaledetails.get(nodeName + ".dateOfBirth"),((String)extremeScaledetails.get(nodeName + ".dateOfBirth")).contains(DataStorage.getDOB1()));
				} else if(extremeScaledetails.containsKey(nodeName + ".dob") && extremeScaledetails.get(nodeName + ".dob") != JSONObject.NULL) {
					Assert.assertTrue("Expected DOB1 value from testdata file is- " + DataStorage.getDOB1() + ", But actual value(" + nodeName + ".dob) is- " + (String) extremeScaledetails.get(nodeName + ".dob"), ((String) extremeScaledetails.get(nodeName + ".dob")).contains(DataStorage.getDOB1()));
				} else {
					Assert.fail("Please check if "+nodeName+".birthDate or "+nodeName+".dateOfBirth or "+nodeName+".dob nodes doesn't find or returning as null in extreme scale response for DOB1");
				}
			} else if (key.equalsIgnoreCase("Zip")) {
				if(extremeScaledetails.containsKey(nodeName + ".zip") && extremeScaledetails.get(nodeName + ".zip") != JSONObject.NULL ) {
					Assert.assertTrue("Expected Zip value from testdata file is- "+ DataStorage.getZip()+", But actual value("+nodeName+".zip) from extreme scale is- "+extremeScaledetails.get(nodeName + ".zip"), ((String)extremeScaledetails.get(nodeName + ".zip")).contains(DataStorage.getZip()));
				} else {
					Assert.fail("Please check if "+nodeName+".zip node doesn't find or returning as null in extreme scale response for Zip");
				}
			} else if (key.equalsIgnoreCase("MDMSubId")) {
				if(extremeScaledetails.containsKey(nodeName + ".subscriberId") && extremeScaledetails.get(nodeName + ".subscriberId") != JSONObject.NULL ) {
					Assert.assertTrue("Expected MDMSubId value from testdata file is- "+ DataStorage.getMDMSubId()+", But actual value("+nodeName+".subscriberId) from extreme scale is- "+extremeScaledetails.get(nodeName + ".subscriberId"),((String)extremeScaledetails.get(nodeName + ".subscriberId")).contains(DataStorage.getMDMSubId()));
				} else {
					Assert.fail("Please check if "+nodeName+".subscriberId node doesn't find or returning as null in extreme scale response for MDMSubId");
				}
			} else if (key.equalsIgnoreCase("irisId")) {
				if(extremeScaledetails.containsKey(nodeName + ".irisId") && extremeScaledetails.get(nodeName + ".irisId") != JSONObject.NULL ) {
					Assert.assertTrue("Expected irisId value from testdata file is- "+ DataStorage.getirisId()+", But actual value("+nodeName+".irisId) from extreme scale is- "+extremeScaledetails.get(nodeName + ".irisId"),((String)extremeScaledetails.get(nodeName + ".irisId")).contains(DataStorage.getirisId()));
				} else {
					Assert.fail("Please check if "+nodeName+".irisId node doesn't find or returning as null in extreme scale response for irisId");
				}
			} else if (key.equalsIgnoreCase("patientId")) {
				if(extremeScaledetails.containsKey(nodeName + ".patientId")){
				if(DataStorage.getpatientId().equalsIgnoreCase("NULL")) {
					Assert.assertTrue(nodeName+".patientId is not null in extreme scale",extremeScaledetails.get(nodeName + ".patientId") == JSONObject.NULL);
				}
				else {
				 	Assert.assertTrue("Expected patientId value from testdata file is- "+ DataStorage.getpatientId()+", But actual value("+nodeName+".patientId) from extreme scale is- "+extremeScaledetails.get(nodeName + ".patientId"),((String)extremeScaledetails.get(nodeName + ".patientId")).contains(DataStorage.getpatientId()));
				}
				} else {
					Assert.fail("Please check if "+nodeName+".patientId node doesn't find in extreme scale response for patientId");
				}

			} else if (key.equalsIgnoreCase("migrationFlag")) {
				if(extremeScaledetails.containsKey(nodeName + ".migrationFlag") && extremeScaledetails.get(nodeName + ".migrationFlag").toString()!=null ) {
					Assert.assertTrue("Expected migrationFlag value from testdata file is- "+ DataStorage.getmigrationFlag()+", But actual value("+nodeName+".migrationFlag) from extreme scale is- "+extremeScaledetails.get(nodeName + ".migrationFlag"),(extremeScaledetails.get(nodeName + ".migrationFlag").toString()).contains(DataStorage.getmigrationFlag()));
				} else {
					Assert.fail("Please check if "+nodeName+".migrationFlag node doesn't find or returning as null in extreme scale response for migrationFlag");
				}
			
			} else if (key.equalsIgnoreCase("sourceCd")) {
				if(extremeScaledetails.containsKey(nodeName + ".sourceCd") && extremeScaledetails.get(nodeName + ".sourceCd") != JSONObject.NULL ) {
					Assert.assertTrue("Expected sourceCd value from testdata file is- "+ DataStorage.getsourceCd()+", But actual value("+nodeName+".sourceCd) from extreme scale is- "+extremeScaledetails.get(nodeName + ".sourceCd"),((String)extremeScaledetails.get(nodeName + ".sourceCd")).contains(DataStorage.getsourceCd()));
				} else {
					Assert.fail("Please check if "+nodeName+".sourceCd node doesn't find or returning as null in extreme scale response for sourceCd");
				}
			} else if (key.equalsIgnoreCase("FaroId")) {
				if(extremeScaledetails.containsKey(nodeName + ".faroId") && extremeScaledetails.get(nodeName + ".faroId") != JSONObject.NULL ) {
					Assert.assertTrue("Expected FaroId value from testdata file is- "+ DataStorage.getFaroId()+", But actual value("+nodeName+".faroId) from extreme scale is- "+extremeScaledetails.get(nodeName + ".faroId"),((String)extremeScaledetails.get(nodeName + ".faroId")).equalsIgnoreCase(DataStorage.getFaroId()));
				} else {
					Assert.fail("Please check if "+nodeName+".faroId node doesn't find or returning as null in extreme scale response for FaroId");
				}
			} else if (key.equalsIgnoreCase("Id")) {
				if(extremeScaledetails.containsKey(nodeName + ".id") && extremeScaledetails.get(nodeName + ".id") != JSONObject.NULL ) {
					Assert.assertTrue("Expected id value from testdata file is- "+ DataStorage.getId()+", But actual value("+nodeName+".id) from extreme scale is- "+extremeScaledetails.get(nodeName + ".id"),((String)extremeScaledetails.get(nodeName + ".id")).equalsIgnoreCase(DataStorage.getId()));
				} else {
					Assert.fail("Please check if "+nodeName+".id node doesn't find or returning as null in extreme scale response for Id");
				}
			} else if (key.equalsIgnoreCase("Account")) {
				if(extremeScaledetails.containsKey(nodeName + ".account") && extremeScaledetails.get(nodeName + ".account") != JSONObject.NULL ) {
					Assert.assertTrue("Expected Account value from testdata file is- "+ DataStorage.getAccount()+", But actual value("+nodeName+".account) from extreme scale is- "+extremeScaledetails.get(nodeName + ".account"),((String)extremeScaledetails.get(nodeName + ".account")).equalsIgnoreCase(DataStorage.getAccount()));
				} else if(extremeScaledetails.containsKey(nodeName + ".accountName") && extremeScaledetails.get(nodeName + ".accountName") != JSONObject.NULL) {
					Assert.assertTrue("Expected AccountName value from testdata file is- "+ DataStorage.getAccount()+", But actual value("+nodeName+".accountName) is- "+(String)extremeScaledetails.get(nodeName + ".accountName"),((String)extremeScaledetails.get(nodeName + ".accountName")).equalsIgnoreCase(DataStorage.getAccount()));

					} else {
						Assert.fail("Please check if "+nodeName+".account or "+nodeName+".AccountName nodes doesn't find or returning as null in extreme scale response for Account and AccountName");
					} 
			} else if (key.equalsIgnoreCase("AccountHolderId")) {
				if(extremeScaledetails.containsKey(nodeName + ".accountHolderId") && extremeScaledetails.get(nodeName + ".accountHolderId") != JSONObject.NULL ) {
					Assert.assertTrue("Expected AccountHolderId value from testdata file is- "+ DataStorage.getAccountHolderId()+", But actual value("+nodeName+".accountHolderId) from extreme scale is- "+extremeScaledetails.get(nodeName + ".accountHolderId"),((String)extremeScaledetails.get(nodeName + ".accountHolderId")).equalsIgnoreCase(DataStorage.getAccountHolderId()));
				} else {
					Assert.fail("Please check if "+nodeName+".accountHolderId node doesn't find or returning as null in extreme scale response for AccountHolderId");
				}
			} else if (key.equalsIgnoreCase("RecType")) {
				if(extremeScaledetails.containsKey(nodeName) && extremeScaledetails.get(nodeName) != JSONObject.NULL ) {
					Assert.assertTrue("Expected RecType value from testdata file is- "+ DataStorage.getRecType()+", But actual value("+nodeName+") from extreme scale is- "+extremeScaledetails.get(nodeName), ((String)extremeScaledetails.get(nodeName)).equalsIgnoreCase(DataStorage.getRecType()));
					}
				else {
					Assert.fail("Please check if "+nodeName+" RecType doesn't find or returning as null in extreme scale response");
				}
			} else if (key.equalsIgnoreCase("carrier")) {
				if(extremeScaledetails.containsKey(nodeName + ".carrier") && extremeScaledetails.get(nodeName + ".carrier") != JSONObject.NULL ) {
					Assert.assertTrue("Expected group value from testdata file is- "+ DataStorage.getcarrier()+", But actual value("+nodeName+".carrier) from extreme scale is- "+extremeScaledetails.get(nodeName + ".carrier"),((String)extremeScaledetails.get(nodeName + ".carrier")).contains(DataStorage.getcarrier()));
				} else {
					Assert.fail("Please check if "+nodeName+".carrier node doesn't find or returning as null in extreme scale response for carrier");
				}
			} else if (key.equalsIgnoreCase("PrtlSubId")) {
				if(extremeScaledetails.containsKey(nodeName + ".subscriberId") && extremeScaledetails.get(nodeName + ".subscriberId") != JSONObject.NULL) {
					Assert.assertTrue("Expected PrtlSubId value from testdata file is- "+ DataStorage.getPrtlSubId()+", But actual value("+nodeName+".subscriberId) is- "+(String)extremeScaledetails.get(nodeName + ".subscriberId"),((String)extremeScaledetails.get(nodeName + ".subscriberId")).contains(DataStorage.getPrtlSubId()));
				} else if(extremeScaledetails.containsKey(nodeName + ".subscriberid") && extremeScaledetails.get(nodeName + ".subscriberid") != JSONObject.NULL) {
					Assert.assertTrue("Expected PrtlSubId value from testdata file is- "+ DataStorage.getPrtlSubId()+", But actual value("+nodeName+".subscriberid) is- "+(String)extremeScaledetails.get(nodeName + ".subscriberid"),((String)extremeScaledetails.get(nodeName + ".subscriberid")).contains(DataStorage.getPrtlSubId()));
				} else if(extremeScaledetails.containsKey(nodeName + ".memberId") && extremeScaledetails.get(nodeName + ".memberId") != JSONObject.NULL) {
					Assert.assertTrue("Expected PrtlSubId value from testdata file is- "+ DataStorage.getPrtlSubId()+", But actual value("+nodeName+".memberId) is- "+(String)extremeScaledetails.get(nodeName + ".memberId"),((String)extremeScaledetails.get(nodeName + ".memberId")).contains(DataStorage.getPrtlSubId()));
				}
				else {
					Assert.fail("Please check if "+nodeName+".subscriberId or "+nodeName+".subscriberid or "+nodeName+".memberId nodes doesn't find or returning as null in extreme scale response for PrtlSubId");
				}
			} else if (key.equalsIgnoreCase("AltId")) {
				if(extremeScaledetails.containsKey(nodeName + ".altSubscriberNbr") && extremeScaledetails.get(nodeName + ".altSubscriberNbr") != JSONObject.NULL) {
					Assert.assertTrue("Expected AltId value from testdata file is- "+ DataStorage.getAltId()+", But actual value("+nodeName+".altSubscriberNbr) is- "+(String)extremeScaledetails.get(nodeName + ".altSubscriberNbr"),((String)extremeScaledetails.get(nodeName + ".altSubscriberNbr")).contains(DataStorage.getAltId()));
				} else if(extremeScaledetails.containsKey(nodeName + ".alternateId") && extremeScaledetails.get(nodeName + ".alternateId") != JSONObject.NULL) {
					Assert.assertTrue("Expected AltId value from testdata file is- "+ DataStorage.getAltId()+", But actual value("+nodeName+".alternateId) is- "+(String)extremeScaledetails.get(nodeName + ".alternateId"),((String)extremeScaledetails.get(nodeName + ".alternateId")).contains(DataStorage.getAltId()));
				} else if(extremeScaledetails.containsKey(nodeName + ".altId") && extremeScaledetails.get(nodeName + ".altId") != JSONObject.NULL) {
					Assert.assertTrue("Expected AltId value from testdata file is- "+ DataStorage.getAltId()+", But actual value("+nodeName+".altId) is- "+(String)extremeScaledetails.get(nodeName + ".altId"),((String)extremeScaledetails.get(nodeName + ".altId")).contains(DataStorage.getAltId()));
				}  
				else {
					Assert.fail("Please check if "+nodeName+".altSubscriberNbr or "+nodeName+".alternateId nodes doesn't find or returning as null in extreme scale response for AltId");
				}
			} else if (key.equalsIgnoreCase("GroupNumber")) {
				if(extremeScaledetails.containsKey(nodeName + ".policy") && extremeScaledetails.get(nodeName + ".policy") != JSONObject.NULL) {
					Assert.assertTrue("Expected GroupNumber value from testdata file is- "+ DataStorage.getGroupNumber()+", But actual value("+nodeName+".policy) is- "+(String)extremeScaledetails.get(nodeName + ".policy"),((String)extremeScaledetails.get(nodeName + ".policy")).contains(DataStorage.getGroupNumber()));
				} else if(extremeScaledetails.containsKey(nodeName + ".groupId") && extremeScaledetails.get(nodeName + ".groupId") != JSONObject.NULL) {
					Assert.assertTrue("Expected GroupNumber value from testdata file is- "+ DataStorage.getGroupNumber()+", But actual value("+nodeName+".groupId) is- "+(String)extremeScaledetails.get(nodeName + ".groupId"),((String)extremeScaledetails.get(nodeName + ".groupId")).contains(DataStorage.getGroupNumber()));
				} else if(extremeScaledetails.containsKey(nodeName + ".group") && extremeScaledetails.get(nodeName + ".group") != JSONObject.NULL) {
				Assert.assertTrue("Expected GroupNumber value from testdata file is- "+ DataStorage.getGroupNumber()+", But actual value("+nodeName+".group) is- "+(String)extremeScaledetails.get(nodeName + ".group"),((String)extremeScaledetails.get(nodeName + ".group")).contains(DataStorage.getGroupNumber()));

				} else {
					Assert.fail("Please check if "+nodeName+".policy or "+nodeName+".groupId or "+nodeName+" .group nodes doesn't find or returning as null in extreme scale response for GroupNumber");
				}
			} else if (key.equalsIgnoreCase("Email")) {
				if(extremeScaledetails.containsKey(nodeName + ".email") && extremeScaledetails.get(nodeName + ".email") != JSONObject.NULL) {
					Assert.assertTrue("Expected Email value from testdata file is- "+ DataStorage.getEmail()+", But actual value("+nodeName+".email) from extreme scale is- "+extremeScaledetails.get(nodeName + ".email"),(DataStorage.getEmail()).equalsIgnoreCase((String)extremeScaledetails.get(nodeName + ".email")));
				} else {
					Assert.fail("Please check if "+nodeName+".email nodes doesn't find or returning as null in extreme scale response for Email");
				}
			} else if (key.equalsIgnoreCase("UserName")) {
				if(extremeScaledetails.containsKey(nodeName + ".userId") && extremeScaledetails.get(nodeName + ".userId") != JSONObject.NULL) {
					Assert.assertEquals("Expected UserName value from testdata file is- "+ DataStorage.getUserName()+", But actual value("+nodeName+".userId) from extreme scale is- "+extremeScaledetails.get(nodeName + ".userId"), DataStorage.getUserName(),extremeScaledetails.get(nodeName + ".userId"));
				} else {
					Assert.fail("Please check if "+nodeName+".userId nodes doesn't find or returning as null in extreme scale response for UserName");
				}
			} else if (key.equalsIgnoreCase("EID")) {
				if(extremeScaledetails.containsKey(nodeName + ".enterpriseId") && extremeScaledetails.get(nodeName + ".enterpriseId") != JSONObject.NULL) {
					Assert.assertTrue("Expected EID value from testdata file is- "+ DataStorage.getEID()+", But actual value("+nodeName+".enterpriseId) from extreme scale is- "+extremeScaledetails.get(nodeName + ".enterpriseId"),((String)extremeScaledetails.get(nodeName + ".enterpriseId")).contains(DataStorage.getEID()));
				} else {
					Assert.fail("Please check if "+nodeName+".enterpriseId nodes doesn't find or returning as null in extreme scale response for EID");
				}
			} else if (key.equalsIgnoreCase("SSN")) {
				if(extremeScaledetails.containsKey(nodeName+".ssn")) {
					if(DataStorage.getSSNPDB().equalsIgnoreCase("Null"))
						Assert.assertTrue(nodeName+".ssn is not null in extreme scale",extremeScaledetails.get(nodeName + ".ssn") == JSONObject.NULL);
					else
						Assert.assertFalse(nodeName+".ssn is null in extreme scale",extremeScaledetails.get(nodeName + ".ssn") == JSONObject.NULL);
				}
				else
					Assert.fail("The node "+nodeName+".ssn is not present in the extreme scale");
			} else if (key.equalsIgnoreCase("HealthSafeId")) {
				Assert.assertFalse("HealthSafeId value is null in extreme scale node - "+nodeName + ".healthSafeId", extremeScaledetails.get(nodeName + ".healthSafeId") == JSONObject.NULL);
			} else if (key.equalsIgnoreCase("individualId_Gps")) {
				if(extremeScaledetails.containsKey(nodeName) && extremeScaledetails.get(nodeName)!= JSONObject.NULL ) {
					Assert.assertTrue("Expected individualId value from testdata file is- "+ DataStorage.getIndividualId_Gps()+", But actual value("+nodeName+".individualId) from extreme scale is- "+extremeScaledetails.get(nodeName), ((String)extremeScaledetails.get(nodeName)).contains(DataStorage.getIndividualId_Gps()));
				} else if(extremeScaledetails.containsKey(nodeName))
					{
					Assert.assertTrue("individaulId_gps is not null", extremeScaledetails.get(nodeName) == JSONObject.NULL);
					}
				else {
					Assert.fail("Please check if "+nodeName+".individualId node doesn't find or returning as null in extreme scale response for individualId");
				} 
			} else if (key.equalsIgnoreCase("householdId_Gps")) {
				if(extremeScaledetails.containsKey(nodeName) && extremeScaledetails.get(nodeName) != JSONObject.NULL ) {
					Assert.assertTrue("Expected householdId value from testdata file is- "+ DataStorage.getHouseholdId_Gps()+", But actual value("+nodeName+".householdId) from extreme scale is- "+extremeScaledetails.get(nodeName), ((String)extremeScaledetails.get(nodeName)).contains(DataStorage.getHouseholdId_Gps()));
				} else if(extremeScaledetails.containsKey(nodeName))
					{
					Assert.assertTrue("householdId_gps is not null", extremeScaledetails.get(nodeName) == JSONObject.NULL);
					}
				else {
					Assert.fail("Please check if "+nodeName+".householdId node doesn't find or returning as null in extreme scale response for householdId");
				} 
			} else if (key.equalsIgnoreCase("individualId_Compass")) {
				if(extremeScaledetails.containsKey(nodeName) && extremeScaledetails.get(nodeName) != JSONObject.NULL ) {
					Assert.assertTrue("Expected individualId value from testdata file is- "+ DataStorage.getIndividualId_Compass()+", But actual value("+nodeName+".individualId) from extreme scale is- "+extremeScaledetails.get(nodeName), ((String)extremeScaledetails.get(nodeName)).contains(DataStorage.getIndividualId_Compass()));
				} else if(extremeScaledetails.containsKey(nodeName))
					{
					Assert.assertTrue("individualId_compass is not null", extremeScaledetails.get(nodeName) == JSONObject.NULL);
					}
				else {
					Assert.fail("Please check if "+nodeName+".individualId node doesn't find or returning as null in extreme scale response for individualId");
				} 
			}  else if (key.equalsIgnoreCase("PartitionId")) {
				if (extremeScaledetails.containsKey(nodeName + ".partitionId")) {
					Assert.assertFalse("partitionId value is null in extreme scale node - "+nodeName + ".partitionId", extremeScaledetails.get(nodeName + ".partitionId") == JSONObject.NULL);
				}
			} else if (key.equalsIgnoreCase("PopulationId")) {
				if (extremeScaledetails.containsKey(nodeName + ".populationId")) {
					Assert.assertFalse("populationId value is null in extreme scale node - "+nodeName + ".populationId", extremeScaledetails.get(nodeName + ".populationId") == JSONObject.NULL);
				} 	
			} else if (key.equalsIgnoreCase("XrefId")) {
				if (extremeScaledetails.containsKey(nodeName + ".xrefId")) {
					Assert.assertFalse("XrefId value is null in extreme scale node - "+nodeName + ".xrefId", extremeScaledetails.get(nodeName + ".xrefId") == JSONObject.NULL);
				}	
			} else if (key.equalsIgnoreCase("ProductId")) {
				if (extremeScaledetails.containsKey(nodeName+ ".productId")) {
					Assert.assertFalse("productId value is null in extreme scale node - "+nodeName + ".productId", extremeScaledetails.get(nodeName + ".productId") == JSONObject.NULL);
				}
			} else if (key.equalsIgnoreCase("SurrogateKey")) {
				if (extremeScaledetails.containsKey(nodeName+ ".surrogateKey")&& extremeScaledetails.get(nodeName+ ".surrogateKey") != JSONObject.NULL) {
					Assert.assertTrue("Expected surrogateKey value from testdata file is- " + DataStorage.getSurrogateKey() + ", But actual value(" + nodeName + ".surrogateKey) from extreme scale is- " + extremeScaledetails.get(nodeName + ".surrogateKey"), DataStorage.getSurrogateKey().equalsIgnoreCase((String) extremeScaledetails.get(nodeName + ".surrogateKey")));
				} else{
					Assert.fail("Please check if " + nodeName + ".surrogateKey node doesn't find or returning as null in extreme scale response for surrogateKey");
				}
			} else if (key.equalsIgnoreCase("PortalIndicator")) {
				if (extremeScaledetails.containsKey(nodeName + ".portalIndicator") && extremeScaledetails.get(nodeName + ".portalIndicator") != JSONObject.NULL) {
					Assert.assertTrue("Expected portalIndicator value from testdata file is- "+ DataStorage.getPortalIndicator()+", But actual value("+nodeName+".portalIndicator) from extreme scale is- "+extremeScaledetails.get(nodeName + ".portalIndicator"), DataStorage.getPortalIndicator().equalsIgnoreCase((String) extremeScaledetails.get(nodeName + ".portalIndicator")));
				} else {
					Assert.fail("Please check if " + nodeName + ".portalIndicator node doesn't find or returning as null in extreme scale response for portalIndicator");
				}
			} else if (key.equalsIgnoreCase("ActiveFlag")) {			
				if(extremeScaledetails.containsKey(nodeName + ".activeFlag") && !JSONObject.NULL.equals(extremeScaledetails.get(nodeName + ".activeFlag"))) {
				Assert.assertTrue("Expected ActiveFlag value from testdata file is- "+ DataStorage.getactiveFlag()+", But actual value("+nodeName+".activeFlag) from extreme scale is- "+extremeScaledetails.get(nodeName + ".activeFlag"),(extremeScaledetails.get(nodeName + ".activeFlag").toString()).equalsIgnoreCase(DataStorage.getactiveFlag()));
			} else {
				Assert.fail("Please check if "+nodeName+".activeFlagnode doesn't find or returning as null in extreme scale response for activeFlag");
				} 
			}  else if (key.equalsIgnoreCase("GroupName")) {
			   if(extremeScaledetails.containsKey(nodeName + ".groupName") && !JSONObject.NULL.equals(extremeScaledetails.get(nodeName + ".groupName"))) {
				Assert.assertTrue("Expected GroupName value from testdata file is- "+ DataStorage.getgroupName()+", But actual value("+nodeName+".groupName) from extreme scale is- "+extremeScaledetails.get(nodeName + ".groupName"),((String)extremeScaledetails.get(nodeName + ".groupName")).contains(DataStorage.getgroupName()));
			} else {
				Assert.fail("Please check if "+nodeName+".groupNamenode doesn't find or returning as null in extreme scale response for groupName");
			}			
			} else if (key.equalsIgnoreCase("HealthSafeIdFlag")) {
				if(extremeScaledetails.containsKey(nodeName + ".healthSafeIdFlag") && extremeScaledetails.get(nodeName + ".healthSafeIdFlag").toString()!=null ) {
					Assert.assertTrue("Expected HealthSafeIdFlag value from testdata file is- "+ DataStorage.getHealthSafeIdFlag()+", But actual value("+nodeName+".healthSafeIdFlag) from extreme scale is- "+extremeScaledetails.get(nodeName + ".healthSafeIdFlag"),(extremeScaledetails.get(nodeName + ".healthSafeIdFlag").toString()).equalsIgnoreCase(DataStorage.getHealthSafeIdFlag()));
				} else {
					Assert.fail("Please check if "+nodeName+".healthSafeIdFlag node doesn't find or returning as null in extreme scale response for HealthSafeIdFlag");
				}
			}else if (key.equalsIgnoreCase("AccountId")) {
				String accountID = ReadXMLData.getTestData(DataStorage.getuserRootNode(), "AccountId");
				if(!JSONObject.NULL.equals(extremeScaledetails.get(nodeName + ".accountId"))) {
				if(extremeScaledetails.containsKey(nodeName + ".accountId") && extremeScaledetails.get(nodeName + ".accountId") != JSONObject.NULL ) {
					Assert.assertTrue("Expected accountId value from testdata file is- "+ accountID+", But actual value("+nodeName+".accountId) from extreme scale is- "+extremeScaledetails.get(nodeName + ".accountId"),((String)extremeScaledetails.get(nodeName + ".accountId")).equalsIgnoreCase(accountID));					
				} else {
					Assert.fail("Please check if "+nodeName+".accountId node doesn't find or returning as null in extreme scale response for AccountId");
				}
				}	
			} else if (key.equalsIgnoreCase("IndividualId")) {
				String IndividualID = ReadXMLData.getTestData(DataStorage.getuserRootNode(), "IndividualId");
				if(!JSONObject.NULL.equals(extremeScaledetails.get(nodeName + ".individualId"))) {
				if(extremeScaledetails.containsKey(nodeName + ".individualId") && extremeScaledetails.get(nodeName + ".individualId") != JSONObject.NULL ) {
					Assert.assertTrue("Expected IndividualId value from testdata file is- "+ IndividualID+", But actual value("+nodeName+".individualId) from extreme scale is- "+extremeScaledetails.get(nodeName + ".individualId"),((String)extremeScaledetails.get(nodeName + ".individualId")).equalsIgnoreCase(IndividualID));
				}else {
						Assert.fail("Please check if "+nodeName+".individualId or "+nodeName+".IndividualId nodes doesn't find or returning as null in extreme scale response for IndividualId");
					} 
				}
			} else if (key.equalsIgnoreCase("BusinessType")) {
				String BusinessTypeValue = ReadXMLData.getTestData(DataStorage.getuserRootNode(), "BusinessType");
				if(!JSONObject.NULL.equals(extremeScaledetails.get(nodeName + ".businessType"))) {
				if(extremeScaledetails.containsKey(nodeName + ".businessType") && extremeScaledetails.get(nodeName + ".businessType") != JSONObject.NULL ) {
					Assert.assertTrue("Expected BusinessType value from testdata file is- "+ BusinessTypeValue+", But actual value("+nodeName+".businessType) from extreme scale is- "+extremeScaledetails.get(nodeName + ".businessType"),((String)extremeScaledetails.get(nodeName + ".businessType")).equalsIgnoreCase(BusinessTypeValue));
				} else {
					Assert.fail("Please check if "+nodeName+".businessType node doesn't find or returning as null in extreme scale response for BusinessType");
				}	
				}
			}else	{
				Assert.fail("Please check if you are checking correct detail -"+key+" in extreme scale");
			}
		}	
		
	}
	@Given("^I should see \"([^\"]*)\" as \"([^\"]*)\" node in extreme scale using (FirstName|LastName|FirstAndLastName) as alias name$")
    public void iShouldSeeAsInExtremeScaleUsingaliasname(String nodeName, String nodeValue,String aliasName) {
		String Firstname=null;
		String Lastname=null;
        String DOB = DataStorage.getDOB();
        
        // in case of provided alias name, below code will override the value
		if (aliasName.equalsIgnoreCase("FirstName")) {	
			Firstname=DataStorage.getFirstName_Alias();
			Lastname= DataStorage.getLastName();
		}else if(aliasName.equalsIgnoreCase("LastName")) {
			Firstname= DataStorage.getFirstName();
			Lastname= DataStorage.getLastName_Alias();			
		}else if(aliasName.equalsIgnoreCase("FirstAndLastName")) {
			Firstname=DataStorage.getFirstName_Alias();
			Lastname= DataStorage.getLastName_Alias();			
		}
           try {
            Assert.assertTrue("Fail,"+nodeName +"field is not present in extreme scale", DBOperation.getExtremeScaleDetailsFromExtremeScaleTable(Firstname, Lastname, DOB).contains("\""+nodeName+"\":"+"\""+nodeValue+"\""));
           }catch (Exception e) {
                  DataStorage.setCustomErrmsg("Exception while getting details from extreme scale::" + e.toString());
                  Assert.fail("Exception while getting extreme scale from PDB Data Base::" + e.toString());
           }
     }
	
	@Given("^I should see \"([^\"]*)\" as \"([^\"]*)\" in extreme scale for \"([^\"]*)\" portal$")
    public void iShouldSeeAsInExtremeScalePortalSpecific(String nodeName, String nodeValue, String portalName) {
           String Firstname= DataStorage.getFirstName();
           String Lastname= DataStorage.getLastName();
           String DOB = DataStorage.getDOB();

		if(Firstname == null || Lastname == null || DOB == null)
			Assert.fail("Some or all of the Firstname/Lastname/DOB are coming as null from the Test Data file. Please check test data or the data reading step");

           try {
           	String extremeScaleDetail = DBOperation.getExtremeScaleDetailsFromExtremeScaleTablePortalSpecific(Firstname, Lastname, DOB, portalName);
           	if(extremeScaleDetail == null)
           	Assert.fail("No extreme scale record found for the the user with FirstName: "+Firstname+", LastName: "+Lastname+", DOB: "+DOB+", PORTALNAME: "+portalName );

            Assert.assertTrue("Fail, ["+nodeName+"] field value is incorrect in extreme scale", extremeScaleDetail.contains("\""+nodeName+"\":"+"\""+nodeValue+"\""));
           }catch (Exception e) {
                  DataStorage.setCustomErrmsg("Exception while getting details from extreme scale::" + e.toString());
                  Assert.fail("Exception while getting extreme scale from PDB Data Base::" + e.toString());
           }
     }
	@Then("^I should see valid values for below details under \"([^\"]*)\" node in MBR_PRTL_ELIGIBILITY_RESPONSE$")
	public void iShouldSeeValidValuesForBelowDetailsUnderNodeInMEMBERPORTALELIGIBILITY(String nodeName,List<String> userDetails) throws SQLException {

		Map<String, Object> memberEligibilityResponse = DBOperation.memberEligibilityDetailsAsMap();

		for (String key : userDetails) {

			if( nodeName.equals("parent")) {
				if (key.equalsIgnoreCase("DOB")) {
					String DOB = DataStorage.getDOB();
					DOB = PageObjectBase.getDateInYYYY_MM_DDFormat(DOB);
					if (memberEligibilityResponse.containsKey("dob") && memberEligibilityResponse.get("dob") != JSONObject.NULL) {
						Assert.assertTrue("Expected DOB value from testdata file is- " +DOB+ ", But actual value('dob') from MBR_PRTL_ELIGIBILITY_RESPONSE is: "+ memberEligibilityResponse.get("dob"),DOB.equalsIgnoreCase((String) memberEligibilityResponse.get("dob")));
					} else
						Assert.fail("Please check if dob does not find or returning as null in MBR_PRTL_ELIGIBILITY_RESPONSE in PDB");


				} else if (key.equalsIgnoreCase("SSN")) {
					if (memberEligibilityResponse.containsKey("ssn")) {
						if (DataStorage.getSSNPDB().equalsIgnoreCase("Null"))
							Assert.assertTrue("ssn is coming as not null in MBR_PRTL_ELIGIBILITY_RESPONSE in PDB",memberEligibilityResponse.get("ssn") == null);
						else
							Assert.assertFalse("ssn is coming as null in MBR_PRTL_ELIGIBILITY_RESPONSE in PDB",memberEligibilityResponse.get("ssn") == null);
					}

				} else
					Assert.fail("No Such attribute found for the parent node in MBR_PRTL_ELIGIBILITY_RESPONSE in PDB: [Key="+key+"]");

			} else {
				if (key.equalsIgnoreCase("FirstName")) {
					if (memberEligibilityResponse.containsKey(nodeName + ".first") && memberEligibilityResponse.get(nodeName + ".first") != JSONObject.NULL) {
						Assert.assertTrue("Expected FirstName value from testdata file is: " +DataStorage.getFirstName()+ ", But actual value(" + nodeName + ".first) from MBR_PRTL_ELIGIBILITY_RESPONSE is: "+memberEligibilityResponse.get(nodeName + ".first"),DataStorage.getFirstName().equalsIgnoreCase((String) memberEligibilityResponse.get(nodeName + ".first")));
					} else
						Assert.fail("Please check if " + nodeName+ ".first node doesn't find or returning as null in MBR_PRTL_ELIGIBILITY_RESPONSE in PDB");

				} else if (key.equalsIgnoreCase("LastName")) {
					if (memberEligibilityResponse.containsKey(nodeName + ".last") && memberEligibilityResponse.get(nodeName + ".last") != JSONObject.NULL) {
						Assert.assertTrue("Expected LastName value from testdata file is: " + DataStorage.getLastName()	+ ", But actual value(" + nodeName + ".last) from member eligibility is- "+ memberEligibilityResponse.get(nodeName + ".last"),DataStorage.getLastName().equalsIgnoreCase((String) memberEligibilityResponse.get(nodeName + ".last")));
					} else
						Assert.fail("Please check if " + nodeName + ".last node doesn't find or returning as null in MBR_PRTL_ELIGIBILITY_RESPONSE in PDB");

				} else if (key.equalsIgnoreCase("IndRelCode")) {
					if (memberEligibilityResponse.containsKey(nodeName + ".indRelCode")	&& memberEligibilityResponse.get(nodeName + ".indRelCode") != JSONObject.NULL) {
						Assert.assertTrue("Expected indRelCode value from testdata file is: " + DataStorage.getIndRelCode()+ ", But actual value(" + nodeName + ".indRelCode) from member eligibility is- "	+ memberEligibilityResponse.get(nodeName + ".indRelCode"),DataStorage.getIndRelCode().equalsIgnoreCase((String) memberEligibilityResponse.get(nodeName + ".indRelCode")));
					} else
						Assert.fail("Please check if " + nodeName + ".indRelCode node doesn't find or returning as null in MBR_PRTL_ELIGIBILITY_RESPONSE field in PDB");

				}
			}
		}
	}
	@Given("^I update EXPIRE_TS in PDB to current date for user for \"([^\"]*)\" portal registered from \"([^\"]*)\" portal$")
	public void updateExpireTSInPDB(String portalName, String registeredPortal) throws SQLException {
		String firstName = DataStorage.getFirstName();
		String lastName = DataStorage.getLastName();
		String DOB = DataStorage.getDOB();
		DOB = PageObjectBase.getDateInYYYY_MM_DDFormat(DOB);
		int portalID = DBOperation.getPortalIdBasedOnPortalName(portalName);
		int regPortalID = DBOperation.getPortalIdBasedOnPortalName(registeredPortal);

		Assert.assertNotNull("First Name is null.",firstName);
		Assert.assertNotNull("Last Name is null.",lastName);

		DBOperation.updateExpire_TS(firstName,lastName,DOB,portalID,regPortalID);
	}

	/**
	 * @author vchaube1
	 * @param numberOfDays, 0 for current date, 1 for next date and so on
	 * @param portalName
	 * @param registeredPortal
	 * @throws SQLException
	 * @throws ParseException
	 */
	@Given("^I verify EXPIRE_TS date is \"([^\"]*)\" day from current date for \"([^\"]*)\" portal registered from \"([^\"]*)\" portal$")
	public void iVerifyExpireTS(String numberOfDays, String portalName, String registeredPortal) throws SQLException, ParseException {
		String firstName = DataStorage.getFirstName();
		String lastName = DataStorage.getLastName();
		String DOB = DataStorage.getDOB();
		DOB = PageObjectBase.getDateInYYYY_MM_DDFormat(DOB);
		int portalID = DBOperation.getPortalIdBasedOnPortalName(portalName);
		int regPortalID = DBOperation.getPortalIdBasedOnPortalName(registeredPortal);

		Assert.assertNotNull("First Name is null.",firstName);
		Assert.assertNotNull("Last Name is null.",lastName);

		DBOperation.verifyExpire_TS(firstName, lastName,DOB,portalID,regPortalID,Integer.parseInt(numberOfDays));

	}
}

