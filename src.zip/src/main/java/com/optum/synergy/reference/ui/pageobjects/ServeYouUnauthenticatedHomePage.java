package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.optum.synergy.reference.ui.utility.DataStorage;
import com.optum.synergy.reference.ui.utility.ReadXMLData;

public class ServeYouUnauthenticatedHomePage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'loginregistration')]")
	private WebElement loginRegistrationForm;
	
	@FindBy(how = How.XPATH, using = "//img[@alt='Logo' and @src='/content/dam/rxmember/serveyou-header-logo.png']")
	private WebElement logo;

	public void openServeYouHomePage() {
		String page_url = ReadXMLData.getTestData(DataStorage.getPortalName(), "AppURL");
		openPage(page_url);
	}

	public boolean isPageLoaded() {
		return longWait.get().until(ExpectedConditions.visibilityOf((loginRegistrationForm))).isDisplayed();
	}
	
	public boolean isLogoDisplayed() {
		return longWait.get().until(ExpectedConditions.visibilityOf((logo))).isDisplayed();
	}
	
}
