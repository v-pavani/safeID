package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.MNRAuthenticatedHomePage;

import cucumber.api.java.en.Then;

public class MNRAuthenticatedHomePageStepDefinition {

	private MNRAuthenticatedHomePage page;

	public MNRAuthenticatedHomePageStepDefinition() {
		page = new MNRAuthenticatedHomePage();
	}

	@Then("^I should be at MNR authenticated home page$")
	public void iShouldBeAtMNRAuthenticatedHomePage() {
		Assert.assertTrue("Issue while loading the MNR authenticated page", page.verifyIfAuthPageContentIsDisplayed());

	}

	@Then("^I should be at AARP authenticated home page$")
	public void iShouldBeAtAarpAuthenticatedHomePage() {
		Assert.assertTrue("Issue while loading the Aarp authenticated page", page.verifyIfAuthPageContentIsDisplayed());
		String authPageTitle = page.getPageTitle();
		Assert.assertEquals("Issue in loading MNR-AARP authenticated page, Title mismatch: ","Home | UnitedHealthcare",authPageTitle);
	}

	@Then("^I should be at Medicare authenticated home page$")
	public void iShouldBeAtMedicareAuthenticatedHomePage() {
		Assert.assertTrue("Issue while loading the Medicare authenticated page",page.verifyIfAuthPageContentIsDisplayed());
		String authPageTitle = page.getPageTitle();
		Assert.assertEquals("Issue in loading MNR-AARP authenticated page, Title mismatch: ","Home | UnitedHealthcare",authPageTitle);
	}

	@Then("^I should be at Medica authenticated home page$")
	public void iShouldBeAtMedicaAuthenticatedHomePage() {
		Assert.assertTrue("Issue while loading the Medica authenticated page",page.verifyIfAuthPageContentIsDisplayed());
		String authPageTitle = page.getPageTitle();
		Assert.assertEquals("Issue in loading MNR-Medica authenticated page, Title mismatch: ","Home | UnitedHealthcare",authPageTitle);
	}

	@Then("^I should be at PCP authenticated home page$")
	public void iShouldBeAtPcpAuthenticatedHomePage() {
		Assert.assertTrue("Issue while loading the Pcp authenticated page", page.verifyIfAuthPageContentIsDisplayed());
		String authPageTitle = page.getPageTitle();
		Assert.assertEquals("Issue in loading MNR-PCP authenticated page, Title mismatch: ","Home | UnitedHealthcare",authPageTitle);
	}

	@Then("^I should be at Retiree authenticated home page$")
	public void iShouldBeAtRetireeAuthenticatedHomePage() {
		Assert.assertTrue("Issue while loading the Retiree authenticated page",	page.verifyIfAuthPageContentIsDisplayed());
		String authPageTitle = page.getPageTitle();
		Assert.assertEquals("Issue in loading Retiree authenticated page, Title mismatch: ","Home | UnitedHealthcare",authPageTitle);
	}
}