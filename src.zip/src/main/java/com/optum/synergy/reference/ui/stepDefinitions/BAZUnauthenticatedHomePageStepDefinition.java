package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.BAZUnauthenticatedHomePage;
import com.optum.synergy.reference.ui.pageobjects.Registration_PersonalInformationSectionPage;

import cucumber.api.java.en.Given;

public class BAZUnauthenticatedHomePageStepDefinition {

	private BAZUnauthenticatedHomePage page;

	public BAZUnauthenticatedHomePageStepDefinition() {
		page = new BAZUnauthenticatedHomePage();
	}

	@Given("^I am at BAZ unauthenticated home page$")
	public void i_am_at_BAZ_unauthenticated_home_page() {
		page.openBAZHomePage();
		Assert.assertTrue("Issue while loading the BAZ Unauthenticated page", page.isPageLoaded());

	}

	@Given("^I should be at BAZ unauthenticated home page$")
	public void i_shouldBe_at_BAZ_unauthenticated_home_page() {
		Assert.assertTrue("Issue while loading the BAZ Unauthenticated page", page.isPageLoaded() && new Registration_PersonalInformationSectionPage().getBAZLogo().isDisplayed());
	}

}
