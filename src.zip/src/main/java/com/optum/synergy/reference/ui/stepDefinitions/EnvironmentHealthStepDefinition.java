package com.optum.synergy.reference.ui.stepDefinitions;

import java.sql.Connection;
import java.sql.SQLException;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.EnvironmentHealth;
import com.optum.synergy.reference.ui.pageobjects.ExtremeScaleServicesPage;
import com.optum.synergy.reference.ui.utility.DBOperation;

import cucumber.api.java.en.Then;

public class EnvironmentHealthStepDefinition {
	private EnvironmentHealth page;
	private ExtremeScaleServicesPage extremscale;

	public EnvironmentHealthStepDefinition() {
		page = new EnvironmentHealth();
		extremscale = new ExtremeScaleServicesPage();
	}

	@Then("^I should get response with status code 200 upon invoking client access token services$")
	public void validateStatusCodeForClientTokenService() {
		Assert.assertEquals(200, extremscale.getReponseCodeFromClientTokenService());

	}

	@Then("^I should get response with status code less than 500 upon invoking LAWW eligibility services$")
	public void validateStatusCodeForLAWWeligibiltyservices() {
		int status = page.getStatusCodeFromLAWWEligibilityService();
		Assert.assertTrue("Failure status message [" + status + "] from LAWW /eligibility services", 
				status < 500);

	}
	
	@Then("^I should get response with status code less than 500 upon invoking OptumRx eligibility services$")
	public void validateStatusCodeForOptumRxeligibiltyservices() {
		int status = page.getStatusCodeFromOptumRxEligibilityService();
		Assert.assertTrue("Failure status message [" + status + "] from OptumRx /eligibility service", 
				status < 500);
	}
	
	@Then("^I should get response with status code less than 500 upon invoking OptumRx findmember services$")
	public void validateStatusCodeForOptumRxFindmemberservices() {
		int status = page.getStatusCodeFromOptumRxFindmemberService();
		Assert.assertTrue("Failure status message [" + status + "] from OptumRx /findmember service", 
				status < 500);		
	}

	@Then("^I should get response with status code less than 500 upon invoking MDM services$")
	public void validateStatusCodeForMdmservices() throws Throwable {
		int status = page.getStatusCodeFromMDMService();
		Assert.assertTrue("Failure status message [" + status + "] from MDM services", 
				status < 500);	

	}
	
	@Then("^I should get response with status code less than 500 upon invoking  MyUHC Validmember services$")
	public void validateStatusCodeForMyUHCeligibiltyservices() {
		int status = page.getStatusCodeFromMyUHCligibilityService();
		Assert.assertTrue("Failure status message [" + status + "] from MyUHC /validmember service", 
				status < 500);	

	}
	
	@Then("^I should get response with status code less than 500 upon invoking  SSO services$")
	public void validateStatusCodeForSsoServices() {
		int status = page.getStatusCodeFromSSOService();
		Assert.assertTrue("Failure status message [" + status + "] from SSO service", 
				status < 500);	

	}
	
	@Then("^I should get response with status message as \"([^\"]*)\" upon invoking RBA services$")
	public void validateStatusCodeForRBAservices(String message) {
		 String actualMessage = page.getStatusMessageFromRBAServices();
		Assert.assertTrue("Failed: Unexpected RBA status message [" + actualMessage + "]",
				actualMessage.contains(message));

	}
		
	@Then("^I should get response with status message as \"([^\"]*)\" upon invoking ESSO services$")
	public void validateStatusCodeForESSOservices(String message) {
		String actualMessage = page.getStatusMessageFromESSOServices();
		 Assert.assertTrue("Failed: Unexpected ESSO status message [" + actualMessage + "]",
				 actualMessage.contains(message));

	}
		
	@Then("^I am able to connect to PDB$")
	public void iAmAbleToConnectToPDB() {
		Connection DBStatus = null;
		String exceptionErr = "";
		try {
			DBStatus = DBOperation.getPDBDBConnection();
		} catch (Exception e) {
			exceptionErr = e.getMessage();
		}
		Assert.assertNotEquals("Error connecting to PDB [" + exceptionErr + "]",null, DBStatus);
	}

	@Then("^I am able to connect to ISECDB$")
	public void iAmAbleToConnectToISECDB() {
		Connection DBStatus = null;
		try {
			DBStatus = DBOperation.getISECDBConnection();
		} catch (Exception e) {
		}
		Assert.assertNotEquals(null, DBStatus);

	}
	
	@Then("^I am able to connect to MyUHCDB$")
	public void iAmAbleToConnectToMyUHCDB() {
		Connection DBStatus = null;
		try {
			DBStatus = DBOperation.getMyUHCPDBconnection();
		} catch (Exception e) {
		}
		Assert.assertNotEquals(null, DBStatus);

	}
	
	@Then("^I am able to connect to OptumRxDB$")
	public void iAmAbleToConnectToOptumRxDB() {
		Connection DBStatus = null;
		try {
			DBStatus = DBOperation.getOptumRxDBconnection();
		} catch (Exception e) {
		}
		Assert.assertNotEquals(null, DBStatus);

	}

}
