package com.optum.synergy.reference.ui.stepDefinitions;

import com.optum.synergy.reference.ui.pageobjects.MyOptumAuthenticatedHomePage;
import cucumber.api.java.en.Then;
import org.junit.Assert;

public class MyOptumAuthenticatedHomePageStepDefinition {

	private MyOptumAuthenticatedHomePage page;

	public MyOptumAuthenticatedHomePageStepDefinition() {
		page = new MyOptumAuthenticatedHomePage();
	}

	@Then("^I should be at MyOptum authenticated home page$")
	public void iShouldBeAtMyOptumAuthenticatedHomePage() {
		Assert.assertTrue("Issue while loading the MyOptum authenticated page",
				page.verifyIfAuthPageContentIsDisplayed());
	}

	@Then("^I should be at MyOptum No Access page$")
	public void iShouldBeAtMyOptumNoAccessPage() {
		Assert.assertTrue("Some thing went wrong", page.verifyIfNoAccessPageContentIsDisplayed());
	}
}