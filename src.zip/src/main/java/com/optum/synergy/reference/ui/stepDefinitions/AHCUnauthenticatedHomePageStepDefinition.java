package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;
import com.optum.synergy.reference.ui.pageobjects.AHCUnauthenticatedHomePage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class AHCUnauthenticatedHomePageStepDefinition {

	private AHCUnauthenticatedHomePage page;

	public AHCUnauthenticatedHomePageStepDefinition() {
		page = new AHCUnauthenticatedHomePage();
	}

	@Given("^I am at AHC unauthenticated home page$")
	public void i_am_at_AHC_unauthenticated_home_page() {
		page.openAHCHomePage();
		Assert.assertTrue("Issue while loading the AHC Unauthenticated page", page.isPageLoaded());
	}

	@Then("^I should be at AHC unauthenticated home page$")
	public void iShouldBeAtAHCUnauthenticatedHomePage() {
		Assert.assertTrue("Issue while loading unauthenticated page", page.isPageLoaded());
	}
}