package com.optum.synergy.reference.ui.stepDefinitions;

import com.optum.synergy.reference.ui.pageobjects.SigninAndSecuritySettingsPage;
import com.optum.synergy.reference.ui.utility.DataStorage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;

import java.util.List;

public class SigninAndSecuritySettingsStepDefinition {

	
private SigninAndSecuritySettingsPage page;
	
	public SigninAndSecuritySettingsStepDefinition() {
		page = new SigninAndSecuritySettingsPage();
	}
	
		
	@Then("^I should see Enter current password label with text box in SignIn and Security Settings page$")
	public void iShouldSeeEnterCurrentPasswordLabelWithTextBoxInSignInAndSecuritySettingsPage() {
		Assert.assertTrue("Issue in displaying the Current password label with text box in SignIn and Security Settings page", page.verifyCurrentPasswordLabelwithTextBox());
	}
	
	@Then("^I should see New password label with text box in SignIn and Security Settings page$")
	public void iShouldSeeEnterNewPasswordLabelWithTextBoxInSignInAndSecuritySettingsPage() {
		Assert.assertTrue("Issue in displaying the New password label with text box in SignIn and Security Settings page", page.verifyNewtPasswordLabelwithTextBox());
	}
	
	@Then("^I should see Re-enter new password label with text box in SignIn and Security Settings page$")
	public void iShouldSeeReEnterNewPasswordLabelWithTextBoxInSignInAndSecuritySettingsPage() {
		Assert.assertTrue("Issue in displaying the re Enter New password label with text box in SignIn and Security Settings page", page.verifyreEnterNewPasswordLabelwithTextBox());
	}
	
	@Then("^I should see Edit link for Password field in SignIn and Security Settings page$")
	public void iShouldSeeEditLinkForPasswordFieldInSignInAndSecuritySettingsPage() {
		Assert.assertTrue("Issue in displaying the Edit link for Password field in SignIn and Security Settings page", page.verifyIfEditLinkIsDisplayedForPassword());
	}
	
	@Then("^I should see Edit link for Recovery Email field in SignIn and Security Settings page$")
	public void iShouldSeeEditLinkForRecoveryEmailFieldInSignInAndSecuritySettingsPage() {
		Assert.assertTrue("Issue in displaying the Edit link for Recovery Email field in SignIn and Security Settings page", page.verifyIfEditLinkIsDisplayedForEmail());
	}
	
	@Then("^I should see Edit link for Account Recovery field in SignIn and Security Settings page$")
	public void iShouldSeeEditLinkForAccountRecoveryInSignInAndSecuritySettingsPage() {
		Assert.assertTrue("Issue in displaying the Edit link for Account Recovery in SignIn and Security Settings page", page.verifyIfEditLinkIsDisplayedForAcntRecovery());
	}
	
	@Then("^I should see SignIn and Security Settings page in Display mode on password update section$")
	public void iShouldSeeSignInAndSecuritySettingsPageInDisplayModeOnPasswordUpdateSection() {
		Assert.assertTrue("Issue in displaying Password section in Display mode in SignIn and Security Settings page", page.verifyIfPasswordUpdateSectionIsInDisplayMode());
	}
	
	@Then("^I click on the new password field$")
	public void iClickOnTheNewPasswordField() {
		page.clickOnTheNewPasswordField();		
	}
	
	@Then("^I should see the following rules marked with green tick in New Password field tool tip for \"([^\"]*)\"$")
	public void iShouldSeeTheFollowingRulesMarkedWithGreenInNewPasswordFieldTooltip(String pwd,List<String> contentList) throws Throwable {
		page.enterNewPwd(pwd);
		Thread.sleep(1000);
		Assert.assertEquals(contentList.size(),page.returnNumberOfRulesMarkedAsGreenForNewPassword());
		
		for (String content : contentList) {
			content = content.trim();
			Assert.assertTrue("\"" + content + "\" content is not displaying on the Tool tip",
					page.returnPasswordRulesMarkedAsGreen().contains(content));
		}
	}
	
	@Then("^I should see a gradient bar with RGB color codes \"([^\"]*)\" and \"([^\"]*)\" on Sign In & Security page$")
	public void iShouldSeeAGradientBarWithRGBColorCodesInSignInAndSecurityPage(String rGBColor1, String rGBColor2) {
		 Assert.assertTrue("Gradient bar not displaying with RGB colors "+rGBColor1+ " and "+rGBColor2, page.getGradientBarElement(rGBColor1, rGBColor2).isDisplayed());
	}

	@When("^I navigate to SignIn And Security page$")
	public void iNavigateToSignInAndSecurityPage() {
		page.openSignInAndSecurityPage();
	}
	
	@When("^I should be navigated to Security and Settings page$")
	public void iShouldBeNavigatedToSecurityAndSettingsPage() {
		Assert.assertTrue("Failed to navigate to Signin & Security page", page.verifyIfPageLoaded());
	}

	@Then("^I should see username as logged in user$")
	public void iShouldSeeUsernameAsLoggedInUser() {
	    Assert.assertEquals(DataStorage.getUserName().toUpperCase(), page.getdisplayedusername().toUpperCase());
	}

	@When("^I click on Edit password link$")
	public void iClickOnEditPasswordLink() {
	    page.clickOnEditPassword();
	}

	@When("^I enter current password as \"([^\"]*)\"$")
	public void iEnterCurrentPasswordAs(String arg1) {
	    page.enterCurrentPwd(arg1);
	}

	@When("^I enter new password as \"([^\"]*)\"$")
	public void iEnterNewPasswordAs(String arg1) {
	    page.enterNewPwd(arg1);
	}

	@When("^I enter re-enter new password as \"([^\"]*)\"$")
	public void iEnterReEnterNewPasswordAs(String arg1) {
	    page.enterConfirmNewPwd(arg1);
	}

	@When("^I click on Cancel button on password update section$")
	public void iClickOnCancelButtonOnPasswordUpdateSection() {
	   page.clickonCancelButtonForPWd();
	}

	@When("^I click on Save button on password update section$")
	public void iClickOnSaveButtonOnPasswordUpdateSection() {
	   page.clickonSaveButtontoSavepwd();
	}

	@Then("^I should see the error message as \"([^\"]*)\" for current password$")
	public void iShouldSeeTheErrorMessageAsForCurrentPassword(String arg1) {
	  Assert.assertEquals(arg1, page.getErrorMsgForCurrentPwd());
	}

	@Then("^I should see the error message as \"([^\"]*)\" for New password$")
	public void iShouldSeeTheErrorMessageAsForNewPassword(String arg1) {
		Assert.assertEquals(arg1, page.getErrorMsgForNewPwd());
	}

	@Then("^I should see the error message as \"([^\"]*)\" for Re-enter password$")
	public void iShouldSeeTheErrorMessageAsForReEnterPassword(String arg1) {
		Assert.assertEquals(arg1, page.getErrorMsgForConfirmPwd());
	}
	
	@Then("^I should see Email address prefilled in Sign In Security page$")
	public void iShouldSeeEmailAddressPrefilledInSignInSecurityPage() {
	    Assert.assertEquals(DataStorage.getEmail().toLowerCase(), page.getEmailIdContent().toLowerCase());
	}
	
	@Then("^I should see Email Unconfirmed Icon displayed$")
	public void iShouldSeeEmailUnonfirmedIconDisplayed() {
	    Assert.assertTrue(page.verifyEmailUnconfirmedIconDisplayed());
	}
	
	@Then("^I should see Edit link for Recovery Email section in Sign In Security page$")
	public void iShouldSeeEditLinkForRecoveryEmailSectionInSignInSecurityPage() {
	    Assert.assertTrue("Edit link for Recover Email not displayed.", page.VerifyEditRecoveryEmailLink());
	}

	@When("^I click on Edit Recovery email link$")
	public void iClickOnEditRecoveryEmailLink() {
	    page.clickonEditRecoveryEmail();
	}
	
	@Then("^I should see the New Email field with label \"([^\"]*)\"$")
	public void iShouldSeeTheNewEmailFieldWithLabel(String label) {
		Assert.assertEquals(label, page.getNewEmailLabel());
	    Assert.assertTrue(page.verifyNewEmail());
	}
    
	@Then("^I should see the message \"([^\"]*)\" in Edit Email section$")
	public void iShouldSeeTheMessageInEditEmailSection(String message) {
		String actualContent = page.getEditEmailFormMessage();
	    Assert.assertTrue("Issue in displaying the content\nExpectedContent: "+message+"\nActualContent: "+actualContent,actualContent.contains(message));
	}
	
	@When("^I enter new email id as \"([^\"]*)\"$")
	public void iEnterNewEmailIdAs(String arg1) {
	    page.enterNewEmail(arg1);
	}
	   
	@Then("^I enter valid temporary email in New Email address$")
	public void iEnterValidTemporaryEmailInNewEmailAddress() {
		//reset emailId to null to ensure we get a fresh unique email address
		String prevEmail= DataStorage.getEmailId();
		DataStorage.setPreviousEmailId(prevEmail);
		DataStorage.resetEmailId();
		String tempEmail = DataStorage.getEmailId();
		System.out.println("New Email: "+ tempEmail);
	    page.enterNewEmail(tempEmail);
	    DataStorage.setEmail(tempEmail); //To check for emails to this address
	}
	
	@When("^I click on Cancel button on Recovery email section$")
	public void iClickOnCancelButtonOnRecoveryEmailSection() {
	    page.clickOnCancelBtnForEmailRecovery();
	}

	@When("^I click on Save button on Recovery email section$")
	public void iClickOnSaveButtonOnRecoveryEmailSection() throws Throwable {
	   page.clickOnSaveBtnForEmailRecovery();
	   Thread.sleep(250);
	}
	
	@Then("^I should see the error message \"([^\"]*)\" in Recovery Email Header in Sign In Security page$")
	public void iShouldSeeTheErrorMessageInRecoveryEmailHeaderInSignInSecurityPage(String arg1) {
		Assert.assertEquals(arg1, page.getErrorMsgHeaderForEmail());
	}
	
	@Then("^I should see the error message as \"([^\"]*)\" for New email$")
	public void iShouldSeeTheErrorMessageAsForNewEmail(String arg1) {
		Assert.assertEquals(arg1, page.getErrorMsgForEmail());
	}

	@When("^I click on Edit Account Recovery link$")
	public void iClickOnEditAccountRecoveryLink() {
	    page.clickonEditAccountRecoverylink();
	}

	@When("^I Select security options as \"([^\"]*)\"$")
	public void iSelectSecurityOptionsAs(String arg1) {
	   page.selectAccountRecoveryOption(arg1);
	}

	@When("^I Select security question one as \"([^\"]*)\"$")
	public void iSelectSecurityQuestionOneAs(String arg1) {
	   page.selectSecurityQuestionOne(arg1);
	}

	@When("^I Select security question two as \"([^\"]*)\"$")
	public void iSelectSecurityQuestionTwoAs(String arg1) {
		page.selectSecurityQuestionTwo(arg1);
	}

	@When("^I Select security question three as \"([^\"]*)\"$")
	public void iSelectSecurityQuestionThreeAs(String arg1) {
		page.selectSecurityQuestionThree(arg1);
	}

	@When("^I enter answer for security question one as \"([^\"]*)\"$")
	public void iEnterAnswerForSecurityQuestionOneAs(String arg1) {
	    page.enterAnswerOne(arg1);
	}

	@When("^I enter answer for security question two as \"([^\"]*)\"$")
	public void iEnterAnswerForSecurityQuestionTwoAs(String arg1) {
		page.enterAnswerTwo(arg1);
	}

	@When("^I enter answer for security question three as \"([^\"]*)\"$")
	public void iEnterAnswerForSecurityQuestionThreeAs(String arg1) {
		page.enterAnswerThree(arg1);
	}

	@Then("^I should see the error message for security answer one as \"([^\"]*)\"$")
	public void iShouldSeeTheErrorMessageForSecurityAnswerOneAs(String arg1) {
		Assert.assertEquals(arg1, page.getErrMsgForAnswerOne());
	}

	@Then("^I should see the error message for security answer two as \"([^\"]*)\"$")
	public void iShouldSeeTheErrorMessageForSecurityAnswerTwoAs(String arg1) {
		Assert.assertEquals(arg1, page.getErrMsgForAnswerTwo());
	}

	@Then("^I should see the error message for security answer three as \"([^\"]*)\"$")
	public void iShouldSeeTheErrorMessageForSecurityAnswerThreeAs(String arg1) {
		Assert.assertEquals(arg1, page.getErrMsgForAnswerThree());
	}

	@Then("^I should see the top error message as \"([^\"]*)\" for security questions update$")
	public void iShouldSeeTheTopErrorMessageAsForSecurityQuestionsUpdate(String arg1) {
		Assert.assertEquals(arg1, page.getTopErrorForAccountRecoveryThroughSecurityQuestion());
	}

	@When("^I click on Cancel button on Security Question-Answer update section$")
	public void iClickOnCancelButtonOnSecurityQuestionAnswerUpdateSection() {
	    page.clickOnCancelButtonAnswerUpdate();
	}

	@When("^I click on Save button on Security Question-Answer update section$")
	public void iClickOnSaveButtonOnSecurityQuestionAnswerUpdateSection() {
		page.clickOnSaveButtonAnswerUpdate();
	}

	@When("^I enter phone number as \"([^\"]*)\"$")
	public void iEnterPhoneNumberAs(String arg1) {
	   page.enterPhoneNumber(arg1);
	}

	@When("^I select phone type as \"([^\"]*)\"$")
	public void iSelectPhoneTypeAs(String arg1) {
	    page.selectPhoneType(arg1);
	}

	@Then("^I should see error message as \"([^\"]*)\" for phone number$")
	public void iShouldErrorMessageAsForPhoneNumber(String arg1) {
		Assert.assertEquals(arg1, page.getErrMsgForPhoneNumber());
	}
	
	@Then("^I should not see the error label for security phone number$")
	public void iShouldNotSeeErrorMessageForPhoneNumber() {
		Assert.assertNull(page.getErrMsgForPhoneNumber());
	}

	@Then("^I should see error message as \"([^\"]*)\" for phone type$")
	public void iShouldErrorMessageAsForPhoneType(String arg1) {
		Assert.assertEquals(arg1, page.getErrMsgForPhoneType());
	}
	
	@Then("^I should not see the error label for security phone type$")
	public void iShouldNotSeeErrorMessageForPhoneType() {
		Assert.assertNull(page.getErrMsgForPhoneType());
	}

	@When("^I click on Cancel button on phonenumber update section$")
	public void iClickOnCancelButtonOnPhonenumberUpdateSection() {
	  page.clickOnCancelButtonPhoneNumber();
	}

	@When("^I click on Save button on phonenumber update section$")
	public void iClickOnSaveButtonOnPhonenumberUpdateSection() {
	    page.clickOnSaveButtonPhoneNumber();
	}

	@Then("^I should see the content as \"([^\"]*)\" for Consumer Communication Notice$")
	public void iShouldSeeTheContentAsForConsumerCommunicationNotice(String arg1) {
		Assert.assertEquals(arg1, page.getContentForConsumerCommunicationNotice());
	}

	@Then("^I should see the content as \"([^\"]*)\" for Texting terms and Conditions$")
	public void iShouldSeeTheContentAsForTexttingTermsAndConditions(String arg1) {
		Assert.assertEquals(arg1, page.getContentForTextingTermsConditions());
	}
	
	@Then("^I should see the \"([^\"]*)\" on SiginSecurity page$")
	public void i_should_see_the_text_on_Confirm_Email_Page(String arg1) {
		Assert.assertTrue("Content MISMATCH:\nExpected Content: <"+arg1+"> not found on page", page.verifytextOnSigninndSecurityPage(arg1));
	}
	
	@Then("^I should see success message as \"([^\"]*)\" on SiginSecurity page$")
	public void i_should_see_success_message(String arg1) {
		Assert.assertEquals("Success message- "+ arg1+ " is not verified",arg1, page.getsuccessMessageFromSignInSecurityPage());
	}
	
	@Then("^I enter valid email in New Email address field$")
	public void EnterValidTemporaryEmailInNewEmailAddress() {
		String tempEmail = "hsidauto8+" + DataStorage.getUserName()+"NEW@gmail.com";
		System.out.println("New Email: "+ tempEmail);
	    page.enterNewEmail(tempEmail);
	    DataStorage.setEmail(tempEmail);
	}
	@When("^I click on Close button on model view$")
	public void iClickOnCloseButtonOnModelView() {
		page.clickOnCloseButton();
	}
}
