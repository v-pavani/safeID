package com.optum.synergy.reference.ui.utility;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

public class HTMLReport {

	/*
	public static String testResultTextFile = "target/cucumber-parallel/emailhtml/test.txt";
	public static String htmlReportOutputFile = "target/cucumber-parallel/emailhtml/dashboard.html";
	*/
	
	public static String testResultTextFile = "target/testResultsForReport.txt";
	
	// Highest percentage for color coding
	public static final int redThreshold = 59;
	public static final int yellowThreshold = 84;
	

	public static void main(String[] args) throws IOException {
		
		String htmlReportOutputFile = "target/dashboard.html";
		// Read testResultTextFile, build hashMap of modules with pass/fail array
//		File scf= new File("synergy_proj/" + testResultTextFile);
		File scf= new File(testResultTextFile);
		Scanner scan = null;
		
		if ( ! scf.exists() ) {
			// Jenkins runs have different working directory, hack workaround
			scf = new File("synergy_proj/" + testResultTextFile);
			
			if ( scf.exists() ) {
				htmlReportOutputFile = "synergy_proj/" + htmlReportOutputFile;
			} else {
				// Create empty dummy file
				scf = File.createTempFile("dummyTmp", null);
			}
			
		}
		
		HashMap<String, int[]> hm = new HashMap<String, int[]>();
		
		try {
			scan = new Scanner(scf);

			String line;
			int cntr=0;
			while(scan.hasNextLine()){
				line=scan.nextLine();
				if (cntr==0){
					// Skip first line
					cntr++;
					continue;
				} 

				String[] tmparr = line.split(",");
				String modulename = tmparr[0];
				String status = tmparr[1];

				int[] arr = hm.get(modulename);
				// If modulename does not yet exist in HashMap, get() returns a null array object
				// Initialize to zeroes
				if ( arr == null ) {
					arr = new int[2];
					arr[0] = 0;
					arr[1] = 0;
				}
				if (status.equalsIgnoreCase("PASS")) {
					arr[0] = arr[0] + 1;
				} else {
					arr[1] = arr[1] + 1;
				}
				hm.put(modulename, arr);
				cntr++;
			}
		} finally {
			if ( scan != null) { scan.close(); }
		}
		
		//File dashboard = new File("synergy_proj/" + htmlReportOutputFile);
		File dashboard = new File(htmlReportOutputFile);
		dashboard.createNewFile();

		PrintWriter dashboardwriter = new PrintWriter(dashboard);
		
		
		dashboardwriter.println("<html><head><style>table, th, td {border: 1px solid black;}</style></head><body>");		

		dashboardwriter.println("<table><thead><th>Module</th><th>#Pass</th><th>#Fail</th><th>HealthStatus(Pass %)</th></thead><tbody>");
		// dashboardwriter.println(x);
		Set<Entry<String, int[]>> kyset = hm.entrySet();
		for (Entry<String, int[]> m : kyset) {
			//
			int[] a = m.getValue();
			int passPercentage=(a[0]*100)/(a[0]+a[1]);
			
			String colorcode = null;
			
			if (passPercentage <= redThreshold ) {
				colorcode="\"#FF0000\"";
			} else if (passPercentage <= yellowThreshold ) {
				colorcode="\"#FFFF00\"";
			} else {
				colorcode="\"#00FF00\"";
			}
			

			dashboardwriter.println("<tr><td>" + m.getKey() + "</td>" + "<td >" + a[0]
					+ "</td>" + "<td>" + a[1] + "</td><td bgcolor="+colorcode+">"+passPercentage+"%"+"</td></tr>");
		}
		dashboardwriter.println("</tbody></table><br></br>");
		
		dashboardwriter.println("<table ><thead><th style=\"font-size: 12px;\">Passed Range</th><th style=\"font-size: 12px;\">Health"		
				+"Indicator</th></thead><tbody>"		
				+"<tr><td style=\"font-size: 10px;\">" + (yellowThreshold+1) + "%-100%</td><td bgcolor=\"#00FF00\"></td></tr>"		
				+"<tr><td style=\"font-size: 10px;\">" + (redThreshold+1) + "%-" + yellowThreshold + "% </td><td bgcolor=\"#FFFF00\"></td></tr>"		
				+"<tr><td style=\"font-size: 10px;\">0-" + redThreshold + "%</td><td bgcolor=\"#FF0000\"></td></tr>"
				+"</table></body></html>");
		dashboardwriter.close();

	}

}
