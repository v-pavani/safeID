package com.optum.synergy.reference.ui.pageobjects;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TestDataExcelPage extends PageObjectBase {
	
	public FileInputStream fileIn=null;
	public XSSFWorkbook workbook=null;

	public XSSFSheet getSheetFromExcelWorkbook(String sheetName) throws IOException {
		String excelWorkbookPath = getSystemVariable("test_data_Workbook_location");
		fileIn = new FileInputStream(excelWorkbookPath);
		workbook = new XSSFWorkbook(fileIn);
		// open sheet with the given name
		XSSFSheet sheet = workbook.getSheet(getSystemVariable("environment.type").toUpperCase()+"_"+sheetName);

		return sheet;
	}

	public Map<String, Integer> getColumnIndicesBasedOnColumnNamesFromASheet(XSSFSheet sheet,
			List<String> columnNames) {
		Row firstRow = sheet.getRow(0);
		Map<String, Integer> columnNamesWithIndices=new HashMap<String, Integer>();
		for (Cell cell : firstRow) {
			if(cell.getCellType()!= Cell.CELL_TYPE_BLANK){
			String cellValue = cell.getStringCellValue().trim();
			Integer columnNo = null;
			for (String columnName : columnNames) {
				if (columnName.equals(cellValue)) {
					columnNo = cell.getColumnIndex();
					columnNamesWithIndices.put(columnName, columnNo);
					break;
				}
			}
			}
		}

		return columnNamesWithIndices;
	}
}
