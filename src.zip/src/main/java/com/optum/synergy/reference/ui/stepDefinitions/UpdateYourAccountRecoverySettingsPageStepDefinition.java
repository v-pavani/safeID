package com.optum.synergy.reference.ui.stepDefinitions;

import java.util.List;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.Hooks;
import com.optum.synergy.reference.ui.pageobjects.UpdateYourAccountRecoverySettingsPage;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UpdateYourAccountRecoverySettingsPageStepDefinition {

	private UpdateYourAccountRecoverySettingsPage page;

	public UpdateYourAccountRecoverySettingsPageStepDefinition() {
		page = new UpdateYourAccountRecoverySettingsPage();
	}

	@When("^I click on \"([^\"]*)\" link in username dropdown$")
	public void i_click_on_link_in_username_dropdown(String arg1) {
		page.submitSignInSecurity();
	}

	@Then("^I should see an error message \"([^\"]*)\" for question1$")
	public void i_should_see_an_error_message_for_question1(String message) {
		Assert.assertTrue(page.verifyErrorMessageOnSecurityQuestion1(message));
	}

	@Then("^I should see an error message \"([^\"]*)\" for answer1$")
	public void i_should_see_an_error_message_for_answer1(String message) {
		Assert.assertTrue(page.verifyErrorMessageOnSecurityAnswer1(message));
	}

	@Then("^I should see an error message \"([^\"]*)\" for question2$")
	public void i_should_see_an_error_message_for_question2(String message) {
		Assert.assertTrue(page.verifyErrorMessageOnSecurityQuestion2(message));
	}

	@Then("^I should see an error message \"([^\"]*)\" for answer2$")
	public void i_should_see_an_error_message_for_answer2(String message) {
		Assert.assertTrue(page.verifyErrorMessageOnSecurityAnswer2(message));
	}

	@Then("^I should see an error message \"([^\"]*)\" for question3$")
	public void i_should_see_an_error_message_for_question3(String message) {
		Assert.assertTrue(page.verifyErrorMessageOnSecurityQuestion3(message));
	}

	@Then("^I should see an error message \"([^\"]*)\" for answer3$")
	public void i_should_see_an_error_message_for_answer3(String message) {
		Assert.assertTrue(page.verifyErrorMessageOnSecurityAnswer3(message));
	}

	@Then("^I should see an error message \"([^\"]*)\" for New email$")
	public void iShouldSeeAnErrorMessageForNewEmail(String message) throws Throwable {
		Thread.sleep(4000);
		Assert.assertTrue(page.verifyErrorMessageOnUpdateNewEmail(message));
	}

	@Then("^I should not see the \"([^\"]*)\" link$")
	public void i_should_not_see_the_link(String message) {
		Assert.assertTrue(page.verifyLinkIsNotDisplayed(message));
	}

	@Then("^I enter password with \"([^\"]*)\" into current password field$")
	public void i_enter_password_with_into_current_password_field(String currentPassword) {
		page.enterCurrentPassword(currentPassword);
	}

	@Then("^I enter password with \"([^\"]*)\" into confirm Password field$")
	public void i_enter_password_with_into_confirm_Password_field(String confirmPassword) {
		page.enterConfirmNewPassword(confirmPassword);
	}

	@Then("^I should see an error message \"([^\"]*)\" at the top of Change your password section$")
	public void iShouldSeeAnErrorMessageAtTheTopOfChangeYourPasswordSection(String message) {
		Assert.assertTrue(page.verifyErrForOldPwdWrong(message));
	}
		
	@Then("^I should see an error message \"([^\"]*)\" for current password field$")
	public void i_should_see_an_error_message_for_current_password_field(String message) {
		Assert.assertTrue(page.verifyErrorInvalidCurrentPwd(message));
	}

	@Then("^I should see an error message \"([^\"]*)\" for New password field$")
	public void iShouldSeeAnErrorMessageForNewPasswordField(String message) {
		Assert.assertTrue(page.verifyErrorInvalidNewPwd(message));
	}

	@Then("^I should see an error message \"([^\"]*)\" for Confirm password field$")
	public void iShouldSeeAnErrorMessageForConfirmPasswordField(String message) {
		Assert.assertTrue(page.verifyErrorInvalidConfirmPwd(message));
	}

	@Then("^I should see a heading \"([^\"]*)\" with following password guidelines$")
	public void i_should_see_a_heading_with_following_password_guidelines(String heading, List<String> passGuidelines) {
		Assert.assertTrue(page.verifyRuleTipMessage(heading));
		for (String msg : passGuidelines) {
			Assert.assertTrue(page.verifyRuleTipMessage(msg));
		}
	}

	@Then("^I should see an error message \"([^\"]*)\" for phone number field$")
	public void i_should_see_an_error_message_for_phone_number_field(String message) {
		Assert.assertTrue(page.verifyErrorNewPhoneNo(message));
	}

	@Then("^I enter password with \"([^\"]*)\" into New password field$")
	public void i_enter_password_with_into_New_password_field(String newpassword) {
		page.enterNewPassword(newpassword);

	}

}
