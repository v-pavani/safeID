package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import com.optum.synergy.reference.ui.utility.ReadXMLData;

public class PAIUnauthenticatedHomePage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//div[@class='loginregistration section']")
	private WebElement loginRegistrationForm;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'tag.png')]|//img[contains(@src,'PAI_Logo.png')]")
	private WebElement paiLogo;

	public void openPaiHomePage() {
		String page_url = ReadXMLData.getTestData("PAI", "AppURL");
		openPage(page_url);
	}

	public boolean isPageLoaded() {
		if (longWait.get().until(ExpectedConditions.visibilityOf((loginRegistrationForm))).isDisplayed()
				&& getPaiLogo().isDisplayed()) {
			return true;
		} else
			return false;
	}

	public WebElement getPaiLogo() {
		return longWait.get().until(ExpectedConditions.visibilityOf(paiLogo));
	}
}
