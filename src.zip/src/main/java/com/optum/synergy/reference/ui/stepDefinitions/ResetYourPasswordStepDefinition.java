package com.optum.synergy.reference.ui.stepDefinitions;

import java.util.List;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.ResetYourPasswordPage;
import com.optum.synergy.reference.ui.utility.DataStorage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ResetYourPasswordStepDefinition {
	private ResetYourPasswordPage page;
	private String captchaImageUrl = "";

	public ResetYourPasswordStepDefinition() {
		page = new ResetYourPasswordPage();
	}

	@Then("^I should be at Reset your password page$")
	public void i_should_be_at_Reset_your_password_page() {
			Assert.assertTrue("Issue while loading Reset your password page",page.verifyIfPageLoaded());
	}
	
	@Then("^I should be at Reset Password-Security Questions Page$")
	public void i_should_be_at_security_questions_page() {
			Assert.assertTrue("Issue while loading Reset your password page",page.verifyIfSecurityQuestionPageLoaded());
	}
	
	@Then("^I should be at Reset Password-Phone number Page$")
	public void i_should_be_at_Phone_number_page() {
			Assert.assertTrue("Issue while loading Reset your password page",page.verifyIfPhonePageLoaded());
	}
	
	@Then("^I should see the Reset your password page header as \"([^\"]*)\"$")
	public void i_should_see_the_Reset_your_password_page_header_as(String pageHeader) {
	 Assert.assertTrue("\""+pageHeader+"\" heading is not displaying on the Reset your password page", page.verifyForPageHeader(pageHeader));
	}
	
	@Then("^I should see an error message for account locked as \"([^\"]*)\"$")
	public void i_should_see_an_error_message_for_locked_account_myuhc(String errorMessage) {
	Assert.assertEquals("error message not",errorMessage, page.verifyAccountLockedErrorMessage());
	}

	@Then("^I should see a label for username field with heading \"([^\"]*)\"$")
	public void i_should_see_a_label_for_username_field_with_heading(String userNameLabel) {
		Assert.assertTrue(userNameLabel + " label with text box doesn't exist",
				page.verifyForUserNameTextBoxWithHeading(userNameLabel));
	}

	@Given("^I should see the optum logo with valid image source url$")
	public void i_should_see_the_optum_logo_with_valid_image_source_url() {
		Assert.assertTrue("optum logo is not displaying", page.verifyForTheOptumLogo());
	}

	@Then("^I should see header with heading \"([^\"]*)\" on step \"([^\"]*)\"$")
	public void iShouldSeeStepOfWithHeading(String headingName, String stepNumber) {
	Assert.assertEquals(headingName, page.getHeaderTextOfHeadingsAlongWithSteps(stepNumber));
	}
	
	@Then("^I should see header with heading \"([^\"]*)\" is bold on step \"([^\"]*)\"$")
	public void iShouldSeeStepOfWithHeadingisBold(String headingName, String stepNumber) {
		//Value 700 means text is in bold , css code returning bold for safari browser
		//Assert.assertEquals("700", page.getCSSValueIfHeaderBoldOrNotOfHeadingsAlongWithSteps(stepNumber));
		Assert.assertTrue(page.getCSSValueIfHeaderBoldOrNotOfHeadingsAlongWithSteps(stepNumber).equalsIgnoreCase("bold") || page.getCSSValueIfHeaderBoldOrNotOfHeadingsAlongWithSteps(stepNumber).equalsIgnoreCase("700"));
		}
	@Then("^I should see header with heading \"([^\"]*)\" is not bold on step \"([^\"]*)\"$")
	public void iShouldSeeStepOfWithHeadingisNotBold(String headingName, String stepNumber) {
		//Value 700 means text is in bold
		Assert.assertNotEquals("700", page.getCSSValueIfHeaderBoldOrNotOfHeadingsAlongWithSteps(stepNumber));
		}
	
	@Then("^I enter valid \"([^\"]*)\" into Password field on Reset your password page$")
	public void i_enter_valid_into_Password_field(String password) {
		page.enterPassword(password);
	}

	@Then("^I enter valid \"([^\"]*)\" into Confirm password field on Reset your password page$")
	public void i_enter_valid_into_Confirm_password_field(String password) {
		page.enterConfirmPassword(password);
	}
	
	@Then("^I should see \"([^\"]*)\" after reset the password$")
	public void i_should_see_success_message_after_reset_Password(String text) {
		Assert.assertEquals(text, page.verifySuccessMessageAfterResetPassword(text));
	}

	@When("^I enter valid security answer on Reset Your Password Page$")
	public void iManageTheRBAPageWithSecurityAnswer() throws Throwable {
	     page.enterValidSecurityAnsweOnResetYourPasswordPage();
	}
	
	@Then("^I should see the Text Me link on reset password page$")
	public void i_should_see_the_text_me_link_on_reset_password_page() {
		Assert.assertTrue("\"" + "\" is not displaying as Text Me link", page.verifyTextMeLink());
	}
		
	@Then("^I click on Text Me link on reset password page$")
	public void i_click_on_text_me_link_on_reset_password_page() {
		page.clickTextMeLink();
	}

	@Then("^I should see the field for \"([^\"]*)\" with security question label on Reset Your Password Page$")
	public void iShouldSeeTheFieldWithLabelforResetYourPassword(String arg1) {
		 Assert.assertTrue("Security question label and security answer field is not visible", page.verifyLabels(arg1));	  
     }
	
	@Then("^I enter \"([^\"]*)\" as \"([^\"]*)\" on Reset Your Password Page$")
	public void ienterSecurityAnswers(String arg1, String arg2) {
		 page.enterValuesintoFieldsOnResetPasswordPage(arg1, arg2);	  
     }
	
	@Then("^I should see the error message for \"([^\"]*)\" as \"([^\"]*)\" on Reset Your Password Page$")
	public void iShouldSeeTheErrorMessageForSecurityAnswer(String arg1, String arg2) {
		Assert.assertEquals(arg2, page.getErrMsgForResetAccountPage(arg1));
	}
	
	@Then("^I should see aggregate error message as \"([^\"]*)\" on Reset Your Password Page$")
	public void iShouldSeeaggregateErrorMessageForSecurityAnswer(String arg1) {
		page.waitForJavascriptToLoad(9000, 1000);
		Assert.assertEquals(arg1, page.getaggregateErrMsgForAnswer());
	}
	
	@Then("^I enter valid \"([^\"]*)\" on Reset Your Password Page$")
	public void ienterValidSecurityAnswer(String arg1) throws Throwable {
		 page.enterValidSQA(arg1);	  
     }
	
	@Then("^I should see New password label and text field on Reset Your Password Page$")
	public void iShouldSeeNewPasswordLabelandTextFiedForResetYourPassword() {
		 Assert.assertTrue("New password label and text field is not visible", page.verifyLabelsAndFieldForNewPasswordField());	  
     }
	
	@Then("^I should not see any error message for \"([^\"]*)\" field$")
	public void i_should_not_see_any_error_message_for_passwordField(String field) {
		Assert.assertTrue(page.verifyNoErrorMessageOnPasswordField(field));
	}
	
	@Then("^I should see the \"([^\"]*)\" label on Reset Your Password Step two Page$")
	public void i_should_see_the_text_on_Confirm_Email_Page(String arg1) {
		Assert.assertTrue("\""+arg1+"\" Text is not displaying on the Reset Your Password Step two Page", page.verifytextOnResetyourPasswordPhoneStep2Page(arg1));
	}
	
	@Given("^I should see Green Check Mark replacing step \"([^\"]*)\" of Reset Your Password with heading \"([^\"]*)\"$")
	public void iShouldSeeGreenCheckforMarkreplacingStepOfResetYourPasswordWithHeading(String arg1, String arg2) {
		Assert.assertTrue("Issue Green check Mark is not displaying",
				page.verifyGreencheckMarkandHeading(arg2));
	}
	
	@When("^I enter newpassword as Username on Reset Your Password Page$")
	public void iEnterNewPasswordAsUsernameOnResetYourPasswordPage() {
		page.enterPassword(DataStorage.getUserName());
	}
	
	@When("^I enter reEnterNewPassword as Username on Reset Your Password Page$")
	public void iReEnterNewPasswordAsUsernameOnResetYourPasswordPage() {
		page.enterConfirmPassword(DataStorage.getUserName());
	}
		
	@Then("^I should see an account lock error message \"([^\"]*)\" on step 1 page$")
	public void ishouldseeanaccountlockerrormessageonstep1page(String expectedMsg) {
		Assert.assertEquals("FAIL: Did not find expected error message", expectedMsg,
				page.getAccountLockedErrorMessage().getText());
	}

	@Then("^I should see success message as \"([^\"]*)\" after reset password$")
	public void i_should_see_success_messageas_after_reset_Password(String text) {
		Assert.assertTrue("Success message not verified", page.getWebElementOnSuccessMessageAfterResetPassword().getText().contains(text));
	}
	
	@Then("^I should see an error message \"(.*)\" after clicking on Continue button from Reset your password page$")
	public void iShouldSeeAnErrorMessage(String expectedMessage ) {
		Assert.assertEquals("FAIL: Did not find expected error message", expectedMessage,  page.getErrorMessage().getText());
	}
	
	@Then("^I enter valid username into Username field in Reset your password page$")
	public void iEnterValidUsernameIntoUsernameFieldInResetYourPasswordPage() {
	    page.enterUserName(DataStorage.getUserName());
	}
	
	@Then("^I should see the following error message on Recover your password form$")
	public void i_should_see_the_following_error_message_On_Recover_your_password_form(List<String> contents) {
		for (String content : contents) {
			Assert.assertTrue(content + " does not exist on Recover your username form", page.getErrorMessageElement().getText().contains(content));
		}
	}
}
