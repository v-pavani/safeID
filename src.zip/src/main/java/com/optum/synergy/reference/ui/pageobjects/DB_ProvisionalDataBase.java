package com.optum.synergy.reference.ui.pageobjects;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.optum.synergy.reference.ui.utility.DBOperation;
import com.optum.synergy.reference.ui.utility.DataStorage;

public class DB_ProvisionalDataBase extends PageObjectBase {

	//Declare connection as ThreadLocal to ensure safe parallel execution when open/closing
	private static ThreadLocal<Connection> con = new ThreadLocal<Connection>();

	public void connectToDataBase() throws SQLException {
		con.set(DBOperation.getPDBDBConnection());
	}

	public void closeConnectionToDataBase() throws SQLException {
		con.get().close();
	}

	public int returnRecordsFromMBRTable(String firstName, String lastName) throws SQLException {
		return DBOperation.recordcountFromMmberTable(firstName, lastName);
	}
	
	public int returnRecordsFromMBR_PRTLTable(String firstName, String lastName) throws SQLException {
		return DBOperation.recordcountFromMmberPortalTable(firstName, lastName);
	}

	public int updateTERM_AND_COND_ACPT_DTinMBRTableWithDate(String date,String firstName, String lastName) throws SQLException {
		PreparedStatement stmt = con.get().prepareStatement("UPDATE mbr set TERM_AND_COND_ACPT_DT =? where MDM_FST_NM =? and MDM_LST_NM =?");
		stmt.setString(1, date);
		stmt.setString(2, firstName);
		stmt.setString(3, lastName);
		
		int updatedRows = stmt.executeUpdate();
		DataStorage.setCustomErrmsg("Rows updated in updateTERM_AND_COND_ACPT_DTinMBRTableWithDate(): " + updatedRows);
		return updatedRows;
	}
	
	public boolean verifyIfTERM_AND_COND_ACPT_DTisUpdatedToCurrentDate(String firstName, String lastName) throws SQLException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String todaysDate = sdf.format(date);
		PreparedStatement stmt = con.get().prepareStatement("SELECT TERM_AND_COND_ACPT_DT from mbr where MDM_FST_NM=? and MDM_LST_NM=?");
		stmt.setString(1, firstName);
		stmt.setString(2, lastName);
		ResultSet rs = stmt.executeQuery();
		String value=null;
		if ( rs.last() ) {
			 value = rs.getString("TERM_AND_COND_ACPT_DT");
		}
		return todaysDate.equals(value);
	}
	
	public int returnPortalIDFromMBR_PRTLTable(String firstName, String lastName) throws SQLException {
		return DBOperation.returnPortalID(firstName, lastName);
	}
	
	public int returnMemRegisTypeIDFromMBRTable(String firstName, String lastName, String Dob) throws SQLException {
		return DBOperation.returnMemRegTypeID(firstName, lastName, Dob);
	}

	public int returnMemRegisTypeIDFromMBRTablePortalSpecific(String firstName, String lastName, String Dob, String portalName) throws SQLException {
		return DBOperation.returnMemRegTypeIDPortalSpecific(firstName, lastName, Dob, portalName);
	}

}
