package com.optum.synergy.reference.ui.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.*;
import java.util.*;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.PageObjectBase;

public class DBOperation {

	private static final String ISECDB_USERNAME = "ML6330TH";
	private static final String MyUHCProvisioningDB_USERNAME = "myu0_own";
	private static final String OptumRxProvisioningDB_USERNAME = "OPTUMRX042";
	private static List<String> pathList = new ArrayList<String>();
	private static Map<String, Object> map = new HashMap<String, Object>();

	public static void deleterecordFromPDB(String FirstName, String LastName, String dateOfBirth) throws SQLException {
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		ResultSet rs = null;
		
		try {
			stmt = con.createStatement();
			
			rs = stmt.executeQuery("SELECT HLTHSF_ID,PRVSN_MBR_ID FROM mbr WHERE MDM_FST_NM = \"" + FirstName
					+ "\" AND MDM_LST_NM = \"" + LastName + "\" And MDM_MBR_DOB =\"" + dateOfBirth + "\"");
			String hsid = null;
			String provisionID = null;

			while (rs.next()) {
				hsid = rs.getString(1);
				provisionID = rs.getString(2);
			}

			stmt.executeUpdate("delete  from mbr_prtl where PRVSN_MBR_ID= \"" + provisionID + "\"");
			if (hsid != null) {
				stmt.executeUpdate("delete  from mbr where HLTHSF_ID = \"" + hsid + "\"");
				stmt.executeUpdate("delete  from mbr_extrm_scl_dtl where HLTHSF_ID = \"" + hsid + "\"");
			}
		} finally {
			if ( rs != null ) {
				rs.close();
			}
			if ( stmt != null ) {
				stmt.close();
			}
			con.close();
			con = null;
		}
	}

	/*
     * This method takes firstname, lastname, portal id which need to delete and register portal id  arguments and delete the
     * particular user record from the mbr_prtl for the particular portal
     */
	public static void deleterecordFrommbrprtl(String FirstName, String LastName, String dateOfBirth, int portalid, int regprtlid) throws SQLException {
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		ResultSet rs = null;
		
		try {
			stmt = con.createStatement();
			
			rs = stmt.executeQuery("SELECT PRVSN_MBR_ID FROM mbr WHERE MDM_FST_NM = \"" + FirstName
					+ "\" AND MDM_LST_NM = \"" + LastName + "\" And MDM_MBR_DOB =\"" + dateOfBirth + "\" And MBR_RGST_PRTL_ID = \"" + regprtlid + "\""); 
			String provisionID = null;

			while (rs.next()) {
				provisionID = rs.getString(1);
			}

			stmt.executeUpdate("delete  from mbr_prtl where PRVSN_MBR_ID= \"" + provisionID + "\" AND PRTL_ID = \"" + portalid + "\"");
		} finally {
			if ( rs != null ) {
				rs.close();
			}
			if ( stmt != null ) {
				stmt.close();
			}
			con.close();
			con = null;
		}
	}
	/*
     * This method takes firstname, lastname and SubscriberId/CardHolderId as arguments and delete the
     * particular user record from the PDB and extreme scale
     * (i.e. Use it when there are more than one users with the same firstname and lastname but different subscriber id.)
     */
	public static void deleterecordFromPDBUsingId(String FirstName, String LastName, String id) throws SQLException {
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		ResultSet rs = null;

		try {
			stmt = con.createStatement();

			rs = stmt.executeQuery("SELECT PRVSN_MBR_ID,HLTHSF_ID FROM mbr WHERE MDM_FST_NM = \"" + FirstName
					+ "\" AND MDM_LST_NM = \"" + LastName + "\" AND MDM_MBR_SBSCR_ID = \"" + id + "\"");
			String prvsnid = null;
			String hsid = null;

			while (rs.next()) {
				prvsnid = rs.getString(1);
				hsid = rs.getString(2);
			}

			stmt.executeUpdate("delete FROM mbr_prtl WHERE PRVSN_MBR_ID= \"" + prvsnid + "\"");
			stmt.executeUpdate(
					"delete FROM mbr WHERE PRVSN_MBR_ID = \"" + prvsnid + "\"");
			if (hsid != null) {
				stmt.executeUpdate("delete FROM mbr_extrm_scl_dtl WHERE HLTHSF_ID = \"" + hsid + "\"");
			}
		} finally {
			if ( rs != null ) {
				rs.close();
			}
			if ( stmt != null ) {
				stmt.close();
			}
			con.close();
			con = null;
		}
	}

	public static void deletePortalSpecificRecordFromPDB(String FirstName, String LastName) throws SQLException {
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		ResultSet rs = null;
		int portalNumber= DataStorage.getPortalNumber();
		try {
			stmt = con.createStatement();
			
			rs = stmt.executeQuery("Select PRVSN_MBR_ID from mbr_prtl where MBR_PRTL_FST_NM = \"" + FirstName
					+ "\" AND MBR_PRTL_LST_NM = \"" + LastName + "\" and PRTL_ID="+portalNumber);
			int provisionMbrId=0;

			while (rs.next()) {
				provisionMbrId = rs.getInt(1);
			}
			rs.close();
			
			rs = stmt.executeQuery("SELECT HLTHSF_ID FROM mbr WHERE MDM_FST_NM = \"" + FirstName
					+ "\" AND MDM_LST_NM = \"" + LastName + "\"");
			String hsid = null;

			while (rs.next()) {
				hsid = rs.getString(1);
			}

			stmt.executeUpdate("delete  from mbr_prtl where mbr_prtl_fst_nm= \"" + FirstName + "\" and mbr_prtl_lst_nm= \""
					+ LastName + "\" and PRTL_ID="+portalNumber);
			stmt.executeUpdate(
					"delete FROM mbr WHERE PRVSN_MBR_ID = " + provisionMbrId);
			if (hsid != null) {
				stmt.executeUpdate("delete  from mbr_extrm_scl_dtl where HLTHSF_ID = \"" + hsid + "\"");
			}
		} finally {
			if ( rs != null ) {
				rs.close();
			}
			if ( stmt != null ) {
				stmt.close();
			}
			con.close();
			con = null;
		}
	}
	
	public static void deleterecordFromPDBUsingProvisionID(String FirstName, String LastName) throws SQLException {
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
			
			rs = stmt.executeQuery("SELECT PRVSN_MBR_ID FROM mbr WHERE MDM_FST_NM = '" + FirstName
					+ "' AND MDM_LST_NM = '" + LastName + "'");
			String provisionid = null;

			while (rs.next()) {
				provisionid = rs.getString(1);
			}

			stmt.executeUpdate("delete from mbr_prtl where PRVSN_MBR_ID= '" + provisionid + "'");
			stmt.executeUpdate("delete FROM mbr where PRVSN_MBR_ID= '" + provisionid + "'");
				stmt.executeUpdate("delete  from mbr_extrm_scl_dtl where HLTHSF_ID = (SELECT HLTHSF_ID FROM mbr WHERE MDM_FST_NM = '"
							+ FirstName + "' AND MDM_LST_NM = '" + LastName + "')");
			
		} finally {
			if ( rs != null ) {
				rs.close();
			}
			if ( stmt != null ) {
				stmt.close();
			}
			con.close();
			con = null;
		}
	}

	public static String deleterecordFromMyUHCPDB(String FirstName, String LastName, String DOB) throws SQLException {
		String PersonalID;
		String lstPersonalID = "";
		Connection con = getMyUHCPDBconnection();
		String[] tmpArr = DOB.split("/");
		DOB = tmpArr[2] + "-" + tmpArr[0] + "-" + tmpArr[1];
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
			rs = stmt
					.executeQuery("Select uhcPersonalID from myu001.member_info where myu001.member_info.cn = '"
							+ FirstName.toUpperCase() + " " + LastName.toUpperCase()
							+ "'and myu001.member_info.uhcDateOfBirth='" + DOB + "'");

			while (rs.next()) {
				PersonalID = rs.getString(1);
				if (lstPersonalID.length() > 0) {
					lstPersonalID = lstPersonalID + ",'" + PersonalID + "'";
				} else {
					lstPersonalID = lstPersonalID + "'" + PersonalID + "'";
				}
			}

			stmt.executeUpdate(
					"delete  from myu001.member_info where myu001.member_info.cn = '" + FirstName.toUpperCase() + " "
							+ LastName.toUpperCase() + "'and myu001.member_info.uhcDateOfBirth='" + DOB + "'");
			return lstPersonalID;

		} finally {
			if ( stmt != null ) {
				stmt.close();
			}
			if ( rs != null ) {
				rs.close();
			}
			con.close();
			con = null;
		}
	}

	public static void deleterecordFromISEC(String FirstName, String LastName, String DOB) throws SQLException {

		Connection con = getISECDBConnection();
		Statement stmt = null;
		try {
			String lstPersonalID = deleterecordFromMyUHCPDB(FirstName, LastName, DOB);
			if (lstPersonalID.length() > 0) {

				stmt = con.createStatement();

				stmt.executeUpdate(
						"delete FROM F6330DBB.I_MEMBER_CURRENT where PERSONAL_ID IN (" + lstPersonalID + ")");
			}

		} finally {
			if ( stmt != null ) {
				stmt.close();
			}
			con.close();
			con = null;
		}
	}

	public static Connection getPDBDBConnection() throws SQLException {

		Connection con = null;
		// Obtain database username from runtime environment
		String user = System.getenv("NTID");
		String pwd = System.getenv(System.getProperty("ExecutionEnv") + "PDBpw");
		if (user == null) {
			throw new IllegalStateException("Missing value for DB username environment variable [" + "NTID" + "]");
		}
		if (pwd == null) {
			throw new IllegalStateException("Missing value for DB password environment variable ["
					+ System.getProperty("ExecutionEnv") + "PDBpw" + "]");
		}

		Random random = new Random();
		int index = 1 + random.nextInt(2);

		String dbConnectionString = ReadXMLData.getTestData("DB/PDB", "DBConnectionString_"+index);
		DataStorage.setCustomErrmsg("::DEBUG::Setting DB Connection String to: [" + dbConnectionString + "]");

		if(!dbConnectionString.isEmpty())
		con = DriverManager.getConnection(dbConnectionString, user, pwd);
		else Assert.fail("DBConnectionString is retrieved as Empty String. Please check the value in TestData file");
		return con;
	}

	public static Connection getISECDBConnection() throws SQLException {

		// ISEC DB2 credentials, password must come from environment variable.

		String ISECDB_PWD = System.getenv(System.getProperty("ExecutionEnv") + "IsecDbPw");
		

		if (ISECDB_PWD == null) {
			throw new IllegalStateException("Missing value for ISEC DB password environment variable ["
					+ System.getProperty("ExecutionEnv") + "IsecDbPw" + "] for username [" + ISECDB_USERNAME + "]");
		}

		Connection con;
		String dbcnectionstring = ReadXMLData.getTestData("DB/ISEC", "DBConnectionString");
		con = DriverManager.getConnection(dbcnectionstring, ISECDB_USERNAME, ISECDB_PWD);
		return con;
	}
	
	public static Connection getMyUHCPDBconnection() throws SQLException {
		// MyUhc Provision DB credentials, password must come from environment
		// variable.

		String MyUHCProvisioningDB_PWD = System.getenv(System.getProperty("ExecutionEnv") + "MyUhcPdbPw"); // "asEFq3a8";
		

		if (MyUHCProvisioningDB_PWD == null) {
			throw new IllegalStateException("Missing value for MyUHC Provisioning DB password environment variable ["
					+ System.getProperty("ExecutionEnv") + "MyUhcPdbPw" + "] for username ["
					+ MyUHCProvisioningDB_USERNAME + "]");
		}

		Connection con;
		String dbcnectionstring = ReadXMLData.getTestData("DB/MyUHCProvisioning", "DBConnectionString");
		con = DriverManager.getConnection(dbcnectionstring, MyUHCProvisioningDB_USERNAME, MyUHCProvisioningDB_PWD);
		return con;
	}
	
	public static Connection getOptumRxDBconnection() throws SQLException {
		
		// OptumRx DB credentials, password must come from environment
				// variable.
		
		String OptumRxProvisioningDB_PWD = System.getenv(System.getProperty("ExecutionEnv") + "OptumRxPdbPw");

		if (OptumRxProvisioningDB_PWD == null) {
			throw new IllegalStateException("Missing value for OptumRx Provisioning DB password environment variable ["
					+ System.getProperty("ExecutionEnv") + "OptumRxPdbPw" + "] for username ["
					+ OptumRxProvisioningDB_USERNAME + "]");
		}

		Connection con;
		String dbcnectionstring = ReadXMLData.getTestData("DB/OptumRxProvisioning", "DBConnectionString");
		con = DriverManager.getConnection(dbcnectionstring, OptumRxProvisioningDB_USERNAME, OptumRxProvisioningDB_PWD);
		return con;
	}
	
	public static int recordcountFromMmberTable(String frstname, String lstname) throws SQLException {
		Connection con = getPDBDBConnection();
		int rcrdcnt;
		Statement stmt = null;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS recordcnt from	 mbr where MDM_FST_NM= '" + frstname
					+ "' and MDM_LST_NM= '" + lstname + "'");
			rs.next();
			rcrdcnt = Integer.parseInt(rs.getString(1));
			return rcrdcnt;

		} catch (Exception e) {
			DataStorage.setCustomErrmsg(
					"There is a exception thrown while communicating with PDB [" + e.getMessage() + "]");
			return -1;
		} finally {
			if ( stmt != null ) {
				stmt.close();
			}
			con.close();
			con = null;
		}
	}

	public static int recordcountFromMmberPortalTable(String frstname, String lstname) throws SQLException {
		Connection con = getPDBDBConnection();
		int rcrdcnt;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery("SELECT COUNT(*) AS recordcnt from	 mbr_prtl where mbr_prtl_fst_nm= '"
					+ frstname + "' and mbr_prtl_lst_nm= '" + lstname + "'");
			rs.next();
			rcrdcnt = Integer.parseInt(rs.getString(1));
			return rcrdcnt;
		} catch (Exception e) {
			DataStorage.setCustomErrmsg("There is a exception thrown while communicating with PDB" + e.toString());
			return -1;
		} finally {
			if ( rs != null ) {
				rs.close();
			}
			if ( stmt != null ) {
				stmt.close();
			}
			con.close();
			con = null;
		}
	}
	
	public static String getPortalSubscriberIDFromPDB(String firstName, String lastName) throws SQLException {
		String specificMemberID = "MEMBER_NOT_FOUND";
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery("SELECT MBR_PRTL_SBSCR_ID FROM mbr_prtl WHERE mbr_prtl_fst_nm = '"
					+ firstName + "' AND mbr_prtl_lst_nm = '" + lastName + "'");

			rs.last();
			if (rs.getRow() > 0) {
				specificMemberID = rs.getString(1);
			}

			return specificMemberID;

		} finally {
			if ( rs != null ) {
				rs.close();
			}
			if ( stmt != null ) {
				stmt.close();
			}
			con.close();
			con = null;
		}
	}
	
	public static String getPortalSSNFromPDB(String firstName, String lastName) throws SQLException {
		String ssn = "SSN_NOT_FOUND";
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery("SELECT MBR_PRTL_SSN FROM mbr_prtl WHERE mbr_prtl_fst_nm = '"
					+ firstName + "' AND mbr_prtl_lst_nm = '" + lastName + "'");

			rs.last();
			if (rs.getRow() > 0) {
				ssn = rs.getString(1);
			}

			return ssn;

		} finally {
			if ( rs != null ) {
				rs.close();
			}
			if ( stmt != null ) {
				stmt.close();
			}
			con.close();
			con = null;
		}
	}
	
	public static String getPortalEnSSNFromPDB(String firstName, String lastName) throws SQLException {
		String enssn = "SSN_NOT_FOUND";
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery("SELECT MBR_PRTL_ENCRP_SSN FROM mbr_prtl WHERE mbr_prtl_fst_nm = '"
					+ firstName + "' AND mbr_prtl_lst_nm = '" + lastName + "'");

			rs.last();
			if (rs.getRow() > 0) {
				enssn = rs.getString(1);
			}

			return enssn;

		} finally {
			if ( rs != null ) {
				rs.close();
			}
			if ( stmt != null ) {
				stmt.close();
			}
			con.close();
			con = null;
		}
	}

	public static String getExtremeScaleDetailsFromExtremeScaleTable(String firstName, String lastName, String DOB)
			throws SQLException {
		String extremeScaleDetail = null;
	    String DOB_PDB = new PageObjectBase().getDateInYYYY_MM_DDFormat(DataStorage.getDOB());
		
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(
					"SELECT EXTRM_SCL_DTL FROM mbr_extrm_scl_dtl where HLTHSF_ID = (SELECT HLTHSF_ID FROM mbr WHERE MDM_FST_NM = '"
							+ firstName + "' AND MDM_LST_NM = '" + lastName + "' And MDM_MBR_DOB = '" + DOB_PDB + "')");
			rs.last();
			if (rs.getRow() > 0) {
				extremeScaleDetail = rs.getString(1);
			}
			return extremeScaleDetail;
			
		} finally {
			if ( rs != null ) {
				rs.close();
			}
			if ( stmt != null ) {
				stmt.close();
			}
			con.close();
			con = null;
		}
	}
	
	public static String getExtremeScaleDetailsFromExtremeScaleTablePortalSpecific(String firstName, String lastName, String DOB, String portalName)
			throws SQLException {
		String extremeScaleDetail = null;
	    String DOB_PDB = new PageObjectBase().getDateInYYYY_MM_DDFormat(DataStorage.getDOB());
		int portalNumber = getPortalIdBasedOnPortalName(DataStorage.getPortalName());

		Connection con = getPDBDBConnection();
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(
					"SELECT EXTRM_SCL_DTL FROM mbr_extrm_scl_dtl where HLTHSF_ID = (SELECT HLTHSF_ID FROM mbr WHERE MDM_FST_NM = '"
							+ firstName + "' AND MDM_LST_NM = '" + lastName + "' And MDM_MBR_DOB = '" + DOB_PDB + "'AND mbr_rgst_prtl_id = '" + portalNumber + "')");
			rs.last();
			if (rs.getRow() > 0) {
				extremeScaleDetail = rs.getString(1);
			}
			return extremeScaleDetail;

		} finally {
			if ( rs != null ) {
				rs.close();
			}
			if ( stmt != null ) {
				stmt.close();
			}
			con.close();
			con = null;
		}
	}

	public static String getDetailsFromEpmpLoadTable(String firstName, String lastName, String DOB)
			throws SQLException {
		String epmpLoadDetail = null;
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		ResultSet rs = null;
		String[] tmpArr = DOB.split("/");
		DOB = tmpArr[2] + "-" + tmpArr[0] + "-" + tmpArr[1];
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(
					"SELECT * FROM hlthsf_epmp_load where HLTHSF_ID = (SELECT HLTHSF_ID FROM mbr WHERE MDM_FST_NM = '"
							+ firstName + "' AND MDM_LST_NM = '" + lastName + "' And MDM_MBR_DOB = '" + DOB + "')");
			rs.last();
			if (rs.getRow() > 0) {
				epmpLoadDetail = rs.getString(1);
			}
			return epmpLoadDetail;
 		} finally {
			if ( rs != null ) {
				rs.close();
			}
			if ( stmt != null ) {
				stmt.close();
			}
			con.close();
			con = null;
		}
	}

	public static void cleanupMyUHCmember(String FirstName, String LastName, String DOB) throws SQLException {
		String[] dob = DOB.split("/");
		String DOBWithPDBFormat = dob[2] + "-" + dob[0] + "-" + dob[1];
		deleterecordFromPDB(FirstName, LastName, DOBWithPDBFormat);
		deleterecordFromISEC(FirstName, LastName, DOB);
	}
  
  // code implemented to validate member portal fields
  public static int returnMemPrtlDOB(String firstName, String lastName) throws SQLException{
	  Connection con = getPDBDBConnection();
		int rcrdcnt;

		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * from	 mbr_prtl where mbr_prtl_fst_nm= '" + firstName
					+ "' and mbr_prtl_lst_nm= '" + lastName + "'");
			rs.first();
			rcrdcnt = rs.getInt("MBR_PRTL_DOB");
			return rcrdcnt;

		} catch (Exception e) {
			DataStorage.setCustomErrmsg(
					"Exception thrown while communicating with PDB [" + e.getMessage() + "]");
			return -1;
		} finally {
			con.close();
			con = null;
		}
  }
  
  public static int returnMemPrtlPrvsMbrId(String firstName, String lastName) throws SQLException{
	  Connection con = getPDBDBConnection();
		int rcrdcnt;

		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * from	 mbr_prtl where mbr_prtl_fst_nm= '" + firstName
					+ "' and mbr_prtl_lst_nm= '" + lastName + "'");
			rs.first();
			rcrdcnt = rs.getInt("PRVSN_MBR_ID");
			return rcrdcnt;

		} catch (Exception e) {
			DataStorage.setCustomErrmsg(
					"Exception thrown while communicating with PDB [" + e.getMessage() + "]");
			return -1;
		} finally {
			con.close();
			con = null;
		}
  }
  
  public static int returnMemPrtlPrvsMbrzipCode(String firstName, String lastName) throws SQLException{
	  Connection con = getPDBDBConnection();
		int rcrdcnt;

		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * from	 mbr_prtl where mbr_prtl_fst_nm= '" + firstName
					+ "' and mbr_prtl_lst_nm= '" + lastName + "'");
			rs.first();
			rcrdcnt = rs.getInt("MBR_PRTL_ZIP_CD");
			return rcrdcnt;

		} catch (Exception e) {
			DataStorage.setCustomErrmsg(
					"Exception thrown while communicating with PDB [" + e.getMessage() + "]");
			return -1;
		} finally {
			con.close();
			con = null;
		}
  }
  
  public static int returnMemPrtlPrvsMbrPolicyNumber(String firstName, String lastName) throws SQLException{
	  Connection con = getPDBDBConnection();
		int rcrdcnt;

		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * from	 mbr_prtl where mbr_prtl_fst_nm= '" + firstName
					+ "' and mbr_prtl_lst_nm= '" + lastName + "'");
			rs.first();
			rcrdcnt = rs.getInt("MBR_PRTL_POL_NBR");
			return rcrdcnt;

		} catch (Exception e) {
			DataStorage.setCustomErrmsg(
					"Exception thrown while communicating with PDB [" + e.getMessage() + "]");
			return -1;
		} finally {
			con.close();
			con = null;
		}
  }
  
  public static int returnPortalID(String firstName, String lastName) throws SQLException{
	  Connection con = getPDBDBConnection();
		int rcrdcnt;
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT PRTL_ID FROM mbr_prtl WHERE mbr_prtl_fst_nm = '"
					+ firstName + "' AND mbr_prtl_lst_nm = '" + lastName + "'");
			rs.next();
			rcrdcnt = Integer.parseInt(rs.getString(1));
			return rcrdcnt;
		} catch (Exception e) {
			DataStorage.setCustomErrmsg(
					"Exception thrown while communicating with PDB [" + e.getMessage() + "]");
			return -1;
		} finally {
			con.close();
			con = null;
		}
	}
  
  public static int returnMemRegTypeID(String firstName, String lastName, String Dob) throws SQLException{
	  Connection con = getPDBDBConnection();
		int rcrdcnt;
		try {
			String[] tmpArr = Dob.split("/");
			Dob = tmpArr[2] + "-" + tmpArr[0] + "-" + tmpArr[1];
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT MBR_RGST_TYP_ID FROM mbr WHERE mdm_fst_nm = '"
					+ firstName + "' AND mdm_lst_nm = '" + lastName + "' AND mdm_mbr_dob = '" + Dob + "'");
			rs.next();
			rcrdcnt = Integer.parseInt(rs.getString(1));
			return rcrdcnt;
		} catch (Exception e) {
			DataStorage.setCustomErrmsg(
					"Exception thrown while communicating with PDB [" + e.getMessage() + "]");
			return -1;
		} finally {
			con.close();
			con = null;
		}
	}
  
   public static int provisionMbrId(String FirstName, String LastName)
			throws SQLException {
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		ResultSet rs = null;
			try {
				stmt = con.createStatement();
				rs = stmt.executeQuery("Select PRVSN_MBR_ID from mbr_prtl where MBR_PRTL_FST_NM = \"" + FirstName
						+ "\" AND MBR_PRTL_LST_NM = \"" + LastName + "\"");
				int provisionMbrId= 0;

				while (rs.next()) {
					provisionMbrId = rs.getInt(1);
				}		
				System.out.println(provisionMbrId);
			return provisionMbrId;	

		} finally {
			if ( rs != null ) {
				rs.close();
			}
			if ( stmt != null ) {
				stmt.close();
			}
			con.close();
			con = null;
		}
	}

	public static void updateRecordFromPDB(String U_FirstName, String U_LastName,
			String U_DOB, String U_Zip, String U_SSN, int provisionMbrId) throws SQLException {
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		String[] tmpArr = U_DOB.split("/");
		U_DOB = tmpArr[2] + "-" + tmpArr[0] + "-" + tmpArr[1];
		stmt = con.createStatement();
			System.out.println("UPDATE MBR SET MDM_FST_NM = \"" + U_FirstName + "\" , MDM_LST_NM = \"" + U_LastName
					+ "\" , MDM_MBR_DOB = \"" + U_DOB + "\" , MDM_MBR_ZIP_CD = \"" + U_Zip + "\" and MDM_MBR_SSN = \""
					+ U_SSN + "\" WHERE PRVSN_MBR_ID= \"" + provisionMbrId + "\"");
			stmt.executeUpdate("UPDATE MBR SET MDM_FST_NM = \"" + U_FirstName + "\" , MDM_LST_NM = \"" + U_LastName
					+ "\" , MDM_MBR_DOB = \"" + U_DOB + "\" , MDM_MBR_ZIP_CD = \"" + U_Zip + "\" and MDM_MBR_SSN = \""
					+ U_SSN + "\" WHERE PRVSN_MBR_ID= \"" + provisionMbrId + "\"");
			System.out.println("PDB updated with new record");
		}
	
	public static void updateRecordInMemberTable(String U_FirstName, String U_LastName,
			String U_DOB, String U_Zip, String U_SubscriberID, int provisionMbrId) throws SQLException {
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		String[] tmpArr = U_DOB.split("/");
		U_DOB = tmpArr[2] + "-" + tmpArr[0] + "-" + tmpArr[1];
		stmt = con.createStatement();
			stmt.executeUpdate("UPDATE MBR SET MDM_FST_NM = \"" + U_FirstName + "\" , MDM_LST_NM = \"" + U_LastName
					+ "\" , MDM_MBR_DOB = \"" + U_DOB + "\" , MDM_MBR_ZIP_CD = \"" + U_Zip + "\" and MDM_MBR_SBSCR_ID = \""
					+ U_SubscriberID + "\" WHERE PRVSN_MBR_ID= \"" + provisionMbrId + "\"");
		}
	
	public static void updateRecordInMemberPotalTable(String U_FirstName, String U_LastName,
			String U_DOB, String U_Zip, String U_SubscriberID, int provisionMbrId) throws SQLException {
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		String[] tmpArr = U_DOB.split("/");
		U_DOB = tmpArr[2] + "-" + tmpArr[0] + "-" + tmpArr[1];
		stmt = con.createStatement();
			stmt.executeUpdate("UPDATE MBR PRTL SET MDM_FST_NM = \"" + U_FirstName + "\" , MDM_LST_NM = \"" + U_LastName
					+ "\" , MDM_MBR_DOB = \"" + U_DOB + "\" , MDM_MBR_ZIP_CD = \"" + U_Zip + "\" and MDM_MBR_SBSCR_ID = \""
					+ U_SubscriberID + "\" WHERE PRVSN_MBR_ID= \"" + provisionMbrId + "\"");
		}

	public static void updateFieldInMemberTable(String field, String fieldValue, String provisionMbrId) throws SQLException {
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		if (field == "MDM_MBR_DOB") {
			String[] tmpArr = fieldValue.split("/");
			fieldValue = tmpArr[2] + "-" + tmpArr[0] + "-" + tmpArr[1];
		}
		stmt = con.createStatement();
		stmt.executeUpdate("UPDATE MBR SET " + field + " = \"" + fieldValue + "\" WHERE PRVSN_MBR_ID= \"" + provisionMbrId + "\"");
	}

	public static void updateFieldInMemberPortalTable(String field, String fieldValue, String provisionMbrId) throws SQLException {
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		if (field == "MBR_PRTL_DOB") {
			String[] tmpArr = fieldValue.split("/");
			fieldValue = tmpArr[2] + "-" + tmpArr[0] + "-" + tmpArr[1];
		}
		stmt = con.createStatement();
		stmt.executeUpdate("UPDATE MBR_PRTL SET " + field + " = \"" + fieldValue + "\" WHERE PRVSN_MBR_ID= \"" + provisionMbrId + "\"");
	}
	
	public static String getExtremeScaleDetailsFromExtremeScaleTableForApostropheData(String firstName, String lastName)
			throws SQLException {
		String extremeScaleDetail = null;
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(
					"SELECT EXTRM_SCL_DTL FROM mbr_extrm_scl_dtl where HLTHSF_ID = (SELECT HLTHSF_ID FROM mbr WHERE MDM_FST_NM = \""+ firstName + "\" AND MDM_LST_NM = \"" + lastName + "\")");
			rs.last();
			if (rs.getRow() > 0) {
				extremeScaleDetail = rs.getString(1);
			}
			return extremeScaleDetail;

		} finally {
			if ( rs != null ) {
				rs.close();
			}
			if ( stmt != null ) {
				stmt.close();
			}
			con.close();
			con = null;
		}
	}
	
	public static void deleteRecordFromExtremeScale(String firstName, String lastName, String finalDOB)
			throws SQLException {
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		try {
			stmt = con.createStatement();
			stmt.executeUpdate(
					"delete FROM mbr_extrm_scl_dtl where HLTHSF_ID = (SELECT HLTHSF_ID FROM mbr WHERE MDM_FST_NM = \""
							+ firstName + "\" AND MDM_LST_NM = \"" + lastName + "\" AND MDM_MBR_DOB = \"" + finalDOB + "\")");

		} catch (Exception e) {
			System.err.println("Error in deleting data from Extreme scale table");
		} finally {

			if (stmt != null) {
				stmt.close();
			}
			con.close();
			con = null;
		}
	}
	
	public static Map<String, String> getRecordFromMBRTableByFN_LN_DOB_and_PortalID()
			throws SQLException {
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		ResultSet rs = null;
		Map<String, String> userDetails = new HashMap<String, String>();
		String firstName = DataStorage.getFirstName();
		String lastName = DataStorage.getLastName();
		String dob = DataStorage.getDOB();

		if(firstName == null || lastName == null || dob == null)
			Assert.fail("Some or all of the Firstname/Lastname/DOB are coming as null from the Test Data file. Please check test data or the data reading step");

		int portalNumber = getPortalIdBasedOnPortalName(DataStorage.getPortalName());
		String[] initialDOB = dob.split("/");
		String finalDOB = initialDOB[2] + "-" + initialDOB[0] + "-" + initialDOB[1];
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery("Select * from mbr where MDM_FST_NM = \"" + firstName + "\" AND MDM_LST_NM = \""
					+ lastName + "\" AND MDM_MBR_DOB = \"" + finalDOB + "\" AND MBR_RGST_PRTL_ID = \"" + portalNumber+"\"");

			Assert.assertTrue("MBR table record not found for the user with details as, FirstName: "+firstName+", LastName: "+lastName+", DOB: "+dob,rs.first());

			rs.first();
				userDetails.put("MDMSubId", rs.getString("MDM_MBR_SBSCR_ID"));
				userDetails.put("GroupNumber", rs.getString("MDM_MBR_POL_NBR"));
				userDetails.put("EID", rs.getString("MDM_MBR_EID"));
				userDetails.put("Zip", rs.getString("MDM_MBR_ZIP_CD"));
				userDetails.put("Zip1", rs.getString("MDM_MBR_ZIP_CD"));
				userDetails.put("SSN", rs.getString("MDM_MBR_SSN"));
				userDetails.put("RgstPrtlID", rs.getString("MBR_RGST_PRTL_ID"));
				userDetails.put("Account", rs.getString("MDM_MBR_ACCT_ID"));
				userDetails.put("carrier", rs.getString("MDM_MBR_CARR_ID"));
				System.out.println("MBR TABLE DETAILS::- "+userDetails);

			return userDetails;
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			con.close();
			con = null;
		}
	}
	public static Map<String, String> getRecordFromMBRTableByFN_LN_DOB_and_PortalID(String aliasName) throws SQLException {
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		ResultSet rs = null;
		Map<String, String> userDetails = new HashMap<String, String>();
		String firstName = DataStorage.getFirstName();
		String lastName = DataStorage.getLastName();
		if (aliasName.equalsIgnoreCase("FirstName")) {
			firstName = DataStorage.getFirstName_Alias();
		} else if (aliasName.equalsIgnoreCase("LastName")) {
			lastName = DataStorage.getLastName_Alias();
		} else {
			firstName = DataStorage.getFirstName_Alias();
			lastName = DataStorage.getLastName_Alias();
		}
		String dob = DataStorage.getDOB();
		int portalNumber = getPortalIdBasedOnPortalName(DataStorage.getPortalName());
		String[] initialDOB = dob.split("/");
		String finalDOB = initialDOB[2] + "-" + initialDOB[0] + "-" + initialDOB[1];

		Assert.assertNotNull("firstName value is null",firstName);
		Assert.assertNotNull("lastName value is null",lastName);
		Assert.assertNotNull("finalDOB value is null",finalDOB);
		Assert.assertNotNull("portalNumber value is null",portalNumber);

		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery("Select * from mbr where MDM_FST_NM = \"" + firstName + "\" AND MDM_LST_NM = \""
					+ lastName + "\" AND MDM_MBR_DOB = \"" + finalDOB + "\" AND MBR_RGST_PRTL_ID = \"" + portalNumber + "\"");

			Assert.assertTrue("MBR table record not found for the user with details as, FirstName: "+firstName+", LastName: "+lastName+", DOB: "+dob,rs.first());

			rs.first();
			userDetails.put("MDMSubId", rs.getString("MDM_MBR_SBSCR_ID"));
			userDetails.put("GroupNumber", rs.getString("MDM_MBR_POL_NBR"));
			userDetails.put("EID", rs.getString("MDM_MBR_EID"));
			userDetails.put("Zip", rs.getString("MDM_MBR_ZIP_CD"));
			userDetails.put("SSN", rs.getString("MDM_MBR_SSN"));
			userDetails.put("RgstPrtlID", rs.getString("MBR_RGST_PRTL_ID"));
			System.out.println("mbr table details:- " + userDetails);
			return userDetails;
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			con.close();
			con = null;
		}
	}

	public static String getColumnValueFromMemberTable(String firstname, String lastname, String columnName, String dob)
			throws SQLException {
		// TODO Auto-generated method stub
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		ResultSet rs = null;
		String[] initialDOB = dob.split("/");
		String finalDOB = initialDOB[2] + "-" + initialDOB[0] + "-" + initialDOB[1];
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery("SELECT *FROM mbr WHERE MDM_FST_NM =\"" + firstname + "\" AND MDM_LST_NM =\""
					+ lastname + "\" And MDM_MBR_DOB =\"" + finalDOB + "\"");
			rs.next();
			switch (columnName) {
			case "MDM_FST_NM":
				return rs.getString("MDM_FST_NM");
			case "MDM_LST_NM":
				return rs.getString("MDM_LST_NM");
			case "MDM_MBR_DOB":
				return rs.getString("MDM_MBR_DOB");
			case "MDM_MBR_SBSCR_ID":
				return rs.getString("MDM_MBR_SBSCR_ID");
			case "MDM_MBR_EID":
				return rs.getString("MDM_MBR_EID");
			case "MDM_MBR_ZIP_CD":
				return rs.getString("MDM_MBR_ZIP_CD");
			case "MBR_RGST_PRTL_ID":
				return rs.getString("MBR_RGST_PRTL_ID");
			default:
				System.out.println("Given column name" + columnName + " is not present in the table");
				return null;
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		} finally {
			if (stmt != null) {
				stmt.close();
			}
			con.close();
			con = null;
		}
	}

	public static Map<String, String> getRecordFromMBRPRTLTableByProvisionID(String portalName)
			throws SQLException {
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		ResultSet rs = null;
		Map<String, String> userDetails = new HashMap<String, String>();
		String firstName = DataStorage.getFirstName();
		String lastName = DataStorage.getLastName();
		int portalNumber = getPortalIdBasedOnPortalName(DataStorage.getPortalName());
		String dob = DataStorage.getDOB();

		if(firstName == null || lastName == null || dob == null)
			Assert.fail("Some or all of the Firstname/Lastname/DOB are coming as null from the Test Data file. Please check test data or the data reading step");

		String[] initialDOB = dob.split("/");
		String finalDOB = initialDOB[2] + "-" + initialDOB[0] + "-" + initialDOB[1];
		try {
			stmt = con.createStatement();


			/**
			 * Getting PRVSN_MBR_ID from MBR table using FirstName, LastName, DOB, PortalID
			 */
			rs = stmt.executeQuery("Select PRVSN_MBR_ID from mbr where MDM_FST_NM = \"" + firstName + "\" AND MDM_LST_NM = \""
					+ lastName + "\" AND MDM_MBR_DOB = \"" + finalDOB + "\" AND MBR_RGST_PRTL_ID = \"" + portalNumber+"\"");

			Assert.assertTrue("MBR table record not found for the user with the details [FirstName- "+firstName+"::LastName- "+lastName+"::DOB- "+finalDOB+"::PortalId- "+portalNumber+"]",rs.first());

			int provisionID = rs.getInt(1);

			rs.close();

			/**
			 * Getting Record from MBR_PRTL table using PRVSN_MBR_ID
			 */
			portalNumber = getPortalIdBasedOnPortalName(portalName);
			rs = stmt.executeQuery(
					"Select * from mbr_prtl where PRVSN_MBR_ID= \"" + provisionID + "\" AND PRTL_ID= \"" + portalNumber+"\"");
			Assert.assertTrue("No record found for the user in mbr_prtl table for "+portalName+" with the Provision ID: "+provisionID,rs.first());

				userDetails.put("FirstName", rs.getString("MBR_PRTL_FST_NM"));
				userDetails.put("LastName", rs.getString("MBR_PRTL_LST_NM"));
				userDetails.put("DOB", rs.getString("MBR_PRTL_DOB"));
				userDetails.put("PrtlSubId", rs.getString("MBR_PRTL_SBSCR_ID"));
				userDetails.put("GroupNumber", rs.getString("MBR_PRTL_POL_NBR"));
				userDetails.put("AltId", rs.getString("MBR_PRTL_SPC_MBR_ID"));
				userDetails.put("Zip", rs.getString("MBR_PRTL_ZIP_CD"));
				userDetails.put("Zip1", rs.getString("MBR_PRTL_ZIP_CD"));
				userDetails.put("SSN", rs.getString("MBR_PRTL_SSN"));
				userDetails.put("PrtlSSN", rs.getString("MBR_PRTL_SSN"));
			System.out.println("mbr_prtl table details:- "+userDetails);
			return userDetails;
			} finally {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				con.close();
				con = null;
		}
	}
	public static Map<String, String> getRecordFromMBRPRTLTableByProvisionId(String portalName,String aliasName)
			throws SQLException {
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		ResultSet rs = null;
		Map<String, String> userDetails = new HashMap<String, String>();
		String firstName = DataStorage.getFirstName();
		String lastName = DataStorage.getLastName();

		if(firstName == null || lastName == null)
			Assert.fail("Some or all of the Firstname/Lastname are coming as null from the Test Data file. Please check test data or the data reading step");

		if (aliasName.equalsIgnoreCase("FirstName")) {
			firstName = DataStorage.getFirstName_Alias();
		} else if (aliasName.equalsIgnoreCase("LastName")) {
			lastName = DataStorage.getLastName_Alias();
		} else{
			firstName = DataStorage.getFirstName_Alias();
			lastName = DataStorage.getLastName_Alias();
		}
		int portalNumber = getPortalIdBasedOnPortalName(DataStorage.getPortalName());
		String dob = DataStorage.getDOB();
		String[] initialDOB = dob.split("/");
		String finalDOB = initialDOB[2] + "-" + initialDOB[0] + "-" + initialDOB[1];

		Assert.assertNotNull("firstName value is null",firstName);
		Assert.assertNotNull("lastName value is null",lastName);
		Assert.assertNotNull("finalDOB value is null",finalDOB);
		Assert.assertNotNull("portalNumber value is null",portalNumber);

		try {
			stmt = con.createStatement();

			/**
			 * Getting PRVSN_MBR_ID from MBR table using FirstName, LastName, DOB, PortalID
			 */
			rs = stmt.executeQuery("Select PRVSN_MBR_ID from mbr where MDM_FST_NM = \"" + firstName + "\" AND MDM_LST_NM = \""
					+ lastName + "\" AND MDM_MBR_DOB = \"" + finalDOB + "\" AND MBR_RGST_PRTL_ID = \"" + portalNumber+"\"");

			Assert.assertTrue("No record found for the user with the details [FirstName- "+firstName+"::LastName- "+lastName+"::DOB- "+finalDOB+"::PortalId- "+portalNumber+"]",rs.first());

			int provisionID = rs.getInt(1);

			rs.close();

			/**
			 * Getting Record from MBR_PRTL table using PRVSN_MBR_ID
			 */
			portalNumber = getPortalIdBasedOnPortalName(portalName);
			rs = stmt.executeQuery(
					"Select * from mbr_prtl where PRVSN_MBR_ID= \"" + provisionID + "\" AND PRTL_ID= \"" + portalNumber+"\"");
			Assert.assertTrue("No record found for the user in mbr_prtl table with the Provision ID: "+provisionID,rs.first());

			userDetails.put("FirstName", rs.getString("MBR_PRTL_FST_NM"));
			userDetails.put("LastName", rs.getString("MBR_PRTL_LST_NM"));
			userDetails.put("DOB", rs.getString("MBR_PRTL_DOB"));
			userDetails.put("PrtlSubId", rs.getString("MBR_PRTL_SBSCR_ID"));
			userDetails.put("GroupNumber", rs.getString("MBR_PRTL_POL_NBR"));
			userDetails.put("AltId", rs.getString("MBR_PRTL_SPC_MBR_ID"));
			userDetails.put("Zip", rs.getString("MBR_PRTL_ZIP_CD"));
			userDetails.put("SSN", rs.getString("MBR_PRTL_SSN"));
			System.out.println("mbr_prtl table details:- "+userDetails);
			return userDetails;
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			con.close();
			con = null;
		}
	}

	public static int getPortalIdBasedOnPortalName(String portalName) {
		int portalNumber = 0;
		if (portalName.equalsIgnoreCase("CAP") || portalName.equalsIgnoreCase("UHCHA") || portalName.equalsIgnoreCase("UHCRA") || portalName.equalsIgnoreCase("UHCRAF") || portalName.equalsIgnoreCase("DISNEY") || portalName.equalsIgnoreCase("BANKAARP")) {
			portalNumber = 1;
		} else if (portalName.equalsIgnoreCase("LAWW")) {
			portalNumber = 1262;
		} else if (portalName.equalsIgnoreCase("OPTUMRX") || portalName.equalsIgnoreCase("BAZ") || portalName.equalsIgnoreCase("SERVEYOU") || portalName.equalsIgnoreCase("AHC") || portalName.equalsIgnoreCase("PHP")|| portalName.equalsIgnoreCase("PAI")|| portalName.equalsIgnoreCase("TCC")|| portalName.equalsIgnoreCase("OPTUMRX-AARP")|| portalName.equalsIgnoreCase("BCBSSC")|| portalName.equalsIgnoreCase("AMERIHEALTH") || portalName.equalsIgnoreCase("AHA") || portalName.equalsIgnoreCase("IBX")) {
			portalNumber = 1264;
		} else if (portalName.equalsIgnoreCase("MYUHC") || portalName.equalsIgnoreCase("COMMUNITYANDSTATE") || portalName.equalsIgnoreCase("HEALTHSELECT") || portalName.equalsIgnoreCase("MYHEALTHCAREVIEW") || portalName.equalsIgnoreCase("SSOMYUHC") ||portalName.equalsIgnoreCase("HarvardPilgrimSSO")|| portalName.equalsIgnoreCase("BSCA")) {
			portalNumber = 1265;
		} else if (portalName.equalsIgnoreCase("WCP")) {
			portalNumber = 1268;
		} else if (portalName.equalsIgnoreCase("BRIOVARX")) {
			portalNumber = 1280;
		} else if (portalName.equalsIgnoreCase("RALLYDHP")) {
			portalNumber = 1265;
		} else if (portalName.equalsIgnoreCase("MNR") || portalName.equalsIgnoreCase("AARP") || portalName.equalsIgnoreCase("MEDICA") || portalName.equalsIgnoreCase("RETIREE") || portalName.equalsIgnoreCase("MEDICARE")) {
			portalNumber = 1282;
		} else if (portalName.equalsIgnoreCase("PHS")) {
			portalNumber = 1291;
		} else if (portalName.equalsIgnoreCase("MYOPTUM")) {
			portalNumber = 1292;
		} else if (portalName.equalsIgnoreCase("WOMENSHEALTH") || portalName.equalsIgnoreCase("WOMENSHEALTH-UHC") || portalName.equalsIgnoreCase("WOMENSHEALTH-OPTUM")) {
			portalNumber = 1319;
		} else if (portalName.equalsIgnoreCase("GEHUB")) {
			portalNumber = 1277;
		} else if (portalName.equalsIgnoreCase("RailRoadSSO")) {
			portalNumber = 1378;
		}
		else {
			Assert.fail("Please check if you are looking for correct portal- "+portalName);
		}
		return portalNumber;
	}

	public static Map<String, Object> getExtremescaledetailsAsMap() throws SQLException {
		String firstName = DataStorage.getFirstName();
		String lastName = DataStorage.getLastName();
		String DOB = DataStorage.getDOB();

		if(firstName == null || lastName == null || DOB == null)
			Assert.fail("Some or all of the Firstname/Lastname/DOB are coming as null from the Test Data file. Please check test data or the data reading step");

		String[] initialDOB = DOB.split("/");
		String DOB_PDB = initialDOB[2] + "-" + initialDOB[0] + "-" + initialDOB[1];
		int portalNumber = getPortalIdBasedOnPortalName(DataStorage.getPortalName());
		String extremeScaleDetails = "";
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		ResultSet rs = null;
		stmt = con.createStatement();
		rs = stmt.executeQuery(
				"SELECT EXTRM_SCL_DTL FROM mbr_extrm_scl_dtl where HLTHSF_ID = (SELECT HLTHSF_ID FROM mbr WHERE MDM_FST_NM = \""
						+ firstName + "\" AND MDM_LST_NM like \"" +"%"+ lastName +"%"+ "\" And MDM_MBR_DOB = \"" + DOB_PDB
						+ "\" And MBR_RGST_PRTL_ID= \"" + portalNumber + "\")");
		rs.last();
		if (rs.getRow() > 0) {
			extremeScaleDetails = rs.getString(1);	
			
		} else {
			Assert.fail("Unable to find extreme scale record with user details: FirstName-"+firstName+" LastName-"+lastName+" DOB-"+DOB_PDB+" PortalNumber-"+portalNumber);
		}
		JSONObject object1 = new JSONObject(extremeScaleDetails);
		String nodePath = "";
		readObject(object1, nodePath);
		return map;
	}
	
	public static Map<String, Object> getExtremescaledetailsAsMapByUsername() throws SQLException {
		String userName = DataStorage.getUserName();
		String extremeScaleDetails = "";
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		ResultSet rs = null;
		stmt = con.createStatement();
		rs = stmt.executeQuery("SELECT EXTRM_SCL_DTL FROM mbr_extrm_scl_dtl where EXTRM_SCL_DTL like '"+"%"+userName + "%"+ "'" );
		rs.last();
		if (rs.getRow() > 0) {
			extremeScaleDetails = rs.getString(1);
		} else {
			Assert.fail("Unable to find extreme scale record for username: "+userName);
		}
		JSONObject object1 = new JSONObject(extremeScaleDetails);
		String nodePath = "";
		readObject(object1, nodePath);
		return map;
	}

	private static void readObject(JSONObject object, String nodePath) {
		Iterator<String> keysItr = object.keys();
		String parentPath = nodePath;
		while (keysItr.hasNext()) {
			String key = keysItr.next();
			Object value = object.get(key);
			if (parentPath != "")
				nodePath = parentPath + "." + key;
			else if (parentPath == "")
				nodePath = parentPath + key;
			if (value instanceof JSONArray) {
				readArray((JSONArray) value, nodePath);
			} else if (value instanceof JSONObject) {
				readObject((JSONObject) value, nodePath);
			} else if (value instanceof String) {
				pathList.add(nodePath);
			//	System.out.println(nodePath+"="+value);
				map.put(nodePath, (String) value);
			} else { // is a value
				pathList.add(nodePath);
			//	System.out.println(nodePath+"="+value);
				map.put(nodePath, value);
			}
		}
	}

	private static void readArray(JSONArray array, String nodePath) {
		String parentPath = nodePath;
		for (int i = 0; i < array.length(); i++) {
			Object value = array.get(i);
			nodePath = parentPath + "[" + i + "]";
			if (value instanceof JSONArray) {
				readArray((JSONArray) value, nodePath);
			} else if (value instanceof JSONObject) {
				readObject((JSONObject) value, nodePath);
			} else if (value instanceof String) {
				pathList.add(nodePath);
			//	System.out.println(nodePath+"="+value);
				map.put(nodePath, (String) value);
			} else { // is a value
				pathList.add(nodePath);
			//	System.out.println(nodePath+"="+value);
				map.put(nodePath, value);
			}
		}
	}
	
	public static Map<String, Object> getExtremescaledetailsAsMapForAlias(String firstName,String lastName) throws SQLException {
		String dateOfBirth = new PageObjectBase().getDateInYYYY_MM_DDFormat(DataStorage.getDOB());
		int portalNumber = getPortalIdBasedOnPortalName(DataStorage.getPortalName());
		String extremeScaleDetails = "";
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		ResultSet rs = null;
		stmt = con.createStatement();
		rs = stmt.executeQuery(
				"SELECT EXTRM_SCL_DTL FROM mbr_extrm_scl_dtl where HLTHSF_ID = (SELECT HLTHSF_ID FROM mbr WHERE MDM_FST_NM = '"
						+ firstName + "' AND MDM_LST_NM like '" +"%"+ lastName +"%"+ "' And MDM_MBR_DOB = '" + dateOfBirth
						+ "' And MBR_RGST_PRTL_ID= '" + portalNumber + "')");

		Assert.assertTrue("No record found in exetreme scale table for the user with details, FirstName: "+firstName+", LastName: "+lastName+", DOB: "+dateOfBirth,rs.last());

		rs.last();

		if (rs.getRow() > 0) {
			extremeScaleDetails = rs.getString(1);	
		}
		JSONObject object1 = new JSONObject(extremeScaleDetails);
		String nodePath = "";
		readObject(object1, nodePath);
		return map;
	}
	
	 public static int returnMemRegTypeIDPortalSpecific(String firstName, String lastName, String Dob, String portalName) throws SQLException{
		  Connection con = getPDBDBConnection();
			int rcrdcnt;
			try {
				String[] tmpArr = Dob.split("/");
				Dob = tmpArr[2] + "-" + tmpArr[0] + "-" + tmpArr[1];
				int portalNumber = getPortalIdBasedOnPortalName(DataStorage.getPortalName());
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery("SELECT MBR_RGST_TYP_ID FROM mbr WHERE mdm_fst_nm = '"
						+ firstName + "' AND mdm_lst_nm = '" + lastName + "' AND mdm_mbr_dob = '" + Dob + "' AND mbr_rgst_prtl_id = '" + portalNumber + "'");
				rs.next();
				rcrdcnt = Integer.parseInt(rs.getString(1));
				return rcrdcnt;
			} catch (Exception e) {
				DataStorage.setCustomErrmsg(
						"Exception thrown while communicating with PDB [" + e.getMessage() + "]");
				return -1;
			} finally {
				con.close();
				con = null;
			}
		}
	public static Map<String, Object> memberEligibilityDetailsAsMap() throws SQLException {
		String firstName = DataStorage.getFirstName();
		String lastName = DataStorage.getLastName();
		String DOB = DataStorage.getDOB();

		if (firstName == null || lastName == null || DOB == null)
			Assert.fail(
					"Some or all of the Firstname/Lastname/DOB are coming as null from the Test Data file. Please check test data or the data reading step");

		DOB = PageObjectBase.getDateInYYYY_MM_DDFormat(DOB);
		int portalNumber = getPortalIdBasedOnPortalName(DataStorage.getPortalName());
		String memberEligibilityDetails = "";
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		ResultSet rs = null;
		stmt = con.createStatement();
		rs = stmt.executeQuery(
				"SELECT MBR_PRTL_ELIGIBILITY_RESPONSE FROM mbr_prtl where PRVSN_MBR_ID = (SELECT PRVSN_MBR_ID FROM mbr WHERE MDM_FST_NM = \""
						+ firstName + "\" AND MDM_LST_NM like \"" + "%" + lastName + "%" + "\" And MDM_MBR_DOB = \""
						+ DOB + "\" And MBR_RGST_PRTL_ID= \"" + portalNumber + "\")");
		rs.last();
		if (rs.getRow() > 0) {
			memberEligibilityDetails = rs.getString(1);
		}
		JSONObject object1 = new JSONObject(memberEligibilityDetails);
		String nodePath = "";
		readObject(object1, nodePath);
		return map;
	}
	/**
	 * Method to update Expire_TS field in MBR_PRTL table to the current date with timestamp 00:00:00
	 * @author vchaube1
	 * @param firstName
	 * @param lastName
	 * @param dateOfBirth
	 * @param portalID
	 * @param regPrtlID
	 * @throws SQLException
	 */

	public static void updateExpire_TS(String firstName, String lastName, String dateOfBirth, int portalID, int regPrtlID) throws SQLException {
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		ResultSet rs = null;

		try {
			stmt = con.createStatement();

			rs = stmt.executeQuery("SELECT PRVSN_MBR_ID FROM mbr WHERE MDM_FST_NM = \"" + firstName
					+ "\" AND MDM_LST_NM = \"" + lastName + "\" And MDM_MBR_DOB =\"" + dateOfBirth + "\" And MBR_RGST_PRTL_ID = \"" + regPrtlID + "\"");
			String provisionID = null;

			while (rs.next()) {
				provisionID = rs.getString(1);
			}

			if(provisionID == null)
				Assert.fail("Provision ID is coming as null for the user [FirstName: "+firstName+", LastName: "+lastName+", DOB: "+dateOfBirth);

			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			Date date = new Date();
			String currentDate = formatter.format((date));
			String updatedDate = currentDate + " 00:00:00";

			int status = stmt.executeUpdate("UPDATE mbr_prtl SET EXPIRE_TS =\""+updatedDate+"\" WHERE PRVSN_MBR_ID=\""+provisionID+"\" AND PRTL_ID = \""+portalID+"\"");

			Assert.assertEquals("Issue in updating the EXPIRE_TS in the PDB", 1,status);

			rs = stmt.executeQuery("Select EXPIRE_TS from mbr_prtl where PRVSN_MBR_ID= \"" + provisionID + "\" AND PRTL_ID = \"" + portalID + "\"");
			String expireTS_PDB = null;
			while (rs.next()) {
				expireTS_PDB = rs.getString(1);
			}

			Assert.assertEquals("EXPIRE_TS Field is not updated to the current date",updatedDate,expireTS_PDB.substring(0,expireTS_PDB.length()-2));

		} finally {
			if ( rs != null ) {
				rs.close();
			}
			if ( stmt != null ) {
				stmt.close();
			}
			con.close();
			con = null;
		}
	}
	/**
	 * Method to verify Expire_TS field in MBR_PRTL table
	 * @author vchaube1
	 * @param firstName
	 * @param lastName
	 * @param dateOfBirth
	 * @param portalID
	 * @param regPrtlID
	 * @param numberfDays
	 * @throws SQLException
	 * @throws ParseException
	 */

	public static void verifyExpire_TS(String firstName, String lastName, String dateOfBirth, int portalID, int regPrtlID, int numberfDays) throws SQLException, ParseException {
		Connection con = getPDBDBConnection();
		Statement stmt = null;
		ResultSet rs = null;

		try {
			stmt = con.createStatement();

			rs = stmt.executeQuery("SELECT PRVSN_MBR_ID FROM mbr WHERE MDM_FST_NM = \"" + firstName
					+ "\" AND MDM_LST_NM = \"" + lastName + "\" And MDM_MBR_DOB =\"" + dateOfBirth + "\" And MBR_RGST_PRTL_ID = \"" + regPrtlID + "\"");
			String provisionID = null;

			while (rs.next()) {
				provisionID = rs.getString(1);
			}

			if(provisionID == null)
				Assert.fail("Provision ID is coming as null for the user [FirstName: "+firstName+", LastName: "+lastName+", DOB: "+dateOfBirth);

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Date date = new Date();
			String currentDate = format.format((date));
			date = format.parse(currentDate);
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);
			calendar.add(Calendar.DAY_OF_YEAR, numberfDays);
			String nextDate = format.format(calendar.getTime());


			rs = stmt.executeQuery("Select EXPIRE_TS from mbr_prtl where PRVSN_MBR_ID= \"" + provisionID + "\" AND PRTL_ID = \"" + portalID + "\"");
			String expireTS_PDB = null;
			while (rs.next()) {
				expireTS_PDB = rs.getString(1);
			}

			Assert.assertEquals("Incorrect EXPIRE_TS date found in PDB MBR_PRTL table",nextDate,expireTS_PDB.split(" ")[0]);

		} finally {
			if ( rs != null ) {
				rs.close();
			}
			if ( stmt != null ) {
				stmt.close();
			}
			con.close();
			con = null;
		}
	}
}
