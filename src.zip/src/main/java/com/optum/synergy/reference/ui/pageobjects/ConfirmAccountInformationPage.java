package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

public class ConfirmAccountInformationPage extends PageObjectBase {
	
	@FindBy(how = How.CLASS_NAME, using = "form__content")
	private WebElement formContent;
	
	@FindBy(how = How.ID, using = "confirmEmail2")
	private WebElement confirmEmail2Field;
	
	@FindBy(how = How.XPATH, using = "//span[@class='step-three-option__icon icon-email']/../span[2]")
	private WebElement emailLabel;
	
	@FindBy(how = How.XPATH, using = "//span[@class='step-three-option__icon icon-phone']/../span[2]")
	private WebElement phoneLabel;
	
	@FindBy(how = How.XPATH, using = "//span[@class='step-three-option__icon icon-sms_text']/../span[2]")
	private WebElement smsTextLabel;
	
	@FindBy(how = How.XPATH, using = "//h4/strong|//h5/strong")
	private WebElement numberPlaceHolder;

	@FindBy(how = How.CLASS_NAME, using = "message")
	private WebElement customPageConfirmEmailMessage;

	@FindBy(how = How.ID, using = "verificationType_input")
	private WebElement confirmationType;
	
	public boolean verifyIfPageLoaded()	{
		try {
			waitForPageLoad(driver);
			return longWait.get().until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.form__step3"))).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public boolean verifyFormContent(String content) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(formContent)).getText().contains(content);
	}

	public String getLabelforEmail() {
		try{
		return mediumWait.get().until(ExpectedConditions.visibilityOf(emailLabel)).getText().trim();
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	
	public String getLabelforCall()	{
		try{
		return mediumWait.get().until(ExpectedConditions.visibilityOf(phoneLabel)).getText().trim();
		}catch(Exception e){
			return null;
		}
	}
	
	public String getLabelforSMS() {
		try{
		return mediumWait.get().until(ExpectedConditions.visibilityOf(smsTextLabel)).getText().trim();
		}catch(Exception e){
			return null;
		}
	}
	
	public boolean getCustomConfirmEmailPage()	{
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='brandlogo']"))).getCssValue("background-image").contains("whuhc.gif");
	}
	
	public boolean getCustomConfirmEmailPageforOptum()	{
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='brandlogo']"))).getCssValue("background-image").contains("whoptum.gif");
	}
	
	public boolean getCustomPageMessage(String message)	{
		return mediumWait.get().until(ExpectedConditions.visibilityOf(customPageConfirmEmailMessage)).getText().contains(message);
	}

    public String getSelectedItem() {
		return new Select(mediumWait.get().until(ExpectedConditions.visibilityOf(confirmationType))).getFirstSelectedOption().getText();
    }
}
