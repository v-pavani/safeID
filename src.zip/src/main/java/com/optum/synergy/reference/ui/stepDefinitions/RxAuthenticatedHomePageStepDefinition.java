package com.optum.synergy.reference.ui.stepDefinitions;

import com.optum.synergy.reference.ui.pageobjects.RxAuthenticatedHomePage;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.junit.Assert;

public class RxAuthenticatedHomePageStepDefinition {

	private RxAuthenticatedHomePage page;

	public RxAuthenticatedHomePageStepDefinition() {
		page = new RxAuthenticatedHomePage();
	}

	@Then("^I should be at OptumRx authenticated home page$")
	public void iShouldBeAtOptumRxAuthenticatedHomePage() {
		if (page.isGotoMedicineCabinetButtonDisplayed()) {
			page.clickOnGotoMedicineCabinetButton();
		}
		Assert.assertTrue("Issue while loading the Rx authenticated page", page.verifyIfHomePageContentIsDisplayed());
	}

	@Then("^I should be at OptumRx authenticated home page for Caregiver$")
	public void iShouldBeAtOptumRxAuthenticatedHomePageForCaregiver() {
		Assert.assertTrue("Issue while loading the Rx Caregiver authenticated page",
				page.verifyIfCaregiverHomePageContentIsDisplayed());
	}

	@Then("^I should be at My Medicine Cabinet page$")
	public void iShouldBeAtMyMedicineCabinetPage() {
		if (page.isGotoMedicineCabinetButtonDisplayed()) {
			page.clickOnGotoMedicineCabinetButton();
		}
		Assert.assertTrue("Issue while loading the My Medicine Cabinet page",
				page.verifyIfHomePageContentIsDisplayed());
	}
	
	@Then("^I should be at OptumRx mobile authenticated home page$")
	public void iShouldBeAtOptumRxMobileAuthenticatedHomePage() {
		Assert.assertTrue("Issue in navigating to OptumRx mobile authenticated home page", page.getShoppingCart().isDisplayed() && page.getRxAddPrescriptionButton().isDisplayed());
		
	}
}