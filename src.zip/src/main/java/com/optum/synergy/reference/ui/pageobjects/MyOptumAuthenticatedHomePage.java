package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

/**
 * Page object class for MyOptumHomepage authenticated page.
 * 
 * @author spraka27
 *
 */

public class MyOptumAuthenticatedHomePage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//div[@class='content-container']")
	private WebElement billboardWidget;

	@FindBy(how = How.XPATH, using = "//*[@alt='Optum']")
	private WebElement optumLogo;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Sorry, it looks like you')]")
	private WebElement noAccessContent;

	public boolean isPageLoaded() {
		return longWait.get().until(ExpectedConditions.visibilityOf((billboardWidget))).isDisplayed();
	}

	public WebElement getOptumLogo() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(optumLogo));
	}

	public boolean isNoAccessPageLoaded() {
		return longWait.get().until(ExpectedConditions.visibilityOf((noAccessContent))).isDisplayed();
	}

	public boolean verifyIfAuthPageContentIsDisplayed() {
		waitForPageLoad(driver);
		waitForJavascriptToLoad(100000, 10000);
		return  (getOptumLogo().isDisplayed() && isPageLoaded());
	}

	public boolean verifyIfNoAccessPageContentIsDisplayed() {
		waitForPageLoad(driver);
		waitForJavascriptToLoad(100000, 10000);
		return  isNoAccessPageLoaded();
	}

}