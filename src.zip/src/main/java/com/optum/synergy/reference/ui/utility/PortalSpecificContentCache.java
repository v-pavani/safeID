package com.optum.synergy.reference.ui.utility;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Properties;

public class PortalSpecificContentCache extends AbstractCache<String> {

    private static final Properties portals;

    static {
        portals = new Properties();
        try {
            final String env = System.getProperty("ExecutionEnv");
            portals.load(new FileInputStream(String.format("Configs/%s/portals.properties", env)));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String get(String portal, String key) {

        final String lang = portals.getProperty("lang." + "English");

        return get(portal, () ->
                        Arrays.asList("PortalSpecificContent/" + portal + "/" + "English" + "_PortalSpecific_Content.properties"),
                key,
                lang);
    }
}
