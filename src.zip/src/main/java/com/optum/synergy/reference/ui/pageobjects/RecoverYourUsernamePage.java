package com.optum.synergy.reference.ui.pageobjects;

import com.optum.synergy.reference.ui.utility.DriverFactory;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;


public class RecoverYourUsernamePage extends PageObjectBase{
	
	@FindBy(how = How.NAME, using = "personalInfo")
	private WebElement recoverYourUsernameForm;
	
	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Email associated with your account')]/following-sibling::input[@id='email']")
	private WebElement emailAssociatedWithYourAccountLabelWithTextBox;
	
	@FindBy(how=How.XPATH, using="//span[@class='icon-alert_filled error']/parent::div[contains(@ng-show,'personalInfoTopError')]|//form[@name='personalInfo']//*[@id='pageErrors']/p|//*[@id='pageErrors']")
	private WebElement recoverYourUsernameTopError;
	
	@FindBy(how = How.XPATH, using = "//div[@id='header']/h1|//div[@class='tb-margin ng-scope']/h1")
	private WebElement formHeaderOnRecoverUserName;
	
	@FindBy(how = How.XPATH, using = "//div[@id='header']/following-sibling::*")
	private WebElement formSubHeaderOnRecoverUserName;
	
	@FindBy(how = How.XPATH, using = "//i[@class='icon-home']")
	private WebElement homeIcon;

	@FindBy(how = How.XPATH, using = "//flex-content[contains(@class,'left-divider')]/div|//div[contains(@id,'helpText')]|//div[@ui-view='rightView']|//footer[@id='footer_container']")
	private WebElement needHelpSection;
	
	@FindBy(how = How.ID, using = "piFirstName")
	private WebElement firstNameTextBox;

	@FindBy(how = How.ID, using = "piLastName")
	private WebElement lastNameTextBox;

	@FindBy(how = How.ID, using = "piDoB")
	private WebElement dateOfBirthTextBox;
	
	@FindBy(how = How.ID, using = "email")
	private WebElement emailTextBox;
	
	@FindBy(how = How.XPATH, using = "//div[@ng-show='$parent.formDesc']")
	private WebElement errorMessageRecoverUsername;
	
	public boolean verifyIfPageLoaded(){
		try {
			waitForJavascriptToLoad(25000, 1000);
			return longWait.get().until(ExpectedConditions.visibilityOf(recoverYourUsernameForm)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public boolean verifyIfemailassociatedwithyouraccountLabelWithTextBoxExist() {
		return smallWait.get().until(ExpectedConditions.visibilityOf(emailAssociatedWithYourAccountLabelWithTextBox)).isDisplayed();
	}
	
	public String recoverYourUsernameTopErrorMessage() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(recoverYourUsernameTopError)).getText();
	}	
		
	public String getFormHeaderOnRecoverUserNamePage() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(formHeaderOnRecoverUserName)).getText();
	}
	
	public String getFormSubHeaderOnRecoverUserNamePage() {
		String textContent = mediumWait.get().until(ExpectedConditions.visibilityOf(formSubHeaderOnRecoverUserName)).getText().trim().replaceAll(String.valueOf((char)160)," ");
		return textContent;
	}
	
	public WebElement getWebElementforHomeIcon() {
		return smallWait.get().until(ExpectedConditions.visibilityOf(homeIcon));
	}
	
	public String getNeedHelpContent(){
		String textContent = mediumWait.get().until(ExpectedConditions.visibilityOf(needHelpSection)).getText().trim().replaceAll(String.valueOf((char)160)," ");
		return textContent;
	}
	
	public void enterFirstName(String firstName) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(firstNameTextBox));
		firstNameTextBox.clear();
		firstNameTextBox.sendKeys(firstName);
	}

	public void enterLastName(String lastName) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(lastNameTextBox));
		lastNameTextBox.clear();
		lastNameTextBox.sendKeys(lastName);
	}

	public void enterDateOfBirth(String dateOfBirth) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(dateOfBirthTextBox));
		dateOfBirthTextBox.clear();
		dateOfBirthTextBox.sendKeys(Keys.BACK_SPACE);
		dateOfBirthTextBox.sendKeys(dateOfBirth.replace("/", ""));
	}
	
	public void enterEmail(String email) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(emailTextBox));
		emailTextBox.clear();
		emailTextBox.sendKeys(email);
	}
	
	public WebElement getErrorMessageElement() {
		waitForJavascriptToLoad(10000, 1000);
		return mediumWait.get().until(ExpectedConditions.visibilityOf(errorMessageRecoverUsername));
	}

	public void clickPartialLinkInNeedHelpSection(String linkName){
		waitForJavascriptToLoad(10000,2000);
		WebElement elem = needHelpSection.findElement(By.partialLinkText(linkName));
		scrollElementIntoView(elem);
		((JavascriptExecutor) DriverFactory.getDeviceDriver()).executeScript("arguments[0].click();", elem);
	}
}
