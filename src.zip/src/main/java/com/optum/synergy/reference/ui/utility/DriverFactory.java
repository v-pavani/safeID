package com.optum.synergy.reference.ui.utility;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.optum.synergy.reference.ui.pageobjects.PageObjectBase;

import cucumber.deps.com.thoughtworks.xstream.InitializationException;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;

public class DriverFactory {

	private static ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>();

	private final static String DEFAULT_BROWSERTYPE = "FIREFOX";
	private final static String DEFAULT_BROWSERVERSION_SAUCE = "57";
	private final static String DEFAULT_BROWSERVERSION_LOCAL = "52";
	private final static String DEFAULT_BROWSERENV = "local";
	private final static String DEFAULT_SAUCE_TUNNEL = "NONE";
	
	// TODO: Find a better choice of default SauceLabs credentials
	private final static String DEFAULT_SAUCE_USER = "puneet.ratti";
	private final static String DEFAULT_SAUCE_ACCESSKEY = "47c43165-349e-4d2a-a138-2d7a26bef5cd";

	/**
	 * Method to return driver instance for current thread. If one is not set,
	 * create a new driver from system property configuration.
	 * 
	 * @return Current thread's driver instance or newly created driver
	 * @throws MalformedURLException
	 *             If invalid SauceLabs URL is built
	 */
	public static WebDriver createAndGetDeviceDriver() throws MalformedURLException {

		if (driver.get() != null) {
			return driver.get();
		}

		// Retrieve desired browser configuration from system properties
		String BrowserVersion = System.getProperty("BrowserVersion");
		;
		String BrowserType = System.getProperty("BrowserType");
		String browserEnv = System.getProperty("BrowserEnv");
		String sauceUsername = System.getenv("SAUCE_USERNAME");
		String saucePassword = System.getenv("SAUCE_ACCESS_KEY");
		String sauceTunnel = System.getenv("SAUCE_TUNNEL_NAME");

		if (browserEnv == null) {
			browserEnv = DEFAULT_BROWSERENV;
		}
		
		if (BrowserVersion == null && browserEnv.equals("saucelab")) {
			BrowserVersion = DEFAULT_BROWSERVERSION_SAUCE;
		} else if (BrowserVersion == null) {
			BrowserVersion = DEFAULT_BROWSERVERSION_LOCAL;
		}
		
		if (BrowserType == null) {
			BrowserType = DEFAULT_BROWSERTYPE;
		}


		if (browserEnv.equalsIgnoreCase("saucelab")) {
			
			if (sauceUsername == null || saucePassword == null ) {
				sauceUsername = DEFAULT_SAUCE_USER;
				saucePassword = DEFAULT_SAUCE_ACCESSKEY;
			}
			
			if (sauceTunnel == null  ) {
				
				sauceTunnel = DEFAULT_SAUCE_TUNNEL;
				DataStorage.setCustomErrmsg("DEBUG::sauceTunnel was null, defaulting [" + sauceTunnel
						+ "]");
			}
			
			DesiredCapabilities capabilities = null;

			switch ( BrowserType.toUpperCase() ) {
			case "IE":
				capabilities = DesiredCapabilities.internetExplorer();
				capabilities.setCapability("platform", "Windows 10");
				capabilities.setCapability("screenResolution", "1280x768");
				capabilities.setCapability("iedriverVersion", "3.141.0");
				capabilities.setCapability("seleniumVersion", "3.141.0");
				break;

			case "EDGE":
				capabilities = DesiredCapabilities.edge();
				capabilities.setCapability("platform", "Windows 10");
				capabilities.setCapability("screenResolution", "1280x768");
				break;
				
			case "FIREFOX":
				capabilities = DesiredCapabilities.firefox();
				capabilities.setCapability("platform", "Windows 10");
				capabilities.setCapability("screenResolution", "1280x768");
				break;
				
			case "SAFARI":
				capabilities = DesiredCapabilities.safari();
				capabilities.setCapability("platform", "macOS 10.13");
				capabilities.setCapability("screenResolution", "1280x960");
				break;
				
			case "CHROME":
				capabilities = DesiredCapabilities.chrome();
				capabilities.setCapability("platform", "Windows 10");
				capabilities.setCapability("screenResolution", "1280x768");
				break;
				
			default:
				throw new IllegalArgumentException("Unsupported Platform/Browser Configuration " + BrowserType);
			}
			
			boolean notProd = !("prod".equalsIgnoreCase(System.getProperty("ExecutionEnv")));
			URL sauceLabUrl = new URL( "https://" + sauceUsername + ":" + saucePassword  + "@ondemand.us-west-1.saucelabs.com:443/wd/hub");

			if(BrowserVersion.equalsIgnoreCase("Latest"))
				BrowserVersion = "latest";
			capabilities.setCapability("version", BrowserVersion);
			capabilities.setCapability("maxDuration", 10800);
			capabilities.setCapability("avoidProxy", true);
			capabilities.setCapability("autoAcceptAlerts", true);

			// Skip using tunnel if in Production or using "NONE" from env
			if ( notProd && ! sauceTunnel.equals("NONE")) {
				// Use sauceLabs tunnel either set via SAUCE_TUNNEL_NAME environment
				// variable or from default	
				DataStorage.setCustomErrmsg("::DEBUG::Setting tunnel capabilities [" + sauceTunnel + "]");
				capabilities.setCapability("tunnelIdentifier", sauceTunnel);
				capabilities.setCapability("parent-tunnel", "optumtest");
			} else {
				DataStorage.setCustomErrmsg("::DEBUG::Skipping SauceLabs tunnel");
			}
			
			capabilities.setCapability("recordVideo", true);
			capabilities.setCapability("recordScreenshots", notProd);
			capabilities.setCapability("recordLogs", notProd);

			// TODO Re-assess sauceLab timeouts...
			capabilities.setCapability("idleTimeout", 1000);
			capabilities.setCapability("commandTimeout", 600);

			// Turn on enhanced network logging.  Needs evaluation on performance impact, may parameterize
			capabilities.setCapability("extendedDebugging", true);

			setDriver(new RemoteWebDriver(sauceLabUrl, capabilities));
			DataStorage.setCustomErrmsg("Play in saucelab: " + "https://saucelabs.com/beta/tests/"
					+ ((RemoteWebDriver) driver.get()).getSessionId().toString());

		}
		/**
		 * @author vchaube1 
		 * Configuration for Android device in TestObject for mobile browser testing.   
		 * Establishing connection with the android device.  
		 *  
		*/
		else if(BrowserType.equalsIgnoreCase("Android")) {
			
			URL url = new URL("https://us1.appium.testobject.com/wd/hub");
			DesiredCapabilities androidCapabilities = new DesiredCapabilities();
			androidCapabilities.setCapability("platformName", "Android");
			androidCapabilities.setCapability("platformVersion", "8");
			androidCapabilities.setCapability("testobject_api_key", "9001B8D076D94199BD28F03085C23126");
			androidCapabilities.setCapability("phoneOnly", true);
			androidCapabilities.setCapability("autoAcceptAlerts", true);
			androidCapabilities.setCapability("name", "MobileRealDevice_Android");
			setDriver(new AndroidDriver(url,androidCapabilities));
		} 
		/**
		 * @author vchaube1 
		 * Configuration for IOS device in TestObject for mobile browser testing.   
		 * Establishing connection with the IOS device.  
		 *  
		*/
		else if(BrowserType.equalsIgnoreCase("IOS")) {
			
			URL url = new URL("https://us1.appium.testobject.com/wd/hub");
			DesiredCapabilities iOSCapabilities = new DesiredCapabilities();
			iOSCapabilities.setCapability("platformName", "iOS");
			iOSCapabilities.setCapability("platformVersion", "11");
			iOSCapabilities.setCapability("testobject_api_key", "9001B8D076D94199BD28F03085C23126");
			iOSCapabilities.setCapability("phoneOnly", true);
			iOSCapabilities.setCapability("autoAcceptAlerts", true);
			iOSCapabilities.setCapability("name", "MobileRealDevice_IOS");
			setDriver(new IOSDriver(url,iOSCapabilities));
			
		} else {
			// Instantiate local browser
			
			switch ( BrowserType.toUpperCase() ) {
			case "IE":
				System.setProperty("webdriver.ie.driver", "lib" + File.separator + "IEDriverServer.exe");
				setDriver(new InternetExplorerDriver());
				break;
				
			case "FIREFOX":
				
				DesiredCapabilities capabilities = new DesiredCapabilities();
				boolean isMarionette = true;
				if (Integer.parseInt(BrowserVersion) < 47) {
					isMarionette = false;
				}
				capabilities.setCapability("marionette", isMarionette);

				// To ensure proper proxy/certificate configuration, use
				// 'default' Firefox profile.
				ProfilesIni profileIni = new ProfilesIni();
				FirefoxProfile fp = profileIni.getProfile("default");
				capabilities.setCapability(FirefoxDriver.PROFILE, fp);
				
				System.setProperty("webdriver.gecko.driver", "lib" + File.separator + "geckodriver.exe");
				
				setDriver(new FirefoxDriver(capabilities));
				break;
				
			case "SAFARI":			
//				break;
				
			case "CHROME":
//				break;
				
			default:
				throw new IllegalArgumentException("Unsupported local Platform/Browser Configuration " + BrowserType);	
			}
			
		}
		if(!(browserEnv.equalsIgnoreCase("Android") || browserEnv.equalsIgnoreCase("IOS")))
		{
			driver.get().manage().window().maximize();
		}
			driver.get().manage().deleteAllCookies();
		
		// Initialize threadLocal instances of wait objects with new driver
		// instance
		PageObjectBase.smallWait.set(new WebDriverWait(getDeviceDriver(), PageObjectBase.SMALL_WAIT_TIME));
		PageObjectBase.mediumWait.set(new WebDriverWait(getDeviceDriver(), PageObjectBase.MEDIUM_WAIT_TIME));
		PageObjectBase.longWait.set(new WebDriverWait(getDeviceDriver(), PageObjectBase.LONG_WAIT_TIME));

		return getDeviceDriver();
	}

	/**
	 * 
	 * @return driver object for current execution thread
	 * @throws InitializationException
	 *             If browser has not been set
	 */
	public static WebDriver getDeviceDriver() throws InitializationException {

		if (driver.get() != null) {
			return driver.get();
		}

		throw new InitializationException("Browser Driver Not Initialized");
	}

	/**
	 * 
	 * @param inputDriver
	 *            Driver object to store in ThreadLocal<WebDriver>
	 */
	private static void setDriver(WebDriver inputDriver) {
		driver.set(inputDriver);
	}

	/**
	 * Closes driver for current thread, sets current thread driver to null.
	 * 
	 * @return true if driver shut down, otherwise false.
	 */
	public static boolean closeDeviceDriver() {

		try {
			WebDriver currentDriver = getDeviceDriver();
			if (currentDriver != null) {
				setDriver(null);
				currentDriver.quit();
			}
			return getDeviceDriver() == null;
		} catch (InitializationException e) {
			return true;
		}
	}
}
