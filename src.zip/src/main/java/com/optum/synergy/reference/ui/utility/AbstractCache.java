package com.optum.synergy.reference.ui.utility;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.*;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public class AbstractCache<T> {

    private final Logger log = LogManager.getLogger(AbstractCache.class.getName());

    protected final Map<String, Map<String, T>> cache = Collections.synchronizedMap(new HashMap<>());

    protected T get(String cacheKey, Supplier<List<String>> locator, String key, String lang) {
        List<String> resourceLocators = locator.get();
        String cacheItemKey = cacheKey + (StringUtils.isEmpty(lang) ? "" : "_" + lang);
        Map<String, T> cacheItem = cache.get(cacheItemKey);

        if (cacheItem == null) {
            cacheItem = new HashMap<>();
            for (String resourceLocator : resourceLocators) {
                Map<String, T> cacheData = loadCache(resourceLocator);
                if (cacheData != null) {
                    cacheItem.putAll(cacheData);
                }
            }
            cache.put(cacheItemKey, cacheItem);
        }

        return cacheItem.get(key);
    }

    @SuppressWarnings({"unchecked"})
    protected Map<String, T> loadCache(String resourceLocator) {

        Map<String, String> cacheItem = new HashMap<>();

        try (final InputStreamReader reader = new InputStreamReader(
                new FileInputStream(resourceLocator),
                Charset.forName("UTF-8"))) {

            Properties props = new Properties();
            props.load(reader);
            cacheItem = props.entrySet().stream().collect(
                    Collectors.toMap(
                            e -> String.valueOf(e.getKey()),
                            e -> String.valueOf(e.getValue()),
                            (prev, next) -> next, HashMap::new
                    ));
        } catch (IOException e) {
            log.warn("PORTAL CONFIG FILE: {} DOES NOT EXIST (OK IF NOT NEEDED)", resourceLocator);
        }

        return (Map<String, T>) cacheItem;
    }
}
