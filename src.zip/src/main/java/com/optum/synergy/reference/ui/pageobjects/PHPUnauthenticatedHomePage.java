package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.optum.synergy.reference.ui.utility.DataStorage;
import com.optum.synergy.reference.ui.utility.ReadXMLData;

public class PHPUnauthenticatedHomePage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'loginregistration')]")
	private WebElement loginRegistrationForm;
	
	public void openPHPHomePage() {
		String page_url = ReadXMLData.getTestData(DataStorage.getPortalName(), "AppURL");
		openPage(page_url);
	}

	public boolean isPageLoaded() {
		return longWait.get().until(ExpectedConditions.visibilityOf((loginRegistrationForm))).isDisplayed();
	}
}
