package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.optum.synergy.reference.ui.utility.ReadXMLData;

public class PHSUnauthenticatedHomePage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//*[@id='mainContent']|//div[contains(@class,'lobby-hero__cta')]")
	private WebElement loginRegistrationForm;

	@FindBy(how = How.XPATH, using = "//div[@class='optum-purified___widgetTop ']//b")
	private WebElement useYourHsidToSignInLabel;

	@FindBy(how = How.XPATH, using = "//div[@class='optum-purified___footerStyle']//b")
	private WebElement newToHsidLabel;
	
	public void openPHSHomePage() {
		String page_url = ReadXMLData.getTestData("PHS", "AppURL");
		deleteCookies();
		openPage(page_url);
	}

	public boolean isPageLoaded() {
		return longWait.get().until(ExpectedConditions.visibilityOf((loginRegistrationForm))).isDisplayed();
	}

	public boolean verifyIfUseYourHSIDToSignInLabelIsDisplayed() {
		return longWait.get().until(ExpectedConditions.visibilityOf((useYourHsidToSignInLabel))).isDisplayed();
	}

	public boolean verifyIfNewToHSIDLabelIsDisplayed() {
		return longWait.get().until(ExpectedConditions.visibilityOf((newToHsidLabel))).isDisplayed();
	}
	
	public void openPHSOptumHomePage() {
		String page_url = ReadXMLData.getTestData("PHS", "PHSOPTUMAPPURL");
		deleteCookies();
		openPage(page_url);
	}

}
