package com.optum.synergy.reference.ui.utility;

import com.optum.synergy.reference.ui.pageobjects.PageObjectBase;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AEMJsonReader {

    private static final Pattern CONTENT_KEY_PATTERN = Pattern.compile("\\{\\{(\\w+)\\}\\}");
    private static final Pattern CONFIG_KEY_PATTERN = Pattern.compile("\\[(\\w+)\\]");

    private final Map<String, String> map = new HashMap<String, String>();
    private final JSONParser parser = new JSONParser();

    public Map<String, String> getData(String filePath) throws ParseException {
        try {
            Object obj = parser.parse(new FileReader(filePath));
            JSONObject jsonObject = (JSONObject) obj;
            printJSONOBject(jsonObject);
        } catch (FileNotFoundException e) {

        } catch (IOException ioe) {

        }
        return map;
    }

    private void printJSONOBject(JSONObject jsonObject) throws ParseException {
        for (Object keyObj : jsonObject.keySet()) {
            String key = (String) keyObj;
            //  System.out.println(jsonObject.get(key));
            if (jsonObject.get(key).toString().contains("{") && !jsonObject.get(key).toString().contains("[")) {
                Object obj = parser.parse(getplainContent(jsonObject.get(key).toString()));
                printJSONOBject((JSONObject) obj);
            } else {
                //  	System.out.println(key + " : " + getplainContent(jsonObject.get(key).toString()));
                map.put(key, getplainContent(jsonObject.get(key).toString()));
            }
        }
    }

    public String getJSONObjectValue(JSONObject jsonObject) throws ParseException {
        String value = null;

        for (Object keyObj : jsonObject.keySet()) {
            final String jsonValue = jsonObject.get(keyObj).toString();
            if (jsonValue.contains("{")) {
                if (jsonValue.contains("{{")) {
                    String plainString = getplainContent(jsonValue);
                    Matcher matcher = CONTENT_KEY_PATTERN.matcher(plainString);
                    while (matcher.find()) {
                        String innerKey = matcher.group(1);
                        String keyValue = getplainContent(PageObjectBase.getAEMContent(DataStorage.getPortalName(), null, innerKey));
                        plainString = plainString.replace("{{" + innerKey + "}}", keyValue);
                    }
                    value = plainString;
                } else {
                    Object obj = parser.parse(getplainContent(jsonValue));
                    getJSONObjectValue((JSONObject) obj);
                }
            } else if (jsonValue.contains("[")) {
                Matcher matcher = CONFIG_KEY_PATTERN.matcher(jsonValue);
                String replacedString = jsonValue;
                while (matcher.find()) {
                    String innerKey = matcher.group(1);
                    String keyValue = PageObjectBase.getPortalConfig(DataStorage.getPortalName(), innerKey, false);
                    if (keyValue != null) {
                        replacedString = jsonValue.replace("[" + innerKey + "]", keyValue);
                    }
                }
                value = getplainContent(replacedString);
            } else {
                value = getplainContent(jsonValue);
            }
        }
        return value;
    }

    public String getplainContent(String keyValue) {
        String con = keyValue;
        do {
            Document html = Jsoup.parse(con);
            con = html.body().text();
        } while (con.contains("</") || con.contains("/>") || con.contains("&lt") || con.contains("&gt"));

        if (DataStorage.getContentWithDynamicValue() != null)
            DataStorage.setContentWithDynamicValue(DataStorage.getContentWithDynamicValue() + con);
        else
            DataStorage.setContentWithDynamicValue(con);
        return con.replaceAll("\\[.*\\]", "");  //this will return the content which doesn't include the dynamic values for ex:[Field_Name]
    }
}
