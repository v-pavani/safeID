package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;


public class AlreadyHaveHSIDPage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//*[starts-with(@ng-if,'alreadyHaveId')]|//*[contains(@ng-include,'alreadyHaveId')]|//*[starts-with(@ng-if,'alreadyHaveId && isHSIDUser')]")
	private WebElement alreadyHaveHSIDForm;
	
	@FindBy(how = How.CLASS_NAME, using = "ng-scope")
	private WebElement contentLabels;
	
	@FindBy(how = How.XPATH, using = "//*[@id='Login']//p[@class='ng-binding']")
	private WebElement prepopulatedUsername;
	
	@FindBy(how = How.XPATH, using = "//*[@id='Login']//p[contains(@ng-bind-html,'getAEMContentSTD')]")
	private WebElement yourUsernameLabel;

	public boolean verifyIfAlreadyhaveHSIDPageLoaded() {
		try{
			waitForPageLoad(driver);
			waitForJavascriptToLoad(30000, 5000);
			return longWait.get().until(ExpectedConditions.visibilityOf((alreadyHaveHSIDForm))).isDisplayed();
		} catch (TimeoutException e){
			DataFailureStatus.set(1);
			return false;
		}

	}
	
	public WebElement getContentLabels() {
		return contentLabels;
	}
	
	public WebElement getYourUsernameIsLabel() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(yourUsernameLabel));
	}

	public WebElement getPrepopulatedUsername() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(prepopulatedUsername));
	}
}
