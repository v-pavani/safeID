package com.optum.synergy.reference.ui.pageobjects;

import java.util.NoSuchElementException;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LAWWAdminPortalUserDeleteConfirmationPage extends PageObjectBase{
	
	@FindBy(how = How.XPATH, using = "//button[text()='Confirm Delete']")
	private WebElement userDeleteConfirmationForm;
	
	@FindBy(how = How.XPATH, using = "//div[@role='alert']")
	private WebElement actionMessge;
	
	@FindBy(how = How.XPATH, using = "//input[@class='btnprimary' and contains(@value, 'Done')]")
	private WebElement donebutton;
	
	@FindBy(how = How.XPATH, using = "//div[@class='sidebar-heading' and text()='LAWW Admin']")
	private WebElement homeLink;
	
	@FindBy(how = How.XPATH, using = "//button[text()='Confirm']")
	private WebElement confirmDeleteActionButton;
	
	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(userDeleteConfirmationForm)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public void clickConfirmDeleteButton() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmDeleteActionButton));
		confirmDeleteActionButton.click();
	}
	
	public boolean verifyForTheActionMessage(String message){
		waitForPageLoad(driver);
		try{
		return mediumWait.get().until(ExpectedConditions.textToBePresentInElement(actionMessge,message));
		}
		catch(TimeoutException e){
			e.printStackTrace();
			return false;
		}
		catch(NoSuchElementException e){
			e.printStackTrace();
			return false;
		}
	}
	
	public void clickDoneButton() {
			mediumWait.get().until(ExpectedConditions.visibilityOf(donebutton));
			donebutton.click();
	}
	
	public void clickHomeLink() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(homeLink));
		homeLink.click();
	}
}
