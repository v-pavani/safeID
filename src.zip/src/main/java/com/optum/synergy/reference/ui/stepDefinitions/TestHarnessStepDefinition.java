package com.optum.synergy.reference.ui.stepDefinitions;

import com.optum.synergy.reference.ui.pageobjects.TestHarnessPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import org.junit.Assert;

import java.util.Map;

public class TestHarnessStepDefinition {
		
	private TestHarnessPage page;

	public TestHarnessStepDefinition()  {
		page = new TestHarnessPage();
	}

	@Given("^I am on Test Harness Page$")
	public void i_am_on_Test_Harness_Page() throws Throwable {
		page.openPage();
	}
	
	@When("^I select \"([^\"]*)\" as TARGETPORTAL$")
	public void i_select_As_TARGETPORTAL(String arg1) {
		page.enterTargetPortal(arg1);
	}

	@Given("^I select \"([^\"]*)\" as ACTION$")
	public void i_select_As_ACTION(String arg1) {
		page.enterTargetAction(arg1);
	}
	
	@Given("^I select \"([^\"]*)\" as RX_WHITELABEL_SITE$")
	public void i_select_As_RX_WHITELABEL_SITE(String arg1) {
		page.enterRxWhiteLabelSite(arg1);	    
	}

	@Given("^I select \"([^\"]*)\" as ELIGIBILITY$")
	public void i_select_As_ELIGIBILITY(String arg1) {
		page.enterEligibility(arg1);
	}

	@Given("^I select \"([^\"]*)\" as LANGUAGE$")
	public void i_select_As_LANGUAGE(String arg1) {
		page.enterLanguage(arg1);
	}

	@Given("^I select \"([^\"]*)\" as ACCESSTYPE$")
	public void i_select_As_ACCESSTYPE(String arg1) {
		page.enterAccessType(arg1);   
	}
	
	@Given("^I entered HTTP Target URL for \"([^\"]*)\" portal$")
	public void i_entered_TargetURL(String arg1) {
		page.enterHTTPTargetURL(arg1);
	}
	
	@Given("^I set captcha to TEST$")
	public void setCaptchaToTest() {
		page.disableCaptcha();
	}
	
	@When("^I click on \"([^\"]*)\" button in Test Harness Page$")
	public void i_click_on_button_in_Test_Harness_Page(String arg1) {
		page.submitTestHarness();
	}
	
	@Given("^I select \"([^\"]*)\" as Marketing Site$")
	public void i_select_As_CAP_MARKETING_SITE(String arg1) {
		page.enterCapMarketingSite(arg1);
	}

	@Given("^I am on StageB Test Harness Page$")
	public void i_am_on_StageB_Test_Harness_Page() throws Throwable {
		page.openPage_stageB();
	}
	
	@When("^I enter Site URL for \"([^\"]*)\" portal$")
	public void i_enter_SiteURL(String arg1) {
		page.enterSiteURL(arg1);
	}
	
	@When("^I select \"([^\"]*)\" as PHS_SUBPORTAL$")
	public void iSelectAsPHS_SUBPORTAL(String arg1) {
		page.selectPhsSubPortal(arg1);
	}
	
	@When("^I select \"([^\"]*)\" as WH_SUBPORTAL$")
	public void iSelectAsWH_SUBPORTAL(String arg1) {
	page.selectWhSubPortal(arg1);
	}


	@When("^I launch Test Harness with the following details$")
	public void i_launch_testHarness_with_the_following_details(Map<String,String> details) throws Throwable{
		//open test harness
		page.openPage();
		//enter necessary details
		if(details.containsKey("TARGETPORTAL")){
			Assert.assertFalse("TARGETPORTAL value is empty",details.get("TARGETPORTAL").isEmpty());
			page.enterTargetPortal(details.get("TARGETPORTAL"));
		}else{
			Assert.fail("Target portal attribute is missing in the feature step");
		}
		if(details.containsKey("ACTION")){
			Assert.assertFalse("ACTION value is empty",details.get("ACTION").isEmpty());
			page.enterTargetAction(details.get("ACTION"));
		}else{
			Assert.fail("Target action attribute is missing in the feature step");
		}
		//enter not necessary details
		for(String key: details.keySet()){
			switch (key){
				case "TARGETPORTAL":
					break;
				case "ACTION":
					break;
				case "SUBPORTAL":
					Assert.assertFalse("SUBPORTAL value is empty",details.get("SUBPORTAL").isEmpty());
					page.enterSubPortal(details.get("TARGETPORTAL"),details.get("SUBPORTAL"));
					break;
				case "ACCESSTYPE":
					Assert.assertFalse("ACCESSTYPE value is empty",details.get("ACCESSTYPE").isEmpty());
					page.enterAccessType(details.get("ACCESSTYPE"));
					break;
				case "ELIGIBILITY":
					Assert.assertFalse("ELIGIBILITY value is empty",details.get("ELIGIBILITY").isEmpty());
					page.enterEligibility(details.get("ELIGIBILITY"));
					break;
				case "LANGUAGE":
					Assert.assertFalse("LANGUAGE value is empty",details.get("LANGUAGE").isEmpty());
					page.enterLanguage(details.get("LANGUAGE"));
					break;
				case "CAPTCHA":
					if(details.get("CAPTCHA").equalsIgnoreCase("DISABLE")){
						page.disableCaptcha();
					}else if(details.get("CAPTCHA").equalsIgnoreCase("ENABLE")){
						//do something
					}else {
						Assert.fail("Captcha value is Invalid,It can be either DISABLE or ENABLE");
					}
					break;
				case "TARGETURL":
					Assert.assertFalse("TARGETURL value is empty",details.get("TARGETURL").isEmpty());
					page.enterHTTPTargetURL(details.get("TARGETURL"));  //target url value must be a portal name
					break;
				case "SITEURL":
					Assert.assertFalse("SITEURL value is empty",details.get("SITEURL").isEmpty());
					page.enterSiteURL(details.get(details.get("SITEURL")));  //site url value must be a portal name
					break;
				case "GRADIENTCOLOR1":
					Assert.assertFalse("GRADIENTCOLOR1 value is empty",details.get("GRADIENTCOLOR1").isEmpty());
					page.enterGradientColor("GRADIENTCOLOR1",details.get("GRADIENTCOLOR1"));
					break;
				case "GRADIENTCOLOR2":
					Assert.assertFalse("GRADIENTCOLOR2 value is empty",details.get("GRADIENTCOLOR1").isEmpty());
					page.enterGradientColor("GRADIENTCOLOR2",details.get("GRADIENTCOLOR2"));
					break;
				default:
					Assert.fail("Invalid attribute selection: ["+key +" not found]");
			}
		}
		//click on submit button
		page.submitTestHarness();
	}
}




