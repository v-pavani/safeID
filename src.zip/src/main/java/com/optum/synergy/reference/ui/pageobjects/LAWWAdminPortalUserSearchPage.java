package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LAWWAdminPortalUserSearchPage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//input[@id='lastName']")
	private WebElement userLastNameTextBox;

	@FindBy(how = How.XPATH, using = "//input[@id='firstName']")
	private WebElement userFirstNameTextBox;
	
	@FindBy(how = How.XPATH, using = "//button[@type='submit' and contains(@class,'btn btn-primary')]")
	private WebElement searchButton;

	@FindBy(how = How.XPATH, using = "//div[text()='Member Account Search']")
	private WebElement userSearchSection;
	
	@FindBy(how = How.XPATH, using = "//*[@class='react-bs-table-no-data']")
	private WebElement noSearchResultsErrorMessage;

	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(userSearchSection)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public void enterUserLastName(String lastName) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(userLastNameTextBox));
		userLastNameTextBox.clear();
		userLastNameTextBox.sendKeys(lastName);
	}

	public void enterUserFirstName(String firstName) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(userFirstNameTextBox));
		userFirstNameTextBox.clear();
		userFirstNameTextBox.sendKeys(firstName);
	}
	
	public void clickSearchButton() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(searchButton));
		searchButton.click();
	}
	
	public boolean verifySearchResults() {
				
		try {
			searchButton.click();
		} catch (StaleElementReferenceException e) {
			searchButton.click();
		}
		try{
			smallWait.get().until(ExpectedConditions.visibilityOf(noSearchResultsErrorMessage));
			return false;
		}catch(TimeoutException e){
			return true;
		}
	}

}
