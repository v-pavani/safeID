package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.optum.synergy.reference.ui.utility.ReadXMLData;

public class ForgotUsernamePasswordPage extends PageObjectBase {

	@FindBy(how = How.ID, using = "username")
	private WebElement userNameTextBox;

	@FindBy(how = How.ID, using = "email")
	private WebElement enterEmailField;

	@FindBy(how = How.NAME, using = "accountInfo")
	private WebElement resetPasswordForm;

	@FindBy(how = How.XPATH, using = "//form[@name='personalInfo']")
	private WebElement recoverYourUserNameForm;

	@FindBy(how = How.XPATH, using = "//*[@ng-show='pageError']/p/span[@class='ng-scope']"
			+ "|//*[@id='pageErrors']/p/span[@class='ng-scope']")
	private WebElement lostFlowErrorMessage;
	
	@FindBy(how = How.XPATH, using = "//div[starts-with(@ng-if,'serviceError')]")
	private WebElement forgotUsernameErrorMsg;
	
	@FindBy(how=How.XPATH, using ="//span[@class='icon-checkmark_filled success']")
	private WebElement passwordResetConfirmationIcon;
	
	@FindBy(how=How.XPATH, using ="//*[@id='confirmPassword']")
	private WebElement confirmPasswordField;
	
	@FindBy(how=How.XPATH, using ="//*[@ng-show='creds.confirmPassword']")
	private WebElement confirmPasswordShowPassword;

	public void enterUserName(String username) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(userNameTextBox));
		userNameTextBox.clear();
		userNameTextBox.sendKeys(username);
	}

	public void clearEmailField() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(enterEmailField));
		enterEmailField.clear();
	}

	public void enterEmail(String EmailAddress) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(enterEmailField));
		enterEmailField.sendKeys(EmailAddress);
	}

	public void clickResetPasswordInfoForm() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(resetPasswordForm));
		resetPasswordForm.click();
	}

	public void clickRecoverUsernameInfoForm() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(recoverYourUserNameForm));
		recoverYourUserNameForm.click();
	}

	public boolean verifyErrorMessageOnUsername(String message) {

		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//input[@id='username']/following-sibling::span[contains(@class,'error') and contains(.,'"
						+ message + "')]|//label[@for='username']/span[contains(@class,'error') and contains(.,'" + message + "')]")))
				.isDisplayed();
	}

	public boolean verifyNoErrorMessageOnUsername() {
		try {
			return !(smallWait.get()
					.until(ExpectedConditions.presenceOfElementLocated(
							By.xpath("//input[@id='username']/following-sibling::span[contains(@class,'error')]|//label[@for='username']/span[@class='error']")))
					.isDisplayed());
		} catch (TimeoutException e) {
			return true;
		}		
	}
	
	public boolean verifyNoErrorMessageOnPhonenumber() {
		return !(smallWait.get()
				.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//input[@id='phoneNo']/following-sibling::p[contains(@class,'error')]")))
				.isDisplayed());
	}

	public boolean verifyErrorMessageOnCaptcha(String message) {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//input[@id='captcha1']/following-sibling::span[contains(@class,'error') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}

	public boolean verifyNoErrorMessageOnCaptcha() {
		try {
			smallWait.get().until(ExpectedConditions.visibilityOfElementLocated(
					By.xpath("//input[@id='captcha1']/following-sibling::span[contains(@class,'error')]")));
			return false;
		} catch (TimeoutException e) {
			return true;
		}

	}

	public boolean verifyErrorMessageOnEnterEmail(String message) {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//span[contains(@class,'error') and contains(.,'" + message + "')]| //span[contains(@class,'ng-binding') and contains(.,'"+ message + "')]"))).isDisplayed();
	}

	public boolean verifyNoErrorMessageOnEnterEmail() {
		boolean noMessage = false;
		try {

			if (smallWait.get().until(
					ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(@class,'error')]/*[contains(.,'email')]"))) == null)
				noMessage = true;
		} catch (TimeoutException e) {
			noMessage = true;
		}
		return noMessage;
	}
	
	public WebElement getWebElementOfErrorMessageForLostFlows(){
		return mediumWait.get().until(ExpectedConditions.visibilityOf(lostFlowErrorMessage));
	}
		
	public boolean verifyErrorMsg(String messageText) {
		WebElement errorMessage = mediumWait.get().until(ExpectedConditions.visibilityOf(forgotUsernameErrorMsg));
		return errorMessage.getText().equals(messageText);
	}
	
	public WebElement getPasswordResetConfirmationIcon() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(passwordResetConfirmationIcon));
	}
	
	public WebElement getConfirmPasswordField() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmPasswordField));
	}
	
	public WebElement getConfirmPasswordShowPassword() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmPasswordShowPassword));
	}
	
	public void clickForgotUsernamePasswordMobile(String linkName, String portalName) {
		waitForJavascriptToLoad(15000, 1000);
		
		WebElement linkElem = mediumWait.get().until(ExpectedConditions.elementToBeClickable(By.partialLinkText(linkName)));
		if(linkName.equalsIgnoreCase("username") && portalName.equalsIgnoreCase("OptumRx")) {
			String url = ReadXMLData.getTestData("OptumRx", "ForgotUsernameMobile");
			driver.get(url + "&USE_TEST_RECAPTCHA=true");
		} else if(linkName.equalsIgnoreCase("password") && portalName.equalsIgnoreCase("OptumRx")) {
			String url = ReadXMLData.getTestData("OptumRx", "ForgotPasswordMobile");
			driver.get(url + "&USE_TEST_RECAPTCHA=true");
		} else {
			scrollElementIntoView(linkElem);
			linkElem.click();
		}
		
	}
}
