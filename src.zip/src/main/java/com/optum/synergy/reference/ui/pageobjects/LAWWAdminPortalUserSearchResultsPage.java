package com.optum.synergy.reference.ui.pageobjects;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LAWWAdminPortalUserSearchResultsPage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//table[@class='table table-striped table-hover table-bordered table-sm']")
	private WebElement searchResultsTable;

	@FindBy(how = How.XPATH, using = "//table[@class='table table-striped table-hover table-bordered table-sm']/tbody/tr/td[1]")
	private List<WebElement> usersIds;
	
	@FindBy(how = How.LINK_TEXT, using = "Back")
	private WebElement topBackButton;

	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(searchResultsTable)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}

	public void clickTopBackButton() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(topBackButton));
		topBackButton.click();
	}

	public List<String> getListOfSearchedUsers() {
		List<String> userIds = new ArrayList<String>();
		mediumWait.get().until(ExpectedConditions.visibilityOf(searchResultsTable));
		waitForJavascriptToLoad(LONG_WAIT_TIME*1000, 500);
		for (WebElement user : usersIds) {
			userIds.add(user.getText());
		}
		return userIds;
	}
	
	public List<String> getListOfSearchedUsersByFirstNameLastNameDob(String firstName, String lastName, String Dob) {
		List<String> userIds = new ArrayList<String>();
		mediumWait.get().until(ExpectedConditions.visibilityOf(searchResultsTable));
		waitForJavascriptToLoad(LONG_WAIT_TIME*1000, 500);
		try{
			List<WebElement> usersList = driver.findElements(By.xpath("//table[@class='table table-striped table-hover table-bordered table-sm']/tbody/tr/*[contains(text(),'" + firstName.toUpperCase() + "')]/../*[contains(text(),'" + lastName.toUpperCase() + "')]/../*[contains(text(),'"+ Dob +"')]/../td[1]"));
		for (WebElement user : usersList) {
		userIds.add(user.getText());
		System.out.println("User id to delete: "+user.getText());
		}
		return userIds;
		}
		catch(Exception e){
			System.out.println("User not found in search results.");
			return null;
		}
	}	

}
