package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebElement;

import com.optum.synergy.reference.ui.pageobjects.OptumRx_RequestaCallBackModalPage;

import cucumber.api.java.en.When;

public class OptumRx_RequestaCallBackModalPageStepDefinition {
	private OptumRx_RequestaCallBackModalPage page;

	public OptumRx_RequestaCallBackModalPageStepDefinition() {
		page = new OptumRx_RequestaCallBackModalPage();
	}

	@When("^I enter valid \"([^\"]*)\" into Enter phone number$")
	public void iEnterValidIntoEnterPhoneNumber(String phone) {
		WebElement phoneNumber = page.getPhoneNumber();
		phoneNumber.clear();
		phoneNumber.sendKeys(phone);

	}

	@When("^I enter valid \"([^\"]*)\" into Confirm phone number is required$")
	public void iEnterValidIntoConfirmPhoneNumberIsRequired(String cnfPhone) {
		WebElement cnfPhoneNumber = page.getConfirmPhoneNumber();
		cnfPhoneNumber.clear();
		cnfPhoneNumber.sendKeys(cnfPhone);

	}

	@When("^I select Whats the best time for us to call you as \"([^\"]*)\"$")
	public void iSelectWhatSTheBestTimeForUsToCallYouAs(String selectDropDown) {
		page.selectCallMeType(selectDropDown);
	}

	@When("^I should see \"([^\"]*)\" label for phone number field$")
	public void iSeePhoneNumberLabel(String label) {
		Assert.assertTrue(label + " label not found", page.getPhoneNumberLabel().getText().contains(label));
	}

	@When("^I should see \"([^\"]*)\" label for confirm phone number field$")
	public void iSeeConfirmPhoneNumberLabel(String label) {
		Assert.assertTrue(label + " label not found", page.getConfirmPhoneNumberLabel().getText().contains(label));
	}

	@When("^I should see \"([^\"]*)\" label for best time to call field$")
	public void iSeeBestTimeToCallLabel(String label) {
		Assert.assertTrue(label + " label not found", page.getBestTimeToCallLabel().getText().contains(label));
	}
}
