package com.optum.synergy.reference.ui.stepDefinitions;
import org.junit.Assert;
import com.optum.synergy.reference.ui.pageobjects.IBXUnauthenticatedHomePage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class IBXUnauthenticatedHomePageStepDefinition {
	private IBXUnauthenticatedHomePage page;

	public IBXUnauthenticatedHomePageStepDefinition() {
		page = new IBXUnauthenticatedHomePage();
	}

	@Given("I should see an IBX logo")
	public void iShouldSeeAnIbxLogo() {
		Assert.assertTrue("Issue displaying Ibx Logo", page.getIbxLogo().isDisplayed());
	}
}
