package com.optum.synergy.reference.ui.utility;

import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * Class to allow for thread-safe storage of a data set.
 * 
 * @author cnye1
 *
 * @param <T> class of objects stored in ResourcePool
 */
public class ResourcePool<T> {

  private LinkedBlockingQueue <T> poolList = new LinkedBlockingQueue<T>();

  /**
   * Default constructor, starts with empty pool.
   */
  public ResourcePool() {
    
  }

  /**
   * Constructor to initialize pool with initial list of objects.
   * 
   * @param input List of objects to be added to the pool
   */
  public ResourcePool(List<T> input) {
	  
	  poolList.addAll(input);
	  
  }
  
  /**
   * Check whether current pool state contains input object
   * @param input
   * @return
   */
  public boolean contains(T input) {
	  return poolList.contains(input);
  }

  /**
   * Removes next item from the pool and returns to caller.
   * 
   * @return
   */
  public T getResource() {
    synchronized (this) {
      
      T value = null;
      try {
        value = poolList.poll(0, TimeUnit.SECONDS);
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
      
      if ( value == null ) {
        // If pool is empty, poll() returns null.  
      	// For now, leave handling of empty pool to calling methods.
      }
        
      return value;
    }
  }

  /**
   * Adds new item to pool.  Commonly used in an @After method to return 
   * a previously retrieved item to the pool
   * 
   * @param value
   */
  public void returnResource(T value) {
    if ( value != null ) {
      // Never add null objects to the pool
      synchronized (this) {
        poolList.add(value);
      }
    }
    return;
  }
  
  /**
   * 
   * @return Number of items currently stored in pool
   */
  public int size() {
    return poolList.size();
  }
  

  public String toString() {
    
    return poolList.toString();
  }

}
