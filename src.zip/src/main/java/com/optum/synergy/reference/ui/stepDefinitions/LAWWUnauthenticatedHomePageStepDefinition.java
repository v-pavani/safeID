package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;
import com.optum.synergy.reference.ui.pageobjects.LAWWUnauthenticatedHomePage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LAWWUnauthenticatedHomePageStepDefinition {
	
	private LAWWUnauthenticatedHomePage page;

	public LAWWUnauthenticatedHomePageStepDefinition() {
		page = new LAWWUnauthenticatedHomePage();
	}

	@Given("^I am at LAWW unauthenticated home page$")
	public void iAmAtLawwUnauthenticatedHomePage() {
		page.openPage();
		Assert.assertTrue("Issue while loading unauthenticated page", page.verifyIfPageLoaded());
	}
	
	@Then("^I should be at LAWW unauthenticated home page$")
	public void iShouldBeAtLawwUnauthenticatedHomePage() {
		Assert.assertTrue("Issue while loading unauthenticated page", page.verifyIfPageLoaded());
	}

	@Then("^I should be at [^ ]* unathenticated page$")
	public void i_should_be_at_LAWW_unathenticated_page() {
		Assert.assertTrue("Issue while loading LAWW Unathenticated page", page.verifyIfPageLoaded());
	}
	
}
