package com.optum.synergy.reference.ui.pageobjects;

import java.util.List;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import com.optum.synergy.reference.ui.utility.ReadEmail;


public class Registration_ConfirmEmailSectionPage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//div[@id='verify_emailType']"+"|//*[contains(@class,'form__step3')]"
			+ "|//*[contains(@class,'step-three-selection')]/../../../..")
	private WebElement confirmEmailSection;
	
	@FindBy(how = How.XPATH, using = "//*[contains(@class,'form__step3')]"
			+ "|//flex[contains(@class,'form__content')]//p[contains(.,'Please check your inbox and follow the instructions to complete registration.')]")
	private WebElement confirmEmailSectionMessage;

	@FindBy(how = How.ID, using = "step3ConfirmEditedEmail")
	private WebElement confirmEmail2Field;
	
	@FindBy(how = How.CLASS_NAME, using = "error-text")
	private WebElement errorText;
	
	@FindBy(how = How.XPATH, using = "//p[contains(text(),'please click the confirmation')]/../../p/a/span[text()='Edit']"
			+ "|//p[@class='text-center ng-scope']/a/span[2]")
	private WebElement editlink;
	
	@FindBy(how = How.ID, using = "step3ConfirmEditedEmail")
	private WebElement confirmEditedEmail;
	
	@FindBy(how = How.XPATH, using = "//*[@id='step3ConfirmEditedPhoneNumber']"
			+ "|//*[@class='ng-scope']/div/input")
	private WebElement confirmEditedPhoneNumber;
	
	@FindBy(how = How.XPATH, using = "//*[@id='confirmCode']|//*[@id='verifyAuthPasscodeInput']|//*[@id='verificationCodeInput']")
	private WebElement txtConfirmationCode;

	@FindBy(how=How.XPATH, using="//p[contains(@ng-bind-html,'ConfirmInfo')]")
	private WebElement onlyOneMoreStepLeftConfirmation; 
		
	@FindBy(how=How.CLASS_NAME, using="tb-padding")
	private WebElement tbPadding;	
	
	@FindBy(how=How.XPATH, using="//div[@class='content-container']/header/p"
			+ "|//div[contains(@ng-bind-html,'ActionRequired')]")
	private WebElement actionNeededHeader;
	
	@FindBy(how=How.XPATH, using="//*[contains(@class,'modal__dialog')]//*[contains(@class,'modal__content')]//h2")
	private WebElement updatePhoneHeader;
	
	@FindBy(how=How.ID, using="step3ConfirmEditedPhoneNumber")
	private WebElement updatePhoneTextBox;
	
	@FindBy(how=How.CLASS_NAME, using="modal__close")
	private WebElement closeUpdatePhoneModalWindow;
	
	@FindBy(how=How.XPATH, using="//span[@ng-bind-html='step3ConfirmPhoneNumberError']")
	private WebElement updatePhoneValidationError;
	
	@FindBy(how=How.XPATH, using="//div[contains(@ng-if,'step3Confirm')]//h5")
	private WebElement callingNowMessage;
	
	@FindBy(how=How.XPATH, using="//div[contains(@ng-if,'step3Confirm')]//h4/span")
	private WebElement callingNowMessageConfirmAccount;
	
	@FindBy(how=How.XPATH, using="//span[contains(@ng-bind-html,'PhoneUpdated')]")
	private WebElement phoneUpdatedMessage;
	
	@FindBy(how=How.XPATH, using="//p[contains(@ng-show,'step3ConfirmCallError')]"
			+"| //p[contains(@ng-show,'step3ConfirmPhoneError')]|//*[@id='pageErrors']/div")
	private WebElement confirmCallError;
	
	@FindBy(how=How.XPATH, using="//div[contains(@ng-if,'step3Confirm')]//p[1]/span[3]")
	private WebElement confirmCallErrorConfirmAccount;
	
	@FindBy(how=How.XPATH, using="//span[@ng-bind-html='step3ConfirmTextError']/parent::div"
			+"| //p[contains(@ng-show,'step3ConfirmPhoneError')]")
	private WebElement confirmTextError;

	@FindBy(how=How.XPATH, using=".//div[@id='pageErrors']")
	private WebElement confirmTextError_Callme;
	
	@FindBy(how=How.XPATH, using="//span[contains(@ng-bind-html,'RegistrationStep3_11')]")
	private WebElement importantMessage;
	
	@FindBy(how=How.XPATH, using="//*[@name='confirmBySms']//*[@class='icon-checkmark_filled success']")
	private WebElement codeSentSuccessCheckmark;
	
	@FindBy(how = How.XPATH, using = "//flex-content/a/span[contains(@class,'icon-close')]"
			+	"| //a[contains(@class,'modal-close')]")
	private WebElement confirmXMarkRightTop;

	@FindBy(how = How.ID, using = "verifyLogin_page")
	private WebElement verifyAccountPage;
	
	
	public boolean verifyIfPageLoaded() {
		try {
			waitForJavascriptToLoad(10000, 1000);
			mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEmailSection));
			return confirmEmailSection.isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}

	public boolean verifyFormContent(String message) throws InterruptedException {
		Thread.sleep(2000);
		waitForJavascriptToLoad(10000, 1000);
		longWait.get().until(ExpectedConditions.visibilityOf(confirmEmailSection));
		String textContent = confirmEmailSection.getText().trim().replaceAll(String.valueOf((char)160)," ");
		return textContent.contains(message);
	}
	
	public boolean verifyFormContentConfirmAccount(String message) throws InterruptedException {
		Thread.sleep(2000);
		waitForJavascriptToLoad(10000, 1000);
		longWait.get().until(ExpectedConditions.visibilityOf(confirmEmailSectionMessage));
		return confirmEmailSectionMessage.getText().contains(message);
	}
	
	
	public void enterConfirmEmail2(String confirmEmailAddress) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEmail2Field));
		confirmEmail2Field.sendKeys(confirmEmailAddress);
	}
	
	public boolean verifyErrorMessageOnConfirmEmail2(String message) {

		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//span[contains(@class,'error') and contains(.,'" + message + "')]"))).isDisplayed();
	}

	public boolean verifyNoErrorMessageOnConfirmEmail2() {
		boolean noMessage = false;
		try {

		if( smallWait.get().until(
					ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(@class,'error')"))) == null)
			noMessage = true;
		} catch (TimeoutException e) {
			noMessage = true;

		}
		return noMessage;
	}

	public void clickOnConfirmEmailForm() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEmailSection));
		confirmEmailSection.click();
	}

	public void clearConfirmEmail2Field() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEmail2Field));
		confirmEmail2Field.clear();
	}
	
	public boolean verifyTheErrorText(String text)	{
		Assert.assertTrue("Error text element not found", smallWait.get().until(ExpectedConditions.visibilityOf(errorText)).isDisplayed());
		try{
		smallWait.get().until(ExpectedConditions.visibilityOf(errorText));
		return errorText.getText().contains(text);
		}
		catch(TimeoutException e )
		{
			return false;
		}
	}
	
	
	public void clickOnEditEmaillink()	{
		mediumWait.get().until(ExpectedConditions.elementToBeClickable(editlink)).click();
	}
	
	public String getMessageOnStep3PageOfRegisteration() {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//div[@class='form__step3 ng-scope']/p/p"))).getText().trim();
	}

	public boolean verifyConfirmEmail2Textbox() {
		 return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEmail2Field)).isDisplayed();
	}

	public void enterEditedEmail(String emailText) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEditedEmail));
		confirmEditedEmail.clear();
		confirmEditedEmail.sendKeys(emailText);
	}
	
	public void clickOnConfirmEditedEmailButton(String buttonName) {
		WebElement elem = mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//p[@class='tb-margin']/*[contains(.,'"+buttonName + "')]")));
		 scrollElementIntoView(elem);
		 elem.click();		
	}
	
	public void clickOnTextOnConfirmEmailPage(String buttonName) {
		 WebElement elem = mediumWait.get().until(ExpectedConditions.elementToBeClickable(
				By.xpath("//p[@class='text-center step-three-option']/a[contains(.,'"+buttonName + "')]/span[2]|//span[contains(text(),'"+buttonName+"')]")));
		 scrollElementIntoView(elem);
		 elem.click();
	}
	
	public boolean clickElementByClassNameAndText(String className, String text) {
		boolean isClicked = false;
		JavascriptExecutor js = (JavascriptExecutor) driver;
		try {
			List<WebElement> elems = mediumWait.get().until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.className(className)));
			for (WebElement elem : elems) {
				if (elem.getText().contains(text)) {		
					js.executeScript("arguments[0].click();", elem);
					isClicked = true;
					break;
				}
			}
		} catch (Exception e) {
			isClicked = false;
		}
		return isClicked;
	}
	
	public boolean verifytextOnEmailConfirmPage(String message) {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//*[contains(.,'"+message + "')]"))).isDisplayed();
	}
	
	public void enterEditedPhoneNumberField(String phoneText) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmEditedPhoneNumber));
		confirmEditedPhoneNumber.clear();
		confirmEditedPhoneNumber.sendKeys(phoneText);
	}

	public void clickOnConfirmEditedPhoneNumberButton(String buttonName) throws InterruptedException {
		mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//p[@class='tb-margin']/*[contains(.,'"+buttonName + "')]"))).click();
		Thread.sleep(1000);
	}
	
	public void enterConfirmationCode(String code) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(txtConfirmationCode));
		txtConfirmationCode.clear();
		txtConfirmationCode.sendKeys(code);

	}
	
	public String getPaddingContent() { 
		return mediumWait.get().until(ExpectedConditions.visibilityOf(tbPadding)).getText();
	}
	
	public String getPersonalInfoDescription() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(onlyOneMoreStepLeftConfirmation)).getText();
		}

	public void enterOTP() {
		String OTP= ReadEmail.getOTPFromEmail();
		mediumWait.get().until(ExpectedConditions.visibilityOf(txtConfirmationCode)).sendKeys(OTP);
	}
	
	public String getActionNeededContent() {
		return longWait.get().until(ExpectedConditions.visibilityOf(actionNeededHeader)).getText();
	}
	
	public void enterPhoneNumber(String number) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(updatePhoneTextBox));
		updatePhoneTextBox.clear();
		updatePhoneTextBox.sendKeys(number);
	}
	
	public void clickCloseModalWindow() {
		try {
		mediumWait.get().until(ExpectedConditions.visibilityOf(closeUpdatePhoneModalWindow)).click();
		} catch (Exception e) {
			//No-op; assume non-visible close means it's already closed.
		}
	}
	
	public WebElement verifyXMarkOnTopRight() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmXMarkRightTop));
	}
	
	public String getUpdatePhoneValidationMessage() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(updatePhoneValidationError)).getText();
	}
	
	public String getCallingNowMessage() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(callingNowMessage)).getText();
	}
	
	public String getCallingNowMessageConfirmAccount() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(callingNowMessageConfirmAccount)).getText();
	}
	
	public String getPhoneUpdatedMessage() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(phoneUpdatedMessage)).getText();
	}
	
	public String getconfirmCallError() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmCallError)).getText();
	}
	
	public String getconfirmCallErrorConfirmAccount() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmCallErrorConfirmAccount)).getText();
	}
	
	public void clickElementByLink() {
		WebElement elem = smallWait.get().until(ExpectedConditions.presenceOfElementLocated(By.className("icon-edit")));
		scrollElementIntoView(elem);
		elem.click();
	}
	
	public String getConfirmTextMeError() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmTextError_Callme)).getText();
	}
	
	public String getImportantMessage() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(importantMessage)).getText();
	}
	
	public WebElement getCodeSentCheckmarkElementOnStep3Page() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(codeSentSuccessCheckmark));
	}

	public WebElement getOTPField() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(txtConfirmationCode));
	}

	public WebElement getPhoneNumberField() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(updatePhoneTextBox));
	}

	public boolean veifyIfVerifyYourAccountPageLoaded() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(verifyAccountPage)).isDisplayed();
	}
}

