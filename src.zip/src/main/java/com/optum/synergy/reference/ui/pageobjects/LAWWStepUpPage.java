package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LAWWStepUpPage extends PageObjectBase{
	
	@FindBy(how = How.XPATH, using = "//a[contains(@class,'nav-link') and contains(.,'Benefits & Claims')]|//a/span[contains(.,'Benefits & Claims')]")
	private WebElement benefitsAndClaims;
	
	@FindBy(how = How.XPATH, using = "//a[contains(@class,'nav-sublink') and contains(.,'View Claim Status')]|//a/span[contains(.,'View Claim Status')]")
	private WebElement viewClaimStatus;
	
	@FindBy(how = How.NAME, using = "personalInfo")
	private WebElement verifyYourInfoSection;
	
	public boolean verifyErrorMessageOnAccessNotConfirmed(String message) {
		return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//p[contains(@class,'error-text') and contains(.,'"+message+"')]")))
				.isDisplayed();
	}
	
	public void benefitsAndClaimsClick(){
		longWait.get().until(ExpectedConditions.visibilityOf(benefitsAndClaims)).click();
	}
	
	public void viewClaimsStatusClick() {
		longWait.get().until(ExpectedConditions.visibilityOf(viewClaimStatus)).click();
	}
	
	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(verifyYourInfoSection)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}

}