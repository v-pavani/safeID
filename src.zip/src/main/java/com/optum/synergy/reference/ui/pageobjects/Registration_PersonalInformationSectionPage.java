package com.optum.synergy.reference.ui.pageobjects;

import com.optum.synergy.reference.ui.utility.DataStorage;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

public class Registration_PersonalInformationSectionPage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//div[@ui-view='rightView']/div[@class='ng-binding ng-scope']/p|//div[@ui-view='rightView']/div[@class='ng-scope']|//flex-content[contains(@class,'left-divider')]/div/div|//flex-content[contains(@class,'left-divider')]/div/p|//div[@ui-view='rightView']/div[@class='mb30 ng-binding ng-scope']|//*[@id='helpText']|//div[@class='tb-padding ng-scope']")
	private WebElement rightViewContent;

	@FindBy(how = How.XPATH, using = "//*[@name='personalInfo']|//div[@id='bigFive_page']")
	private WebElement personalInfoSection;

	@FindBy(how = How.CLASS_NAME, using = "mb30")
	private WebElement personalInfoDescription;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'First name')]/following-sibling::input[@id='piFirstName']"
			+ "|//span[contains(@class,'strong') and contains(.,'First name')]/following-sibling::div[@class='tooltip']/input[@id='piFirstName']"
			+ "|//label[@for='piFirstName']/span[contains(text(),'Patient first name')]"
			+ "|//label[@for='piFirstName']/span[contains(text(),\"Patient's first name\")]")
	private WebElement firstNameLabelWithTextBox;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Last name')]/following-sibling::input[@id='piLastName']"
			+ "|//span[contains(@class,'strong') and contains(.,'Last name')]/following-sibling::div[@class='tooltip']/input[@id='piLastName']"
			+ "|//label[@for='piLastName']/span[contains(text(),'Patient last name')]"
			+ "|//label[@for='piLastName']/span[contains(text(),\"Patient's last name\")]")
	private WebElement lastNameLabelWithTextBox;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Date of birth')]/following-sibling::input[@id='piDoB']"
			+ "|//span[contains(@class,'strong') and contains(.,\"Patient's date of birth\")]/following-sibling::input[@id='piDoB']")
	private WebElement dobLabelWithTextBox;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Zip code')]/following-sibling::input[@id='piZipCode']")
	private WebElement zipCodeLabelWithTextBox;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Member ID')]/following-sibling::input[@id='piMemberId']"
			+ "|//span[contains(@class,'strong') and contains(.,'Member ID')]/following-sibling::input[@name='memberId']"
			+ "|//span[contains(@class,'strong') and contains(.,'Membership ID')]/following-sibling::input[@id='piMemberId4Dst']"
			+ "|//span[contains(@class,'strong') and contains(.,'Member ID')]/following-sibling::input[@name='memberId']"
			+ "|//span[contains(@class,'strong') and contains(.,'Member ID')]/following-sibling::input[@id='piMemberId4Wcp']"
			+ "|//span[contains(@class,'strong') and contains(.,'Member ID')]/following-sibling::input[@id='piMemberId4Cap']"
			+ "|//span[contains(@class,'strong') and contains(.,'Member ID')]/following-sibling::input[@id='piMemberId4Laww']"
			+ "|//span[contains(@class,'strong') and contains(.,'Member ID')]/following-sibling::input[@id='piMemberId4Mnr']")
	private WebElement memberIdLabelWithTextBox;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong')][contains(.,'Group/Policy number') or contains(.,'Group/Policy#')] /following-sibling::input[@id='piGroupNum4Myuhc']"
			+ "|//span[contains(@class,'strong') and contains(.,'Group/Policy number') or contains(.,'Group/Policy#')]/following-sibling::input[@id='piGroupNum4Wcp']")
	private WebElement groupOrPolicyNumberLabelWithTextBox;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Social Security Number')]/following-sibling::input[@id='piSSN']"
			+ "|//span[contains(@class,'strong') and contains(.,'Social Security Number')]/following-sibling::input[@id='piSSN4Wcp']"
			+ "|//span[contains(@class,'strong') and contains(.,'Social Security Number')]/following-sibling::input[@id='piSSN4Cap']"
			+ "|//span[contains(@class,'strong ng-binding') and contains(.,'Social Security Number')]/following-sibling::input[@id='piSSN4MyOptum']"
			+ "|//*[contains(text(),'Social Security Number.')]/following-sibling::input[starts-with(@id, 'piSSN')]")
	private WebElement ssnLabelWithTextBox;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'form__step1')]/p[contains(@class,'ng-scope')]"
			+ "|//div[@ng-show='pageError']/p" + "|//div[@id='pageErrors']/p|//div[@ng-show='$parent.formDesc']")
	private WebElement PersonalInfoTopError;

	@FindBy(how = How.XPATH, using = "//*[@id='piFirstName']|//input[@value='ABCDEFGH']|//input[@value='EmpFirstName']/../following-sibling::td/input|//input[@name='firstName']|//label[@for='piFirstName']/div/span")
	private WebElement firstNameTextBox;

	@FindBy(how = How.XPATH, using = "//*[@id='piLastName']|//input[@value='IJKLMNOPQRSTUVWXYZ']|//input[@value='EmpLastName']/../following-sibling::td/input|//input[@name='lastName']|//label[@for='piLastName']/div/span")
	private WebElement lastNameTextBox;

	@FindBy(how = How.XPATH, using = "//*[@id='piDoB']|//label[@for='piDoB']/p/following-sibling::span[1]|//*[@id='dob']")
	private WebElement dateOfBirthTextBox;

	@FindBy(how = How.ID, using = "piZipCode")
	private WebElement zipCodeTextBox;

	@FindBy(how = How.ID, using = "piMemberId4Rx")
	private WebElement cardholderId;

	@FindBy(how = How.XPATH, using = "//*[@id='memberIdModal']|//*[contains(@class,'memberId-modal-content')]|//*[contains(@class,'modal__dialog')]")
	private WebElement memberIdPopUpWindow;

	@FindBy(how = How.XPATH, using = "//div[@class='modal-footer']/button|//div[@class='modal-footer mt20']")
	private WebElement doneButtonInMemberIdPopUp;

	@FindBy(how = How.XPATH, using = "//*[starts-with(@id,'memberId')]//*[@class='icon-close']")
	private WebElement closeIconInMemberIdPopUp;

	@FindBy(how = How.XPATH, using = "//select[starts-with(@id,'registerWith')]|//select[starts-with(@id,'registerWithCap')]|//select[starts-with(@id,'registerWithLaww')]")
	private WebElement registerWithDropdown;

	@FindBy(how = How.XPATH, using = "//input[starts-with(@id,'piMemberId')]|//*[@id='piMemberId4Dst']|//input[starts-with(@id,'piMemberID')]|//input[@value='00000000000']|//input[starts-with(@id,'memberId')]")
	private WebElement memberIdTextBox;
	
	@FindBy(how = How.XPATH, using = "//input[@id='piCaregiverAccessCode']")
	private WebElement careGiveraccessCodeTextBox;

	@FindBy(how = How.XPATH, using = "//input[starts-with(@id,'piMemberId')]|//*[@id='piMemberId4Dst']")
	private WebElement employeeIdTextBox;

	@FindBy(how = How.XPATH, using = "//input[starts-with(@id,'piGroupNum')]|//input[@value='0000000']|//input[@value='EmpGroupNumber']/../following-sibling::td/input |//input[@name ='groupId']")
	private WebElement groupNumberTextBox;

	@FindBy(how = How.XPATH, using = "//input[starts-with(@id, 'piSSN')]")
	private WebElement ssnTextBox;

	@FindBy(how = How.ID, using = "header")
	private WebElement formHeader;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'optum-logo.png')]"
			+ "| //img[contains(@src,'OPTUM_RGB.png')]"
			+ "| //img[contains(@src,'optumbank-logo.png')]"
			+ "| //img[contains(@src,'logo.png')]"
			+ "|//img[contains(@src,'OPTUM.gif')]"
			+ "|//img[contains(@src,'OPTUM_logo.svg')]"
			+ "|//img[contains(@src,'Optum_Speciatly_Rx.png')]"
			+ "|//img[contains(@src,'Optum_Logo.png')]")
	private WebElement optumLogo;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'HarvardPilgrim.jpg')]")
	private WebElement harvardPilgrimLogo;
	
	@FindBy(how = How.XPATH, using = "//img[contains(@src,'Railroad_Logo.png')]")
	private WebElement railRoadLogo;	

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'optum-logo.png')]/../../a"
			+ "|//img[contains(@src,'OPTUM.gif')]/../../a/img"
			+ "|//img[contains(@alt,'Live and Work Well Logo')]")
	private WebElement optumLogoBelowGN;
	
	@FindBy(how = How.XPATH, using = "//img[contains(@src,'logo-optumrx.png')]"
			+ "| //img[contains(@src,'OPTUMRx_RGB.png')]"
			+ "|//img[contains(@src,'optumrx.png')]"
			+ "|//img[contains(@src,'OptumRx_Logo.png')]")
	private WebElement optumRxLogo;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'logos/uhc_logo.gif')]|//img[contains(@src,'hsid/UHC_logo.png')]|//img[contains(@src,'header-logo.png')]|//img[contains(@src,'UHC-Logo.svg')]|//img[contains(@src,'Logos/UHC.svg')]|//img[@class='brandlogo' and contains(@src,'MyUHC_Logo.svg')]|//img[contains(@src,'New_UHC_Logo.png')]")
	private WebElement uhcLogo;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'logos/logo_myuhc.gif')]|//img[contains(@src,'logos/myuhc.gif')]|//img[contains(@src,'dam/hsid/myuhc.gif')]|//div[@id='returntologoMain']")
	private WebElement myUhcLogo;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'logos/Lockup_Medica.gif')]")
	private WebElement uhcMedicaLogo;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'Community_Logo.svg')]|//img[contains(@src,'New_Community_Logo.png')]")
	private WebElement uhcCommunityPlanLogo;
	
	@FindBy(how = How.XPATH, using = "//img[contains(@src,'New_UHC_Logo.png')]")
	private WebElement uhcMNRLogo;

	@FindBy(how = How.XPATH, using = "//*[@id='pageContent']//img[contains(@src,'optum.com/content/dam/OptumDashboard/ad-box/logos/logo_laww.gif')]|//*[contains(@class,'portal-title')][contains(text(),'Live and Work Well')]|//*[contains(@class,'portal-title') and contains(text(),'Live and Work Well')]")
	private WebElement LAWWLogo;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'AARPMedicare_Logo.png')]"
			+ "|//header[@class='hide-mobile']//img[@src='/images/branding/aarp.svg']" + "|//img[@alt='AARP logo']"
			+ "|//img[@class='brandlogo' and contains(@src,'AARPMedicare_Logo')]" + "|//img[contains(@src,'logo/AARP.svg')]"
	        	+ "|//img[contains(@src,'Logos/AARP.svg')]" + "|//img[contains(@src,'Logos/UHC.svg')]")
	private WebElement aarpLogo;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'https://myoptum-stage.optum.com/content/dam/hsid/UHC_logo.png')]|//header[@class='hide-mobile']//img[@src='/images/branding/unitedhealth.svg']|//img[@alt='UHC logo']|//img[contains(@src,'Logos/UHC.svg')]")
	private WebElement medicareLogo;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'MedicaMedicare_Logo.png')]|//header[@class='hide-mobile']//img[@src='/images/branding/medicahealthcare.svg']|//img[@alt='Medica Logo']|//img[@alt='Medica Health Care']|//img[@alt='United Health Care']|//img[contains(@src,'archive/MEDICA.svg')]|//img[contains(@src,'Logos/UHC.svg')]|//img[contains(@src,'PCN_Logo.png')]")
	private WebElement medicaLogo;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'PCPMedicare_Logo.png')]|//header[@class='hide-mobile']//img[@src='/images/branding/preferredcare.svg']|//img[@alt='PCP logo']|//img[@alt='Preferred Care Partners']|//img[contains(@src,'archive/PCP.svg')]|//img[contains(@src,'Logos/PCP.svg')]")
	private WebElement pcpLogo;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'UHC_logo.png')]|//header[@class='hide-mobile']//img[@src='/images/branding/unitedhealth.svg']|//img[@alt='UHC logo']|//img[@alt='United Health Care']|//img[contains(@src,'Logos/UHC.svg')]|//img[contains(@src,'hsid/UHC_logo.png')]")
	private WebElement retireeLogo;
	
	@FindBy(how = How.XPATH, using = "//img[@class='brandlogo' and contains(@src,'RxAARP_logo.jpg')]")
	private WebElement aarpOptumRxLogo;
	
	@FindBy(how = How.XPATH, using = "//img[@class='brandlogo' and contains(@src,'AHA.png')]")
	private WebElement ahaOptumRxLogo;
	
	@FindBy(how = How.XPATH, using = "//img[@class='brandlogo' and contains(@src,'AHNJ.png')]")
	private WebElement rxAMERIHEALTHLogo;

	@FindBy(how = How.XPATH, using = "//img[@class='Header_logoImage__1Rs3V' and contains(@src,'Railroad_Logo.png')]")
	private WebElement RailroadLogo;
	
	@FindBy(how = How.CLASS_NAME, using = "brandlogo")
	private WebElement GNbrand;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Username')]")
	private WebElement usernameLabel;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Password')]")
	private WebElement passwordLabel;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Confirm password')]")
	private WebElement confirmPasswordLabel;

	@FindBy(how = How.XPATH, using = "//input[contains(@id,'registerWithMember') and @ng-value='regOptions.yes']")
	private WebElement optionYesForMemberIDcard;

	@FindBy(how = How.XPATH, using = "//input[contains(@id,'registerWithMember') and @ng-value='regOptions.no']")
	private WebElement optionNoForMemberIDcard;

	@FindBy(how = How.XPATH, using = "//label[@for='piFirstName']/span[@class='error']")
	private WebElement firstNameErrorMsg;

	@FindBy(how = How.XPATH, using = "//label[@for='piLastName']/span[@class='error']")
	private WebElement lastNameErrorMsg;

	@FindBy(how = How.XPATH, using = "//label[@for='piDoB']//span[contains(@class,'error') and not(contains(@class,'ng-hide'))]")
	private WebElement dateOfBirthErrorMsg;

	@FindBy(how = How.XPATH, using = "//label[@for='username']//span[contains(@class,'error') and not(contains(@class,'ng-hide'))]")
	private WebElement usernameErrorMsg;

	@FindBy(how = How.XPATH, using = "//label[@for='password']//span[contains(@class,'error') and not(contains(@class,'ng-hide'))]")
	private WebElement passwordErrorMsg;

	@FindBy(how = How.XPATH, using = "//*[@for='confirmPassword']//*[contains(@class,'error')]")
	private WebElement confirmPasswordErrorMsg;

	@FindBy(how = How.XPATH, using = "//label[@for='email']//span[contains(@class,'error') and not(contains(@class,'ng-hide'))]")
	private WebElement emailErrorMsg;

	@FindBy(how = How.XPATH, using = "//label[@for='piZipCode']/span[starts-with(@class,'error')]")
	private WebElement zipcodeErrorMsg;
	
	@FindBy(how = How.XPATH, using = "//label[@for='piCaregiverAccessCode']/div[contains(text(),'Caregiver')]")
	private WebElement careGiverAccessCodeErrorMsg;

	@FindBy(how = How.XPATH, using = "//label[starts-with(@for,'piSSN')]/span[@class='error']|//label[starts-with(@for,'piSSN')]/span[@class='error ng-binding']|//label[starts-with(@for,'piSSN')]/span[contains(@class,'error')]")
	private WebElement ssnErrorMsg;

	@FindBy(how = How.XPATH, using = "//label[starts-with(@for,'piMemberId')]//*[@ng-bind-html='piMemberIdError']|//label[@for='piMemberId']/span[@class='error']|//*[@ng-bind-html='piMemberId4OxError']")
	private WebElement memberIdErrorMsg;

	@FindBy(how = How.XPATH, using = "//label[starts-with(@for,'piMemberId')]//*[@ng-bind-html='piMemberIdError']|//label[@for='piMemberId']/span[@class='error']")
	private WebElement employeeIdErrorMsg;

	@FindBy(how = How.XPATH, using = "//label[starts-with(@for,'piGroupNum')]//*[starts-with(@ng-bind-html,'piGroup')]|//label[@for='piGroupNumMyuhc']/span[@class='error']")
	private WebElement groupNumberErrorMsg;

	@FindBy(how = How.XPATH, using = "//label[starts-with(@for,'piPrescriptionNo')]//*[@ng-bind-html='piPrescriptionNoError']")
	private WebElement prescriptionNumErrorMsg;

	@FindBy(how = How.XPATH, using = "//flex-content[@id='header']/h1|//flex-content[@id='header']|//header[@class = 'header']|//flex-content/p[contains(@class,'body-text')]")
	private WebElement myUhcBreadCrumbContainer;

	@FindBy(how = How.XPATH, using = "//*[@name='credentials']|//div[contains(@class,'form__step1')]/p[contains(@class,'milli ng-binding')]")
	private WebElement personalInfoRequiredMessage;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'rx-card1.png')]|//*[@id='memberId-dialog']/flex/flex-content/div")
	private WebElement memberIdCardImage1;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'rx-card2.png')]")
	private WebElement memberIdCardImage2;
	
	@FindBy(how = How.XPATH, using = "//img[contains(@src,'aarpcard1.png')]")
	private WebElement memberIdCardImage3;

	@FindBy(how = How.XPATH, using = "//*[@id='memberIdModal']/flex//div/img[contains(@src,'DiME_membercard_v2.png')]|//*[contains(@src,'DiME_membercard_v2.png')]")
	private WebElement membershipIdCardImage;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'logo_dental.gif')]"
			+ "|//img[contains(@src,'BSCA_logo.gif')]" + "|//img[@alt='Blue of California']" + "|//img[contains(@src,'hsid/bsca-logo.png')]")
	private WebElement bscaLogo;

	@FindBy(how = How.XPATH, using = "//img[@alt='member card']")
	private WebElement bscaMemberIDcardOnModalDialog;

	@FindBy(how = How.XPATH, using = "//p[contains(.,'Member ID:') and //img[contains(@title,'Sample Member Identification (ID) Card.')]]")
	private WebElement memberIDWithGreenCircle;

	@FindBy(how = How.XPATH, using = "//img[@class='brandlogo']|//img[contains(@src,'BCBS_AZ_Logo.png')]|//img[contains(@src,'BCBS-AZ-LOGO.jpg')]")
	private WebElement bazLogo;

	@FindBy(how = How.XPATH, using = "//img[@alt='member card']|//img[@alt='Myuhc new']|//img[@alt='harvardpilgrim']")
	private WebElement bazMemIDImg;

	@FindBy(how = How.XPATH, using = "//img[@alt='Myuhc new']|//img[@alt='ID Card Sample']")
	private WebElement myUhcMemIDImg;

	@FindBy(how = How.XPATH, using = "//img[@alt='myMedicaDentalIDCardPassport']")
	private WebElement myUhcDentalIDImg;

	@FindBy(how = How.XPATH, using = "//label[starts-with(@for,'piMemberId')]/a/i")
	private WebElement memberIDToolTip;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'logo.png')]|//img[contains(@src,'BriovaRx.png')]")
	private WebElement briovaRxlogo;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Optum Specialty Pharmacy prescription number')]/following-sibling::div[contains(@class,'tooltip')]/input[contains(@id,'piPrescriptionNo4Briova')]")
	private WebElement briovaRxprescriptionNoTextBox;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'prescription%20image.png')]")
	private WebElement briovaRxtooltipImg1;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'Combined%20Statements.png')]")
	private WebElement briovaRxtooltipImg2;

	@FindBy(how = How.XPATH, using = "//img[@class='brandlogo' and @src='https://myoptum-stage.optum.com/content/dam/hsid/AHC_Logo.jpg']"
			+ "|//img[@class='brandlogo' and @src='https://www.myoptum.com/content/dam/hsid/AHC_Logo.jpg']|//img[@class='brandlogo' and contains(@src,'AHC_Logo.jpg')]")
	private WebElement ahcLogo;

	@FindBy(how = How.XPATH, using = "//img[@class='brandlogo' and @src='https://myoptum-stage.optum.com/content/dam/hsid/SRVU_Logo.jpg']"
			+ "|//img[contains(@src,'serveyou-header-logo.png')]" + "|//img[contains(@src,'SRVU_Logo.jpg')]")
	private WebElement serveyouLogo;

	@FindBy(how = How.XPATH, using = "//*[@class='center-align']/p")
	private WebElement centeralignText;

	@FindBy(how = How.XPATH, using = "//div[@class='tooltip-content ruletip']")
	private WebElement toolTipPrescriptionNumberField;

	@FindBy(how = How.XPATH, using = "//img [@class='brandlogo' and contains(@src,'OptumBank_270px.png')]"
			+ "|//img[@class='brandlogo' and contains(@src,'optumbank-logo.png')]"
			+ "|//img[@class='brandlogo' and contains(@src,'Optum Bank_FDIC.jpg')]"
			+ "|//img[contains(@src,'optumbank-logo.png')]"
			+ "|//img[contains(@src,'OptumBank_Logo.png')]")
	private WebElement optumbankLogo;

	@FindBy(how = How.XPATH, using = "//label[starts-with(@for,'registerWith')]")
	private WebElement registerWithLabel;

	@FindBy(how = How.XPATH, using = "//*[@class='brandlogo' and contains(@src,'DisneyLogo2.png')]"
			+ "|//img[@alt='logo' and contains(@src,'1542839549056.png')]")
	private WebElement disneyLogo;

	@FindBy(how = How.XPATH, using = "*//*[text()='Accessibility Statement for Individuals with Disabilities']")
	private WebElement accessibilityPageLoad;
	
	@FindBy(how = How.XPATH, using= "//img[@class='brandlogo' and contains(@src,'AARPOptumBankLogo.JPG')]")
	private WebElement AARPLogo;
	
	@FindBy(how = How.XPATH, using = "//p[contains(.,'Group Number:') and //img[contains(@title,'Sample Member Identification (ID) Card.')]]")
	private WebElement groupNumberWithBlueSquare;
	
	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Cardholder ID')]/following-sibling::input[@id='piMemberId4Rx']")
	private WebElement cardHolderIdLabelWithTextBox;
	
	@FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Caregiver access code')]/following-sibling::input[@id='piCaregiverAccessCode']")
	private WebElement careGiverAccessCodeLabelWithTextBox;

	@FindBy(how = How.XPATH, using = "//img[@class='brandlogo' and contains(@src,'BCBSSC_Logo.png')]")
	private WebElement bcbsscLogo;

	@FindBy(how = How.XPATH, using = "//span[contains(@ng-if,\"personalInfoTopError.id===''\")]|//div[contains(@ng-show,'pageError')]|//*[@id='pageErrors']/p|//span[@class='icon-alert_filled error']//following-sibling::span[@ng-bind-html='step3ConfirmEmailError']|//div[contains(@class,'authOobValidationError')]")
	private WebElement errorText;

	public boolean verifyUsernameLabel() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(usernameLabel));
		return usernameLabel.isDisplayed();
	}

	public boolean verifyPasswordLabel() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(passwordLabel));
		return passwordLabel.isDisplayed();
	}

	public boolean verifyConfPasswordLabel() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmPasswordLabel));
		return confirmPasswordLabel.isDisplayed();
	}

	public String getPersonalInfoDescription() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(personalInfoDescription)).getText().trim().replaceAll(String.valueOf((char)160)," ");
	}

	public void clickOptumLogo() {
		optumLogo.click();
	}
	
	public void clickOptumLogoBelowGN(){
		mediumWait.get().until(ExpectedConditions.visibilityOf(optumLogoBelowGN)).click();
		}

	public boolean verifyLAWWlogo() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(LAWWLogo)).isDisplayed();
	}

	public boolean VerifyOptumLogo() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(optumLogo)).isDisplayed();
	}

	public boolean VerifyOptumRxLogo() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(optumRxLogo)).isDisplayed();
	}

	public boolean verifyUhcLogo() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(uhcLogo)).isDisplayed();
	}

	public boolean verifyClickableUHCLogo(){
		return mediumWait.get().until(ExpectedConditions.elementToBeClickable(uhcLogo)).isDisplayed();
	}

	public boolean verifyHarvardPilgrimLogo() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(harvardPilgrimLogo)).isDisplayed();
	}
	
	public boolean verifyRailroadLogo() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(railRoadLogo)).isDisplayed();
	}	

	public boolean verifyMyUhcLogo() {
		return longWait.get().until(ExpectedConditions.visibilityOf(myUhcLogo)).isDisplayed();
	}

	public boolean verifyMyUhcMedicaLogo() {
		return uhcMedicaLogo.isDisplayed();
	}

	public boolean verifyMemberIdOrSSNDropdown() {
		return registerWithDropdown.isDisplayed();
	}

	public boolean verifyMyUhcCommunityPlanLogo() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(uhcCommunityPlanLogo)).isDisplayed();
	}
	
	public boolean verifyUHCMNRLogo() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(uhcMNRLogo)).isDisplayed();
	}
	
	public boolean verifyAARPOptumRxLogo() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(aarpOptumRxLogo)).isDisplayed();
	}
	
	public boolean verifyAHAOptumRxLogo() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(ahaOptumRxLogo)).isDisplayed();
  }
  
	public boolean verifyAMERIHEATLHLogo() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(rxAMERIHEALTHLogo)).isDisplayed();
	}
	
	public boolean verifyClickableRailroadLogo() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(RailroadLogo)).isDisplayed();
	}
	
	public boolean verifyIfPageLoaded() {
		try {
			waitForJavascriptToLoad(25000, 1000);
			longWait.get().until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(personalInfoSection)));
			return true;
		} catch (TimeoutException e) {
			return false;
		}
	}

	public void enterFirstName(String firstName) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(firstNameTextBox));
		firstNameTextBox.clear();
		firstNameTextBox.sendKeys(firstName);
	}
	
	public void enterLastName(String lastName) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(lastNameTextBox));
		lastNameTextBox.clear();
		lastNameTextBox.sendKeys(lastName);
	}

	public void enterDateOfBirth(String dateOfBirth) throws InterruptedException {
		mediumWait.get().until(ExpectedConditions.visibilityOf(dateOfBirthTextBox));
		dateOfBirthTextBox.clear();
		dateOfBirthTextBox.sendKeys(Keys.BACK_SPACE);
		dateOfBirthTextBox.sendKeys(dateOfBirth.replace("/", ""));
	}

	public void enterZipCode(String zipCode) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(zipCodeTextBox));
		zipCodeTextBox.clear();
		zipCodeTextBox.sendKeys(zipCode);
	}

	public void enterMemberID(String memberId) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(memberIdTextBox));
		memberIdTextBox.clear();
		memberIdTextBox.sendKeys(memberId);
	}
	
	public void enterCaregiverAccessCode(String accessCode) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(careGiveraccessCodeTextBox));
		careGiveraccessCodeTextBox.clear();
		careGiveraccessCodeTextBox.sendKeys(accessCode);
	}

	public void enterGroupNumber(String groupNum) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(groupNumberTextBox));
		groupNumberTextBox.clear();
		groupNumberTextBox.sendKeys(groupNum);
	}

	public void enterSSN(String ssn) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(ssnTextBox));
		ssnTextBox.clear();
		ssnTextBox.sendKeys(ssn);
	}

	public void enterPrescriptionNumber(String prescriptionno) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(briovaRxprescriptionNoTextBox));
		briovaRxprescriptionNoTextBox.clear();
		briovaRxprescriptionNoTextBox.sendKeys(prescriptionno);
	}

	public boolean SSNisEnabled() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(ssnTextBox));
		return ssnTextBox.isEnabled();
	}

	public boolean verifyIfSSNFieldIsDisplayed() {
		try {
			smallWait.get().until(ExpectedConditions.visibilityOf(ssnTextBox));
			return true;
		} catch (TimeoutException e) {
			return false;
		}
	}

	public boolean verifyIfSSNIsNotDisplayed() {
		try {
			return smallWait.get().until(ExpectedConditions.visibilityOf(ssnTextBox)) == null;
		} catch (TimeoutException e) {
			return true;
		}
	}

	public boolean memberidisenabled() {
		return memberIdTextBox.isEnabled();
	}

	public boolean verifyRightViewContent(String message) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(rightViewContent));
		return rightViewContent.getText().trim().replaceAll(String.valueOf((char)160), " ").contains(message);
	}

	public String getErrorMessageOnFirstName() {
		try {
			smallWait.get().until(ExpectedConditions.visibilityOf(firstNameErrorMsg));
			return firstNameErrorMsg.getText().trim();
		} catch (Exception e) {
			return null;
		}
	}

	public String getErrorMessageOnLastName() {
		try {
			smallWait.get().until(ExpectedConditions.visibilityOf(lastNameErrorMsg));
			return lastNameErrorMsg.getText().trim();
		} catch (Exception e) {
			return null;
		}
	}

	public boolean verifyNoErrorMessageOnFirstName() {

		try {
			return !firstNameErrorMsg.isDisplayed();
		} catch (Exception e) {
			return true;
		}
	}

	public boolean verifyNoErrorMessageOnLastName() {

		try {
			return !lastNameErrorMsg.isDisplayed();
		} catch (Exception e) {
			return true;
		}
	}

	public String getErrorMessageOnDateofBirth() {
		try {
			smallWait.get().until(ExpectedConditions.visibilityOf(dateOfBirthErrorMsg));
			return dateOfBirthErrorMsg.getText().trim();
		} catch (Exception e) {
			return "";
		}
	}

	public String getErrorMessageOnUsername() {
		try {
			smallWait.get().until(ExpectedConditions.visibilityOf(usernameErrorMsg));
			return usernameErrorMsg.getText().trim();
		} catch (Exception e) {
			return "";
		}
	}

	public String getErrorMessageOnPassword() {
		try {
			smallWait.get().until(ExpectedConditions.visibilityOf(passwordErrorMsg));
			return passwordErrorMsg.getText().trim();
		} catch (Exception e) {
			return "";
		}
	}

	public String getErrorMessageOnConfirmPassword() {
		try {
			smallWait.get().until(ExpectedConditions.visibilityOf(confirmPasswordErrorMsg));
			return confirmPasswordErrorMsg.getText().trim();
		} catch (Exception e) {
			return "";
		}
	}

	public String getErrorMessageOnEmail() {
		try {
			smallWait.get().until(ExpectedConditions.visibilityOf(emailErrorMsg));
			return emailErrorMsg.getText().trim();
		} catch (Exception e) {
			return "";
		}
	}

	public String getErrorMessageOnZipcode() {
		try {
			smallWait.get().until(ExpectedConditions.visibilityOf(zipcodeErrorMsg));
			return zipcodeErrorMsg.getText().trim();
		} catch (Exception e) {
			return null;
		}
	}
	
	public String getErrorMessageOnCaregiverAccessCode() {
		try {
			smallWait.get().until(ExpectedConditions.visibilityOf(careGiverAccessCodeErrorMsg));
			return careGiverAccessCodeErrorMsg.getText().trim();
		} catch (Exception e) {
			return null;
		}
	}

	public boolean verifyNoErrorMessageOnZipcode() {
		try {
			try {
				smallWait.get().until(ExpectedConditions.invisibilityOf(zipcodeErrorMsg));
				return !zipcodeErrorMsg.isDisplayed();
			} catch (TimeoutException e) {
				return zipcodeErrorMsg.getText().equals("");
			} catch (NoSuchElementException nse) {
				return true;
			}
		} catch (NoSuchElementException nsee) {
			return true;
		}
	}

	public String getErrorMessageOnMemberId() {
		try {
			smallWait.get().until(ExpectedConditions.visibilityOf(memberIdErrorMsg));
			return memberIdErrorMsg.getText().trim();
		} catch (Exception e) {
			return null;
		}
	}

	public String getErrorMessageOnEmployeeID() {
		try {
			smallWait.get().until(ExpectedConditions.visibilityOf(employeeIdErrorMsg));
			return memberIdErrorMsg.getText().trim();
		} catch (Exception e) {
			return null;
		}
	}

	public String getErrorMessageOnGroupNumber() {
		try {
			smallWait.get().until(ExpectedConditions.visibilityOf(groupNumberErrorMsg));
			return groupNumberErrorMsg.getText().trim();
		} catch (Exception e) {
			return null;
		}
	}

	public boolean verifyNoErrorMessageOnMemberId() {

		try {
			return !memberIdErrorMsg.isDisplayed();
		} catch (Exception e) {
			return true;
		}
	}

	public boolean verifyNoErrorMessageOnGroupNumber() {
		try {
			smallWait.get().until(ExpectedConditions.invisibilityOf(groupNumberErrorMsg));
			return !groupNumberErrorMsg.isDisplayed();
		} catch (TimeoutException e) {
			return groupNumberErrorMsg.getText().equals("");
		}
	}

	public String getErrorMessageOnSSN() {
		try {
			smallWait.get().until(ExpectedConditions.visibilityOf(ssnErrorMsg));
			return ssnErrorMsg.getText().trim();
		} catch (Exception e) {
			return null;
		}
	}

	public boolean verifyNoErrorMessageOnSSN() {

		try {
			return !ssnErrorMsg.isDisplayed();
		} catch (Exception e) {
			return true;
		}
	}

	public String getErrorMessageOnPrescriptionNum() {
		try {
			smallWait.get().until(ExpectedConditions.visibilityOf(prescriptionNumErrorMsg));
			return prescriptionNumErrorMsg.getText().trim();
		} catch (Exception e) {
			return null;
		}
	}

	public boolean verifyNoErrorMessageOnPrescriptionNum() {

		try {
			return !prescriptionNumErrorMsg.isDisplayed();
		} catch (Exception e) {
			return true;
		}
	}

	public void clickPersonalInfoForm() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(personalInfoSection));
		personalInfoSection.click();
	}

	public boolean verifyToolTipOnMemberIDField(String toolTipName) {
		return mediumWait.get()
				.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//label[@for='piMemberId']/a[contains(.,'" + toolTipName + "')]")))
				.isDisplayed();
	}

	public void ClickOnMemberIdToolTip() {
		clickByJavaScript(memberIDToolTip);
	}

	public boolean verifyForMemberIdToolTipMessage(String message) {
		return verifyTextByClassName("memberId__tooltip", message);
	}

	public boolean verifyForMemberId(String message) {
		return verifyTextByClassName("font-weight--bold", message);
	}

	public boolean verifyFormHeader(String headerName) {
		smallWait.get().until(ExpectedConditions.visibilityOf(formHeader));
		return formHeader.getText().equals(headerName);
	}

	public boolean verifyIfFirstnameLabelWithTextboxExist() {
		return smallWait.get().until(ExpectedConditions.visibilityOf(firstNameLabelWithTextBox)).isDisplayed();
	}

	public boolean verifyIfLastnameLabelWithTextboxExist() {
		return smallWait.get().until(ExpectedConditions.visibilityOf(lastNameLabelWithTextBox)).isDisplayed();
	}

	public boolean verifyIfDOBLabelWithTextboxExist() {
		return smallWait.get().until(ExpectedConditions.visibilityOf(dobLabelWithTextBox)).isDisplayed();
	}

	public boolean verifyIfZipcodeLabelWithTextboxExist() {
		return smallWait.get().until(ExpectedConditions.visibilityOf(zipCodeLabelWithTextBox)).isDisplayed();
	}

	public boolean verifyIfMemberIdLabelWithTextboxExist() {
		return smallWait.get().until(ExpectedConditions.visibilityOf(memberIdLabelWithTextBox)).isDisplayed();
	}

	public boolean verifyIfGroupOrPolicyNumberLabelWithTextboxExist() {
		return smallWait.get().until(ExpectedConditions.visibilityOf(groupOrPolicyNumberLabelWithTextBox))
				.isDisplayed();
	}

	public boolean verifyIfSocialSecurityNumberLabelWithTextboxExist() {
		return smallWait.get().until(ExpectedConditions.visibilityOf(ssnLabelWithTextBox)).isDisplayed();
	}

	public void clearAndenterDateOfBirth(String dateOfBirth) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(dateOfBirthTextBox));
		dateOfBirthTextBox.clear();
		dateOfBirthTextBox.sendKeys(dateOfBirth.replace("/", ""));
	}

	public String getFirstNameValue() {
		try {
			String firstName =  mediumWait.get().until(ExpectedConditions.visibilityOf(firstNameTextBox)).getAttribute("value");
			if(firstName == null)
				firstName= mediumWait.get().until(ExpectedConditions.visibilityOf(firstNameTextBox)).getText();
			return firstName;
		} catch (Exception e) {
			DataStorage.setCustomErrmsg("Exception getting PersonalInfo::FirstName [" + e + "]");
			return null;
		}
	}

	public String getLastNameValue() {
		try {
			String lastName =  mediumWait.get().until(ExpectedConditions.visibilityOf(lastNameTextBox)).getAttribute("value");
			if(lastName == null)
				lastName= mediumWait.get().until(ExpectedConditions.visibilityOf(lastNameTextBox)).getText();
			return lastName;
		} catch (Exception e) {
			DataStorage.setCustomErrmsg("Exception getting PersonalInfo::LastName [" + e.getMessage() + "]");
			return null;
		}
	}

	public String getDateofBirthValue() {
		try {
			String dob =  mediumWait.get().until(ExpectedConditions.visibilityOf(dateOfBirthTextBox)).getAttribute("value");
			if(dob == null)
				dob= mediumWait.get().until(ExpectedConditions.visibilityOf(dateOfBirthTextBox)).getText();
			return dob;
		} catch (Exception e) {
			DataStorage.setCustomErrmsg("Exception getting PersonalInfo::DoB [" + e.getMessage() + "]");
			return null;
		}
	}

	public String getZipCodeValue() {
		try {
			return mediumWait.get().until(ExpectedConditions.visibilityOf(zipCodeTextBox)).getAttribute("value");
		} catch (Exception e) {
			DataStorage.setCustomErrmsg("Exception getting PersonalInfo::ZipCode [" + e.getMessage() + "]");
			return null;
		}
	}

	public String getCardholderIdValue() {
		try {
			return mediumWait.get().until(ExpectedConditions.visibilityOf(cardholderId)).getAttribute("value");
		} catch (Exception e) {
			DataStorage.setCustomErrmsg("Exception getting PersonalInfo::CardholderId [" + e.getMessage() + "]");
			return null;
		}
	}

	public String getMemberIdValue() {
		try {
			return mediumWait.get().until(ExpectedConditions.visibilityOf(memberIdTextBox)).getAttribute("value");
		} catch (Exception e) {
			DataStorage.setCustomErrmsg("Exception getting PersonalInfo::MemberId [" + e.getMessage() + "]");
			return null;
		}
	}

	public String getGroupNumberValue() {
		try {
			return mediumWait.get().until(ExpectedConditions.visibilityOf(groupNumberTextBox)).getAttribute("value");
		} catch (Exception e) {
			DataStorage.setCustomErrmsg("Exception getting PersonalInfo::GroupNum [" + e.getMessage() + "]");
			return null;
		}
	}

	public boolean verifyErrorMessageOnTermConditionsAcceptedcheckbox(String message) {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.xpath(
				"//div[@ng-show='submitted && !login.termsAndConditionsAccepted']/*[contains(.,'" + message + "')]")))
				.isDisplayed();
	}

	public String getErrorMessage() {
		try {
			return mediumWait.get().until(ExpectedConditions.visibilityOf(errorText)).getText();
		} catch (TimeoutException e) {
			return "ERROR MESSAGE ELEMENT NOT DISPLAYED";
		}
	}

	public String PersonalInfoTopErrorMessage() {
		try {
			String textContent = mediumWait.get().until(ExpectedConditions.visibilityOf(PersonalInfoTopError)).getText().trim().replaceAll(String.valueOf((char)160)," ");
			textContent = StringUtils.normalizeSpace(textContent);
			return textContent;
		} catch (StaleElementReferenceException e) {
			String textContent = mediumWait.get().until(ExpectedConditions.visibilityOf(PersonalInfoTopError)).getText().trim().replaceAll(String.valueOf((char)160)," ");
			textContent = StringUtils.normalizeSpace(textContent);
			return textContent;
		} catch (TimeoutException e) {
			return null;
		}
	}

	public void selectOptionForHavingMemberIDcard(String arg) {
		if (arg.equalsIgnoreCase("YES")) {
			clickByJavaScript(optionYesForMemberIDcard);
		} else {
			clickByJavaScript(optionNoForMemberIDcard);
		}
	}

	public void mouseHoverOnLabel(String message) {
		WebElement elem = mediumWait.get().until(ExpectedConditions
				.presenceOfElementLocated(By.xpath("//*[@class='tooltip']/*[contains(.,'" + message + "')]/i")));

		mouseHoverOnElement(elem);
	}

	public String getTootipMessage() {
		List<WebElement> toolTips = mediumWait.get()
				.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//*[@class='tooltip']")));
		String toolTipContent = "";
		for (WebElement toolTip : toolTips) {
			toolTipContent = toolTipContent + toolTip.getText();
		}
		return toolTipContent;
	}

	public void clickLinkunderAlreadyHaveHealthSafeID(String linkName) {
		mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//*[@class='ng-binding ng-scope']/p[contains(.,'" + linkName + "')]/b/a"))).click();
	}

	public void waitForPageLoadforLink(String linkName) {
		longWait.get().until(
				ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='ng-binding ng-scope']/b[contains(.,'"
						+ linkName + "')]|//*[@id='Login']/*[contains(.,'" + linkName + "')]")));
	}

	public void waitForPageLoadLinkForAccessibility() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(accessibilityPageLoad));
	}

	public String getMessageOnPersonalInformationPage() {
		return longWait.get()
				.until(ExpectedConditions
						.presenceOfElementLocated(By.xpath("//*[@id='Login']/div[@class='form__step1--haveaccess']")))
				.getText();
	}

	public boolean verifyBreadCrumbContains(String heading) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(myUhcBreadCrumbContainer));
		String textContent = myUhcBreadCrumbContainer.getText().trim().replaceAll(String.valueOf((char)160)," ");
		return textContent.contains(heading);
	}

	public boolean verifyStepNumberAndHeading(String stepNumber, String stepLabel) {
		try {
			return smallWait.get()
					.until(ExpectedConditions.presenceOfElementLocated(
							By.xpath("//*[contains(@class,'circle') and contains(text(),'" + stepNumber
									+ "')]/parent::p/parent::flex-content/following-sibling::flex-content/h2")))
					.getText().trim().contains(stepLabel);
		} catch (Exception e) {
			return false;
		}
	}

	public WebElement verifyGreencheckMarkandHeading(String stepLabel) {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.xpath(
				"//*[@class='complete']//img[contains(@src,'check-mark.png')]/parent::span/parent::p/parent::flex-content/following-sibling::flex-content/h2[contains(text(),'"
						+ stepLabel + "')]")));
	}

	public String getDOBLabel() {
		return smallWait.get()
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//label[@for='piDoB']/p/span"))).getText();
	}

	public String getMemberIdPopUpWindowContent() {
		String memderIdPopUpWindowContent = mediumWait.get().until(ExpectedConditions.visibilityOf(memberIdPopUpWindow))
				.getText();
		return memderIdPopUpWindowContent;
	}

	public WebElement getDoneButtonInMemberIdPopUpWindow() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(doneButtonInMemberIdPopUp));
	}

	public void clickCloseIconInMemberIdPopupWindow() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(closeIconInMemberIdPopUp)).click();
		// small wait to ensure modal closes
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
		}
	}

	public String getPersonalInfoRequiredMessage() {
		String textContent = mediumWait.get().until(ExpectedConditions.visibilityOf(personalInfoRequiredMessage)).getText().trim().replaceAll(String.valueOf((char)160)," ");
		return textContent;
	}

	public boolean verifyMemberIdCardImages(String cardNumber) {
		   if(cardNumber.equals("1"))
		   return mediumWait.get().until(ExpectedConditions.visibilityOf(memberIdCardImage1)).isDisplayed();
		   else if (cardNumber.equals("2"))
		      return mediumWait.get().until(ExpectedConditions.visibilityOf(memberIdCardImage2)).isDisplayed();
		   else
		   return mediumWait.get().until(ExpectedConditions.visibilityOf(memberIdCardImage3)).isDisplayed();
	}

	public WebElement verifyMembershipIdCardImages() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(membershipIdCardImage));
	}

	public void selectRegisterWith(String registerType) {
		mediumWait.get().until(ExpectedConditions.textToBePresentInElement(registerWithDropdown, registerType));
		Select dropdown = new Select(registerWithDropdown);
		dropdown.selectByVisibleText(registerType);
	}

	public WebElement getBSCALogo() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(bscaLogo));
	}

	public WebElement getCloseButtononModal() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(closeIconInMemberIdPopUp));

	}

	public WebElement getBSCAMemberIDCardOnModalDialog() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(bscaMemberIDcardOnModalDialog));
	}

	public WebElement getAccessibilityLink() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(accessibilityPageLoad));
	}

	public WebElement getMemberIDWithGreenCircle() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(memberIDWithGreenCircle));
	}

	public WebElement getBAZLogo() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(bazLogo));
	}

	public WebElement getBAZMemIDImg() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(bazMemIDImg));
	}

	public WebElement getMyUhcMemIDImg() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(myUhcMemIDImg));
	}

	public WebElement getMyUhcDentalIDImg() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(myUhcDentalIDImg));
	}

	public WebElement getPhoneLink(String Pnumber) {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("a[href*='tel:']")));
	}

	public WebElement getBriovaRxLogo() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(briovaRxlogo));
	}

	public boolean verifyIfPrescriptionNumLabelWithTextboxExist() {
		return smallWait.get().until(ExpectedConditions.visibilityOf(briovaRxprescriptionNoTextBox)).isDisplayed();
	}

	public boolean verifyBriovaRxPrescriptionNumImages() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(briovaRxtooltipImg1)).isDisplayed()
				&& mediumWait.get().until(ExpectedConditions.visibilityOf(briovaRxtooltipImg2)).isDisplayed();
	}

	public WebElement getAHCLogo() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(ahcLogo));
	}

	public WebElement getGradientBar(String hexColor1, String hexColor2) {
		return mediumWait.get()
				.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//div[@id='ognheader' and contains(@modeldata,'\"gradientcolor1\" :\"" + hexColor1
								+ "\",\"gradientcolor2\" :\"" + hexColor2 + "\"')]" + "|"
								+ "//div[@id='ognheader' and contains(@modeldata,'\"gradientcolor1\":\"" + hexColor1
								+ "\",\"gradientcolor2\":\"" + hexColor2 + "\"')]")));
	}

	public WebElement getCardholderIdFiel() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(cardholderId));
	}

	public void enterCardholderId(String id) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(cardholderId)).sendKeys(id);
	}

	public WebElement getServeYouLogo() throws Exception {
		/*
		 * ServeYou forgot password page is getting loaded multiple times unexpectedly
		 * due to that ServeYou logo is not being displayed properly on time.
		 * 
		 * Adding 2 seconds hardwait to temporarily resolve the issue until find any
		 * permanent solution
		 * 
		 */
		Thread.sleep(2000);
		return mediumWait.get().until(ExpectedConditions.visibilityOf(serveyouLogo));
	}

	public void clickButtonOnCOPPAPopup(String buttonName) {
		WebElement elem = mediumWait.get().until(ExpectedConditions
				.presenceOfElementLocated(By.xpath("//*[@id='coppa1']//button[contains(.,'" + buttonName + "')]")));
		scrollElementIntoView(elem);
		elem.click();
	}

	public boolean verifyheadercontent(String expectedContent) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(centeralignText)).getText()
				.contains(expectedContent);
	}

	public boolean verifyAarpLogo() {
		return longWait.get().until(ExpectedConditions.visibilityOf(aarpLogo)).isDisplayed();
	}

	public boolean verifyMedicareLogo() {
		return longWait.get().until(ExpectedConditions.visibilityOf(medicareLogo)).isDisplayed();
	}

	public boolean verifyMedicaLogo() {
		return longWait.get().until(ExpectedConditions.visibilityOf(medicaLogo)).isDisplayed();
	}

	public boolean verifyPcpLogo() {
		return longWait.get().until(ExpectedConditions.visibilityOf(pcpLogo)).isDisplayed();
	}

	public boolean verifyRetireeLogo() {
		return longWait.get().until(ExpectedConditions.visibilityOf(retireeLogo)).isDisplayed();
	}

	public void clickPrescriptionNumberToolTipBriovaRx() {
		smallWait.get().until(ExpectedConditions.visibilityOf(toolTipPrescriptionNumberField)).click();
	}

	public void enterEmployeeID(String employeeId) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(employeeIdTextBox));
		employeeIdTextBox.clear();
		employeeIdTextBox.sendKeys(employeeId);
	}

	public WebElement getOptumBankLogo() {
		return longWait.get().until(ExpectedConditions.visibilityOf(optumbankLogo));
	}

	public WebElement getEmployeeIdTextBox() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(employeeIdTextBox));
	}

	public WebElement getRegisterWithLabel() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(registerWithLabel));
	}

	public WebElement getDisneyLogo() {
		return longWait.get().until(ExpectedConditions.visibilityOf(disneyLogo));
	}

	public WebElement getBankAARPLogo() {
		return longWait.get().until(ExpectedConditions.visibilityOf(AARPLogo));
	}

	public WebElement getGroupNumberWithBlueSquare() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(groupNumberWithBlueSquare));
	}
	
	public boolean verifyIfCardholderIdLabelWithTextboxExist() {
		return smallWait.get().until(ExpectedConditions.visibilityOf(cardHolderIdLabelWithTextBox)).isDisplayed();
	}

	public boolean verifyIfOptumLogoBelowGNIsDisplayed() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(optumLogoBelowGN)).isDisplayed();
	}
	
	public boolean verifyIfcareGiverAccessCodeLabelWithTextboxExist() {
		return smallWait.get().until(ExpectedConditions.visibilityOf(careGiverAccessCodeLabelWithTextBox)).isDisplayed();
	}

    public WebElement getBCBSSCLogo() {
		return longWait.get().until(ExpectedConditions.visibilityOf(bcbsscLogo));
    }
	public boolean isPhoneLinkClickable(String Pnumber) {
		try {
			return mediumWait.get().until(ExpectedConditions.elementToBeClickable(By.cssSelector("a[href*='tel:" + Pnumber + "']"))).isDisplayed();
		} catch (Exception e) {
			PageObjectBase.printDebugInformation(e);
			isLocatorFailure.set(true);
			Assert.fail("Error in verifying clickable Phone number link");
			return false;
		}
	}
}
