package com.optum.synergy.reference.ui.utility;

public enum PortalLanguage {
    ENGLISH("English", "en"),
    SPANISH("Spanish", "es");

    private final String name;
    private final String code;

    PortalLanguage(String name, String code) {
        this.name = name;
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public String getCode() {
        return code;
    }
}
