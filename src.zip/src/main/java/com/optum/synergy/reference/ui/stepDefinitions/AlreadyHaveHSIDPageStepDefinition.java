package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.AlreadyHaveHSIDPage;
import com.optum.synergy.reference.ui.utility.DataStorage;

import cucumber.api.java.en.Then;

public class AlreadyHaveHSIDPageStepDefinition {
	private AlreadyHaveHSIDPage page;
	
	public AlreadyHaveHSIDPageStepDefinition() {
		page = new AlreadyHaveHSIDPage();
	}

	@Then("^I should be at Already have HSID sign in page$")
	public void iAmAtAlreadyhaveHSIDSignInPage() {
		Assert.assertTrue("Issue while loading the Already have HSID sign in page", page.verifyIfAlreadyhaveHSIDPageLoaded());
	}
	
	@Then("^I should see the \"([^\"]*)\" label in Already Have HSID Page$")
	public void i_should_see_the_label(String message) {
		iAmAtAlreadyhaveHSIDSignInPage();
		String textContent = page.getContentLabels().getText().trim().replaceAll(String.valueOf((char)160)," ");
		Assert.assertTrue("Expected Content:: "+message+" not found on page",textContent.contains(message));
	}
	
	@Then("^I should see Your username is label on UI$")
	public void i_should_see_your_username_label_on_UI() {
		Assert.assertEquals("Expected label is not found","Your username is", page.getYourUsernameIsLabel().getText());
	}
	
	@Then("^I should see prepopulated username on UI$")
	public void i_should_see_username_on_UI() {
		Assert.assertEquals("Expected username is not found", DataStorage.getUserName().toUpperCase(), page.getPrepopulatedUsername().getText().toUpperCase());
	}
}
