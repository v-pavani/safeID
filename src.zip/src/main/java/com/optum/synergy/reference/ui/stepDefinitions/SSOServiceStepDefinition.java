package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.SSOService;

import cucumber.api.java.en.Then;

public class SSOServiceStepDefinition {
    private SSOService page;

    public SSOServiceStepDefinition() {
        page = new SSOService();
    }

    @Then("^I create Headless ID for \"([^\"]*)\"$")
    public void check(String portalName) {
        int status = page.getSSOServiceStatus(portalName);
        if(!portalName.toUpperCase().equalsIgnoreCase("MYUHC") && !portalName.equals("PHS") && !portalName.equals("MNR"))
        Assert.assertEquals(200, status);
    }

}