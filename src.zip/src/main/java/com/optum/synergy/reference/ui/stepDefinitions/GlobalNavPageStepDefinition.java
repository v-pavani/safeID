package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.GlobalNavPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GlobalNavPageStepDefinition {
	
	private GlobalNavPage page;

	public GlobalNavPageStepDefinition() {
		page = new GlobalNavPage();
	}

	@When("^I click on \"([^\"]*)\" on global nav bar link$")
	public void i_click_on_on_global_nav_bar_link(String arg1) {
		page.clickOnUserMenuDropDown();
	}
	
	@Then("^I should see portal name as \"([^\"]*)\" on global nav bar$")
	public void i_should_see_portal_name_as(String portalName) {
		Assert.assertTrue("Portal name is not displayed", page.getPortalNameonGlobalNav(portalName).isDisplayed());
	}
	
	@Given("^I should see a gradient bar with RGB color codes \"([^\"]*)\" and \"([^\"]*)\"$")
	public void iShouldSeeAGradientBarWithRGBColorCodesAndInRBAPage(String rGBColor1, String rGBColor2) {
		 Assert.assertTrue("Gradient bar not displaying with RGB colors "+rGBColor1+ " and "+rGBColor2, page.getGradientBarElement(rGBColor1, rGBColor2).isDisplayed());
	}
	
	@Then("^I should see \"([^\"]*)\" portal title$")
	public void i_should_see_portal_title(String title) {
		Assert.assertEquals("Portal title "+title+" is not displayed", title, page.getPortalTitle().getText());
	}

	@Given("^I should see a global navigation gradient bar with color \"([^\"]*)\" and \"([^\"]*)\"$")
	public void iShouldSeeAGNGradientBarWithRGB(String rGBColor1, String rGBColor2) {
		Assert.assertTrue("Gradient bar not displaying with RGB colors "+rGBColor1+ " and "+rGBColor2, page.getGradientBarGN(rGBColor1, rGBColor2).isDisplayed());
	}
	
	@Given("^I should see a gradient bar with RGB color codes \"([^\"]*)\" and \"([^\"]*)\" on Signin and secuity page$")
	public void iShouldSeeAGradientBarWithRGBColorCodesonSignInAndSecurityPage(String rGBColor1, String rGBColor2) {
		 Assert.assertTrue("Gradient bar not displaying with RGB colors "+rGBColor1+ " and "+rGBColor2, page.getGradientBarElementforSignAndSecurity(rGBColor1, rGBColor2).isDisplayed());
	}

}
