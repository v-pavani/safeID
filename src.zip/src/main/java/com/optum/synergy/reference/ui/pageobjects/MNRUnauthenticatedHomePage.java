package com.optum.synergy.reference.ui.pageobjects;

import com.optum.synergy.reference.ui.utility.ReadXMLData;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class MNRUnauthenticatedHomePage extends PageObjectBase {


    @FindBy(how = How.CLASS_NAME, using = "uhc-tempo-banner-login__cta")
    private WebElement loginForm;

    public void openAarpHomePage() {
        String page_url = ReadXMLData.getTestData("MNR", "AarpPortalURL");
        openPage(page_url);
    }

    public void openMedicareHomePage() {
        String page_url = ReadXMLData.getTestData("MNR", "MedicarePortalURL");
        openPage(page_url);
    }

    public void openRetireeHomePage() {
        String page_url = ReadXMLData.getTestData("MNR", "RetireePortalURL");
        openPage(page_url);
    }

    public void openMedicaHomePage() {
        String page_url = ReadXMLData.getTestData("MNR", "MedicaPortalURL");
        openPage(page_url);
    }

    public void openPcpHomePage() {
        String page_url = ReadXMLData.getTestData("MNR", "PcpPortalURL");
        openPage(page_url);
    }

    public boolean verifyIfPageLoaded() {
        try {
            waitForPageLoad(driver);
            waitForJavascriptToLoad(10000, 2000);
            return longWait.get().until(ExpectedConditions.visibilityOf((loginForm))).isDisplayed();
        } catch (TimeoutException e) {
            e.printStackTrace();
            return false;
        }
    }
}
