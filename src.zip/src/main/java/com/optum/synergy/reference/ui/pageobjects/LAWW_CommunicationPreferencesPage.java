package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LAWW_CommunicationPreferencesPage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'subnav content')]")
	private WebElement frameContent;

	@FindBy(how = How.CSS, using = "iframe[title='Preferences']")
	private WebElement iframe;

	public void switchToContentFrame() {
		driver.switchTo().frame(mediumWait.get().until(ExpectedConditions.visibilityOf(iframe)));
	}

	public String getContactInformation() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(frameContent)).getText().trim();
	}
}
