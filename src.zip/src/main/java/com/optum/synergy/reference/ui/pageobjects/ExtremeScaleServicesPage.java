package com.optum.synergy.reference.ui.pageobjects;

import java.security.SecureRandom;
import java.security.cert.X509Certificate;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.ws.rs.core.MediaType;

import org.json.JSONObject;
import org.junit.Assert;

import com.optum.synergy.reference.ui.utility.DataStorage;
import com.optum.synergy.reference.ui.utility.ReadXMLData;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class ExtremeScaleServicesPage {

	private Client client;

	public void initiateClient() {
		client = Client.create();
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			public X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			public void checkClientTrusted(X509Certificate[] certs, String authType) {
			}

			public void checkServerTrusted(X509Certificate[] certs, String authType) {
			}
		} };

		// Install the all-trusting trust manager
		try {
			SSLContext sc = SSLContext.getInstance("TLSv1.2");
			sc.init(null, trustAllCerts, new SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		} catch (Exception e) {
			;
		}
	}

	public String getAccessTokenUsingClientTokenService() {
		initiateClient();
		WebResource webResource_clientToken = client.resource(ReadXMLData.getTestData("Services/Layer7Services", "endPoint"));
		String clientId = ReadXMLData.getTestData("Services/Layer7Services/getAuthTokenService/Headers", "client_id");
		String grantType = ReadXMLData.getTestData("Services/Layer7Services/getAuthTokenService/Headers", "grant_type");
		String clientSecrete = ReadXMLData.getTestData("Services/Layer7Services/getAuthTokenService/Headers", "client_secret");

		String path = ReadXMLData.getTestData("Services/Layer7Services/getAuthTokenService","path");
		System.out.println(clientId + "    " + grantType + "    " + clientSecrete);
		String data = "grant_type=" + grantType + "&client_id=" + clientId + "&client_secret=" + clientSecrete;
		ClientResponse response_clientToken = webResource_clientToken.path(path)
				.type("application/x-www-form-urlencoded").accept("application/json").post(ClientResponse.class, data);
		System.out.println(webResource_clientToken.getProperties());
		int status_clientToken = response_clientToken.getStatus();
		Assert.assertEquals(status_clientToken+" is not the expected status",200,status_clientToken);
		String output_clientToken = response_clientToken.getEntity(String.class);
		System.out.println(output_clientToken);
		JSONObject jobj_clientToken = new JSONObject(output_clientToken);
		String auth_token = jobj_clientToken.getString("access_token");
		return auth_token;
	}
	
	

	
	public  int getReponseCodeFromClientTokenService(){
		int status_clientToken =-1;
		try{
			initiateClient();
			WebResource webResource_clientToken = client.resource(ReadXMLData.getTestData("Services/Layer7Services", "endPoint"));
			String clientId = ReadXMLData.getTestData("Services/Layer7Services/getAuthTokenService/Headers", "client_id");
			String grantType = ReadXMLData.getTestData("Services/Layer7Services/getAuthTokenService/Headers", "grant_type");
			String clientSecrete = ReadXMLData.getTestData("Services/Layer7Services/getAuthTokenService/Headers", "client_secret");

			String path = ReadXMLData.getTestData("Services/Layer7Services/getAuthTokenService","path");
			System.out.println(clientId + "    " + grantType + "    " + clientSecrete);
			String data = "grant_type=" + grantType + "&client_id=" + clientId + "&client_secret=" + clientSecrete;
			ClientResponse response_clientToken = webResource_clientToken.path(path)
					.type("application/x-www-form-urlencoded").accept("application/json").post(ClientResponse.class, data);
			status_clientToken = response_clientToken.getStatus();

		} catch(Exception e){
			DataStorage.setCustomErrmsg("Exception in Client service Token:"+ e.toString());
		}

		return status_clientToken;
		 
	}
	
	public JSONObject returnUserDetailsInJsonObjectForm() throws Exception {
		initiateClient();
		String accessToken = getAccessTokenUsingClientTokenService();
		if (!accessToken.isEmpty()) {
			WebResource webResource = client.resource(ReadXMLData.getTestData("Services/ExtremeScale", "endPoint"));
			String data = "{\"cacheId\":\"" + DataStorage.getUUID() + "\"}";
			
			String authorizationToken = ReadXMLData.getTestData("Services/ExtremeScale/getUserDetailsService/Headers","Authorization")+" "+accessToken;
					
			String timeStamp = ReadXMLData.getTestData("Services/ExtremeScale/getUserDetailsService/Headers","timestamp");
			String scope = ReadXMLData.getTestData("Services/ExtremeScale/getUserDetailsService/Headers","scope");
			String actor = ReadXMLData.getTestData("Services/ExtremeScale/getUserDetailsService/Headers","actor");
			String path= ReadXMLData.getTestData("Services/ExtremeScale/getUserDetailsService","path");
			
			ClientResponse response = webResource.path(path)
					.accept(MediaType.APPLICATION_JSON).type(MediaType.APPLICATION_JSON).header("timestamp", timeStamp)
					.header("scope",scope ).header("actor", actor)
					.header("Authorization", authorizationToken)
					.post(ClientResponse.class, data);
			System.out.println(webResource.getProperties());
			int status = response.getStatus();			
			Assert.assertEquals(status+" is not the expected status",200, status);
			String output = response.getEntity(String.class);			
			output = output.replace("[]", "null");
			output = output.replace("[", "");
			output = output.replace("]", "");			

			JSONObject jobj = new JSONObject(output);
			return jobj;
		} else {
			throw new Exception("Access token should not be empty");
		}

	}
	
}
