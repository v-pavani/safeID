package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import com.optum.synergy.reference.ui.utility.ReadXMLData;

public class TCCUnauthenticatedHomePage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//div[@class='loginregistration section']")
	private WebElement loginRegistrationForm;

	@FindBy(how = How.XPATH, using = "//img[contains(@src,'TCC_Logo.png')]"
					+	"|//img[contains(@src,'TCC_color_hor-250px.png')]|//img[contains(@src,'TCC_Logo.jpg')]")
	private WebElement tccLogo;

	public void openTccHomePage() {
		String page_url = ReadXMLData.getTestData("TCC", "AppURL");
		openPage(page_url);
	}

	public boolean isPageLoaded() {
		if (longWait.get().until(ExpectedConditions.visibilityOf((loginRegistrationForm))).isDisplayed()
				&& getTccLogo().isDisplayed()) {
			return true;
		} else
			return false;
	}

	public WebElement getTccLogo() {
		return longWait.get().until(ExpectedConditions.visibilityOf(tccLogo));
	}
}