package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.MyOptumUnauthenticatedHomePage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * Step definition class for MyOptumHomepage unauthenticated page.
 * 
 * @author vchaube1
 *
 */

public class MyOptumUnauthenticatedHomePageStepDefinition {

	private MyOptumUnauthenticatedHomePage page;

	public MyOptumUnauthenticatedHomePageStepDefinition() {
		page = new MyOptumUnauthenticatedHomePage();
	}

	@When("^I am at MyOptumHomepage unauthenticated home page$")
	public void iAmAtMyOptumUnauthenticatedHomePage() {
		page.openMyOptumHomePage();
		Assert.assertTrue("Issue while loading unauthenticated page", page.getSignInContainer().isDisplayed());
	}
	
	@Then("^I should be at MyOptumHomepage unauthenticated home page$") 
	public void iShouldBeAtMyOptumUnauthenticatedHomePage() {
		Assert.assertTrue("Issue while loading unauthenticated page", page.getSignInContainer().isDisplayed());
	}

}
