package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import com.optum.synergy.reference.ui.utility.DataStorage;
import com.optum.synergy.reference.ui.utility.ReadXMLData;

public class BSCAUnauthenticatedHomePage extends PageObjectBase {

	@FindBy(how = How.CLASS_NAME, using = "login_div")
	private WebElement loginForm;
	
	@FindBy(how = How.ID, using = "myuhcLoginForm")
	private WebElement bscaLegacyPage;

	@FindBy(how = How.XPATH, using = "//*[@id='loginWidget']|//*[@id='Login']")
	private WebElement signInWidget;

	public void openBSCAHomePage() {
		String page_url = ReadXMLData.getTestData(DataStorage.getPortalName(), "AppURL");
		openPage(page_url);
	}

	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return longWait.get().until(ExpectedConditions.visibilityOf((loginForm))).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public boolean verifyIfBscaLegacyPageLoaded() {
		try {
			waitForPageLoad(driver);
			return longWait.get().until(ExpectedConditions.visibilityOf((bscaLegacyPage))).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}

	public String getSignInWidgetContent() {
		String textContent = mediumWait.get().until(ExpectedConditions.visibilityOf(signInWidget)).getText().trim().replaceAll(String.valueOf((char)160)," ");
		return textContent;
	}
	
}