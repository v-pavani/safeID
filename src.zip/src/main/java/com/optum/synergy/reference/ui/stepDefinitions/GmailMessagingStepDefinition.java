package com.optum.synergy.reference.ui.stepDefinitions;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.Assert;

import com.optum.synergy.reference.ui.utility.DataStorage;
import com.optum.synergy.reference.ui.utility.ReadEmail;

import cucumber.api.java.en.Then;

public class GmailMessagingStepDefinition {

	
	public GmailMessagingStepDefinition() {
	}
	
	@Then("^I should see a latest unread mail recieved from \"([^\"]*)\" in mail server$")
	public void i_received_the_email_from_server(String mailSubject){
		DataStorage.resetEmail();
		ReadEmail.retrieveMessage(DataStorage.getEmailId(), mailSubject);
		Assert.assertEquals(mailSubject, DataStorage.getEmailSubject());
	}
	
	@Then("^I should see the following content in the mail body$")
	public void iShouldSeeTheFollowingContentInTheMailBody(List<String> contentList) {
		String expectedContent = "";
		
		for(String content:contentList)
		{
			expectedContent=expectedContent+content;
		}
		expectedContent=expectedContent.replace("\"", "");
		
		Assert.assertEquals(expectedContent, DataStorage.getEmailContent().trim());
	}
	
	@Then("^I should see the following content in the mail body along with the username$")
	public void iShouldSeeTheFollowingContentInTheMailBodyAlongWithTheUsername(List<String> contentList) {
		String emailcontent = "";
		
		for(String content:contentList)
		{
			if(content.equals("<AUTO_GENERATED_USERNAME>")){
				emailcontent=emailcontent+" "+ DataStorage.getUserName();
			}
			else{
			emailcontent=emailcontent+" "+content;
			}
		}
		emailcontent=emailcontent.replace("\"", "");
		emailcontent=emailcontent.trim();
		
		Assert.assertEquals(emailcontent, DataStorage.getEmailContent().trim());
	}
	
	@Then("^I should see a latest unread mail recieved from \"([^\"]*)\" in mail server with the following content body for new email$")
	public void iShouldSeeALatestUnreadMailRecievedFromInMailServerWithTheFollowingContentBody(String arg1, List<String> contentList) {
        String newEmailAddress = DataStorage.getEmailId().replace("@", "_new@");
        String msgContent = ReadEmail.getEmailContent(newEmailAddress);
        Assert.assertNotNull(msgContent);
        String emailcontent = "";
		
		for(String content:contentList)
		{
			if(content.equals("<AUTO_GENERATED_USERNAME>")){
				emailcontent=emailcontent+" "+ DataStorage.getUserName();
			}
			else{
			emailcontent=emailcontent+" "+content;
			}
		}
		emailcontent=emailcontent.replace("\"", "");
		emailcontent=emailcontent.trim();
		
		Assert.assertEquals(emailcontent, msgContent);
	}

	@Then("^I should see \"(.*)\" in the confirmation email body$")
	public void iShouldSeeTheInTheMailBody(String emailcontent) {
		String actualEmailContent= DataStorage.getEmailContent().trim();
	   //System.out.println("::DEBUG::Email content:"+actualEmailContent);
		Assert.assertTrue("FAIL, did not find [" + emailcontent + "] in email message body [" + actualEmailContent	+ "]",
				actualEmailContent.contains(emailcontent));
	}
	
	@Then("^I should see a logo image \"([^\"]*)\" in the email content$")
	public void iShouldSeeALogoImageInTheEmailContent(String logoImage) {
		String emailContent= DataStorage.getEmailContent().trim();
		Pattern pattern = Pattern.compile("<img([^>]*?)src([^>]*?)"+logoImage+"[^>]*>");
        Matcher m = pattern.matcher(emailContent);
        int count=0;
        while ( m.find()) {
                            count++;
                 }
        Assert.assertEquals("Failed to find the matching logo Pattern "+pattern+" or there are more than one matching pattern", 1,count);

	}
	
	@Then("^I should see the AUTO_GENERATED_USERNAME in email body$")
	public void iShouldSeeTheAUTO_GENERATED_USERNAMEInEmailBody() {
		String actualEmailContent= DataStorage.getEmailContent().trim();
		String expectedUsername= DataStorage.getUserName();
		Assert.assertTrue("Failed to find Username: "+expectedUsername+" in email content",actualEmailContent.contains(expectedUsername));
	}
	
	@Then("^I set previous emailId to validate the email content$")
	public void iSetPreviousEmailIdToValidateTheEmailContent() {
	    DataStorage.setEmailId(DataStorage.getPreviousEmailId());
	}
}
