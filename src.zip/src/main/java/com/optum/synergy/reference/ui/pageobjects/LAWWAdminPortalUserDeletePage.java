package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LAWWAdminPortalUserDeletePage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//div[text()='Delete Member Account']")
	private WebElement userSearchSection;
	
	@FindBy(how = How.ID, using = "hsid")
	private WebElement optumUserIdTextBox;

	@FindBy(how = How.XPATH, using = "//button[text()='Back']")
	private WebElement topBackButton;

	@FindBy(how = How.XPATH, using = "//button[text()='Search Member to Delete']")
	private WebElement searchUserToDeleteButton;
	
	@FindBy(how = How.XPATH, using = "//button[text()='Confirm Delete']")
	private WebElement confirmDeleteButton;

	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(userSearchSection)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public void enterOptumUserId(String optumId) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(optumUserIdTextBox));
		optumUserIdTextBox.sendKeys(optumId);
	}
	
	public void clickTopBackButton() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(topBackButton));
		topBackButton.click();
	}

	public void clickSearchUserToDeleteButton() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(searchUserToDeleteButton));
		searchUserToDeleteButton.click();
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmDeleteButton));
		confirmDeleteButton.click();
	}

}
