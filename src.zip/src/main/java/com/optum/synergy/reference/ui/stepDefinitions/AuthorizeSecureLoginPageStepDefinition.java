package com.optum.synergy.reference.ui.stepDefinitions;

import com.optum.synergy.reference.ui.pageobjects.AuthorizeSecureLoginPage;
import com.optum.synergy.reference.ui.pageobjects.ConfirmYourIdentityPage_securityQuestions;
import com.optum.synergy.reference.ui.utility.DataStorage;
import com.optum.synergy.reference.ui.utility.ReadEmail;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class AuthorizeSecureLoginPageStepDefinition {
	private AuthorizeSecureLoginPage page;

	public AuthorizeSecureLoginPageStepDefinition() {
		page = new AuthorizeSecureLoginPage();
	}

	@Given("^I manage the Authorize Secure Login page with Access code$")
	public void iManageTheAuthorizeSecureLoginPageWithAccessCode() throws Throwable {
		if (page.verifyAuthorizeSecurityPageLoaded()) {
			page.switchToFrameByNameOrId(page.getSecureLoginFrameID());
			page.clickAlternateEmailButton();
			String secureCode = ReadEmail.getAccesscodeForLegacyID(DataStorage.getUserName());
			if (secureCode != null) {
				page.enterSecureCodeInput(secureCode);
				page.clickAuthSubmitButton();
			} else
				System.out.println("Secure code not received in 30 seconds.");
		}
	}
	
	@When("^I manage the Authorize Secure Login page with security question$")
	public void i_manage_the_Authorize_Secure_Login_page_with_security_question() throws Throwable {
		//TODO: Should eventually remove this step Def and have feature files explicitly handle 
		//  potential landing on security question page.  For now, keep (for backward compatibility 
		//	with existing feature files) with simpler handling
		ConfirmYourIdentityPage_securityQuestions confirmIdentityPage = new ConfirmYourIdentityPage_securityQuestions();
		if ( confirmIdentityPage.verifyIfPageLoadedSQA() ) {
			confirmIdentityPage.handleSecurityQuestionWithAnswer();	// Fill in default security question answer, click continue			
		}

	}
}
