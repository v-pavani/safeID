package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;
import com.optum.synergy.reference.ui.pageobjects.PHSUnauthenticatedHomePage;
import com.optum.synergy.reference.ui.pageobjects.Registration_PersonalInformationSectionPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class PHSUnauthenticatedHomePageStepDefinition {

	private PHSUnauthenticatedHomePage page;

	public PHSUnauthenticatedHomePageStepDefinition() {
		page = new PHSUnauthenticatedHomePage();
	}

	@Given("^I am at PHS unauthenticated home page$")
	public void i_am_at_PHP_unauthenticated_home_page() {
		page.openPHSHomePage();
		Assert.assertTrue("Issue while loading the PHS Unauthenticated page", page.isPageLoaded() && new Registration_PersonalInformationSectionPage().verifyUhcLogo());
	}
	
	@Then("^I should be at PHS unauthenticated home page$")
	public void iShouldBeAtPHSUnauthenticatedHomePage() {
		Assert.assertTrue("Issue while loading the PHP Unauthenticated page", page.isPageLoaded() && new Registration_PersonalInformationSectionPage().verifyUhcLogo() && page.findLinkText("Sign In"));
	}
	
	@Then("^I should see Use your HSID to Sign In label$")
	public void i_should_see_Use_your_HSID_to_Sign_In_label() {
		Assert.assertTrue("Use your HSID to Sign In label is not visible", page.verifyIfUseYourHSIDToSignInLabelIsDisplayed());
	}

	@Then("^I should see New to HSID label$")
	public void i_should_see_New_to_HSID_label() {
		Assert.assertTrue("New to HSID label is not visible", page.verifyIfNewToHSIDLabelIsDisplayed());
	}
	
	@Given("^I should be at PHSOptum unauthenticated home page$")
	public void i_should_be_at_PHSOptum_unauthenticated_homepage() {
		Assert.assertTrue("Issue while loading the PHSOptum Unauthenticated page", page. isPageLoaded () && new Registration_PersonalInformationSectionPage().VerifyOptumLogo());
	}

	@Given("^I am at PHSOptum unauthenticated home page$")
	public void i_am_at_PHSOptum_unauthenticated_home_page() {
		page.openPHSOptumHomePage();
		Assert.assertTrue("Issue while loading the PHSOptum Unauthenticated page", page.isPageLoaded() && new Registration_PersonalInformationSectionPage().VerifyOptumLogo());
	}	
	
}
