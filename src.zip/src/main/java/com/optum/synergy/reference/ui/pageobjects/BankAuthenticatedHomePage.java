package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class BankAuthenticatedHomePage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//*[@id='tutorial-dashboard-step1']//h2[contains(text(),'Accounts')]|//*[@id='tutorial-dashboard-step1']//h3[contains(text(),'Accounts')]")
	private WebElement accountWidget;

	@FindBy(how = How.XPATH, using = "//h1[contains(text(),'Security Question')]")
	private WebElement SecurityVerification;	
        
    @FindBy(how = How.ID, using = "account-number")
	private WebElement AccNumber;

	@FindBy(how = How.XPATH, using = "//h1[contains(text(),'Terms & Conditions')]")
	private WebElement termsAndConditionsPage;

	@FindBy(how = How.XPATH, using = "//div[@class='shepherd-text']")
	private WebElement takeTheTourPopUp;

	@FindBy(how = How.XPATH, using = "//div[@id='tour-backdrop-close-btn']")
	private WebElement closeTakeTheTourButton;
		
	public boolean isPageLoaded() {
		return longWait.get().until(ExpectedConditions.visibilityOf((accountWidget))).isDisplayed();
	}

	public boolean verifyIfDisneyAuthPageIsDisplayed() {
		waitForPageLoad(driver);
		waitForJavascriptToLoad(100000, 10000);
		return  (isPageLoaded() && driver.getCurrentUrl().contains("disney"));
	}
	
	public boolean verifyIfUHCHAAuthPageIsDisplayed() {
		waitForPageLoad(driver);
		waitForJavascriptToLoad(10000, 10000);
		return (isPageLoaded() && driver.getCurrentUrl().contains("uhchealthaccounts"));
	}
	
	public boolean verifyIfUHCRAAuthPageIsDisplayed() {
		waitForPageLoad(driver);
		waitForJavascriptToLoad(10000, 10000);
		return (isPageLoaded() && driver.getCurrentUrl().contains("uhcretireeaccounts"));
	}
	
 	public boolean verifyIfBankAuthPageIsDisplayed() {
		waitForPageLoad(driver);
		waitForJavascriptToLoad(10000, 10000);
		return (isPageLoaded() && driver.getCurrentUrl().contains("optumbank"));
	}
 	
 	public boolean verifyBankAARPAuthenticatedPageDisplayed() {
		try {
			boolean isAuthPageDisplayed = isPageLoaded();
			boolean isLogoDisplayed = mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.xpath("//img[contains(@src,'aarp-logo')]"))).isDisplayed();
			return  isAuthPageDisplayed && isLogoDisplayed;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public void enterAccNumber(String accnum) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(AccNumber));
		AccNumber.clear();
		AccNumber.sendKeys(accnum);
	}
	
	public boolean verifyBankSecurityVerificationPageLoaded() {
		try {
		return longWait.get().until(ExpectedConditions.visibilityOf(SecurityVerification)).isDisplayed();
		}
		catch(Exception e){
			return false;
		}
	}

	public boolean verifyBankTermsAndConditionsPageLoaded() {
		try {
			return mediumWait.get().until(ExpectedConditions.visibilityOf(termsAndConditionsPage)).isDisplayed();
		}
		catch(Exception e){
			return false;
		}
	}

	public boolean verifyTakeTheTourPageLoaded() {
		try {
			return mediumWait.get().until(ExpectedConditions.visibilityOf(takeTheTourPopUp)).isDisplayed();
		}
		catch(Exception e){
			return false;
		}
	}

	public void clickTakeTheTourCloseButton() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(closeTakeTheTourButton)).click();
	}
}
