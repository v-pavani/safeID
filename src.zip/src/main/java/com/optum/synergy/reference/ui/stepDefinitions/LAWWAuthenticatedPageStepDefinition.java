package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.StaleElementReferenceException;

import com.optum.synergy.reference.ui.pageobjects.ConfirmYourIdentityPage_securityQuestions;
import com.optum.synergy.reference.ui.pageobjects.LAWWAuthenticatedPage;

import cucumber.api.java.en.Then;

public class LAWWAuthenticatedPageStepDefinition {
	private LAWWAuthenticatedPage page;
	
	public LAWWAuthenticatedPageStepDefinition() {
		page = new LAWWAuthenticatedPage();
	}
	
	@Then("^I should be at LAWW Authenticated page$")
	public void i_should_be_at_LAWW_Authenticated_page() {
		Assert.assertTrue("Issue while loading the LAWW authenticated page GlobalNav", page.verifyIfUserMenuDisplayedOnGlobalNav());
	}

	@Then("^I should landed into Authenticated LAWW Home Page$")
	public void i_should_landed_into_Authenticated_LAWW_Home_Page() throws Throwable {
		//NOTE: Moved from CommonStepDefinitions
		
		//TODO: Should eventually remove this step Def and have feature files explicitly handle 
		//  potential landing on security question page.  For now, keep (for backward compatibility 
		//	with existing feature files) with simpler handling
		ConfirmYourIdentityPage_securityQuestions confirmIdentityPage = new ConfirmYourIdentityPage_securityQuestions();
		if ( confirmIdentityPage.verifyIfPageLoadedSQA() ) {
			try{
			confirmIdentityPage.handleSecurityQuestionWithAnswer();	// Fill in default security question answer, click continue
			}catch(StaleElementReferenceException e){
				confirmIdentityPage.handleSecurityQuestionWithAnswer();// re attempt to enter security answers , incase of stalement exception
			}
		}
 		i_should_be_at_LAWW_Authenticated_page();
	}

    @Then("^I manage the LAWW EAP Pop Up$")
    public void iManageTheLAWWEAPPopUp() {
		if(page.verifyEAPPopUpDisplayed()) {
			page.clickElementById("closebtn");
		}
	}
}
