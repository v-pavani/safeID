package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

public class LAWWUserLoginAccessCodePage extends PageObjectBase{
        
        @FindBy(how = How.CLASS_NAME, using = "accesscode-content")
        private WebElement accessCodeEnteringSection;

        @FindBy(how = How.ID, using = "accesscode--company--selection")
        private WebElement accessCodeCompanyDropdown;
        
        public boolean verifyIfPageLoaded() throws InterruptedException {
        	try {
	        	waitForPageLoad(driver);
	        	Thread.sleep(3000);
	        	waitForJavascriptToLoad(15000, 3000);
	        	return mediumWait.get().until(ExpectedConditions.visibilityOf(accessCodeEnteringSection)).isDisplayed();
        	} catch (TimeoutException e) {
    			return false;
    		}
        }
        
        public void selectProviderFromMyBenefitsAreProvidedThroughList(String accessCodeCompany) {
                Select dropdown = new Select(mediumWait.get().until(ExpectedConditions.visibilityOf(accessCodeCompanyDropdown)));
                dropdown.selectByVisibleText(accessCodeCompany);
        }
        
        public void clickOnContinueButton() {
        	WebElement continueButton = longWait.get().until(ExpectedConditions.presenceOfElementLocated(By.id("accesscode--button")));
        	scrollElementIntoView(continueButton);
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click();", continueButton);
        }
}	