package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.LAWW_CommunicationPreferencesPage;

import cucumber.api.java.en.Then;

public class LAWW_CommunicationPreferencesPageStepDefinition {
	
	private LAWW_CommunicationPreferencesPage page;
	public LAWW_CommunicationPreferencesPageStepDefinition() {
		page=new LAWW_CommunicationPreferencesPage();
	}
	
	@Then("^I should see the \"([^\"]*)\" label in communication preferences page$")
	public void iShouldSeeTheLabelInCommunicationPreferencesPage(String label) throws Throwable {
		Thread.sleep(5000);
		page.switchToContentFrame();
		Assert.assertEquals(true,page.getContactInformation().contains(label));
		page.switchToDefaultContent();
	}
}
