package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class RxAuthenticatedHomePage extends PageObjectBase {


	@FindBy(how = How.XPATH, using = "//h1[contains(text(),'Your Medicine Cabinet')]|//h1[contains(text(),'My Medicine Cabinet')]|//*[@id='My prescriptions']")
	private WebElement myMedicineCabinetHeader;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'hidden-xs')]//h1[contains(text(),'My  caregiver access')]")
	private WebElement myCaregiverAccessHeader;

	@FindBy(how = How.XPATH, using = "//div[@class='btn btn-primary' and contains(.,'Go to Medicine Cabinet')]")
	private WebElement gotoMedicineCabinetButton;
	
	@FindBy(how = How.XPATH, using = "//*[@id='shoppingCartDiv']")
	private WebElement shoppingCart;
	
	@FindBy(how = How.ID, using = "newRxTransferBtn")
	private WebElement rxAddPrescriptionButton;

	public boolean verifyIfHomePageContentIsDisplayed() {
		waitForPageLoad(driver);
		waitForJavascriptToLoad(15000, 5000);
		try {
			mediumWait.get()
					.until(ExpectedConditions
							.visibilityOfElementLocated(By.xpath("//*[starts-with(@class,'QSIPopOver SI')]//div[2]")))
					.click();
		} catch (Exception e) {
		}
		mediumWait.get().until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("div.uioverlay")));
		return mediumWait.get().until(ExpectedConditions.visibilityOf(myMedicineCabinetHeader)).isDisplayed();
	}

	public boolean verifyIfCaregiverHomePageContentIsDisplayed() {
		waitForPageLoad(driver);
		waitForJavascriptToLoad(15000, 5000);
		longWait.get().until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("div.uioverlay")));
		try {
			mediumWait.get()
					.until(ExpectedConditions
							.visibilityOfElementLocated(By.xpath("//*[starts-with(@class,'QSIPopOver SI')]//div[2]")))
					.click();
		} catch (Exception e) {
		}
		return mediumWait.get().until(ExpectedConditions.visibilityOf(myCaregiverAccessHeader)).isDisplayed();
	}

	public boolean isGotoMedicineCabinetButtonDisplayed() {
		try {
			return longWait.get().until(ExpectedConditions.visibilityOf(gotoMedicineCabinetButton)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}

	public void clickOnGotoMedicineCabinetButton() {
		longWait.get().until(ExpectedConditions.visibilityOf(gotoMedicineCabinetButton)).click();
	}
	
	public WebElement getShoppingCart() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(shoppingCart));
	}
	
	public WebElement getRxAddPrescriptionButton() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(rxAddPrescriptionButton));
	}
}