package com.optum.synergy.reference.ui.stepDefinitions;

import java.util.List;

import com.optum.synergy.reference.ui.pageobjects.PageObjectBase;
import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.RecoverYourUsernamePage;
import com.optum.synergy.reference.ui.utility.DataStorage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RecoverYourUsernamePageStepDefinition {
	private RecoverYourUsernamePage page;
	
	public RecoverYourUsernamePageStepDefinition() {
		page = new RecoverYourUsernamePage();
	}

	@Then("^I should be at Recover your username page$")
	public void i_should_be_at_Recover_your_username_page() {
		Assert.assertTrue("Issue While loading the Recover your username page", page.verifyIfPageLoaded());
	}
	
	@Then("^I should see a Email associated with your account label with text box$")
	public void i_should_see_a_Email_associated_with_your_account_label_with_text_box() {
	    Assert.assertTrue("Issue while displaying Email associated with your account label with text box", page.verifyIfemailassociatedwithyouraccountLabelWithTextBoxExist());
	}
	
	@Then("^I should see an error message \"([^\"]*)\" on recover your username page$")
	public void iShouldSeeAnErrorMessageOnRecoverYourUsernamePage(String errMsg)
			throws Throwable {
		Assert.assertEquals(
				"\""
						+ errMsg
						+ "\""
						+ " error message is not displaying on Recover Your Username page",
				errMsg, page.recoverYourUsernameTopErrorMessage());
	}

	@Then("^I should see the header as \"([^\"]*)\" on Recover Username page$")
	public void i_should_see_the_header_On_Recover_Username_Page(String formHeading) {
	  Assert.assertEquals("Heading is displayed at Recover Your Username Page", formHeading, page.getFormHeaderOnRecoverUserNamePage());
	}
	
	@Then("^I should see the sub header as \"([^\"]*)\" on Recover Username page$")
	public void i_should_see_the_sub_header_On_Recover_Username_Page(String formSubHeading) {
	  Assert.assertEquals("Text is not displayed in sub header of Recover Your Username Page", formSubHeading, page.getFormSubHeaderOnRecoverUserNamePage());
	}
	
	@Then("^I should see a Home Icon$")
	public void i_should_see_a_Home_Icon() {
	    Assert.assertTrue("Issue while displaying Home Icon", page.getWebElementforHomeIcon().isDisplayed());
	}
	
	@Then("^I should see the following content in Need help section$")
	public void iShouldSeeTheFollowingContentInNeedHelpSection(List<String> contentList) {
		for (String content : contentList) {
			content = content.trim();
			if("LAWW".equalsIgnoreCase(DataStorage.getPortalName())){
				String content1 = PageObjectBase.getAEMContent(DataStorage.getPortalName(), "PageContent", content);
				content1 = content1.trim();

				boolean status = page.getNeedHelpContent().contains(content1);

				if(!status) {
					new PageObjectBase().isContentFailure.set(true);
					Assert.fail("Expected Need help content not found on web page: "+content1);
				}
			}else {
				Assert.assertTrue("\"" + content + "\" content is not displaying in the Need Help section",
						page.getNeedHelpContent().contains(content));
			}
		}
	}

	@Then("^I enter valid FirstName into First name field on recover username page$")
	public void i_enter_valid_FirstName_into_First_name_field() {
		page.enterFirstName(DataStorage.getFirstName());
	}
	
	@Then("^I enter valid LastName into Last name field on recover username page$")
	public void i_enter_valid_LastName_into_Last_name_field() {
		page.enterLastName(DataStorage.getLastName());
	}
	
	@Then("^I enter valid DOB into Date of birth field on recover username page$")
	public void i_enter_valid_DOB_into_Date_of_birth_field() throws InterruptedException {
		page.enterDateOfBirth(DataStorage.getDOB());
	}
	
	@Then("^I enter valid email into Email field on recover username page$")
	public void i_enter_valid_email_into_Email_field() {
		page.enterEmail(DataStorage.getEmailId());
	}
	
	@Then("^I should see the following error message on Recover your username form$")
	public void i_should_see_the_following_error_message_On_Recover_your_username_form(List<String> contents) {
		for (String content : contents) {
			Assert.assertTrue(content + " does not exist on Recover your username form", page.getErrorMessageElement().getText().contains(content));
		}
	}

	@Then("^I click on \"([^\"]*)\" partial link in Need Help section$")
	public void i_click_on_partial_link_in_need_help_section(String link){
		page.clickPartialLinkInNeedHelpSection(link);
	}
}
