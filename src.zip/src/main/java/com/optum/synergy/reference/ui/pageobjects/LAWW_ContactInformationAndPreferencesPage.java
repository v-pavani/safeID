package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LAWW_ContactInformationAndPreferencesPage extends PageObjectBase {

	public WebElement getLink(String link) {
		return mediumWait.get().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a/span[contains(.,'" + link + "')]")));
	}
}