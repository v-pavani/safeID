package com.optum.synergy.reference.ui.pageobjects;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class SignInPage extends PageObjectBase {

    @FindBy(how = How.XPATH, using = "//div[@class='logout']")
    private WebElement signOut;

    @FindBy(how = How.XPATH, using = "//input[@id='EMAIL']" + "|//input[@id='hsid-username']"
            + "|//input[@id='hsid-wdgt-username']" + "|//input[@id='username']")
    private WebElement userNameTextBox;

    @FindBy(how = How.XPATH, using = "//input[@id='PASSWORD']"
            + "|//input[@id='hsid-password']"
            + "|//input[@id='hsid-wdgt-password']"
            + "|//input[@id='password']"
            + "|//input[@name= 'password']")
    private WebElement passwordTextBox;

    @FindBy(how = How.XPATH, using = "//span[contains(@class,'strong') and contains(.,'Username or email address')]/following-sibling::input[@id='EMAIL']"
            + " | //span[@class='strong ng-binding' and contains(.,'Username')]/../following-sibling::input[@id='EMAIL']|//span[@class='strong ng-binding' and contains(.,'Username')]/following-sibling::input[@id='EMAIL']"
            + " | //span[@class='strong' and contains(.,'Username')]/following-sibling::input[@id='hsid-wdgt-username']"
            + "	|//span[@id='hsid-usernameLabel' and contains(.,'Username')]/following-sibling::input[@id='hsid-username']")
    private WebElement usernameOrEmailAddressLabelWithTextbox;

    @FindBy(how = How.XPATH, using = "//label[@for='PASSWORD']/*[contains(@class,'strong') and contains(.,'Password')]/../following-sibling::div/input[@id='PASSWORD']"
            + "	|//span[@id='hsid-passwordLabel' and contains(.,'Password')]/following-sibling::input[@id='hsid-password']"
            + "	|//span[@id='hsid-wdgt-passwordLabel' and contains(.,'Password')]/following-sibling::input[@id='hsid-wdgt-password']")
    private WebElement passwordLablelWithTextbox;

    @FindBy(how = How.XPATH, using = "//*[contains(@class,'ng-scope')]" + "|//*[@id='hsid-wdgt-commonError']"
            + "	|//*[@id='helpToolTipId'] " + "	|//*[@name='personalInfo']" + "|//div[contains(@class,'col-md-12')]" +"|//div[@id='verifyLogin_page']|//h3[@class='is-rds-h6']/../p" + "|//*[@id='page-heading']/span")
    private WebElement verifyLabel;

    @FindBy(how = How.XPATH, using = "//*[contains(@class,'ng-scope')]" + "|//*[@id='hsid-wdgt-commonError']"
            + "	|//*[@id='helpToolTipId'] " + "	|//*[@name='personalInfo']|//*[@id='root']|//*[@id='phoneDetails']|//*[@id='warningTextPageExpire']|//*[@id='warningText']|//input[@id='phoneTextNumber']|//input[@id='phoneCallNumber']|//*[contains(@class,'Text_root')]/span")
    private WebElement verifyLabelOnSignSec;


    @FindBy(how = How.XPATH, using = "//img[contains(@src,'logo_laww.gif')]")
    private WebElement lawwbrandlogo;

    @FindBy(how = How.XPATH, using = "//*[@id='global-profile-container']//a|//*[@id='profileDropdown']|//*[@id='usermenu']/a|//*[@id='profile-menu']")
    private WebElement Usermenu;

    @FindBy(how = How.XPATH, using = "//*[@id='accessCode' or @id='verifyAuthPasscodeInput']|.//*[@id='confirmCode']")
    private WebElement accessCode;

    @FindBy(how = How.XPATH, using = "//div[@class='ng-binding']/p" + "|//div[@id='hsid-commonError']/p"
            + "|//*[@id='Login']//span[contains(@ng-bind-html,'SigninEmailConfirmed')]"
            + "|//p[@ng-if='isPageMessageExistent()']" + "|//p[@ng-if='pageMessages.message']"
            + "|//*[@id='hsid-wdgt-commonError']"
            + "|//div[(@id='signinBanner')and contains(@class,'Banner_container__34yhq')]")
    private WebElement confirmationMessage;

    @FindBy(how = How.XPATH, using = "//*[@class='mb30 ng-scope' or @class='mb20']//h1")
    private WebElement firstNameFromHeader;

    @FindBy(how = How.ID, using = "authoobWrapper")
    private WebElement confirmIdentity;

    @FindBy(how = How.XPATH, using = "//*[@id='authQuestionWrapper']|//*[@id='authoobWrapper']")
    private WebElement alertMessage;

    @FindBy(how = How.XPATH, using = "//*[@id='authQuestionWrapper']/div[1]/p|//*[@id='authoobWrapper']/div[1]/p")
    private WebElement secureMessage;

    @FindBy(how = How.XPATH, using = "//div[@class='authQuestionAnswerBox']")
    private WebElement securityAnswerTextField;

    @FindBy(how = How.XPATH, using = "//*[@id='authQuestiontextLabelId']|//*[@id='Q10.1_container']|//*[@id='Q10.2_container']|//*[@id='Q10.3_container']")
    private WebElement SecurityLabel;

    @FindBy(how = How.XPATH, using = "//*[@id='Login']//span[starts-with(@ng-bind-html,'pageTopError')]"
            + "|//*[@id='hsid-wdgt-commonError']|//span[starts-with(@ng-if,'pageTopError')]|//span[contains(text(),'account has been locked')]|//*[@id='pageErrors']|//*[@id='hsid-commonError']|//p[@ng-if='pageMessages.message']")
    private WebElement errorMsg;

    @FindBy(how = How.XPATH, using = "//span[@class='icon-alert_filled error']/following-sibling::span[contains(@ng-if,'errElementId')]")
    private WebElement errorMsgAccountLock;

    @FindBy(how = How.XPATH, using = "//input[@id='EMAIL']/../span[@class='error']/span"
            + "|//span[@id='hsid-wdgt-usernameError']" + "|//span[@id='hsid-usernameError']")
    private WebElement errmsg_userName;

    @FindBy(how = How.XPATH, using = "//label[@for='PASSWORD']//div[contains(@class,'error')]"
            + "|//span[@id='hsid-wdgt-passwordError']" + "|//span[@id='hsid-passwordError']" + "|//div[text()='Password is required']")
    private WebElement errmsg_pwd;

    @FindBy(how = How.CLASS_NAME, using = "password-show-icon")
    private WebElement showPasswordEyeIcon;

    @FindBy(how = How.XPATH, using = "//*[@name='rememberMe']|//*[@id='remembermydevice']|//*[@id='rememberMe']")
    private WebElement rememberMeCheckBox;

    @FindBy(how = How.XPATH, using = "//*[@for='hsid-wdgt-rememberMe']"
            + "|//*[@for='rememberMe']"
            + "|//*[@for='hsid-rememberMe']"
            + "|//*[@for='remembermydevice']")
    private WebElement rememberMeLabel;

    @FindBy(how = How.XPATH, using = "//*[@id='EMAIL']|//*[@id='hsid-username']|//*[@id='hsid-wdgt-username']")
    private WebElement userNameTextBoxMasked;

    @FindBy(how = How.XPATH, using = "//*[@id='signIn_page']|//*[@id='Login']")
    private WebElement HSIDSignInPage;

    public boolean securityAnswerLabel() {
        return SecurityLabel.isDisplayed();
    }

    public boolean securityAnswerTextField() {
        return securityAnswerTextField.isDisplayed();
    }

    public void clickRememberMeCheckBox() {
        mediumWait.get().until(ExpectedConditions.visibilityOf(rememberMeLabel)).click();
    }

    public boolean verifyForRememberMeCheckBoxSelected() {
        return rememberMeCheckBox.isSelected();
    }

    public WebElement getUserNameTextBoxMasked() {
        return mediumWait.get().until(ExpectedConditions.visibilityOf(userNameTextBoxMasked));
    }

    public boolean verifyForRememberMeCheckBoxDisplayed() {
        return mediumWait.get().until(ExpectedConditions.visibilityOf(rememberMeLabel)).isDisplayed();
    }

    public WebElement getSignInErrorMessage() {
        try {
            return mediumWait.get().until(ExpectedConditions.visibilityOf(errorMsg));
        } catch (StaleElementReferenceException e) {
            return mediumWait.get().until(ExpectedConditions.visibilityOf(errorMsg));
        }
    }

    public WebElement getAccountLockErrorMessage() {
        waitForPageLoad(driver);
        waitForJavascriptToLoad(30000, 5000);
        return longWait.get().until(ExpectedConditions.visibilityOf(errorMsgAccountLock));
    }

    public boolean verifysecureMessage(String message) {
        mediumWait.get().until(ExpectedConditions.visibilityOf(secureMessage));
        String actualText = secureMessage.getText().trim().replaceAll(String.valueOf((char)160)," ");
        actualText = StringUtils.normalizeSpace(actualText);
        return actualText.contains(message);
    }

    public boolean verifyConfirmIdentity(String message) {
        mediumWait.get().until(ExpectedConditions.visibilityOf(confirmIdentity));
        return confirmIdentity.getText().contains(message);
    }

    public boolean verifyAlertMessage(String message) {
        mediumWait.get().until(ExpectedConditions.visibilityOf(alertMessage));
        return alertMessage.getText().contains(message);
    }

    public void enterAccessCode(String text) {
        waitForPageLoad(driver);
        waitForJavascriptToLoad(30000, 2000);
        mediumWait.get().until(ExpectedConditions.visibilityOf(accessCode));
        accessCode.clear();
        accessCode.sendKeys(text);
    }

    public boolean verifyForConfimationMessage(String message) {
        mediumWait.get().until(ExpectedConditions.visibilityOf(confirmationMessage));
        return confirmationMessage.getText().contains(message);
    }

    public void userMenuClick() {
        waitForPageLoad(driver);
        waitForJavascriptToLoad(10000, 500);
        longWait.get().until(ExpectedConditions.visibilityOf(Usermenu)).click();
    }

    public void clickImg() {
        mediumWait.get().until(ExpectedConditions.visibilityOf(lawwbrandlogo)).click();
    }

    public String getFirstNameFromPageHeader() {
        return mediumWait.get().until(ExpectedConditions.visibilityOf(firstNameFromHeader)).getText();
    }

    public boolean verifyContentLabel(String message) {
        waitForPageLoad(driver);
        waitForJavascriptToLoad(5000, 250);
        String textContent = verifyLabel.getText().trim().replaceAll(String.valueOf((char) 160), " ");
        return textContent.contains(message);
    }

    public void enterUserName(String username) {
        try {
            mediumWait.get().until(ExpectedConditions.visibilityOf(userNameTextBox));
            userNameTextBox.clear();
            userNameTextBox.sendKeys(username);
        } catch (StaleElementReferenceException e) {
            mediumWait.get().until(ExpectedConditions.visibilityOf(userNameTextBox));
            userNameTextBox.clear();
            userNameTextBox.sendKeys(username);
        }
    }

    public void enterPassword(String password) {
        try {
            mediumWait.get().until(ExpectedConditions.visibilityOf(passwordTextBox));
            passwordTextBox.clear();
            passwordTextBox.sendKeys(password);
        } catch (StaleElementReferenceException e1) {
            mediumWait.get().until(ExpectedConditions.visibilityOf(passwordTextBox));
            passwordTextBox.clear();
            passwordTextBox.sendKeys(password);
        }
    }

    public String getPasswordType() {
        return mediumWait.get().until(ExpectedConditions.visibilityOf(passwordTextBox)).getAttribute("type");
    }

    public WebElement getPasswordTextBox() {
        return mediumWait.get().until(ExpectedConditions.visibilityOf(passwordTextBox));
    }

    public boolean verifyIfUsernameOrEmailAddressLabelExistWithTextbox() {
        return mediumWait.get().until(ExpectedConditions.visibilityOf(usernameOrEmailAddressLabelWithTextbox))
                .isDisplayed();
    }

    public boolean verifyPasswordLableExistWithTextbox() {
        return mediumWait.get().until(ExpectedConditions.visibilityOf(passwordLablelWithTextbox)).isDisplayed();
    }

    public String getErrorMsgForUserNamefield() {
        try {
            return smallWait.get().until(ExpectedConditions.visibilityOf(errmsg_userName)).getText();
        } catch (Exception e) {
            return null;
        }
    }

    public String getErrorMsgForPasswordfield() {
        try {
            return smallWait.get().until(ExpectedConditions.visibilityOf(errmsg_pwd)).getText();
        } catch (Exception e) {
            return null;
        }
    }

    public void clickShowPasswordButton() {
        mediumWait.get().until(ExpectedConditions.visibilityOf(showPasswordEyeIcon)).click();
    }

    public boolean verifyVisualIndicator(String linkName) {
        return mediumWait.get().until(ExpectedConditions.visibilityOfElementLocated(By.xpath(("//a[contains(.,'" + linkName + "')]/i[@class='icon-new_window']")))).isDisplayed();
    }

    public String getUserNameFieldValue() {
        try {
            return mediumWait.get().until(ExpectedConditions.visibilityOf(userNameTextBox)).getAttribute("value");
        } catch (Exception e) {
            return null;
        }
    }

    public boolean isSignoutPageLoaded() {
        return longWait.get().until(ExpectedConditions.visibilityOf((signOut))).isDisplayed();
    }

    public boolean isHSIDSignPageDisplayed() {
        try {
            boolean hsidLogin = mediumWait.get().until(ExpectedConditions.visibilityOf(HSIDSignInPage)).isDisplayed();
            return hsidLogin;
        } catch (StaleElementReferenceException e) {
            boolean hsidLogin = mediumWait.get().until(ExpectedConditions.visibilityOf(HSIDSignInPage)).isDisplayed();
            return hsidLogin;
        }
    }
    //To check new ui labels on Sign in Security page
    public String getContentLabel() {
        waitForPageLoad(driver);
        waitForJavascriptToLoad(5000, 250);
        String text = verifyLabelOnSignSec.getText().replaceAll("\\r\\n|\\r|\\n", " ").replaceAll(String.valueOf((char)160)," ");
        text = StringUtils.normalizeSpace(text);
        return text;
    }
}
