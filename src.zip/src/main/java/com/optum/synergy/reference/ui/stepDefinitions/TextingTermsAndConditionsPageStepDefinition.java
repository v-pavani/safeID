package com.optum.synergy.reference.ui.stepDefinitions;

import java.util.List;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.TextingTermsAndConditionsPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class TextingTermsAndConditionsPageStepDefinition {

	private TextingTermsAndConditionsPage page;
	public static final String URL = "https://healthsafeid.optum.com/content/pages/default/TextingTerms?HTTP_LANGUAGE=EN";

	TextingTermsAndConditionsPage textingPage = new TextingTermsAndConditionsPage();

	public TextingTermsAndConditionsPageStepDefinition() {
		page = new TextingTermsAndConditionsPage();
	}

	@Then("^I should see the \"([^\"]*)\" header in the Texting Terms and Conditions page$")
	public void i_should_see_header_in_the_page(String header) {
		Assert.assertTrue("\"" + header + "\" heading is not displaying on the Texting Terms & Conditions Page",
				page.verifyHeader(header));
	}

	@Then("^I should see the following content in the Texting Terms and Conditions page$")
	public void iShouldSeeTheFollowingContentInTheTextingTermsAndConditionsPage(List<String> contentList) {
		String pgContent = "";
		for (String content : contentList) {
			pgContent = pgContent + " " + content;
		}
		pgContent = pgContent.replaceAll("\\s+", "");
		Assert.assertTrue("\"" + pgContent + "\" content is not displaying on the Texting Terms & Conditions Page",
				page.verifyPgContent(pgContent));
	}
	
	@Then("^I should see the following content in the Terms of Use page$")
	public void iShouldSeeTheFollowingContentInTheTermsOfUsePage(List<String> contentList) {
		String pgContent = "";
		for (String content : contentList) {
			pgContent = pgContent + " " + content;
		}
		pgContent = pgContent.replaceAll("\\s+", "");
		Assert.assertTrue("\"" + pgContent + "\" content is not displaying on the Terms of Use Page",
				page.verifyPgContent(pgContent));
	}
	
	@Then("^I should see the following content in the Privacy Policy page$")
	public void iShouldSeeTheFollowingContentInThePrivacyPolicyPage(List<String> contentList) {
		String pgContent = "";
		for (String content : contentList) {
			pgContent = pgContent + " " + content;
		}
		pgContent = pgContent.replaceAll("\\s+", "");
		Assert.assertTrue("\"" + pgContent + "\" content is not displaying on the Privacy Policy Page",
				page.verifyPgContent(pgContent));
	}
	
	@Then("^I should see the following content in the Consumer Communications Notice page$")
	public void iShouldSeeTheFollowingContentInTheConsumerCommunicationsNoticePage(List<String> contentList) {
		String pgContent = "";
		for (String content : contentList) {
			pgContent = pgContent + " " + content;
		}
		pgContent = pgContent.replaceAll("\\s+", "");
		Assert.assertTrue("\"" + pgContent + "\" content is not displaying on the Consumer Communications Notice Page",
				page.verifyPgContent(pgContent));
	}
}
