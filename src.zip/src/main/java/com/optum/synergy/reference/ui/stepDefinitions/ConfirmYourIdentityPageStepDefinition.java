package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.ConfirmYourIdentityPage_securityQuestions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ConfirmYourIdentityPageStepDefinition {

	private ConfirmYourIdentityPage_securityQuestions page;
	public ConfirmYourIdentityPageStepDefinition() {
		page = new ConfirmYourIdentityPage_securityQuestions();
	}
	
	@Then("^I should be at Confirm your identity page$")
	public void i_should_be_at_Confirm_your_identity_page() {
	    Assert.assertTrue("Issue while loading the Confirm your identity page",page.verifyIfPageLoadedSQA());
	}
	
	@Then("^I should be at Confirm your identity through phone page$")
	public void i_should_be_at_Confirm_your_identity_through_phone_page() {
	    Assert.assertTrue("Issue while loading the Confirm your identity through phone page",page.verifyIfPageLoadedPhone());
	}

	@Then("^I should see Remember this device section is displayed$")
	public void i_should_see_Remember_this_device_section_is_displayed() {
		 Assert.assertTrue("Remember this device section is not displayed",page.verifyIfRememberThisDeviceSectionDisplayed());
	}
	
	@Given("^I click on the Submit button in Confirm your identity page$")
	public void i_click_on_the_Submit_button_in_Confirm_your_identity_page() {
		page.clickContinueButton();
	}
	
	@Given("^I click on the Continue button in Confirm your identity page$")
	public void i_click_on_the_Continue_button_in_Confirm_your_identity_page() {
		page.clickForgotPasswordContinueButton();
	}
	
	@Then("^I enter security answer \"([^\"]*)\" into Answer textbox$")
	public void iEnterSecurityAnswerIntoAnswerTextbox(String answer) {
	    page.enterSecurityAnswer(answer);
	}
	 
	@Then("^I enter Reset Password security answer \"([^\"]*)\" into Answer textbox$")
		public void iEnterHSIDResetPasswordSecurityAnswerIntoAnswerTextbox(String answer) {
		    page.enterResetPasswordSecurityAnswer(answer);
    }
	
	@Then("^I enter Invalid phone text$") 
 	public void i_enter_Invalid_phone_text() {
		page.enterIncorrectConfirmationCodebytextmessage(); 
  	} 
	
	@Given("^I should see a radio button \"([^\"]*)\" in Confirm your identity page$")
	public void i_should_see_a_radio_button_in_Confirm_your_identity_page(String name) {
	    Assert.assertTrue("Issue while displaying the "+name+" radio button", page.verifyForRadioButton(name));
	}
	
	@Then("^I should see the text \"([^\"]*)\" on Confirm your identity page$")
	public void I_should_see_the_text_on_Confirm_your_identity_page(String message) {
	    Assert.assertTrue(page.verifyFormContent(message));
	}
	
	@When("^I manage the RBA page with security answer$")
	public void iManageTheRBAPageWithSecurityAnswer() throws Throwable {
	    if(page.verifyIfPageLoadedSQA()) {
	     page.enterValidSecurityAnswer();
	     page.clickContinueButton();
	     Thread.sleep(3000);
	    }
	}

	@When("^I manage the RBA page with mobile text$")
	public void iManageTheRBAPageWithMobileText() throws Throwable {
	    if(page.verifyIfPageLoadedPhone()) {
	     page.clickTextRadioButton();
	     page.clickContinueButton();
	     Thread.sleep(1000);
	     page.enterConfirmationCodebytextmessage();
	     page.clickContinueButton();
     }
	}
	
	@When("^I manage the RBA page with security answer or Mobile Text$")
	public void I_manage_the_RBA_page_with_security_answer_or_Mobile_Text() throws Throwable {
	    if(page.verifyIfPageLoadedSQA()) {
	    	page.enterValidSecurityAnswer();
	    	page.clickContinueButton();
	    }else if(page.verifyIfPageLoadedPhone()) {
	    	page.clickTextRadioButton();
	    	page.clickContinueButton();
	    	page.enterConfirmationCodebytextmessage();
	    	page.clickContinueButton();
    	}
	}
	
	@When("^I select text message to confirm identity$")
	public void iSelectTextMessageToConfirmIdentity() {
		page.clickTextRadioButton();
	}

	@Then("^I should see the security question$")
	public void i_should_see_the_security_question() {
		Assert.assertTrue("Security question is not displaying in confirm your identity page",
				page.verifyIfSecurityQuestionIsDisplayed());
	}
	
	@Then("^I should see the SQA error message \"([^\"]*)\" on Confirm Your Identity page$")
	public void iShouldSeeTheSqaErrorMessageOnConfirmYourIdentityPage(String message) throws Throwable {
		Thread.sleep(8000); //Page refreshes slowly. Can be removed if it does immediately.
		Assert.assertEquals(message, page.getSQAErrorMessage().trim().replaceAll(String.valueOf((char)160)," "));
	}
	
	@Then("^I should see the SQA error message \"([^\"]*)\" on Reset Password Confirm Your Identity page$")
	public void iShouldSeeTheSqaErrorMessageOnResetPasswordConfirmYourIdentityPage(String message) throws Throwable {
		Thread.sleep(8000); //Page refreshes slowly. Can be removed if it does immediately.
		Assert.assertEquals(message, page.getFPSQAErrorMessage()); //Failed to verify provided information, retry... 
	}
	
	@Then("^I should see the text error message \"([^\"]*)\" on Confirm Your Identity page$")
	public void iShouldSeeTheTextErrorMessageOnConfirmYourIdentityPage(String message) throws Throwable {
		Thread.sleep(8000); //Page refreshes slowly. Can be removed if it does immediately.
		Assert.assertEquals(message, page.getConfirmationCodeErrorMessage()); //Failed to verify provided information, retry... 
	}
	
	@Then("^I should see the text error message \"([^\"]*)\" on Forgot Password Confirm Your Identity page$")
	public void iShouldSeeTheTextErrorMessageOnConfirmYourIdentityPageForgotPassword(String message) throws Throwable {
		Thread.sleep(8000); //Page refreshes slowly. Can be removed if it does immediately.
		Assert.assertEquals(message, page.getConfirmationCodeErrorMessageForgotPassword()); //Failed to verify provided information, retry... 
	}
	
	@Then("^I should see SQA field validation error message \"(.*)\" on Confirm Your Identity page$")
	public void iShouldSeeSqaFieldValidationErrorMessageOnConfirmYourIdentityPage(String message) {
		Assert.assertEquals(message, page.getSQAFieldValidationErrorMessage()); //Answer must not be empty.
	}
	
	@Then("^I should see confirmation code validation error message \"([^\"]*)\" on Confirm Your Identity page$")
	public void iShouldSeeConfirmationCodeFieldValidationErrorMessageOnConfirmYourIdentityPage(String message) {
		Assert.assertEquals(message, page.getConfirmationCodeValidationErrorMessage()); //One-time code must be entered.
	}
	
	@Given("^I should see a gradient bar with Hex color codes \"([^\"]*)\" and \"([^\"]*)\" in RBA page$")
	public void iShouldSeeAGradientBarWithHexColorCodesAndInRBAPage(String hexColor1, String hexColor2) {
		 Assert.assertTrue("Gradient bar not displaying with Hex colors "+hexColor1+ " and "+hexColor2, page.getGradientBar(hexColor1, hexColor2).isDisplayed());
	}
	
	@Given("^I should see a gradient bar with RGB color codes \"([^\"]*)\" and \"([^\"]*)\" in RBA page$")
	public void iShouldSeeAGradientBarWithRGBColorCodesAndInRBAPage(String rGBColor1, String rGBColor2) {
		 Assert.assertTrue("Gradient bar not displaying with RGB colors "+rGBColor1+ " and "+rGBColor2, page.getGradientBarElement(rGBColor1, rGBColor2).isDisplayed());
	}
	
	@When("^I manage RBA page with security answer$")
	public void iManageRBAPageWithSecurityAnswer() throws Throwable {
	    if(page.verifyIfPageLoadedSQA()) {
	     page.enterValidSecurityAnswer();
	     page.clickTheContinueButton();
	     Thread.sleep(3000);
	    }
	}

	@When("^I should see Remember this device tool tip$")
	public void iShouldSeeRememberThisDeviceToolTip() {
		Assert.assertTrue(page.validateRememberThisDeviceToolTipLabel());
	}

	@When("^I mouse hover the Remember this device tool tip to validate contents$")
	public void iMouseHoverTheRememberThisDeviceToolTipToValidateContents() {
		page.mouseHoverOnRememberThisDeviceToolTipLabel();
	}

	@When("^I verify RBA challenge count for the session$")
	public void iVerifyRBAChallengeCount() {
		page.verifyRBAChallengeCount();
		}

	@Then("^I should see the emailid is masked$")
	public void i_should_see_the_emailid_is_masked() {
		Assert.assertTrue("Either email id is not displayed or not masked ",page.isEmailDisplayedAndMasked());
	}
}
