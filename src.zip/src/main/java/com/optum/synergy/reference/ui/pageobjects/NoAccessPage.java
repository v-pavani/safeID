package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class NoAccessPage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//*[contains(@class,'form__step1--noaccess')]|//*[@id='header' and contains(.,\"You don't have access\") or @id='header' and contains(.,\"Access not confirmed\")]")
	private WebElement noAccessForm;

	@FindBy(how = How.XPATH, using = "//*[contains(@class,'ng-scope')]/span[@class='ng-binding']|//span[@class='ng-binding']")
	private WebElement noAccessErrorMessage;

	@FindBy(how = How.XPATH, using = "//*[@class='center-align learnmore__content']/div")
	private WebElement afterSigninNoAccessPageErrorMessageElement;
	
	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.or(
					ExpectedConditions.visibilityOf(noAccessForm)));
		} catch (TimeoutException e) {
			return false;
		}
	}

	public String getErrorMsg(){
		try {
			return mediumWait.get().until(ExpectedConditions.visibilityOf(noAccessForm)).getText().trim().replaceAll(String.valueOf((char)160)," ");
		}catch(Exception e){
			return null;
		}
	}

	public String getNoAccessErrorMessage() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(noAccessErrorMessage)).getText();
	}

	public WebElement getNoAccessPageErrorMessageElementAfterSignin(){
		return mediumWait.get().until(ExpectedConditions.visibilityOf(afterSigninNoAccessPageErrorMessageElement));
	}
	
	public String getStepAndHeading(String step) {
		return mediumWait.get()
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(@class,'circle') and contains(text(),'" + step
								+ "')]/parent::p/parent::flex-content/following-sibling::flex-content/h2")))
				.getText().trim();
		}
}

