package com.optum.synergy.reference.ui.stepDefinitions;

import com.optum.synergy.common.ui.controller.WebController;
import com.optum.synergy.reference.ui.pageobjects.PageObjectBase;
import com.optum.synergy.reference.ui.pageobjects.Registration_CreateAccountSectionPage;
import com.optum.synergy.reference.ui.pageobjects.Registration_PersonalInformationSectionPage;
import com.optum.synergy.reference.ui.utility.DataStorage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;

import java.util.List;

public class Registration_PersonalInformationSectionPageStepDefinitions {

	private Registration_PersonalInformationSectionPage page;

	public Registration_PersonalInformationSectionPageStepDefinitions() {
		page = new Registration_PersonalInformationSectionPage();
	}

	@When("^I enter Date of birth with \"([^\"]*)\"$")
	public void i_enter_Date_of_birth_with(String dateOfBirth) throws Throwable {
		page.enterDateOfBirth(dateOfBirth);
		page.clickTab();
	}

	@When("^I enter Zip code with \"([^\"]*)\"$")
	public void i_enter_Zip_code_with(String zipCode) {
		page.enterZipCode(zipCode);
		page.clickTab();
	}

	@When("^I enter first name with \"([^\"]*)\"$")
	public void i_enter_first_name_with(String firstName) {
		page.enterFirstName(firstName);
		page.clickTab();
	}

	@When("^I enter Member ID with \"([^\"]*)\"$")
	public void i_enter_Member_ID_with(String memberId) {
		page.enterMemberID(memberId);
		page.clickTab();
	}

	@When("^I enter Group number with \"([^\"]*)\"$")
	public void i_enter_Group_Number_with(String groupNum) {
		page.enterGroupNumber(groupNum);
		page.clickTab();
	}

	@When("^I enter last name with \"([^\"]*)\"$")
	public void i_enter_last_name_with(String lastName) {
		page.enterLastName(lastName);
		page.clickTab();
	}

	@When("^I enter SSN with \"([^\"]*)\"$")
	public void iEnterSSNWith(String ssn) {
		page.enterSSN(ssn);
		page.clickTab();
	}

	@When("^I Click on \"([^\"]*)\" toolTip for Member Id$")
	public void iclickonToolTipForMemberId(String arg1) {
		page.ClickOnMemberIdToolTip();
	}

	@When("^I mouse hover over on \"([^\"]*)\" toolTip for Member Id$")
	public void iMouseHoverOverOnToolTipForMemberId(String arg1) {
		page.mouseHoverOnLabel(arg1);
	}

	@Then("^I should see an error message \"([^\"]*)\" for Date of birth$")
	public void i_should_see_an_error_message_for_Date_of_birth(String errorMessage) {
		Assert.assertEquals(errorMessage, page.getErrorMessageOnDateofBirth());
	}

	@Then("^I should not see any error message for Date of birth$")
	public void i_should_not_see_any_error_message_for_Date_of_birth() {
		Assert.assertEquals("Found DoB Error message when expected none", "", page.getErrorMessageOnDateofBirth());
	}

	@Then("^I should not see any error message for Username field$")
	public void i_should_not_see_any_error_message_for_Username_field() {
		Assert.assertEquals("Found Username Error message when expected none", "", page.getErrorMessageOnUsername());
	}

	@Then("^I should not see any error message for Password field$")
	public void i_should_not_see_any_error_message_for_Password_field() {
		Assert.assertEquals("Found Password Error message when expected none", "", page.getErrorMessageOnPassword());
	}

	@Then("^I should not see the error for confirm password$")
	public void i_should_see_the_error_for_confirm_password() {
		Assert.assertEquals("Found Re-enter password error message when expected none", "",
				page.getErrorMessageOnConfirmPassword());
	}

	@Then("^I should not see any error message for Email field$")
	public void i_should_not_see_any_error_message_for_Email_field() {
		Assert.assertEquals("Found Email Error message when expected none", "", page.getErrorMessageOnEmail());
	}

	@Then("^I should see an error message \"([^\"]*)\" for Zip code$")
	public void i_should_see_an_error_message_for_Zip_code(String errorMessage) {
		Assert.assertEquals(errorMessage, page.getErrorMessageOnZipcode());

	}
	
	@Then("^I should see an error message \"([^\"]*)\" for Caregiver access code$")
	public void i_should_see_an_error_message_for_Caregiver_access_code(String errorMessage) {
		Assert.assertEquals(errorMessage, page.getErrorMessageOnCaregiverAccessCode());
	}

	@Then("^I should not see any error message for Zip code$")
	public void i_should_not_see_any_error_message_for_Zip_code() {
		Assert.assertTrue(page.verifyNoErrorMessageOnZipcode());
	}

	@Then("^I should see an error message \"([^\"]*)\" for first name$")
	public void i_should_see_an_error_message_for_first_name(String errorMessage) {
		Assert.assertEquals(errorMessage, page.getErrorMessageOnFirstName());
	}

	@Then("^I should not see any error message for first name$")
	public void i_should_not_see_any_error_message_for_first_name() {
		Assert.assertTrue(page.verifyNoErrorMessageOnFirstName());
	}

	@Then("^I should see an error message \"([^\"]*)\" for Member ID$")
	public void i_should_see_an_error_message_for_Member_ID(String errorMessage) {
		Assert.assertEquals(errorMessage, page.getErrorMessageOnMemberId());
	}

	@Then("^I should see an error message \"([^\"]*)\" for \"([^\"]*)\"$")
	public void iShouldSeeAnErrorMessageForEmployeeId(String message, String field) {
		Assert.assertEquals(message, page.getErrorMessageOnEmployeeID());
	}

	@Then("^I should not see any error message for Member ID$")
	public void i_should_not_see_any_error_message_for_Member_ID() {
		Assert.assertTrue(page.verifyNoErrorMessageOnMemberId());
	}

	@Then("^I should see an error message \"([^\"]*)\" for Group number$")
	public void i_should_see_an_error_message_for_Group_number(String errorMessage) {
		Assert.assertEquals(errorMessage, page.getErrorMessageOnGroupNumber());
	}

	@Then("^I should see an error message \"([^\"]*)\" for last name$")
	public void i_should_see_an_error_message_for_last_name(String errorMessage) {
		Assert.assertEquals(errorMessage, page.getErrorMessageOnLastName());
	}

	@Then("^I should not see any error message for last name$")
	public void i_should_not_see_any_error_message_for_last_name() {
		Assert.assertTrue(page.verifyNoErrorMessageOnLastName());
	}

	@Then("^I should be at Enter personal information section page$")
	public void i_should_be_at_Enter_personal_information_section_page() {
		Assert.assertTrue("Failed to load Personal Information Page", page.verifyIfPageLoaded());
	}

	@Then("^I enter valid \"([^\"]*)\" into First name field$")
	public void i_enter_valid_into_First_name_field(String firstName) {
		page.enterFirstName(firstName);
	}
	
	@Then("^I enter valid FirstName into First name field$")
	public void i_enter_valid_FirstName_into_First_name_field() {
		page.enterFirstName(DataStorage.getFirstName());
	}

	@Then("^I enter valid \"([^\"]*)\" into Last name field$")
	public void i_enter_valid_into_Last_name_field(String lastName) {
		page.enterLastName(lastName);
	}

	@Then("^I enter valid LastName into Last name field$")
	public void i_enter_valid_LastName_into_Last_name_field() {
		page.enterLastName(DataStorage.getLastName());
	}

	@Then("^I enter valid \"([^\"]*)\" into Date of birth field$")
	public void i_enter_valid_into_Date_of_birth_field(String dateOfBirth) throws Throwable {
		page.enterDateOfBirth(dateOfBirth);
		page.clickTab();
	}

	@Then("^I enter valid DOB into Date of birth field$")
	public void i_enter_valid_DOB_into_Date_of_birth_field() throws Throwable {
		page.enterDateOfBirth(DataStorage.getDOB());
	}

	@Then("^I enter valid \"([^\"]*)\" into Zip code field$")
	public void i_enter_valid_into_Zip_code_field(String zipcode) {
		page.enterZipCode(zipcode);
		page.clickTab();
	}

	@Then("^I enter valid Zip into Zip code field$")
	public void i_enter_valid_Zipcode_into_Zip_code_field() {
		page.enterZipCode(DataStorage.getZip());
	}

	@Then("^I enter valid \"(.*)\" into Member ID field$")
	public void i_enter_valid_into_Member_ID_field(String memberId) {
		page.enterMemberID(memberId);
	}

	@Then("^I enter valid \"([^\"]*)\" into \"([^\"]*)\" field$")
	public void i_enter_valid_into_Employee_ID_field(String employeeId, String field) {
		page.enterEmployeeID(employeeId);
	}

	@Then("^I enter valid memberid into Member ID field$")
	public void i_enter_valid_memberid_into_Member_ID_field() {
		page.enterMemberID(DataStorage.getSubscriberID());
	}
	
	@Then("^I enter valid accesscode into Caregiver access code field$")
	public void i_enter_valid_accesscode_into_Caregiver_Access_Code_field() {
		page.enterCaregiverAccessCode(DataStorage.getCareGiverAccessCode());
	}
	
	@Then("^I enter valid \"(.*)\" into Caregiver Access Code field$")
	public void i_enter_valid__into_Caregiver_Access_Code_field(String accessCode) {
		page.enterCaregiverAccessCode(accessCode);
	}

	@Then("^I enter valid \"([^\"]*)\" into Group Number field$")
	public void i_enter_valid_into_Group_Number_field(String groupNum) {
		page.enterGroupNumber(groupNum);
	}

	@Then("^I enter valid groupnum into Group Number field$")
	public void i_enter_valid_group_number_into_Group_Number_field() {
		page.enterGroupNumber(DataStorage.getUserDetails("GroupNumber"));
	}

	@Then("^I enter valid altid into Member ID field$")
	public void i_enter_valid_altid_into_Member_ID_field() {
		page.enterMemberID(DataStorage.getAltId());
	}

	@Then("^I enter newvalid memberid into Member ID field$")
	public void i_enter_valid_newmemberid_into_Member_ID_field() {
		page.enterMemberID(DataStorage.getNewSubscriberID());
	}

	@Given("^I enter valid BriovaRxPrescriptionNumber into PrescriptionNumber field$")
	public void i_enter_valid_BriovaRxPrescriptionNumber_into_PrescriptionNumber_field() {
		page.enterPrescriptionNumber(DataStorage.getPrescriptionNo());
	}

	@Then("^I enter invalid subscriberid \"([^\"]*)\" into Member ID field$")
	public void i_enter_invalid_subscriberid_into_Member_ID_field(String memberId) {
		page.enterMemberID(memberId);
	}

	@Then("^I enter valid \"([^\"]*)\" into SSN field$")
	public void i_enter_valid_into_SSN_field(String ssn) {
		page.enterSSN(ssn);
	}

	@Then("^I enter invalid \"([^\"]*)\" into SSN field$")
	public void i_enter_invalid_into_SSN_field(String ssn) {
		page.enterSSN(ssn);
	}

	@Then("^I enter valid SSN into SSN field$")
	public void i_enter_validSSN_into_SSN_field() {
		page.enterSSN(DataStorage.getSSN());
	}

	@Then("^I enter invalid ssnnumber \"([^\"]*)\" into SSN field$")
	public void i_enter_invalid_ssnnumber_into_SSN_field(String ssn) {
		page.enterSSN(ssn);
		page.clickTab();
	}

	@Then("^I should not see any error message for SSN$")
	public void iShouldNotSeeAnyErrorMessageForSSN() {
		Assert.assertTrue(page.verifyNoErrorMessageOnSSN());
	}

	@Then("^I should see an error message \"([^\"]*)\" for SSN$")
	public void iShouldSeeAnErrorMessageForSSN(String message) {
		Assert.assertEquals(message, page.getErrorMessageOnSSN());
	}

	@Then("^I should see \"([^\"]*)\" toolTip for Member Id$")
	public void iShouldSeeToolTipForMemberId(String toolTipName) {
		Assert.assertTrue(page.verifyToolTipOnMemberIDField(toolTipName));
	}

	@Then("^I should see tooltip message \"([^\"]*)\" for Member Id$")
	public void iShouldSeeTooltipMessageForMemberId(String message) {
		Assert.assertTrue(page.verifyForMemberIdToolTipMessage(message));
	}

	@Then("^I should see tooltip message \"([^\"]*)\" for Email Id$")
	public void iShouldSeeTooltipMessageForEmailId(String message) {
		Assert.assertTrue(page.verifyForMemberIdToolTipMessage(message));
	}

	@Then("^I should see tooltip message \"([^\"]*)\"$")
	public void iShouldSeeTooltipMessage(String message) {
		Assert.assertTrue(page.verifyForMemberId(message));
	}

	@Given("^I should see an Optum Logo$")
	public void i_should_see_an_Optum_logo() {
		Assert.assertTrue(page.VerifyOptumLogo());
	}

	@Given("^I should see HarvardPilgrim Logo$")
	public void i_should_see_an_HarvardPilgrim_logo() {
		Assert.assertTrue("Issue in displaying the Harvard Pilgrim logo on the page.",page.verifyHarvardPilgrimLogo());
	}

	@Given("^I should see Railroad Logo$")
	public void i_should_see_an_Railroad_logo() {
		Assert.assertTrue("Issue in displaying the Railroad logo on the page.",page.verifyRailroadLogo());
	}

	@Given("^I should see an OptumRx Logo$")
	public void i_should_see_an_OptumRx_logo() {
		Assert.assertTrue(page.VerifyOptumRxLogo());
	}

	@Given("^I should see a UHC Logo$")
	public void iShouldSeeAUHCLogo() {
		Assert.assertTrue("Issue displaying UHC Logo", page.verifyUhcLogo());
	}

	@Given("^I should see a MyUHC Logo$")
	public void iShouldSeeAMyUHCLogo() {
		Assert.assertTrue("Issue displaying MyUHC Logo", page.verifyMyUhcLogo());
	}

	@Given("^I should see a Medica Logo$")
	public void iShouldSeeAMedicaLogo() {
		Assert.assertTrue("Issue displaying Medica Logo", page.verifyMyUhcMedicaLogo());
	}

	@Given("^I should see the \"([^\"]*)\" as form header description in Personal Info page$")
	public void i_should_see_the_in_Personal_Info_page(String Content) {
		Assert.assertTrue("Content verified", page.getPersonalInfoDescription().contains(Content));
	}

	@Given("^I should see an LAWW Logo$")
	public void i_should_see_an_LAWW_logo() {
		Assert.assertTrue(page.verifyLAWWlogo());
	}

	@Then("^I should see a GroupOrPolicy number label with text box$")
	public void i_should_see_a_GroupOrPolicy_number_label_with_text_box() {
		Assert.assertTrue("Issue in displaying the Group/Policy number label with text box",
				page.verifyIfGroupOrPolicyNumberLabelWithTextboxExist());
	}

	@Then("^I should see a Social Security Number label with text box$")
	public void i_should_see_a_Social_Security_Number_label_with_text_box() {
		Assert.assertTrue("Issue in displaying the Social Security Number label with text box",
				page.verifyIfSocialSecurityNumberLabelWithTextboxExist());
	}

	@Given("^I should see ssn field is displayed$")
	public void i_should_see_ssn_field_is_displayed() {
		Assert.assertTrue(page.verifyIfSSNFieldIsDisplayed());
	}

	@Given("^I should see memberid field is disabled$")
	public void i_should_see_memberid_field_is_disabled() {
		Assert.assertFalse(page.memberidisenabled());
	}

	@Given("^I should see ssn field is disabled$")
	public void i_should_see_ssn_field_is_disabled() {
		Assert.assertFalse(page.SSNisEnabled());
	}

	@Given("^I should see memberid field is enabled$")
	public void i_should_see_memberid_field_is_enabled() {
		Assert.assertTrue(page.memberidisenabled());
	}

	@Given("^I should see ssn field is not displayed$")
	public void i_should_see_ssn_field_is_not_displayed() throws InterruptedException{
		Thread.sleep(3000);
		Assert.assertTrue("Issue while not displaying the SSN field", page.verifyIfSSNIsNotDisplayed());
	}

	@Then("^I should see the Enter personal information form header as \"([^\"]*)\"$")
	public void i_should_see_the_Enter_personal_information_form_header_as(String header) throws Throwable {
		Assert.assertTrue("\"" + header + "\" heading is not displaying on the Enter personal information form",
				page.verifyFormHeader(header));
		Thread.sleep(1000);
	}

	@Then("^I should see a First name label with text box$")
	public void i_should_see_a_First_name_label_with_text_box() {
		Assert.assertTrue("Issue in displaying the First name label with text box",
				page.verifyIfFirstnameLabelWithTextboxExist());
	}

	@Then("^I should see a Last name label with text box$")
	public void i_should_see_a_Last_name_label_with_text_box() {
		Assert.assertTrue("Issue in displaying the Last name label with text box",
				page.verifyIfLastnameLabelWithTextboxExist());
	}

	@Then("^I should see a Date of birth label with text box$")
	public void i_should_see_a_Date_of_birth_label_with_text_box() {
		Assert.assertTrue("Issue in displaying the Date of birth label with text box",
				page.verifyIfDOBLabelWithTextboxExist());
	}

	@Then("^I should see a Zip code label with text box$")
	public void i_should_see_a_Zip_code_label_with_text_box() {
		Assert.assertTrue("Issue in displaying the Zip code label with text box",
				page.verifyIfZipcodeLabelWithTextboxExist());
	}

	@Then("^I should see a Member ID label with text box$")
	public void i_should_see_a_Member_ID_label_with_text_box() {
		Assert.assertTrue("Issue in displaying the Member ID label with text box",
				page.verifyIfMemberIdLabelWithTextboxExist());
	}

	@When("^I click on Optum Bank logo$")
	public void i_click_on_Optum_Bank_logo() {
		page.clickOptumLogo();
	}
	
	@When("^I click on Optum logo$")
	public void i_click_on_Optum_logo() {
		page.clickOptumLogoBelowGN();
	}

	@Then("^I should see the \"([^\"]*)\" header in step complete$")
	public void i_should_see_the_header_in_step_complete(String pageContent) {
		Assert.assertTrue("\"" + pageContent + "\" is not displaying as personal info form label",
				page.verifytheSubHeadingByH3Tag(pageContent));
	}

	@Then("^I should see the Username label$")
	public void i_should_see_the_Username_label() {
		Assert.assertTrue("\"" + "\" is not displaying as personal info form label", page.verifyUsernameLabel());
	}

	@Then("^I should see the Password label$")
	public void i_should_see_the_Password_label() {
		Assert.assertTrue("\"" + "\" is not displaying as personal info form label", page.verifyPasswordLabel());
	}

	@Then("^I should see the Confirm Password label$")
	public void i_should_see_the_Confirm_Password_label() {
		Assert.assertTrue("\"" + "\" is not displaying as personal info form label", page.verifyConfPasswordLabel());
	}

	@Then("^I should see the \"([^\"]*)\" form right content$")
	public void i_should_see_the_form_right_content(String pageContent) {
		Assert.assertTrue("\"" + pageContent + "\" is not displaying as form right content",
				page.verifyRightViewContent(pageContent));
	}

	@Then("^I should see the \"([^\"]*)\" link in Sign In page routed to correct page url$")
	public void iShouldSeeTheLinkInSignInPageRoutedToCorrectPageUrl(String link) throws Throwable {
		Assert.assertEquals(PageObjectBase.getEnvVariable("pageLinks.signInPage." + link),
				WebController.returnCurrentURL());
		Assert.assertEquals(PageObjectBase.getEnvVariable("pageLinks.signInPage." + link),
				WebController.returnCurrentURL());

	}

	@Given("^I should see the page routed to valid url from \"([^\"]*)\" and \"([^\"]*)\" link$")
	public void i_should_see_the_page_routed_to_valid_url_from_and_link(String pageName, String linkName)
			throws Throwable {
		Assert.assertEquals("Failed to navigate to expected page URL",
				page.getPagelinkFromTestDataXMLFile(pageName, linkName), page.getCurrentPageUrl());
	}

	@Then("^I should see the First name field is not empty$")
	public void iShouldSeeTheFirstNameFieldIsNotEmpty() {
		Assert.assertNotEquals("", page.getFirstNameValue());
	}

	@Then("^I should see the Last name field is not empty$")
	public void iShouldSeeTheLastNameFieldIsNotEmpty() {
		Assert.assertNotEquals("", page.getLastNameValue());
	}

	@Then("^I should see the Last name field is empty$")
	public void iShouldSeeTheLastNameFieldIsEmpty() {
		Assert.assertEquals("", page.getLastNameValue());
	}

	@Then("^I should see the First name field is empty$")
	public void iShouldSeeTheFirstnameFieldIsEmpty() {
		Assert.assertEquals("", page.getFirstNameValue());
	}

	@Then("^I should see the Date of birth field is empty$")
	public void iShouldSeeTheDateOfBirthFieldIsEmpty() {
		Assert.assertEquals("", page.getDateofBirthValue());
	}

	@Then("^I should see the Zip code field is empty$")
	public void iShouldSeeTheZipCodeFieldIsEmpty() {
		Assert.assertEquals("", page.getZipCodeValue());
	}

	@Then("^I should see the Member ID field is empty$")
	public void iShouldSeeTheMemberIDFieldIsEmpty() {
		Assert.assertEquals("", page.getMemberIdValue());
	}

	@Then("^I should see the Group/Policy field is empty$")
	public void iShouldSeeTheGroupPolicyFieldIsEmpty() {
		Assert.assertEquals("", page.getGroupNumberValue());
	}

	@Then("^I enter valid first name from below list and should not get any error message$")
	public void iEnterValidFirstNameFromBelowListAndShouldNotGetAnyErrorMessage(List<String> arg1) {

		for (String inStr : arg1) {
			String FistName = "First" + inStr + "Name";
			page.enterFirstName(FistName);
			page.clickTab();
			Assert.assertTrue("Unexpected Error displayed on FirstName field validation for special character " + inStr,
					page.verifyNoErrorMessageOnFirstName());
		}

	}

	@Then("^I enter valid last name from below list and should not get any error message$")
	public void iEnterValidLastNameFromBelowListAndShouldNotGetAnyErrorMessage(List<String> arg1) {

		for (String inStr : arg1) {
			String LastName = "Last" + inStr + "Name";
			page.enterLastName(LastName);
			page.clickTab();
			Assert.assertTrue("Unexpected Error displayed on LastName field validation for special character " + inStr,
					page.verifyNoErrorMessageOnLastName());
		}

	}

	@Given("^I should see a Home Icon in breadcrumb$")
	public void iShouldSeeAHomeIconInBreadcrumb() {
		Assert.assertTrue("Issue displaying Home Icon in breadcrumb", page.verifyElementByClassName("icon-home"));
	}

	@Given("^I should see a > icon in breadcrumb$")
	public void iShouldSeeAIconInBreadcrumb() {
		Assert.assertTrue("Issue displaying > icon in breadcrumb",
				page.verifyElementByClassName("fa fa-angle-right mega"));
	}

	@Given("^I should see the text \"([^\"]*)\" in breadcrumb$")
	public void iShouldSeeTheTextInBreadcrumb(String arg1) {
		Assert.assertTrue("Issue displaying expected breadcrumb text [" + arg1 + "]",
				page.verifyBreadCrumbContains(arg1));
	}

	@Given("^I should see a MEDICARE Logo$")
	public void iShouldSeeAMEDICARELogo() {
		Assert.assertTrue("Issue displaying Medicare Logo", page.verifyMedicareLogo());
	}

	@Given("^I should see a RETIREE Logo$")
	public void iShouldSeeARETIREELogo() {
		Assert.assertTrue("Issue displaying Medicare Logo", page.verifyRetireeLogo());
	}

	@Given("^I should see a MEDICA Logo$")
	public void iShouldSeeAMEDICALogo() {
		Assert.assertTrue("Issue displaying Medicare Logo", page.verifyMedicaLogo());
	}

	@Given("^I should see a PCP Logo$")
	public void iShouldSeeAPCPLogo() {
		Assert.assertTrue("Issue displaying Medicare Logo", page.verifyPcpLogo());
	}

	@Given("^I should see a AARP Logo$")
	public void iShouldSeeAARPLogo() {
		Assert.assertTrue("Issue displaying Medicare Logo", page.verifyAarpLogo());
	}

	@When("^I enter Date of birth with \"([^\"]*)\" for field validation$")
	public void i_enter_Date_of_birth_with_for_field_validation(String dateOfBirth) {
		page.clearAndenterDateOfBirth(dateOfBirth);
		page.clickTab();
	}

	@Then("^I should see auto populated \"([^\"]*)\" first name$")
	public void i_should_see_an_auto_populated_first_name(String firstName) {
		String value = page.getFirstNameValue();
		if (value == null) {
			value = "NULL_VALUE";
		}
		Assert.assertEquals(firstName.toLowerCase(), value.toLowerCase());
	}

	@Then("^I should see auto populated \"([^\"]*)\" last name$")
	public void i_should_see_an_auto_populated_last_name(String lastName) {
		Assert.assertEquals(lastName.toLowerCase(), page.getLastNameValue().toLowerCase());
	}

	@Then("^I should see auto populated \"([^\"]*)\" date of birth$")
	public void i_should_see_an_auto_populated_dob(String DOB) {
		Assert.assertEquals(DOB, page.getDateofBirthValue());
	}

	@Given("^I should see the first name field prepopulated$")
	public void i_should_see_the_first_name_field_prepopulated() {
		Assert.assertEquals(DataStorage.getFirstName(), page.getFirstNameValue());
	}

	@Given("^I should see the last name field prepopulated$")
	public void i_should_see_the_last_name_field_prepopulated() {
		Assert.assertEquals(DataStorage.getLastName(), page.getLastNameValue());
	}

	@Given("^I should see the DOB field prepopulated$")
	public void i_should_see_the_DOB_field_prepopulated() {
		Assert.assertEquals(DataStorage.getDOB(), page.getDateofBirthValue());
	}

	@Given("^I should see the Zip field prepopulated$")
	public void iShouldSeeTheZipFieldPrepopulated() {
		Assert.assertEquals(DataStorage.getZip(), page.getZipCodeValue());
	}

	@Given("^I should see the memberid field prepopulated$")
	public void iShouldSeeTheMemberidFieldPrepopulated() {
		Assert.assertEquals(DataStorage.getSubscriberID(), page.getMemberIdValue());
	}

	@Given("^I should see the cardholder field prepopulated$")
	public void iShouldSeeTheCardholderFieldPrepopulated() {
		Assert.assertEquals(DataStorage.getCardholderID(), page.getCardholderIdValue());
	}

	@Then("^I should see error message \"([^\"]*)\" for Terms and conditions accepted checkbox when not selected$")
	public void i_should_see_error_message_for_Terms_and_conditions_accepted_checkbox_when_not_selected(String message) {
		Assert.assertTrue(page.verifyErrorMessageOnTermConditionsAcceptedcheckbox(message));
	}

	@Then("^I should see an error message \"([^\"]*)\" on top of personal information page$")
	public void iShouldSeeAnErrorMessageOnTopOfPersonalInformationPage(String errMsg) {
		Assert.assertEquals("\"" + errMsg + "\"" + " error message is not displaying on personal information page",
				errMsg, page.getErrorMessage());
	}

	@Then("^I should see an error message \"([^\"]*)\" on personal information page$")
	public void iShouldSeeAnErrorMessageOnPersonalInformationPage(String errMsg) {
		Assert.assertTrue("Expected error message is not displaying on personal information page\nExpected Message: "+errMsg+"\nActual Message: "+page.PersonalInfoTopErrorMessage(), page.PersonalInfoTopErrorMessage().contains(errMsg));
	}

	@Then("^I enter invalid \"([^\"]*)\" into Zip code field$")
	public void iEnterInvalidIntoZipCodeField(String zip) {
		page.enterZipCode(zip);
		page.clickTab();
	}

	@When("^I enter invalid \"([^\"]*)\" into Date of birth field$")
	public void iEnterInvalidIntoDateOfBirthField(String dob) throws Throwable {
		page.enterDateOfBirth(dob);
		page.clickTab();
	}

	@Then("^I enter invalid \"([^\"]*)\" into First name field$")
	public void iEnterInvalidIntoFirstNameField(String firstName) {
		page.enterFirstName(firstName);
	}

	@When("^I enter invalid \"([^\"]*)\" into Last name field$")
	public void iEnterInvalidIntoLastNameField(String lastName) {
		page.enterLastName(lastName);
	}

	@When("^I enter invalid \"([^\"]*)\" into Group Number field$")
	public void iEnterInvalidIntoGroupNumberField(String groupNumber) {
		page.enterGroupNumber(groupNumber);
	}

	@When("^I enter invalid prescriptionNo \"([^\"]*)\" into BriovaRx prescriptionNo field$")
	public void i_enter_invalid_prescriptionNo_into_BriovaRx_prescriptionNo_field(String prescriptionno) {
		page.enterPrescriptionNumber(prescriptionno);
		page.clickTab();
	}

	@When("^I select \"([^\"]*)\" for having member ID card$")
	public void IselectforhavingmemberIDcard(String option) {
		page.selectOptionForHavingMemberIDcard(option);
	}

	@When("^I mouse hover on the \"([^\"]*)\" label$")
	public void i_mousehover_on_the_label(String message) {
		page.mouseHoverOnLabel(message);
	}

	@Then("^I should see \"([^\"]*)\" message$")
	public void i_should_see_message_on_ToolTip(String message) {
		String tootipMessage = page.getTootipMessage();
		Assert.assertTrue("Failed to find expected [" + message + "] in actual tooltip message [" + tootipMessage + "]",
				tootipMessage.contains(message));
	}

	@When("^I click on \"([^\"]*)\" link under Already Have Health Safe ID$")
	public void i_click_link_under_Already_Have_Health_Safe_ID(String link) {
		page.clickLinkunderAlreadyHaveHealthSafeID(link);
	}

	@When("^I should wait for page load of Link \"([^\"]*)\"$")
	public void i_should_wait_for_PageLoad(String message) {
		page.waitForPageLoadforLink(message);
	}

	@When("^I should wait for page load of Link Accessibility Statement for Individuals with Disabilities")
	public void i_should_wait_for_PageLoad_Accessibility_statement() {
		page.waitForPageLoadLinkForAccessibility();
	}

	@Given("^I should see step \"([^\"]*)\" of registration with heading \"([^\"]*)\"$")
	public void iShouldSeeStepOfRegistrationWithHeading(String arg1, String arg2) {
		Assert.assertTrue(page.verifyStepNumberAndHeading(arg1, arg2));
	}

	@Given("^I should not see step \"([^\"]*)\" of registration with heading \"([^\"]*)\"$")
	public void iShouldNotSeeStepOfRegistrationWithHeading(String arg1, String arg2) {
		Assert.assertFalse(page.verifyStepNumberAndHeading(arg1, arg2));
	}

	@Given("^I should see Green Check Mark replacing step \"([^\"]*)\" of registration with heading \"([^\"]*)\"$")
	public void iShouldSeeGreenCheckforMarkreplacingStepOfRegistrationWithHeading(String arg1, String arg2) {
		Assert.assertTrue("Issue Green check Mark is not displaying",
				page.verifyGreencheckMarkandHeading(arg2).isDisplayed());
	}

	@Then("^I should see the following content in MemberID PopUp Window$")
	public void iShouldSeeTheFollowingContentInTooltip(List<String> contentList) {
		for (String content : contentList) {
			content = content.trim();
			Assert.assertTrue("\"" + content + "\" content is not displaying on the PopUp",
					page.getMemberIdPopUpWindowContent().contains(content));
		}
	}

	@Then("^I should see the Member ID Card image (1|2|3) in Member ID PopUp Window$")
	public void iShouldSeeTheMemberIDCardImagesInMemberIDPopUpWindow(String cardNumber) {
		Assert.assertTrue("Member ID card images not displayed", page.verifyMemberIdCardImages(cardNumber));
	}

	@Then("^I should see the Member ID Card image in Membership ID PopUp Window for Dime$")
	public void iShouldSeeTheMemberIDCardImagesInMemberIDPopUpWindowforDime() {
		Assert.assertTrue("Membership ID card image not displayed", page.verifyMembershipIdCardImages().isDisplayed());
	}

	@Then("^I should see \"([^\"]*)\" button in MemberID PopUp Window$")
	public void iShouldSeeButtoninMemberIDPopUpWindow(String buttonname) {
		Assert.assertEquals("Button not displayed", buttonname, page.getDoneButtonInMemberIdPopUpWindow().getText().trim());
	}

	@When("^I click on close icon in MemberID PopUp Window$")
	public void IclickoncloseIconinMemberIDPopUpWindow() {
		page.clickCloseIconInMemberIdPopupWindow();
	}

	@When("^I should see \"([^\"]*)\" label beside the DOB field$")
	public void iShouldSeeLabelBesideTheDOBField(String message) {
		Assert.assertEquals("Label is not displaying", message, page.getDOBLabel());
	}

	@Then("^I should see \"([^\"]*)\" message on top of Personal Information Page$")
	public void i_should_see_message_on_top_of_Personal_Information_Page(String message) {
		String personalInfoText = page.getMessageOnPersonalInformationPage();
		Assert.assertTrue("Did not find expected text [" + message + "]\nFound: [" + personalInfoText + "]",
				personalInfoText.contains(message));
	}

	@Then("^I should see a MyUHCCommunityPlan Logo$")
	public void iShouldSeeAMyUHCCommunityPlanLogo() {
		Assert.assertTrue("Issue displaying MyUHCCommunityPlan Logo", page.verifyMyUhcCommunityPlanLogo());

	}
	
	@Then("^I should see a UHC-MNR Logo$")
	public void iShouldSeeAUHCMNRLogo() {
		Assert.assertTrue("Issue displaying MyUHC-MNR Logo", page.verifyUHCMNRLogo());
	}

	@Then("^I should see a MyUHCMedica Logo$")
	public void iShouldSeeAMyUHCMedicaLogo() {
		Assert.assertTrue("Issue displaying MyUHCMedica Logo", page.verifyMyUhcMedicaLogo());
	}

	@Then("^I should see the following required field messages in the Personal Information Page$")
	public void iShouldSeeTheFollowingRequiredFieldMessagesInThePersonalInformationPage(List<String> contentList) {
		String actualPageContent = page.getPersonalInfoRequiredMessage();
		for (String content : contentList) {
			content = content.trim();
			Assert.assertTrue("\"" + content + "\"" + " content is not displaying in the multiple plan sector page",
					actualPageContent.contains(content));
		}

	}

	@When("^I select to register with \"([^\"]*)\"$")
	public void iSelectToRegisterWith(String registerWith) {
		page.selectRegisterWith(registerWith);
	}

	@Then("^I should see a BSCA Logo$")
	public void iShouldSeeABSCALogo() {
		Assert.assertTrue("BSCA Logo is not displayed", page.getBSCALogo().isDisplayed());
	}

	@Then("^I should see the BSCA ID Card$")
	public void iShouldSeeTheBSCAIDCard() {
		Assert.assertTrue("Member ID Card is not displayed on the Modal Dialog",
				page.getBSCAMemberIDCardOnModalDialog().isDisplayed());
	}

	@Then("^I should see close icon in MemberIDPopUp window$")
	public void iShouldSeeCloseIconInMemberIDPopUpWindow() {
		Assert.assertTrue("Close Button on the Modal Dialog is not displayed",
				page.getCloseButtononModal().isDisplayed());
	}

	@Then("^I should see a Accessibility Statement for Individuals with Disabilities link$")
	public void iShouldSeeAccessibilityStatementForIndividualsWithDisabilitieslink() {
		Assert.assertTrue("Issue in seeing the Accessibility Statement Link ",
				page.getAccessibilityLink().isDisplayed());
	}

	@Then("^I should see a MemberID or SSN dropdown in the Personal Information Page$")
	public void iShouldSeeAMemberIDorSsnDropdownInThePersonalInformationPage() {
		Assert.assertTrue("Issue displaying MemberId/SSN dropdown ", page.verifyMemberIdOrSSNDropdown());
	}

	@Then("^I should not see any error message for Group number$")
	public void i_should_not_see_any_error_message_for_Group_number() {
		Assert.assertTrue(page.verifyNoErrorMessageOnGroupNumber());
	}

	@Then("^I should see MemberID with green circle$")
	public void iShouldSeeMemberIDWithGreenCircle() {
		Assert.assertTrue("Member ID text with green dot is not displayed on the Modal Dialog",
				page.getMemberIDWithGreenCircle().isDisplayed());
	}

	@Then("^I should see a BAZ Logo$")
	public void i_should_see_a_BAZ_Logo() {
		Assert.assertTrue("BAZ Logo is not displayed", page.getBAZLogo().isDisplayed());
	}

	@Then("^I should see the Member ID Card image in Member ID PopUp Window$")
	public void i_should_see_the_Member_ID_Card_image_in_Member_ID_PopUp_Window() {
		Assert.assertTrue("BAZ MemId Img not displayed", page.getBAZMemIDImg().isDisplayed());
	}

	@Then("^I should see the Member ID Card and Dental ID Card image in Member ID PopUp Window for myUhc$")
	public void i_should_see_the_Member_ID_Card_image_in_Member_ID_PopUp_Window_for_myUhc() {
		Assert.assertTrue("MyUhc Member Id or Dental ID images are not displayed",
				page.getMyUhcMemIDImg().isDisplayed() && page.getMyUhcDentalIDImg().isDisplayed());
	}

	@Then("^I should see a phone link \"([^\"]*)\"$")
	public void iShouldSeeAPhoneLink(String number) {
		if ("LAWW".equalsIgnoreCase(DataStorage.getPortalName())) {
			String phoneNumber1 = PageObjectBase.getAEMContent(DataStorage.getPortalName(), "PageContent", number);
			Assert.assertTrue("Issue while displaying the phone link", page.isPhoneLinkClickable(phoneNumber1));
		} else{
			Assert.assertTrue("Issue while displaying the phone link",page.getPhoneLink(number).isDisplayed());
		}
	}

	@Then("^I should see a BriovaRx Logo$")
	public void iShouldSeeABriovaRxLogo() {
		Assert.assertTrue("BriovaRx Logo is not displayed", page.getBriovaRxLogo().isDisplayed());
	}

	@Then("^I should see a BriovaRx prescription number label with text box$")
	public void iShouldSeeABriovaRxPrescriptionNumberLabelWithTextBox() {
		Assert.assertTrue("Issue displaying BriovaRx prescription number label with text box  ",
				page.verifyIfPrescriptionNumLabelWithTextboxExist());
	}

	@Then("^I should see \"([^\"]*)\" button in BriovaRx Prescription Number PopUp Window$")
	public void iShouldSeeButtonInBriovaRxPrescriptionNumberPopUpWindow(String buttonname) {
		Assert.assertEquals("Button not displayed", buttonname, page.getDoneButtonInMemberIdPopUpWindow().getText());
	}

	@Given("^I should see the following content in BriovaRx Prescription Number PopUp Window$")
	public void i_should_see_the_following_content_in_BriovaRx_Prescription_Number_PopUp_Window(List<String> contentList) {

		String memberIdPopUpWindowContent = page.getMemberIdPopUpWindowContent();
		for (String content : contentList) {
			content = content.trim();
			Assert.assertTrue("\"" + content + "\" content is not displaying on the PopUp",
					memberIdPopUpWindowContent.contains(content));
		}
	}

	@Then("^I should see the BriovaRx Prescription Number Card image in BriovaRx Prescription Number PopUp Window$")
	public void iShouldSeeTheBriovaRxPrescriptionNumberCardImageInBriovaRxPrescriptionNumberPopUpWindow() {
		Assert.assertTrue("BriovaRx tool tip images not displayed", page.verifyBriovaRxPrescriptionNumImages());
	}

	@When("^I click on close icon in BriovaRx Prescription Number PopUp Window$")
	public void iClickOnCloseIconInBriovaRxPrescriptionNumberPopUpWindow() {
		page.clickCloseIconInMemberIdPopupWindow();
	}

	@Then("^I should see an error message$")
	public void iShouldSeeAnErrorMessage(List<String> contentList) {
		for (String content : contentList) {
			content = content.trim();
			Assert.assertTrue("\"" + content + "\" error msg content is not displaying",
					page.PersonalInfoTopErrorMessage().contains(content));
		}
	}

	@Then("^I enter valid \"([^\"]*)\" into BriovaRx prescriptionNo field$")
	public void i_enter_valid_into_BriovaRx_prescriptionNo_field(String prescriptionno) {
		page.enterPrescriptionNumber(prescriptionno);
		page.clickTab();
	}

	@Then("^I should not see any error message for BriovaRx prescriptionNo field$")
	public void i_should_not_see_any_error_message_for_BriovaRx_prescriptionNo_field() {
		Assert.assertTrue(page.verifyNoErrorMessageOnPrescriptionNum());
	}

	@Then("^I should see an error message \"([^\"]*)\" for BriovaRx prescriptionNo field$")
	public void i_should_see_an_error_message_for_BriovaRx_prescriptionNo_field(String errorMessage) {
		Assert.assertEquals(errorMessage, page.getErrorMessageOnPrescriptionNum());
	}

	@Then("^I should see an AHC logo$")
	public void iShouldSeeAnAHCLogo() {
		Assert.assertTrue("AHC Logo is not displayed", page.getAHCLogo().isDisplayed());
	}

	@Then("^I should see a gradient bar with Hex color codes \"([^\"]*)\" and \"([^\"]*)\"$")
	public void iShouldSeeAGradientBarWithHexColorCodesAnd(String hexColor1, String hexColor2) {
		Assert.assertTrue("Gradient bar not displaying with Hex colors \"" + hexColor1 + "\" and \"" + hexColor2 + "\"",
				page.getGradientBar(hexColor1, hexColor2).isDisplayed());
	}

	@When("^I enable the personal information form$")
	public void iEnableThePersonalInformationForm() {
		page.clickPersonalInfoForm();
	}

	@Then("^I should see a tooltip message \"([^\"]*)\"$")
	public void iShouldSeeATooltipMessage(String message) {
		Assert.assertTrue(page.getTootipMessage().contains(message));
	}

	@Then("^I should see cardholder id field is displayed$")
	public void iShouldSeeCardholderIdFieldIsDisplayed() {
		Assert.assertTrue(page.getCardholderIdFiel().isDisplayed());
	}

	@When("^I enter valid \"([^\"]*)\" into cardholder id field$")
	public void iEnterValidIntoCardholderIdField(String id) {
		page.enterCardholderId(id);
	}

	@Given("^I enter valid cardholder id into Cardholder ID field$")
	public void iEnterValidCardholderIdIntoCardholderIDField() {
		page.enterCardholderId(DataStorage.getCardholderID());
	}

	@Then("^I should see ServeYou logo$")
	public void iShouldSeeServeYouLogo() throws Throwable {
		Assert.assertTrue("ServeYou Logo is not displayed", page.getServeYouLogo().isDisplayed());
	}

	@When("^I click on \"([^\"]*)\" button on COPPA popup$")
	public void i_click_on_button_on_COPPA_popup(String button) {
		page.clickButtonOnCOPPAPopup(button);
	}

	@Then("^I should see \"([^\"]*)\" on header$")
	public void i_should_see_the_on_Header(String pageContent) {
		Assert.assertTrue("\"" + pageContent + "\" is not displaying correct content",
				page.verifyheadercontent(pageContent));
	}

	@Given("^I should see an AARP Logo$")
	public void iShouldSeeAnAaroLogo() {
		Assert.assertTrue("Issue displaying Aarp Logo", page.verifyAarpLogo());
	}

	@Given("^I should see a Medicare Logo$")
	public void iShouldSeeAMedicareLogo() {
		Assert.assertTrue("Issue displaying Medicare Logo", page.verifyMedicareLogo());
	}

	@Given("^I should see a Medica Logo for MNR$")
	public void iShouldSeeAMedicaLogoForMnr() {
		Assert.assertTrue("Issue displaying Medica Logo", page.verifyMedicaLogo());
	}

	@Given("^I should see a Pcp Logo$")
	public void iShouldSeeAPcpLogo() {
		Assert.assertTrue("Issue displaying Pcp Logo", page.verifyPcpLogo());
	}

	@Given("^I should see a Retiree Logo$")
	public void iShouldSeeARetireeLogo() {
		Assert.assertTrue("Issue displaying Retiree Logo", page.verifyRetireeLogo());
	}

	@When("^I click on content tooltip of BriovaRx prescription number field$")
	public void i__click_on_content_tooltip_of_BriovaRx_prescription_number_field() {
		page.clickPrescriptionNumberToolTipBriovaRx();
	}

	@Then("^I should see an error message \"([^\"]*)\" on top$")
	public void iShouldSeeAnErrorMessageOnTop(String errMsg) {
		Assert.assertEquals("\"" + errMsg + "\"" + " error message is not displaying", errMsg, page.getErrorMessage());
	}

	@When("^I click the \"([^\"]*)\" button$")
	public void i_click_the_button(String buttonName) throws Throwable {
		Thread.sleep(500);
		page.clickButtonBySubmitTypeAndName(buttonName);
		Thread.sleep(7000);
	}

	@Given("I should see a OptumBank logo")
	public void iShouldSeeAOptumBankLogo() {
		Assert.assertTrue("Issue displaying OptumBank Logo", page.getOptumBankLogo().isDisplayed());
	}

	@Then("I should see the EmployeeID text box")
	public void iShouldSeeTheEmployeeIDTextBox() {
		Assert.assertTrue(page.getEmployeeIdTextBox().isDisplayed());
	}

	@Then("I should see \"([^\"]*)\" label$")
	public void iShouldSeeLabel(String text) {
		Assert.assertTrue("Label is not displayed: " + text, page.getRegisterWithLabel().isDisplayed());
		Assert.assertTrue(page.getRegisterWithLabel().getText().contains(text));
	}

	@Given("I should see a Disney logo")
	public void iShouldSeeADisneyLogo() {
		Assert.assertTrue("Issue displaying Disney Logo", page.getDisneyLogo().isDisplayed());
	}
	
	@Given("I should see a AARP logo")
	public void iShouldSeeBankAARPLogo() {
		Assert.assertTrue("Issue displaying AARP Logo" , page.getBankAARPLogo().isDisplayed());
	}
	
	@Then("^I should see Group Number with blue square$")
	public void iShouldSeeGroupNumberWithBlueSquare() {
		Assert.assertTrue("Group Number text with blue square is not displayed on the Modal Dialog",
				page.getGroupNumberWithBlueSquare().isDisplayed());
	}
	
	@Then("^I should see a Cardholder ID label with text box$")
	public void i_should_see_a_Cardholder_ID_label_with_text_box() {
		Assert.assertTrue("Issue in displaying the Cardholder ID label with text box",
				page.verifyIfCardholderIdLabelWithTextboxExist());
	}
	
	@Given("^I should see an Optum Logo below GN$")
	public void iShouldSeeAnOptumLogoBelowGN() {
		Assert.assertTrue("Issue in displaying the Optum logo below GN",
				page.verifyIfOptumLogoBelowGNIsDisplayed());
	}
	
	@Then("^I should see a Caregiver access code label with text box$")
	public void i_should_see_a_caregiver_label_with_text_box() {
		Assert.assertTrue("Issue in displaying the CareGiver label with text box",
				page.verifyIfcareGiverAccessCodeLabelWithTextboxExist());
	}

	@And("^I should see a BCBSSC logo$")
	public void i_should_see_a_BCBSSC_logo() {
		Assert.assertTrue("Issue in displaying BCBSSC Logo", page.getBCBSSCLogo().isDisplayed());
	}

	@Given("^I should see an OptumRx-AARP Logo$")
	public void i_should_see_an_OptumRxAARP_logo() {
		Assert.assertTrue("Issue displaying OptumRx-AARP Logo", page.verifyAARPOptumRxLogo());
	}
	
	@Given("^I should see an OptumRx-AHA Logo$")
	public void i_should_see_an_OptumRxAHA_logo() {
		Assert.assertTrue("Issue displaying OptumRx-AHA Logo", page.verifyAHAOptumRxLogo());
  }
  
	@Given("^I should see an AMERIHEALTH Logo$")
	public void i_should_see_an_AMERIHEALTH_logo() {
		Assert.assertTrue("Issue displaying AMERIHEALTH Logo", page.verifyAMERIHEATLHLogo());
	}

	@Then("^I should see a clickable UHC Logo$")
	public void iShouldSeeClickableUHCLogo() {
		Assert.assertTrue("Issue displaying UHC Logo", page.verifyClickableUHCLogo());
	}
	
	@Then("^I should see a clickable Railroad Logo$")
	public void iShouldSeeClickableRailroadLogo() {
		Assert.assertTrue("Issue displaying Railroad Logo", page.verifyClickableRailroadLogo());
	}
}
