package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;
import com.optum.synergy.reference.ui.pageobjects.PHPUnauthenticatedHomePage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class PHPUnauthenticatedHomePageStepDefinition {

	private PHPUnauthenticatedHomePage page;

	public PHPUnauthenticatedHomePageStepDefinition() {
		page = new PHPUnauthenticatedHomePage();
	}

	@Given("^I am at PHP unauthenticated home page$")
	public void i_am_at_PHP_unauthenticated_home_page() {
		page.openPHPHomePage();
		Assert.assertTrue("Issue while loading the PHP Unauthenticated page", page.isPageLoaded());
	}

	@Then("^I should be at PHP unauthenticated home page$")
	public void iShouldBeAtPHPUnauthenticatedHomePage() {
		Assert.assertTrue("Issue while loading unauthenticated page", page.isPageLoaded());
	}
}