package com.optum.synergy.reference.ui.pageobjects;

import com.optum.synergy.reference.ui.utility.DataStorage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import com.optum.synergy.reference.ui.utility.ReadEmail;

public class ConfirmYourIdentityPage_securityQuestions extends PageObjectBase {

	private int RBAChallengeCount;

//	@FindBy(how = How.CLASS_NAME, using = "form__content")---This was for old ui and below one is common in both in old and new both
	@FindBy(how = How.XPATH, using = "//*[@id='formContainer']|//*[@id='question-authentication-challenge-form']")
	private WebElement formContent;

	@FindBy(how = How.XPATH, using = "//*[@id='authQuestionWrapper']|//*[@id='question-authentication-challenge-form']")
	private WebElement confirmYourIdentityFormSQA;

	@FindBy(how = How.XPATH, using = "//*[@id='authoobWrapper']|//*[@id='phone-authentication-method-form']")
	private WebElement confirmYourIdentityFormPhone;
	
	@FindBy(how = How.XPATH, using = "//*[@id='authOobTextRadio']|.//*[@id='phoneInfoForm']/flex/flex-content[2]//a[text()='Text me']|//*[@id='phoneInfoForm']//flex-content[contains(@ng-class,'TextAfterConfirm')]//a[contains(.,'Text me')]|//div[@class='textMessage']/input")
	private WebElement textMessageRadio;

	@FindBy(how = How.XPATH, using = "//*[@name='rememberThisDevice']|//*[@for='rememberMe']|//*[@id='rememeberLabel']")
	private WebElement rememberThisDeviceSection;

	@FindBy(how = How.XPATH, using = "//*[@id='continueSubmitButton']|//*[@id='qnaSubmitButton']|.//*[@id='phoneInfoForm']//button[text()='Submit']|//*[@id='submitBtn']")
	private WebElement continueButton;
	
	@FindBy(how = How.XPATH, using = ".//*[@id='sqForm']/div[3]/p/button")
	private WebElement forgotPasswordContinueButton;

	@FindBy(how = How.XPATH, using = "//*[@id='verifyAuthPasscodeInput']|//*[@id='confirmationCode']")
	private WebElement confirmationTextPassCode;

	@FindBy(how = How.XPATH, using = "//*[@id='challengeQuestionList[0].userAnswer']|//*[@id='Q10.1']|//*[@id='Q10.2']|//*[@id='Q10.3']")
	private WebElement securityAnswerTextbox;

	@FindBy(how = How.ID, using = "answer-0")
	private WebElement resetPasswordSecurityAnswerFirstTextbox;
	
	@FindBy(how = How.ID, using = "answer-1")
	private WebElement resetPasswordSecurityAnswerSecondTextbox;
	
	@FindBy(how = How.XPATH, using = "//div[@ng-show='pageError']//span[@ng-if='!errElementId']"
			+ "|//div[@id='pageErrors']//span[@ng-if='!errElementId']")
	private WebElement fpsqaErrorMessage;
	
	@FindBy(how = How.ID, using = "authQuesWrongAnswerErrorId")
	private WebElement sqaErrorMessage;

	@FindBy(how = How.CSS, using = ".error>span")
	private WebElement confirmationCodeErrorMessage;

	@FindBy(how = How.XPATH, using = "//*[@id='challengeQuestionList0.userAnswer.errors']|//*[@id='userCommand.errors']")
	private WebElement sqaFieldValidationErrorMessage;	

	@FindBy(how = How.XPATH, using = "//*[@id='oneTimePassword.value.errors']|//div[@class='errorOtp']")
	private WebElement confirmationCodeValidationErrorMessage;

	@FindBy(how = How.XPATH,using = "//div[@id='verifyemail' or @id='verifyEmailOnly']//p")
	private WebElement verifyLoginEmail;

	public boolean verifyIfPageLoadedSQA() {
		try {
			waitForJavascriptToLoad(10000, 1000);
			WebElement RBASQA = mediumWait.get().until(ExpectedConditions.visibilityOf(confirmYourIdentityFormSQA));
			if(RBASQA.isDisplayed())
				RBAChallengeCount++;
			return RBASQA.isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}catch(StaleElementReferenceException e){
			try{
				return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmYourIdentityFormSQA)).isDisplayed();
			}catch(Exception f){
				return false;
			}
		}
	}

	public boolean verifyIfPageLoadedPhone() {
		try {
			waitForPageLoad(driver);
			WebElement RBAPhone =  mediumWait.get().until(ExpectedConditions.visibilityOf(confirmYourIdentityFormPhone));
			if(RBAPhone.isDisplayed())
				RBAChallengeCount++;
			return RBAPhone.isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}

	public boolean verifyFormContent(String content) {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(formContent)).getText().contains(content);
	}

	public boolean verifyIfRememberThisDeviceSectionDisplayed() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(rememberThisDeviceSection)).isDisplayed();
	}

	public boolean verifyIfSecurityQuestionIsDisplayed() {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.id("authQuestiontextLabelId")))
				.isDisplayed();
	}

	public void clickContinueButton() {
		waitForJavascriptToLoad(10000, 1000);
		mediumWait.get().until(ExpectedConditions.visibilityOf(continueButton));
		clickByJavaScript(continueButton);
		waitForJavascriptToLoad(10000, 250);
	}
	
	public void clickForgotPasswordContinueButton() {
		waitForJavascriptToLoad(10000, 1000);
		mediumWait.get().until(ExpectedConditions.visibilityOf(forgotPasswordContinueButton));
		clickByJavaScript(forgotPasswordContinueButton);
		waitForJavascriptToLoad(10000, 250);
	}
	
	public void enterIncorrectConfirmationCodebytextmessage() {
  		waitForJavascriptToLoad(10000, 1000); 
  		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmationTextPassCode)).sendKeys("123456");
 	}

	public void enterSecurityAnswer(String answer) {
		waitForPageLoad(driver);
		waitForJavascriptToLoad(30000, 2000);
		mediumWait.get().until(ExpectedConditions.visibilityOf(securityAnswerTextbox));
		securityAnswerTextbox.clear();
		securityAnswerTextbox.sendKeys(answer);
	}
	
	public void enterResetPasswordSecurityAnswer(String answer) {
		waitForPageLoad(driver);
		waitForJavascriptToLoad(30000, 2000);
		mediumWait.get().until(ExpectedConditions.visibilityOf(resetPasswordSecurityAnswerFirstTextbox));
		mediumWait.get().until(ExpectedConditions.visibilityOf(resetPasswordSecurityAnswerSecondTextbox));
		resetPasswordSecurityAnswerFirstTextbox.clear();
		resetPasswordSecurityAnswerSecondTextbox.clear();
		resetPasswordSecurityAnswerFirstTextbox.sendKeys(answer);
		resetPasswordSecurityAnswerSecondTextbox.sendKeys(answer);
	}

	public void enterValidSecurityAnswer() throws Exception {
		Thread.sleep(2000);
		String SecurityQtn = mediumWait.get()
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='authQuestiontextLabelId']|//label[@for='Q10.1']|//label[@for='Q10.2']|//label[@for='Q10.3']"))).getText();
		WebElement answerField = mediumWait.get()
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='challengeQuestionList[0].userAnswer']|//*[@id='Q10.1']|//*[@id='Q10.2']|//*[@id='Q10.3']")));
		answerField.clear();
		formContent.click();

		if (SecurityQtn.contains("number")) {
			answerField.sendKeys("number1");
		} else if (SecurityQtn.contains("name")) {
			answerField.sendKeys("name1");
		} else if (SecurityQtn.contains("team")) {
			answerField.sendKeys("team1");
		} else if (SecurityQtn.contains("color")) {
			answerField.sendKeys("color1");
		} else {
			throw new Exception("unknown challenge " + SecurityQtn);
		}
		formContent.click();
	}

	public void clickTextRadioButton() {
		waitForPageLoad(driver);
		waitForJavascriptToLoad(30000, 2000);
		mediumWait.get().until(ExpectedConditions.visibilityOf(textMessageRadio)).click();
	}

	public void enterConfirmationCodebytextmessage() {
		waitForJavascriptToLoad(10000, 1000);
		String OTP = ReadEmail.getOTPFromEmail();
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmationTextPassCode)).sendKeys(OTP);
	}

	public boolean verifyForRadioButton(String name) {
		return mediumWait.get().until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//div[contains(@class,'radio') and contains(.,'" + name + "')]")))
				.isDisplayed();
	}

	public String getSQAErrorMessage() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(sqaErrorMessage)).getText();
	}

	public String getFPSQAErrorMessage() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(fpsqaErrorMessage)).getText();
	}

	public String getConfirmationCodeErrorMessage() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmationCodeErrorMessage)).getText();
	}
	
	public String getConfirmationCodeErrorMessageForgotPassword() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(fpsqaErrorMessage)).getText();
	}

	public String getSQAFieldValidationErrorMessage() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(sqaFieldValidationErrorMessage)).getText();
	}

	public String getConfirmationCodeValidationErrorMessage() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmationCodeValidationErrorMessage))
				.getText();
	}

	public WebElement getGradientBar(String hexColor1, String hexColor2) {
		return mediumWait.get()
				.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//div[@id='ognheader' and contains(@modeldata,'\"gradientcolor1\":\"" + hexColor1
								+ "\",\"gradientcolor2\":\"" + hexColor2 + "\"')]")));
	}
	
	public WebElement getGradientBarElement(String rgbColor1, String rgbColor2) {
		return mediumWait.get()
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@class='gradientBorder' and contains(@style,'"+rgbColor1+", "+rgbColor2+"')]")));
	}
	
	public void clickTheContinueButton() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(continueButton));
		clickByJavaScript(continueButton);
	}

	public boolean validateRememberThisDeviceToolTipLabel() {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//*[@id='messageBoxLink']"))).isDisplayed();
	}

	public void mouseHoverOnRememberThisDeviceToolTipLabel () {
		mouseHoverOnElement(mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//*[@id='messageBox']/*[contains(.,'Only select this option if you are using a private device, such as your personal computer. It is not recommended for public devices, such as a library or school computer.')]"))));
	}

	public void verifyRBAChallengeCount() {
		Assert.assertEquals("Unexpected RBA Challenge Count",1,RBAChallengeCount);
	}

	public boolean isEmailDisplayedAndMasked() {
		mediumWait.get().until(ExpectedConditions.visibilityOf(verifyLoginEmail));
		String originalEmail = DataStorage.getEmailId().toLowerCase();
		String[] arrEmail = originalEmail.split("@", 2);
		if(arrEmail[0].length()==1){
			return verifyLoginEmail.getText().contains(originalEmail);
		}
		String maskedString = arrEmail[0].substring(1, arrEmail[0].length() - 1).replaceAll(".", "*");
		String maskedEmail = arrEmail[0].charAt(0) + maskedString + arrEmail[0].charAt(arrEmail[0].length() - 1) + "@" + arrEmail[1];
		if (verifyLoginEmail.getText().contains(maskedEmail)) {
			return true;
		} else {
			DataStorage.setCustomErrmsg("Expected masked email [" + maskedEmail + "] not found");
			return false;
		}
	}
}
