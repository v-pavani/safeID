package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class UpdateYourAccountRecoverySettingsPage extends PageObjectBase  {
	
	@FindBy(how = How.XPATH, using = "//*[@id='profile-link']|//*[@id='global-profile-container']//a[text()='Sign In & Security']"
			+ "|//*[@id='usermenu']//a[text()='Sign In & Security']|//a[@class='dropdown-item']//i|//a[@id='profile-link']//*[@class='material-icons']"
			+ "|//*[@id='gnav-profile-Sign_In_&_Security']")
	 private WebElement clickSignInSecurity;
	
	@FindBy(how = How.CLASS_NAME, using = "account_settings")
	private WebElement updateSecuritySettingsSection;
	
	@FindBy(how = How.XPATH, using = "//*[@id='confirmPassword']|//*[@id='updatecurrentPasswordInput']|//*[@id='currentPassword']")
	private WebElement currentPasswordTextBox;
	
	@FindBy(how = How.XPATH, using = "//*[@id='confirmPassword']")
	private WebElement confirmPwdField ;
	
	@FindBy(how = How.XPATH, using = "//div[@class='ruletip']|//div[@class='password-field-container']/following-sibling::div[contains(@class,'ruletip')]")
	private WebElement passwordRules;

	@FindBy(how = How.XPATH, using = ".//*[@id='password']|//*[@id='updatenewPasswordInput']")
	private WebElement newPwdField ;

	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(updateSecuritySettingsSection)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public void submitSignInSecurity() {
		clickSignInSecurity.click();
	}
	
	public boolean verifyErrorMessageOnSecurityQuestion1(String message) {
		return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//select[@id='q1']/following-sibling::span[contains(@class,'error') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
	
	public boolean verifyErrorMessageOnSecurityQuestion2(String message) {
		return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//select[@id='q2']/following-sibling::span[contains(@class,'error') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
	public boolean verifyErrorMessageOnSecurityQuestion3(String message) {
		return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//select[@id='q3']/following-sibling::span[contains(@class,'error') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
	
	public boolean verifyErrorMessageOnSecurityAnswer1(String message) {
		return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//input[@id='a1']/following-sibling::span[contains(@class,'error') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
	
	public boolean verifyErrorMessageOnSecurityAnswer2(String message) {
		return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//input[@id='a2']/following-sibling::span[contains(@class,'error') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
	
	public boolean verifyErrorMessageOnSecurityAnswer3(String message) {
		return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//input[@id='a3']/following-sibling::span[contains(@class,'error') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
	
	public boolean verifyErrorMessageOnUpdateNewEmail(String message) {
		return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//input[@id='email']/following-sibling::span[contains(@class,'error') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
	
	public boolean verifyLinkIsNotDisplayed(String linkText){
		return getAnchorElementByText(linkText)==null;
	}
	
	public void enterConfirmNewPassword(String confirmPassword)	{
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmPwdField));
		confirmPwdField.clear();
		confirmPwdField.sendKeys(confirmPassword);
	}
	
	public boolean verifyErrForOldPwdWrong(String message) {
		return longWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//p[contains(@class,'error-text') and contains(.,'"+message+"')]|//span[contains(@class,'ng-binding') and contains(.,'"+message+"')]")))
				.isDisplayed();	
	}
	
	public boolean verifyRuleTipMessage(String message) {
		return passwordRules.getText().contains(message);
	}
	
	public boolean verifyErrorInvalidCurrentPwd(String message) {
		return longWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//input[@id='currentPassword']/parent::div[@class='password-field-container']/following-sibling::div[contains(@class,'error') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
		
	public boolean verifyErrorInvalidNewPwd(String message) {
		return longWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//input[@id='password']/following-sibling::span[contains(@class,'error') and contains(.,'"
						+ message + "')]|//input[@id='password']/parent::div[@class='password-field-container']/parent::div[@class='tooltip']/following-sibling::div[contains(@class,'error') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
	
	public boolean verifyErrorInvalidConfirmPwd(String message) {
		return longWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//input[@id='confirmPassword']/following-sibling::span[contains(@class,'error') and contains(.,'"
						+ message + "')]|//input[@id='confirmPassword']/parent::div[@class='password-field-container']/following-sibling::div[contains(@class,'error') and contains(.,'"
						+ message + "')]")))
				.isDisplayed();
	}
	
	public boolean verifyErrorNewPhoneNo(String message) {
		return smallWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//input[@id='phoneNo']/following-sibling::p[contains(@class,'error') and contains(.,'"+ message + "')]| //span[contains(@class,'error') and contains(.,'"+ message + "')]")))
				.isDisplayed();
	}
	
	public void enterCurrentPassword(String password) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(currentPasswordTextBox));
		currentPasswordTextBox.clear();
		currentPasswordTextBox.sendKeys(password);
	}

	public void enterNewPassword(String newpassword) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(newPwdField));
		newPwdField.clear();
		newPwdField.sendKeys(newpassword);
	}
	
}