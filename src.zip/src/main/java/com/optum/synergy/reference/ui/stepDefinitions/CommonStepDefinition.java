package com.optum.synergy.reference.ui.stepDefinitions;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.optum.synergy.reference.ui.pageobjects.BriovaRxUnauthenticatedHomePage;
import com.optum.synergy.reference.ui.pageobjects.PageObjectBase;
import com.optum.synergy.reference.ui.pageobjects.Registration_ConfirmEmailSectionPage;
import com.optum.synergy.reference.ui.pageobjects.Registration_CreateAccountSectionPage;
import com.optum.synergy.reference.ui.pageobjects.Registration_PersonalInformationSectionPage;
import com.optum.synergy.reference.ui.pageobjects.SignInPage;
import com.optum.synergy.reference.ui.utility.DataStorage;
import com.optum.synergy.reference.ui.utility.DriverFactory;
import com.optum.synergy.reference.ui.utility.ReadEmail;
import com.optum.synergy.reference.ui.utility.ReadXMLData;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class CommonStepDefinition {

	PageObjectBase page = new PageObjectBase();
	String winHandleBefore;
	String winHandleNew;

	public CommonStepDefinition() {
	}

	@When("^I navigate to URL \"([^\"]*)\"")
	public void openURL(String url) {
		page.openPage(url);
	}

	@Given("^I get the following details for the member \"([^\"]*)\" from xml file$")
	public void i_get_the_following_details_for_the_member_from_xml_sheet(String member, List<String> inputKeys)
			throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {

		String xmlRoot = DataStorage.getPortalName() + "/Users/" + member;
		DataStorage.setuserRootNode(xmlRoot);
		// Loop through each key provided in input List, invoke
		// "DataStorage.set{key}()"
		// passing in data retrieved from XML file
		for (String key : inputKeys) {
			Class<?> cls = Class.forName("com.optum.synergy.reference.ui.utility.DataStorage");
			Method method = cls.getDeclaredMethod("set" + key, String.class);

			if ( key.equalsIgnoreCase("password") && "prod".equalsIgnoreCase(System.getProperty("ExecutionEnv")) ) {
				DataStorage.setCustomErrmsg("Member XML Data::" + xmlRoot + "/" + key + " = **MASKED**");
			} else {
				DataStorage.setCustomErrmsg(
					"Member XML Data::" + xmlRoot + "/" + key + " = " + ReadXMLData.getTestData(xmlRoot, key));
			}
			method.invoke(null, ReadXMLData.getTestData(DataStorage.getPortalName() + "/Users/" + member, key));
		}
	}

	@Given("^I get the following details for the login \"([^\"]*)\" from xml file$")
	public void i_get_the_following_details_for_the_login_from_xml_sheet(String member, List<String> inputKeys)
			throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {

		String xmlRoot = DataStorage.getPortalName() + "/Logins/" + member;
		DataStorage.setuserRootNode(xmlRoot);
		// Loop through each key provided in input List, invoke
		// "DataStorage.set{key}()"
		// passing in data retrieved from XML file
		for (String key : inputKeys) {

			String testDataFromXML = ReadXMLData.getTestData(xmlRoot, key);

			if ( key.equalsIgnoreCase("password") && "prod".equalsIgnoreCase(System.getProperty("ExecutionEnv")) ) {
				DataStorage.setCustomErrmsg("Login XML Data::" + xmlRoot + "/" + key + " = **MASKED**");
			} else {
				DataStorage.setCustomErrmsg("Login XML Data::" + xmlRoot + "/" + key + " = " + testDataFromXML);
			}

			Class<?> cls = Class.forName("com.optum.synergy.reference.ui.utility.DataStorage");
			Method method = cls.getDeclaredMethod("set" + key, String.class);
			method.invoke(null, testDataFromXML);
		}
	}

	/**
	 * Step definition for reading the data from common section in test data file.
	 * @param section
	 * @param member
	 * @param inputKeys
	 * @throws Exception
	 */
	@Given("^I get following user details for the (member|login) \"([^\"]*)\" from xml file$")
	public void i_get_the_following_commondata_xml_sheet(String section, String member, List<String> inputKeys) throws Exception{

		String xmlRoot = "";
		if(section.equalsIgnoreCase("Member"))
		xmlRoot= "CommonData" + "/Users/" + member;
		else
			xmlRoot = "CommonData" + "/Logins/" + member;
		DataStorage.setuserRootNode(xmlRoot);
		// Loop through each key provided in input List, invoke
		// "DataStorage.set{key}()"
		// passing in data retrieved from XML file
		for (String key : inputKeys) {

			String testDataFromXML = ReadXMLData.getTestData(xmlRoot, key);

			if ( key.equalsIgnoreCase("password") && "prod".equalsIgnoreCase(System.getProperty("ExecutionEnv")) ) {
				DataStorage.setCustomErrmsg("Login XML Data::" + xmlRoot + "/" + key + " = **MASKED**");
			} else {
				DataStorage.setCustomErrmsg("Login XML Data::" + xmlRoot + "/" + key + " = " + testDataFromXML);
			}

			Class<?> cls = Class.forName("com.optum.synergy.reference.ui.utility.DataStorage");
			Method method = cls.getDeclaredMethod("set" + key, String.class);
			method.invoke(null, testDataFromXML);
		}
	}

	@When("^I click the tab key$")
	public void i_click_tab_key() {
		page.clickTab();
	}

	@When("^I click browser back button$")
	public void i_click_browser_back_button() {
		page.clickBrowserBackButton();
	}

	@When("^I click \"([^\"]*)\" link$")
	public void i_click_link(String link) {
		page.clickLink(link);
	}

	@When("^I click on \"([^\"]*)\" button$")
	public void i_click_on_button(String buttonName) throws Throwable {
		Thread.sleep(500);
		page.clickButtonBySubmitTypeAndName(buttonName);
		Thread.sleep(1000);
	}

	@When("^I should see \"([^\"]*)\" input button$")
	public void i_should_see_input_button(String buttonName) {
		Assert.assertTrue(" input button is not displaying on the page",
				page.verifytheInputButtonIsDisplayed(buttonName));
	}

	@When("^I should see \"([^\"]*)\" link button is displayed$")
	public void i_should_see_link_button(String link) throws Throwable {
		Assert.assertTrue("\"" + link + "\" link button is not displaying on the page",
				page.verifytheLinkButtonIsDisplayed("button",link));
	}

	@When("^I click on \"([^\"]*)\" link button$")
	public void i_click_on_link_button_on_the_Confirm_Email_page_for_mobile(String link) {
		page.clickElementByClassNameAndText("button",link);
	}

	@Then("^I should see the \"([^\"]*)\" page heading$")
	public void i_should_see_the_page_heading(String heading) {
		if("LAWW".equalsIgnoreCase(DataStorage.getPortalName())){
			String heading1 = PageObjectBase.getAEMContent(DataStorage.getPortalName(), "PageContent", heading);
			boolean isFound = page.verifyPageHeadingByH1newTag(heading) || page.verifyPageHeadingByH1Tag(heading1);
			if(!isFound) {
				new PageObjectBase().isContentFailure.set(true);
				Assert.fail("Expected heading is not getting displayed on page: ["+heading1+"]");
			}

		}else {
			Assert.assertTrue("\"" + heading + "\" heading is not displaying on the page",
					page.verifythePageHeadingByH1Tag(heading));
		}
	}

	@Then("^I should see the sub-heading \"([^\"]*)\"$")
	public void i_should_see_the_sub_heading(String subHeading) {
		if("LAWW".equalsIgnoreCase(DataStorage.getPortalName())){
			String subHeading1 = PageObjectBase.getAEMContent(DataStorage.getPortalName(), "PageContent", subHeading);
			boolean isFound = page.verifySubHeadingByH2Tag(subHeading1);
			if (!isFound) {
				new PageObjectBase().isContentFailure.set(true);
				Assert.fail("Expected sub heading is not getting displayed on page: [" + subHeading1 + "]");
			}
		}else {
			Assert.assertTrue("\"" + subHeading + "\" sub heading is not displaying on the page",
					page.verifytheSubHeadingByH2Tag(subHeading));
		}
	}

	@Then("^I should see the form heading \"([^\"]*)\"$")
	public void i_should_see_the_form_heading(String subHeading) {
		Assert.assertTrue("\"" + subHeading + "\" sub heading is not displaying on the page",
				page.verifytheSubHeadingByPTag(subHeading));
	}

	@Then("^I should see the form span content \"([^\"]*)\"$")
	public void i_should_see_the_form_span_content(String subHeading) {
		Assert.assertTrue("\"" + subHeading + "\" sub heading is not displaying on the page",
				page.verifytheSubHeadingByspan(subHeading));
	}

	@Then("^I should see a new tab opened and switch to it$")
	public void i_should_see_a_new_tab_opened_and_switch_to_it() {

		// TODO: Assumes started with single tab and opening a second
		// may want more general-purpose implementation
		PageObjectBase.mediumWait.get().until(ExpectedConditions.numberOfWindowsToBe(2));
		WebDriver driver = DriverFactory.getDeviceDriver();
		winHandleBefore = driver.getWindowHandle();
		Set<String> windows = driver.getWindowHandles();
		Assert.assertTrue("New browser window is not opened", windows.size() > 1);
		for (String winHandle : driver.getWindowHandles()) {
			winHandleNew = winHandle;
			if(!winHandleBefore.equalsIgnoreCase(winHandleNew)) {
				driver.switchTo().window(winHandle);
				break;
			}
		}
		driver.switchTo().defaultContent();
		page.waitForPageLoad(driver);

	}

	/**
	 * Step for closing all tabs but current one
	 * @throws Throwable
	 */
	@Then("^I close the previous tabs$")
	public void i_close_the_previous_tab() {
		WebDriver driver = DriverFactory.getDeviceDriver();
		Set<String> windows = driver.getWindowHandles();
		Assert.assertTrue("More than 1 browser windows are not there to close", windows.size() > 1);
		String currentWindow = driver.getWindowHandle();

		for(String winHandle : windows) {
			driver.switchTo().window(winHandle);
			if(!winHandle.equalsIgnoreCase(currentWindow))
				driver.close();
		}

		driver.switchTo().window(currentWindow);
		driver.switchTo().defaultContent();
	}

	@Then("^I should see a new tab opened for \"([^\"]*)\" and switch to it$")
	public void i_should_see_a_new_tab_opened_and_switch_to_that(String arg1) throws Throwable {
		// Give new tab two seconds to launch and populate
		Thread.sleep(2000);

		// TODO: Assumes started with single tab and opening a second
		// may want more general-purpose implementation
		PageObjectBase.mediumWait.get().until(ExpectedConditions.numberOfWindowsToBe(2));
		WebDriver driver = DriverFactory.getDeviceDriver();
		Set<String> windows = driver.getWindowHandles();
		Assert.assertTrue("New browser window is not opened", windows.size() > 1);
		boolean found = false;
		for (String winHandle : driver.getWindowHandles()) {

			driver.switchTo().window(winHandle);
			page.waitForPageLoad(driver);
			if (driver.getCurrentUrl().contains(arg1)) {
				found = true;
				winHandleNew = winHandle;
				break;
			} else {
				winHandleBefore = winHandle;
			}
			driver.switchTo().defaultContent();
		}
		Assert.assertTrue("Failed to find tab with [" + arg1 + "], last tab url [" + driver.getCurrentUrl() + "]",
				found);
	}


	@Then("^I should copy the (.*) url to browser$")
	public void I_should_copy_the_confirm_email_url_to_browser(String linkType) {
		page.deleteCookies();
		page.openPage(DataStorage.getConfirmregistrationurl());
	}

	@Then("^I should copy the confirm email url to newtab in the browser$")
	public void I_should_copy_the_confirm_email_url_to_newtab_in_the_browser() {
		page.openNewTab();
		page.openPage(DataStorage.getConfirmregistrationurl());
	}

	@Then("^I should copy the sign in url to browser$")
	public void I_should_copy_the_sign_in_to_browser() {
		page.deleteCookies();
		page.openPage(DataStorage.getConfirmregistrationurl());
	}

	@Then("^I close the new tab and switch back to previous tab$")
	public void i_close_the_new_tab_and_switch_back_to_previous_tab() {
		WebDriver driver = DriverFactory.getDeviceDriver();
		Set<String> windows = driver.getWindowHandles();
		Assert.assertTrue("More than 1 browser windows are not there to close", windows.size() > 1);
		/*
		 * String winHandleBefore = driver.getWindowHandle(); for(String
		 * winHandle : driver.getWindowHandles()){
		 */
		if (driver.getWindowHandle().equals(winHandleNew)) {
			driver.close();
			driver.switchTo().window(winHandleBefore);
			driver.switchTo().defaultContent();
		}

	}

	@Then("^I open a new window tab in browser$")
	public void iOpenANewWindowTabInBrowser() {
		page.openNewTab();
	}

	@Then("^I switch back to previous tab in browser$")
	public void iSwitchBackToPreviousTabInBrowser() {
		page.switchBackToPreviousTab();
	}

	@Then("^I switch to next tab in browser$")
	public void iSwitchBackToNextTabInBrowser() {
		page.switchToNextTab();
	}

	@Then("^I refresh the current window tab$")
	public void iRefreshTheCurrentWindowTab() {
		page.refreshPage();
		page.switchToDefaultContent();
	}

	@Then("^I should switch to next tab$")
	public void i_should_switch_to_next_tab() {
		page.switchToNextTab();
	}

	@Then("^I switch to next window$")
	public void i_switch_to_next_window() throws Throwable {
		page.switchToNextWindow();
	}

	@Then("^I close the current window$")
	public void i_close_the_current_window() {
		page.closeCurrentWindowOfheBrowser();
	}

	@Then("^I should switch to previous window$")
	public void i_close_the_previous_window() {
		page.switchToPreviousWindow();
	}

	@Given("^I switch back to previous tab$")
	public void i_switch_back_to_previous_tab() {
		page.switchBackToPreviousTab();
	}

	@Then("^I should see an optum \"([^\"]*)\" logo$")
	public void i_should_see_an_optum_logo(String arg1) {

		Assert.assertTrue("Issue while displaying the " + arg1, PageObjectBase.mediumWait.get()
				.until(ExpectedConditions.presenceOfElementLocated(By.className(arg1))) != null);
	}

	@Then("^I should see a \"([^\"]*)\" button$")
	public void i_should_see_a_button(String buttonName) {
		if("LAWW".equalsIgnoreCase(DataStorage.getPortalName())){
			String buttonNam1e = PageObjectBase.getAEMContent(DataStorage.getPortalName(), "PageContent", buttonName);

			boolean isFound = page.verifyButtonBySubmitTypeAndName(buttonNam1e);

			if (!isFound) {
				new PageObjectBase().isContentFailure.set(true);
				Assert.fail("Button is not displayed on the page: "+buttonNam1e);
			}
		}else {
			Assert.assertTrue(page.verifyButtonBySubmitTypeAndName(buttonName));
		}
	}

	@Then("^I click on \"([^\"]*)\" partial link$")
	public void i_click_on_partial_link(String partialLink) throws Throwable {
	    page.clickPartialLink(partialLink);
		Thread.sleep(1000);
	}

	@Then("^I see a link for \"([^\"]*)\"$")
	public void iShouldSeeALinkFor(String linkText) {
		Assert.assertTrue(page.findLinkText(linkText));
	}

	@Then("^I should see a \"([^\"]*)\" partial link$")
	public void i_should_see_a_partial_link(String link) {
		Assert.assertTrue(page.findPartialLinkText(link));
	}

	@When("^I click on the link \"([^\"]*)\"$")
	public void iClickOnTheLink(String linkText) {
		page.clickLink(linkText);
	}

	@When("^I click on the partial link \"([^\"]*)\"$")
	public void iClickOnThePartialLink(String linkText) {
		page.clickPartialLink(linkText);
	}

	@Then("^I should see a \"([^\"]*)\" link$")
	public void i_should_see_a_link(String linkName) {
		if("LAWW".equalsIgnoreCase(DataStorage.getPortalName())){
			String[] multipleKey = linkName.split("\\+");
			String linkName1 = "";
			for (String key : multipleKey) {
				key = key.trim();
				linkName1 += PageObjectBase.getAEMContent(DataStorage.getPortalName(), "PageContent", key);
				linkName1 = linkName1.trim();
				linkName1 += " ";
			}
			linkName1 = linkName1.trim();
			Assert.assertTrue("Link is not displayed on the page: "+linkName1,page.findLinkText(linkName1));
		}else {
			Assert.assertTrue(page.findLinkText(linkName));
		}
	}

	@When("^I click on \"([^\"]*)\" link$")
	public void i_click_on_link(String linkName) {
		page.clickLink(linkName);
	}

	@Then("^I should see a \"([^\"]*)\" checkbox with \"([^\"]*)\" label$")
	public void i_should_see_a_checkbox_with_label(String id, String label) {
		Assert.assertTrue(page.verifyCheckboxAndAssociatedLabel(label, id));
	}

	@Then("^I should see a \"([^\"]*)\" checkbox with \"([^\"]*)\" icon$")
	public void i_should_see_a_checkbox_with_icon(String text, String id) {
		Assert.assertTrue("Failed to find element with id [" + id + "]", page.verifyElementById(id));
		Assert.assertTrue("Failed to find checkbox with [" + text + "]", page.verifyTextByClassName("checkbox", text));
	}

	@Then("^I check the \"([^\"]*)\" icon$")
	public void i_check_the_icon(String iconId) {
		page.clickElementById(iconId);
	}

	@Then("^I check the \"([^\"]*)\" checkbox$")
	public void i_check_the_checkbox(String iconId) {
		page.clickElementById(iconId);
	}

	@Then("^I should see the \"([^\"]*)\" button$")
	public void i_should_see_the_button(String buttonName) {
		Assert.assertTrue(page.verifyButtonByText(buttonName));
	}

	@When("^I click on the \"([^\"]*)\" button$")
	public void i_click_on_the_button(String buttonName) {
		page.clickButtonByText(buttonName);
	}

	@When("^I click on \"([^\"]*)\" radio button$")
	public void i_click_on_radio_button(String radioButtonId) {
		page.clickElementById(radioButtonId);
	}

	@Then("^I should see a \"([^\"]*)\" security questions panel$")
	public void i_should_see_a_panel(String panelId) {
		page.verifyElementById(panelId);
	}

	@Then("^I should see \"([^\"]*)\" link enabled$")
	public void i_should_see_link_enabled(String link) {
		Assert.assertTrue("link is not displyed or enabled", page.verifyLinkEnabled(link));
	}

	@Given("^test is running for \"([^\"]*)\"$")
	public void setuptheportalname(String arg1) {
		DataStorage.setPortalName(arg1);
	}

	@Then("^I delete the browser cookies$")
	public void I_delete_the_browser_cookies() {
		page.deleteCookies();
	}

	@Then("^I should see a modal dialog$")
	public void i_should_see_a_modal_dialog() {
		Boolean modalFound = PageObjectBase.mediumWait.get().until(
			ExpectedConditions.or(
				ExpectedConditions.visibilityOfElementLocated(By.className("modal__dialog")),
				ExpectedConditions.visibilityOfElementLocated(By.className("modal-dialog")),
				ExpectedConditions.visibilityOfElementLocated(By.className("modal-content")),
				ExpectedConditions.visibilityOfElementLocated(By.className("typography")),
				ExpectedConditions.visibilityOfElementLocated(By.className("modal__content")),
				ExpectedConditions.visibilityOfElementLocated(By.className("modal learnmore")),
				ExpectedConditions.visibilityOfElementLocated(By.className("modal__dialog terms")),
				ExpectedConditions.visibilityOfElementLocated(By.id("hsid-myModal-learnmore")),
				ExpectedConditions.visibilityOfElementLocated(By.id("hsid-wdgt-myModal-learnmore")),
				ExpectedConditions.visibilityOfElementLocated(By.id("hsid-wdgt-myModal-tc")),
				ExpectedConditions.visibilityOfElementLocated(By.className("modal__content base-padding--lg")),
                ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")),
					ExpectedConditions.visibilityOfElementLocated(By.id("rememberMeModal")),
					ExpectedConditions.visibilityOfElementLocated(By.id("textTermsModal")),
					ExpectedConditions.visibilityOfElementLocated(By.id("consumerNoticeModal"))
			));
		Assert.assertTrue("Failed to find any modal element",modalFound);
	}

	@Then("^I should see the modal heading \"([^\"]*)\"$")
	public void i_should_see_the_modal_heading(String arg1) throws InterruptedException {
		if("LAWW".equalsIgnoreCase(DataStorage.getPortalName())){
			Thread.sleep(2000);
			String heading = PageObjectBase.getAEMContent(DataStorage.getPortalName(), "PageContent", arg1);

			boolean isFound = page.verifySubHeadingByH2Tag(heading) || page.verifyPageHeadingByH1Tag(heading);

			if(!isFound) {
				new PageObjectBase().isContentFailure.set(true);
				Assert.fail("\"" + heading + "\"" + " heading is not displaying");
			}
		}else {
			Thread.sleep(2000);
			Assert.assertTrue("\"" + arg1 + "\"" + " heading is not displaying", page.verifytheSubHeadingByH2Tag(arg1));
		}
	}

	@Then("^I should see the pop up contains \"([^\\\"]*)\" message$")
	public void i_should_see_Pop_Up_Content_contains_message(String message) throws Throwable {
	    Assert.assertTrue("\""+message+"\" message is not diplaying on the pop up", page.verifyPopUpContent(message));
	}

	@Then("^I scroll the page up$")
	public void I_should_see_the_Link() {
		page.scrollthePageUp();
	}

	@Then("^I scroll the page down$")
	public void I_scroll_the_page_down() {
		page.scrollthePageDown();
	}

	@Then("^I should see a label with \"([^\"]*)\" heading and \"([^\"]*)\" text box$")
	public void i_should_see_a_label_with_heading_and_text_box(String fieldHeading, String textboxId) {
		Assert.assertTrue(page.verifyFieldNameAndAssociatedTextBox(fieldHeading, textboxId));
	}

	@Then("^I should navigate to portal url into new tab and close previous tab in the browser$")
	public void I_should_copy_the_OptumRx_url_to_newtab_in_the_browser() {
		page.openNewTabAndClosePreviousTab();
		page.openPage(ReadXMLData.getTestData(DataStorage.getPortalName(), "AppURL"));
	}

	@Then("^I should see the \"([^\"]*)\" drop down with options$")
	public void iShouldSeeTheDropDownWithOptions(String selectDropdownId, List<String> options) {
		Select dropdown = new Select(
				PageObjectBase.mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.id(selectDropdownId))));

		List<String> actualOptionsStr = new ArrayList<String>();
		for ( WebElement actOpt : dropdown.getOptions() ) {
			actualOptionsStr.add(actOpt.getText());
		}
		for ( String opt : options ) {
			Assert.assertTrue("Failed to find [" + opt + "] in dropdown [" + selectDropdownId + "]",
					actualOptionsStr.contains(opt));
		}
	}

	@Then("^I should be at \"([^\"]*)\" page$")
	public void verifyPageTitle(String title){
		Assert.assertEquals("Incorrect page", title, page.getPageTitle());
	}

	@Then("^I should see \"([^\"]*)\" button$")
	public void i_should_see_button(String buttonName) {
		Assert.assertTrue("Failed to find ["+buttonName+"] button", page.verifytheInputOfTypeButtonIsDisplayed(buttonName));
	}

	@When("^I click \"([^\"]*)\" button$")
	public void i_click_button(String buttonId) {
		page.clickElementById(buttonId);
	}

	@Then("^I should see \"([^\"]*)\" heading$")
	public void i_should_see_heading(String heading) {
		Assert.assertTrue("\"" + heading + "\" heading is not displaying on the page",
				page.verifytheSubHeadingByH2Tag(heading));
	}

	@When("^I should be navigated to \"([^\"]*)\" URL$")
	public void i_am_navigated_to(String url) {
		Assert.assertTrue("Navigated to incorrect URL: "+page.getCurrentPageUrl() , page.getCurrentPageUrl().contains(url));
	}

	@When("^I manage the \"([^\"]*)\" button$")
	public void i_manage_the_button(String buttonName) {
		try{
		page.clickButtonByText(buttonName);
		} catch(Exception e){
			System.out.println(buttonName+" Not displayed");
		}
	}

	@Then("^I should not see a latest unread mail recieved from \"([^\"]*)\" in mail server$")
	public void iShouldNotSeeALatestUnreadMailRecievedFromInMailServer(String mailSubject) {
		DataStorage.resetEmail();
		ReadEmail.retrieveMessage(DataStorage.getEmailId(), mailSubject);
		Assert.assertNull(null, DataStorage.getEmailSubject());
	}

	@When("^I wait for \"([^\"]*)\" seconds$")
	public void i_wait_for_seconds(String seconds) throws InterruptedException {
		page.waitTime(seconds);
	}

	@Then("^I should see a \"([^\"]*)\" link contains the url \"([^\"]*)\"$")
	public void iShouldSeeALinkContainsTheUrl(String linkName, String url) {
	    Assert.assertEquals( "\""+linkName+"\" link should contain the url"+ "\""+url+"\"",page.getURLAssociatedWithLink(linkName),url);
	}

	@Then("^I should see a clickable \"([^\"]*)\" link$")
	public void iShouldSeeAclickableLink(String linkName) {
	    Assert.assertTrue( "\""+linkName+"\" link is not clickable",page.verifyClickableLink(linkName));
	}

	@Then("^I should see valid URL for recaptcha Privacy Policy$")
	public void I_should_see_recaptcha_privacy_url() {
		boolean found = false;
		List<WebElement> privacyPolicyLink = page.getRecaptchPrivacyPolicyURL();
		String privacyPolicyURL = ReadXMLData.getTestData("/Urls/GoogleURL/","PrivacyPolicyURL");
		for(WebElement elem : privacyPolicyLink) {
			String URLOnUI = elem.getAttribute("href");
			if(URLOnUI.equals(privacyPolicyURL)) {
				found = true;
			}
		}
		Assert.assertTrue("Error: Incorrect URL for Recaptcha Privacy policy",found);

	}

	@Then("^I should see valid URL for recaptcha Terms of Service$")
	public void I_should_see_recaptcha_terms_url() {
		Assert.assertEquals("Error: Incorrect URL for Terms of Use",page.getRecaptchaTermsOfServiceURL(), ReadXMLData.getTestData("/Urls/GoogleURL/","TermsOfServiceURL"));

	}

	@Then("^I should see valid url for UHC Accessbility Statement link$")
	public void iShouldSeeValidUrlForUHCAccessbilityStatementLink() {
		Assert.assertTrue("UHC Aceessbility Information link is not available or url is wrong",
				page.isAccessbilityUHCUrlDisplayed());
	}

	@Then("^I should see valid url for Accessbility Statement link$")
	public void iShouldSeeValidUrlForAccessbilityStatementLink() {
		Assert.assertTrue("Aceessbility Information link is not available or url is wrong",
				page.isAccessbilityUrlDisplayed());
	}

	@Then("^I manage Survey modal by clicking \"([^\"]*)\"$")
	public void I_manageSurveyModal(String id) {
		try {
			page.clickElementById(id);
		} catch(Exception e) {

		}
	}

	@Then("^I should not be at HSID error page$")
	public void verifyNotAHSIDErrorPage() {
		Assert.assertFalse("HSID error page is displayed", page.isHSIDErrorPage());
	}

	/**
	 * @author vchaube1
	 * @param portalName
	 * 			For specifying the portal for which the registration needs to be done.
	 * @param registrationWith
	 * 			For specifying the ID type with which registration needs to be done.
	 * @param recoveryType
	 * 			For specifying the account recovery type for the user account.
	 * @throws InterruptedException
	 * 			 Thread.sleep() is used in the code.
	 *
	 * Step definition for complete user registration in HSID portals
	 */
	@Then("^I register member in \"([^\"]*)\" portal with (Valid|Dummy) email with (MemberID|SSN|CardHolderID|EmployeeID|PrescriptionID|Tier1_Data) and (SQA|Phone) recovery option$")
	public void registerUserInPortal(String portalName,String emailType, String registrationWith, String recoveryType) throws InterruptedException{
		portalName = portalName.toUpperCase();
		String URL = null;
		Registration_PersonalInformationSectionPage registrationStep1= new Registration_PersonalInformationSectionPage();
		Registration_CreateAccountSectionPage registrationStep2 = new Registration_CreateAccountSectionPage();
		Registration_ConfirmEmailSectionPage registrationStep3= new Registration_ConfirmEmailSectionPage();
        URL = page.getPortalURL(portalName);
        try {
            page.openPage(URL);
            Thread.sleep(15000);

            if (portalName.equals("BRIOVARX") || portalName.equals("OPTUMRX") ) {
               // page.clickButtonByText("Register");
                Thread.sleep(1000);
                //page.clickPartialLink("Patient Register");

            } else if (portalName.equals("BSCA")) {
                page.clickButtonByText("Register Now");

            } else if (portalName.equals("COMMUNITYPLAN")) {
                page.clickButtonByText("Register Now");

            } else if(portalName.contains("MNR")){
				page.clickButtonByText("Registration");

			} else {
                page.clickPartialLink("Register");
            }
            Assert.assertTrue("Failed to load Personal Information Page", registrationStep1.verifyIfPageLoaded());
        } catch (AssertionError | WebDriverException |NullPointerException e){
            String registerURL = ReadXMLData.getTestData(page.getPortalAndSubportalName(portalName)[0],page.getPortalAndSubportalName(portalName)[1]+"HSIDRegisterURL");
            Assert.assertFalse("HSIDRegister URL is null or empty in test data file",registerURL==null || registerURL.isEmpty());
            page.openPage(registerURL);
            Assert.assertTrue("Failed to load Personal Information Page", registrationStep1.verifyIfPageLoaded());
        }

		String fName = DataStorage.getFirstName();
		String lName = DataStorage.getLastName();
		String DOB = DataStorage.getDOB();
		String subscriberID = DataStorage.getSubscriberID();
		String zip = DataStorage.getZip();
		String SSN = DataStorage.getSSN();
		String prescriptionNumber = DataStorage.getPrescriptionNo();
		String cardHolderID = DataStorage.getCardholderID();
		String groupNumber = DataStorage.getGroupNumber();

		if(fName == null || lName == null || DOB == null)
			Assert.fail("FirstName/LastName/DOB: Some or all of these values are retrieved as null. Please check the data/data reading step");

		//Registration Step 1 page
		registrationStep1.enterFirstName(DataStorage.getFirstName());
		registrationStep1.enterLastName(DataStorage.getLastName());
		registrationStep1.enterDateOfBirth(DataStorage.getDOB());

		//Handling registration based on portalName and registrationWith
		if(portalName.contains("MNR") || portalName.equals("BAZ") || portalName.contains("OPTUMRX") || portalName.equals("PHP")) {
			if(!registrationWith.equals("MemberID"))
				Assert.fail("Incorrect registrationWith value for "+portalName+" portal: "+ registrationWith);
			if(zip == null || subscriberID == null)
				Assert.fail("SubscriberID/Zip: Some or all of these values are retrieved as null. Please check the data/data reading step");
			registrationStep1.enterZipCode(DataStorage.getZip());
			registrationStep1.enterMemberID(DataStorage.getSubscriberID());
		} else if(portalName.contains("BANK")) {
			if(zip == null)
				Assert.fail("Zip: is retrieved as null. Please check the data/data reading step");
			registrationStep1.enterZipCode(DataStorage.getZip());
			if(registrationWith.equals("EmployeeID")) {
				if(subscriberID == null)
					Assert.fail("SubscriberID: is retrieved as null. Please check the data/data reading step");
				registrationStep1.selectRegisterWith("Employee ID (if instructed by your employer)");
				registrationStep1.enterMemberID(DataStorage.getSubscriberID());
			} else if(registrationWith.equals("SSN")){
				if(SSN == null)
					Assert.fail("SSN: is retrieved as null. Please check the data/data reading step");
				registrationStep1.selectRegisterWith("Social Security Number (last 6 digits)");
				registrationStep1.enterSSN(DataStorage.getSSN());
			} else {
				Assert.fail("Incorrect registrationWith value for "+portalName+" portal: "+ registrationWith);
			}
		}  else if (portalName.equals("SERVEYOU") || portalName.equals("AHC") || portalName.equals("TCC") || portalName.equals("PAI") || portalName.equals("BCBSSC") || portalName.equals("AMERIHEALTH") || portalName.equals("IBX") || portalName.equals("AHA")) {
			if(!registrationWith.equals("CardHolderID"))
				Assert.fail("Incorrect registrationWith value for "+portalName+" portal: "+ registrationWith);
			if(cardHolderID == null || zip == null)
				Assert.fail("cardHolderID/Zip: is retrieved as null. Please check the data/data reading step");
			registrationStep1.enterZipCode(DataStorage.getZip());
			registrationStep1.enterCardholderId(DataStorage.getCardholderID());
		} else if(portalName.equals("COMMUNITYPLAN") || portalName.equals("RALLYDHP")) {
			if(registrationWith.equals("SSN")) {
				if(SSN == null || zip == null)
					Assert.fail("SSN/Zip: is retrieved as null. Please check the data/data reading step");
				registrationStep1.selectOptionForHavingMemberIDcard("No");
				registrationStep1.enterSSN(DataStorage.getSSN());
				registrationStep1.enterZipCode(DataStorage.getZip());
			} else if(registrationWith.equals("MemberID")) {
				if(subscriberID == null || groupNumber == null)
					Assert.fail("SubscriberID/GroupNumber: is retrieved as null. Please check the data/data reading step");
				registrationStep1.selectOptionForHavingMemberIDcard("Yes");
				registrationStep1.enterMemberID(DataStorage.getSubscriberID());
				registrationStep1.enterGroupNumber(DataStorage.getGroupNumber());
			} else {
				Assert.fail("Incorrect registrationWith value for "+portalName+" portal: "+ registrationWith);
			}
		} else if(portalName.equals("BSCA")) {
			if(!registrationWith.equals("MemberID"))
				Assert.fail("Incorrect registrationWith value for "+portalName+" portal: "+ registrationWith);
			if(subscriberID == null)
				Assert.fail("SubscriberID: is retrieved as null. Please check the data/data reading step");
			registrationStep1.enterMemberID(DataStorage.getSubscriberID());
		} else if(portalName.equals("BRIOVARX")) {
			if(!registrationWith.equals("PrescriptionID"))
				Assert.fail("Incorrect registrationWith value for "+portalName+" portal: "+ registrationWith);
			if(prescriptionNumber == null || zip == null)
				Assert.fail("PrescriptionNumber/Zip: is retrieved as null. Please check the data/data reading step");
			registrationStep1.enterZipCode(DataStorage.getZip());
			registrationStep1.enterPrescriptionNumber(DataStorage.getPrescriptionNo());
		} else if(portalName.equals("LAWW")) {
			if(zip == null)
				Assert.fail("Zip: is retrieved as null. Please check the data/data reading step");
			registrationStep1.enterZipCode(DataStorage.getZip());

			if(registrationWith.equals("SSN")) {
				if(SSN == null)
					Assert.fail("SSN: is retrieved as null. Please check the data/data reading step");
				registrationStep1.selectRegisterWith("Social Security Number (last 6 digits)");
				registrationStep1.enterSSN(DataStorage.getSSN());
			} else if(registrationWith.equals("MemberID")) {
				if(subscriberID == null)
					Assert.fail("SubscriberID/Zip: is retrieved as null. Please check the data/data reading step");
				registrationStep1.selectRegisterWith("Member ID number");
				registrationStep1.enterMemberID(DataStorage.getSubscriberID());
			} else if(registrationWith.equals("Tier1_Data")) {
				//Do nothing
			} else {
				Assert.fail("Incorrect registrationWith value for "+portalName+" portal: "+ registrationWith);
			}

		} else if(portalName.equals("PHS") || portalName.equals("WHUHC")) {
			if(zip == null)
				Assert.fail("Zip: is retrieved as null. Please check the data/data reading step");
			registrationStep1.enterZipCode(DataStorage.getZip());

			if(registrationWith.equals("SSN")) {
				if(SSN == null)
					Assert.fail("SSN/Zip: is retrieved as null. Please check the data/data reading step");
				registrationStep1.selectRegisterWith("Social Security Number (last 6 digits)");
				registrationStep1.enterSSN(DataStorage.getSSN());
			}
			else  if(registrationWith.equals("MemberID")){
				if(subscriberID == null || groupNumber == null)
					Assert.fail("SubscriberID/GroupNumber: some or all of these values are retrieved as null. Please check the data/data reading step");
				registrationStep1.selectRegisterWith("Member ID and group number");
				registrationStep1.enterMemberID(DataStorage.getSubscriberID());
				registrationStep1.enterGroupNumber(DataStorage.getGroupNumber());
			} else  {
				Assert.fail("Incorrect registrationWith value for "+portalName+" portal: "+ registrationWith);
			}

		} else if(portalName.equals("PHS-OPTUM") || portalName.equals("MYOPTUM") || portalName.equals("WHOPTUM")) {
			if(!registrationWith.equals("SSN"))
				Assert.fail("Incorrect registrationWith value for "+portalName+" portal: "+ registrationWith);
			if(SSN == null || zip == null)
				Assert.fail("SSN/Zip: is retrieved as null. Please check the data/data reading step");
			registrationStep1.enterZipCode(DataStorage.getZip());
			registrationStep1.enterSSN(DataStorage.getSSN());
		} else {
			Assert.fail("Implementation issue in the Step Definition. Check portal name passed in if/else");
		}

		page.clickButtonBySubmitTypeAndName("Continue");

		//Registration Step 2 page
		Assert.assertTrue("Issue in loading HealthSafe ID registration step 2 page",registrationStep2.verifyIfPageLoaded());
		registrationStep2.enterUserName(DataStorage.getUserName());
		registrationStep2.enterPassword("Password@1");
		registrationStep2.enterConfirmPassword("Password@1");
		if(emailType.equalsIgnoreCase("Valid")){
			registrationStep2.enterEmail(DataStorage.getEmailId());
			registrationStep2.confirmEmail(DataStorage.getEmailId());
		}else{
			String email = "HSIDTest";

			DateFormat dateFormat = new SimpleDateFormat("yyMMddHHmmss");
			Date date = new Date();
			String randomSuffix = Integer.toString(new Random().nextInt(10000));
			String uniqueText = dateFormat.format(date) + "_" + randomSuffix;

			email = email + uniqueText + "@gmail.com";
			DataStorage.setEmail(email);
			DataStorage.setCustomErrmsg("DEBUG::Using Dummy email for the script. Email: "+ DataStorage.getEmailId());
			
			registrationStep2.enterEmail(DataStorage.getEmailId());
			registrationStep2.confirmEmail(DataStorage.getEmailId());
		}
		//Recovery options choice based on passed parameter
		if(recoveryType.equals("SQA")) {
			registrationStep2.selectSecurityType("Security questions");
			registrationStep2.selectSecurityQuestion1("What was your first phone number?");
			registrationStep2.enterSecurityAnswer1("number1");
			page.scrollthePageDown();
			registrationStep2.selectSecurityQuestion2("What is your best friend's name?");
			registrationStep2.enterSecurityAnswer2("name1");
			page.scrollthePageDown();
			registrationStep2.selectSecurityQuestion3("What is your favorite color?");
			registrationStep2.enterSecurityAnswer3("color1");
		} else {
			registrationStep2.selectSecurityType("Phone number (US only)");
			registrationStep2.enterPhoneNumberFromPool();
			registrationStep2.selectPhoneType("Mobile");
		}

		registrationStep2.clicktermsOfUseCheckBox();
		registrationStep2.clickButtonBySubmitTypeAndName("Create my ID");

		//Registration Step 3 page
		Assert.assertTrue("Issue in loading HealthSafe ID registration step 3 page",registrationStep3.verifyIfPageLoaded());

	}

	@When("^I load the (PortalPage|HSIDSecurityPage) sign-out URL for \"([^\"]*)\" portal in browser$")
	public void iLoadPortalSignOutURL(String pageType,String portalName) {
		page.openLogoutURLInBrowser(pageType,portalName);
	}

	@When("^I should see valid url for Language Assistance link$")
	public void i_should_see_valid_url_for_language_assistance_link() {
		Assert.assertTrue("Language assistance link is not available or URL is wrong",page.isLanguageAssistanceURLDisplayed());
	}

	@When("^I am at HSID (Registration|SignIn|FullStepUp) Page for \"([^\"]*)\" Portal$")
	public void i_am_at_hsid_registration_or_signIn_page(String actionType,String portalName) {
		portalName = portalName.toUpperCase();
		if(actionType.equals("Registration")){
			try{
				if(portalName.equals("BCBSSC") || portalName.equals("RALLYDHP") || portalName.equals("WHOPTUM") || portalName.equals("WHUHC") || portalName.equals("AHA")) {
					Assert.fail();
				}
				String portalUrl = page.getPortalURL(portalName);
				Assert.assertFalse(portalUrl.isEmpty());
				page.openPage(portalUrl);
				if (portalName.equals("BSCA")|| portalName.equals("COMMUNITYPLAN") || portalName.contains("MNR")) {
					page.clickButtonByText("Register Now");
				} else {
					page.clickPartialLink("Register");
				}
				Assert.assertTrue("Failed to load Personal Information Page", new Registration_PersonalInformationSectionPage().verifyIfPageLoaded());
			} catch (AssertionError | WebDriverException e){
				String registerURL = ReadXMLData.getTestData(page.getPortalAndSubportalName(portalName)[0],page.getPortalAndSubportalName(portalName)[1]+"HSIDRegisterURL");
				Assert.assertFalse("HSIDRegister URL is null or empty in test data file",registerURL==null || registerURL.isEmpty());
				page.openPage(registerURL);
				Assert.assertTrue("Failed to load Personal Information Page", new Registration_PersonalInformationSectionPage().verifyIfPageLoaded());
			}
		}else if(actionType.equals("SignIn")){
			try{
				if(portalName.equals("BCBSSC") || portalName.equals("RALLYDHP") || portalName.equals("WHOPTUM") || portalName.equals("WHUHC")) {
					Assert.fail();
				}
				String portalUrl = page.getPortalURL(portalName);
				Assert.assertFalse(portalUrl.isEmpty());
				page.openPage(portalUrl);
				if(portalName.equals("BSCA")|| portalName.equals("COMMUNITYPLAN") || portalName.equals("MYOPTUM")|| portalName.equals("PHS") || portalName.equals("PHS-OPTUM") || portalName.contains("MNR")){
					page.clickButtonByText("Sign In");
				} else if(portalName.equals("AHC") || portalName.equals("BAZ") || portalName.equals("LAWW") || portalName.equals("OPTUMRX") || portalName.equals("SERVEYOU") || portalName.equals("TCC") || portalName.equals("IBX") || portalName.equals("AMERIHEALTH")){
					page.clickPartialLink("Sign in");
				} else if(portalName.equals("BRIOVARX")) {
					BriovaRxUnauthenticatedHomePage homePage = new BriovaRxUnauthenticatedHomePage();
					homePage.clickLinkUnderDropDown("Patient Sign In","Sign In");
				} else if(portalName.equals("PHP") || portalName.equals("PAI")) {
					page.clickPartialLink("Sign In");
				}
				//all portals including remaining ,will go through below Assertion
				Assert.assertTrue("Issue loading in HSID sign in page", new SignInPage().isHSIDSignPageDisplayed());
			} catch (AssertionError | Exception e){
				String signInURL = ReadXMLData.getTestData(page.getPortalAndSubportalName(portalName)[0], page.getPortalAndSubportalName(portalName)[1]+"HSIDSignInURL");
				Assert.assertFalse("HSIDSignIn URL is null or empty in test data file",signInURL == null || signInURL.isEmpty());
				page.openPage(signInURL);
				// Thread.sleep(1000);
				Assert.assertTrue("Issue loading in HSID sign in page", new SignInPage().isHSIDSignPageDisplayed());
			}
		} else if(actionType.equals("FullStepUp")) {
			String fullStepUpURL = ReadXMLData.getTestData(page.getPortalAndSubportalName(portalName)[0], page.getPortalAndSubportalName(portalName)[1]+"HSIDFullStepUpURL");
			page.openPage(fullStepUpURL);
			Assert.assertTrue("Issue in loading Full Step up page", new Registration_PersonalInformationSectionPage().verifyIfPageLoaded());
			Assert.assertTrue("FirstName variable is not provided in the Feature File Data Read Step", DataStorage.getFirstName() != null);
			Assert.assertEquals("Firstname is not prepopulated on FullStepUp page, please check if authentication session issue is there",DataStorage.getFirstName().toUpperCase(), new Registration_PersonalInformationSectionPage().getFirstNameValue().toUpperCase());
		}
		else {
			Assert.fail("Please check if "+actionType+" page is matching with names in step definition or it's not implemented to directly load this page");
		}
	}

    @And("^I should see clickable \"([^\"]*)\" link with valid URL$")
    public void i_should_see_clickable_link_with_validURL(String linkName) {
		if("LAWW".equalsIgnoreCase(DataStorage.getPortalName())){
			String linkName1 = PageObjectBase.getAEMContent(DataStorage.getPortalName(), "PageContent", linkName);
			page.verifyClickableLinkWithValidURL(linkName1, "");
		}else {
			page.verifyClickableLinkWithValidURL(linkName, "");
		}
    }

	@And("^I should see clickable \"([^\"]*)\" link with valid URL on \"([^\"]*)\" page$")
	public void i_should_see_link_on_the_page(String linkName, String pageName){
		String pageNode = "";
		if(pageName.equalsIgnoreCase("Sign in and security settings")){
			pageNode = "SignInAndSecurity";
		} else if(pageName.equalsIgnoreCase("RBA HRT with phone")){
			pageNode = "RBAHRTPhone";
		} else if(pageName.equalsIgnoreCase("RBA HRT with SQA")){
			pageNode = "RBAHRTSQA";
		} else if(pageName.equalsIgnoreCase("Full step up")) {
			pageNode = "FullStepUp";
		} else if(pageName.equalsIgnoreCase("DupCheck")){
			pageNode = "DupCheck";
		} else if(pageName.equalsIgnoreCase("Registration step1")){
			pageNode = "RegistrationStep1";
		} else{
			Assert.fail("Please check if you entered correct page name:["+pageName+"]");
		}
		page.verifyClickableLinkWithValidURL(linkName,pageNode);
	}

	@When("^I navigate to secure URL for \"([^\"]*)\" portal$")
	public void iLoadPortalSecureURL(String portalName) {
		String portalSecureURL = ReadXMLData.getTestData(page.getPortalAndSubportalName(portalName)[0],page.getPortalAndSubportalName(portalName)[1]+"PortalSecureURL");
		DataStorage.setCustomErrmsg("DEBUG_INFORMATION::[ Portal Secure URL for "+portalName+" : "+portalSecureURL+"]");
		page.openPage(portalSecureURL);

	}

	@Given("^I invalidate Optum ID session$")
	public void invalidateOptumIdSession() {
		//navigate to LOGOUT page to clear optumId session cookie
		page.openPage("https://stg-healthid.optum.com/tb/app/index.html?LOGOUT=TRUE");
		page.waitForPageLoad(DriverFactory.getDeviceDriver());
	}
	//This method should be used when you don't have an AEM key for any link or label
	@Then("^I should see the \"([^\"]*)\" (Link|Label)$")
	public void verifyWebElementText(String elementName, String elementType) {
		elementName = elementName.replaceAll("\\s+", "_");
		String elementValue = PageObjectBase.getPortalSpecificValueFromFile(DataStorage.getPortalName(), elementName);
		if (elementType.equals("Link")) {
			Assert.assertTrue("Fail to find the expected Link- " + elementName, page.findLinkText(elementValue));
		} else if (elementType.equals("Label")) {
			String actualLabel = new SignInPage().getContentLabel();
			Assert.assertTrue("Failed to find the label\nExpected Label: [" + elementValue + "]\nActual Label: [" + actualLabel + "]", actualLabel.contains(elementValue));
		} else {
			Assert.fail("Incorrect element type passed- " + elementType);
		}
	}
	@When("^I click on \"([^\"]*)\" (Link|Button Text|Icon)$")
	public void clickWebElement(String elementName, String elementType) {
		String[] words = elementName.split(" ");
		elementName = "";
		int size = words.length;

		for (int i = 0; i < size; i++) {
			if (i < size - 1)
				elementName = elementName + words[i] + "_";
			else
				elementName = elementName + words[i];
		}

		String xPath = PageObjectBase.getPortalConfig("Locator", elementName);

		page.clickElementByXpath(xPath);
	}
	@When("^I verify RememberMe section on (SignIn|Registration|RBA) page$")
	public void verifyRememberMeSection(String pageName) {

		page.verifyRememberMeSection(pageName);
	}
}