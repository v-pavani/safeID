package com.optum.synergy.reference.ui.pageobjects;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

import com.optum.synergy.reference.ui.stepDefinitions.CommonStepDefinition;
import com.optum.synergy.reference.ui.stepDefinitions.SignInPageStepDefinition;
import com.optum.synergy.reference.ui.stepDefinitions.SigninAndSecuritySettingsStepDefinition;
import com.optum.synergy.reference.ui.utility.*;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.UnsupportedCommandException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PageObjectBase {

	private static List<String> pathList = new ArrayList<String>();
	private static String json;
	private static Map<String, String> map = new HashMap<String, String>();

	// Timeouts for each WebDriverWait object, in seconds.
	public static final int SMALL_WAIT_TIME = 15;
	public static final int MEDIUM_WAIT_TIME = 40;
	public static final int LONG_WAIT_TIME = 120;
	public static ThreadLocal<WebDriverWait> smallWait = new ThreadLocal<WebDriverWait>();
	public static ThreadLocal<WebDriverWait> mediumWait = new ThreadLocal<WebDriverWait>();
	public static ThreadLocal<WebDriverWait> longWait = new ThreadLocal<WebDriverWait>();
	public static ThreadLocal<Integer> OTPFoundStatus = new ThreadLocal<Integer>();
	public static ThreadLocal<Integer> DataFailureStatus = new ThreadLocal<Integer>();
	private final static PortalConfigCache configCache = new PortalConfigCache();
	public ThreadLocal<Boolean> isDataFailure = new ThreadLocal<Boolean>();
	public ThreadLocal<Boolean> isOtherFailure = new ThreadLocal<Boolean>();
	public ThreadLocal<Boolean> isLocatorFailure = new ThreadLocal<Boolean>();
	private final static PortalContentCache contentCache = new PortalContentCache();
	private final static PortalSpecificContentCache portalSpecificContentCache = new PortalSpecificContentCache();
	public ThreadLocal<Boolean> isContentFailure = new ThreadLocal<Boolean>();


	protected static final String BROWSER_CONFIG_FILE_RELATIVE_PATH = "src/main/resources/ui/config/browser_config.json";
	protected static final String SYSTEM_CONFIG_FILE_RELATIVE_PATH = "src/main/resources/ui/config/system_config.json";
	protected static final String ENVIRONMENT_CONFIG_FILE_RELATIVE_PATH = "src/main/resources/ui/config/environment_config.json";
	public WebDriver driver = null;
	
	@FindBy(how = How.XPATH, using = "//a[contains(.,'Accessibility Statement')]|//a[contains(.,'Accessibility Information')]")
	private WebElement accessbilityStatement;

	@FindBy(how = How.XPATH, using = "//a[contains(.,'Language Assistance')]")
	private WebElement languageAssistance;

	public PageObjectBase() {

		try {
			if (driver == null) {
				driver = DriverFactory.createAndGetDeviceDriver();

				PageFactory.initElements(driver, this);

			}
		} catch (Exception e) {
			System.out.println("DEBUG DriverException::====================");
			e.printStackTrace();
			System.out.println("DEBUG DriverException::====================");

			// Something went wrong during driver creation, return a failure
			Assert.fail("Exception occurred instantiating PageObjectBase.driver [" + e.getMessage() + "]");
		}

	}

	public void waitForPageLoad(WebDriver driver) {
		ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				try {
					return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
				} catch (UnsupportedCommandException e) {
					return false;
				}
			}
		};
		WebDriverWait ninetySecond = new WebDriverWait(driver, 90);
		try {
			ninetySecond.until(pageLoadCondition);
		} catch (Exception e) {
			System.err.println("Expected condition failed: " + e.getMessage());
		}
	}

	public void waitForJavascriptToLoad(int maxWaitMillis, int pollDelimiter) {
		waitForPageLoad(driver);
		double startTime = System.currentTimeMillis();
		while (System.currentTimeMillis() < startTime + maxWaitMillis) {
			try {
				String prevState = driver.getPageSource();
				Thread.sleep(pollDelimiter);
				if (prevState.equals(driver.getPageSource())) {
					return;
				}
			} catch (Exception e) {
			}
		}
	}

	public static String getSystemVariable(String variableName) throws IOException {
		FileInputStream fileInputStream = null;
		String requiredValue = "";
		StringBuffer stringBuffer = new StringBuffer("");
		try {

			fileInputStream = new FileInputStream(SYSTEM_CONFIG_FILE_RELATIVE_PATH);
			int i;
			while ((i = fileInputStream.read()) != -1) {
				stringBuffer.append((char) i);
			}
			json = stringBuffer.toString();

			JSONObject object = new JSONObject(json);
			String jsonPath = "";
			readObject(object, jsonPath);
			requiredValue = map.get(variableName);
		} catch (Exception e) {
		} finally {
			if (fileInputStream != null) {
				fileInputStream.close();
			}
		}
		return requiredValue;
	}

	public static String getEnvVariable(String jsonVariablePath) throws IOException {
		FileInputStream fileInputStream = null;
		String requiredValue = "";
		StringBuffer stringBuffer = new StringBuffer("");
		try {

			fileInputStream = new FileInputStream(
					"src/main/resources/ui/config/" + getSystemVariable("portal_name") + "_environment_config.json");
			int i;
			while ((i = fileInputStream.read()) != -1) {
				stringBuffer.append((char) i);
			}
			json = stringBuffer.toString();

			requiredValue = getEnvironmentProperty(jsonVariablePath);
		} catch (Exception e) {
		} finally {
			if (fileInputStream != null) {
				fileInputStream.close();
			}
		}
		return requiredValue;
	}

	public static String getEnvironmentProperty(String propertyPath)
			throws IOException {
		JSONObject object = new JSONObject(json);
		String jsonPath = "";
		readObject(object, jsonPath);
		DataStorage.setCustomErrmsg(map.get(getSystemVariable("environment.type") + "." + propertyPath));
		return map.get(getSystemVariable("environment.type") + "." + propertyPath);
	}

	private static void readObject(JSONObject object, String jsonPath) {
		Iterator<String> keysItr = object.keys();
		String parentPath = jsonPath;
		while (keysItr.hasNext()) {
			String key = keysItr.next();
			Object value = object.get(key);
			if (parentPath != "")
				jsonPath = parentPath + "." + key;
			else if (parentPath == "")
				jsonPath = parentPath + key;

			if (value instanceof JSONArray) {
				readArray((JSONArray) value, jsonPath);
			} else if (value instanceof JSONObject) {
				readObject((JSONObject) value, jsonPath);
			} else { // is a value
				pathList.add(jsonPath);
				map.put(jsonPath, (String) value);
			}
		}
	}

	private static void readArray(JSONArray array, String jsonPath) {
		String parentPath = jsonPath;
		for (int i = 0; i < array.length(); i++) {
			Object value = array.get(i);
			jsonPath = parentPath + "[" + i + "]";

			if (value instanceof JSONArray) {
				readArray((JSONArray) value, jsonPath);
			} else if (value instanceof JSONObject) {
				readObject((JSONObject) value, jsonPath);
			} else { // is a value
				pathList.add(jsonPath);
				map.put(jsonPath, (String) value);
			}
		}
	}

	public void scrollElementIntoView(WebElement elem) {
		// OLD SCRIPT: arguments[0].scrollIntoView();
		// NEW SCRIPT: window.scrollBy(0,
		// arguments[0].getBoundingClientRect().top - (window.innerHeight>>1));
		String scrollScript = "window.scrollBy(0, arguments[0].getBoundingClientRect().top - (window.innerHeight/2));";
		((JavascriptExecutor) driver).executeScript(scrollScript, elem);
		try {
			Thread.sleep(100);
		} catch (Exception e) {
		}
	}

	public void clickTab() {
		WebElement currentElement = driver.findElement(By.tagName("body"));
		currentElement.sendKeys(Keys.TAB);
		try {
			Thread.sleep(250);
		} catch (Exception e) {
		}
	}

	public void clickLink(String linkName) {

		waitForJavascriptToLoad(15000, 1000);

		String[] split = linkName.split(" ");
		WebElement linkElem = null;
		if(split.length == 1){
			mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.linkText(linkName))).click();
			return;
		} else {

			List<WebElement> linkList = mediumWait.get()
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//a")));
			for (WebElement link : linkList) {
				String linkText = link.getText().trim().replaceAll(String.valueOf((char) 160), " ");
				if (linkText.equals(linkName)) {
					if (link.isDisplayed()) {
						linkElem = link;
						break;
					}
				}
			}
			if (linkElem == null) {
				throw new org.openqa.selenium.ElementNotVisibleException(
						"Failed to find visible element located by partialLinkText(" + linkName + ")");
			}
		}

		scrollElementIntoView(linkElem);
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", linkElem);

	}

	public void clickPartialLink(String partialLinkName) {

		String browser = System.getProperty("BrowserType");
		if(partialLinkName.equals("SIGN IN") && browser.equalsIgnoreCase("Safari"))
			partialLinkName = "Sign in";

		List<WebElement> linkList = mediumWait.get()
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//a")));
		WebElement linkElem = null;
		for (WebElement link : linkList) {
			String linkText = link.getText().trim().replaceAll(String.valueOf((char)160)," ");
			if(linkText.contains(partialLinkName))
			{
				if (link.isDisplayed()) {
					linkElem = link;
					break;
				}
			}
		}

		if (linkElem == null) {
			throw new org.openqa.selenium.ElementNotVisibleException(
					"Failed to find visible element located by partialLinkText(" + partialLinkName + ")");
		}
		scrollElementIntoView(linkElem);
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", linkElem);
	}

	public void openPage(String pageUrl) {
		driver.get(pageUrl);
		waitForJavascriptToLoad(25000, 1000);
	}

	public void openNewTab() {
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "t");
		ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
	    driver.switchTo().window(tabs.get(tabs.size()-1));
		driver.switchTo().defaultContent();
	}

	public void switchBackToPreviousTab() {
		try {
		Actions action = new Actions(driver);
		action.keyDown(Keys.CONTROL).keyDown(Keys.SHIFT).sendKeys(Keys.TAB).build().perform();
		}
		catch(UnsupportedCommandException e)
		{
			ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
		    driver.switchTo().window(tabs.get(tabs.size()-2));
		}
		driver.switchTo().defaultContent();
	}

	public void switchToNextTab() {
		Actions action = new Actions(driver);
		action.keyDown(Keys.CONTROL).sendKeys(Keys.TAB).build().perform();
		driver.switchTo().defaultContent();
	}

	public void switchToNextWindow() throws InterruptedException {
		Thread.sleep(2000);
		Set<String> windowHandles = driver.getWindowHandles();
		for (String w : windowHandles) {
			driver.switchTo().window(w);
		}
	}

	public void switchToPreviousWindow() {

		String parentWindow = driver.getWindowHandle();
		Set<String> handles = driver.getWindowHandles();
		for (String windowHandle : handles) {
			if (!windowHandle.equals(parentWindow)) {
				driver.switchTo().window(windowHandle);
				// <!--Perform your operation here for new window-->
				driver.close(); // closing child window
				driver.switchTo().window(parentWindow); // cntrl to parent window
			}
		}
	}

	public void refreshPage() {
		driver.navigate().refresh();
	}

	public void clickBrowserBackButton() {
		driver.navigate().back();
	}

	public boolean findLinkText(String expectedLinkText) {
		waitForJavascriptToLoad(7000, 1000);
		WebElement elem = longWait.get()
				.until(ExpectedConditions.presenceOfElementLocated(By.linkText(expectedLinkText)));
		return elem != null;
	}

	public boolean findPartialLinkText(String expectedLinkText) {
		List<WebElement> linkList = mediumWait.get()
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//a")));
		boolean found = false;

		for(WebElement link: linkList){
			String textContent = link.getText().trim().replaceAll(String.valueOf((char)160)," ");
			if(textContent.contains(expectedLinkText)){
				if(link.isDisplayed())
				found = true;
				break;
			}
		}
		return found;
	}
	
	public boolean verifyClickableLink(String linkName) { 
	return mediumWait.get().until(ExpectedConditions.elementToBeClickable(By.linkText(linkName))).isDisplayed();
	}

	public String getPageTitle() {
		return driver.getTitle();
	}

	public boolean verifyElementByClassName(String className) {
		waitForJavascriptToLoad(5000, 1000);
		try {
			return smallWait.get()
					.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@class='" + className + "']")))
					.isDisplayed();
		} catch (TimeoutException | NoSuchElementException e) {
			return false;
		}
	}

	public boolean verifyTextByClassName(String className, String text) {
		boolean isverified = false;
		try {
			List<WebElement> elems = mediumWait.get()
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.className(className)));
			for (WebElement elem : elems) {
				if (elem.getText().contains(text)) {
					isverified = true;
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			isverified = false;
		}
		return isverified;
	}

	public boolean verifyElementById(String id) {
		WebElement elem = null;
		try {
			elem = smallWait.get().until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		} catch (Exception e) {
		}
		return elem != null;
	}

	public void clickElementById(String id) {
		WebElement elem = smallWait.get().until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		scrollElementIntoView(elem);
		elem.click();
	}

	public boolean verifyButtonBySubmitTypeAndName(String buttonName) {
		WebElement elem = smallWait.get().until(ExpectedConditions.presenceOfElementLocated(By.xpath(
				"//button[@type='submit' and contains(.,'" + buttonName + "')] | .//*[@id='continueSubmitButton']|//button[@class='rds-tertiary-button is-rds-fullwidth']")));
		return elem != null;
	}

	public void clickButtonBySubmitTypeAndName(String buttonName) {
		WebElement elem = mediumWait.get().until(ExpectedConditions
				.presenceOfElementLocated(By.xpath("//button[@type='submit' and contains(.,'" + buttonName + "')]|//input[@value='"+ buttonName + "']")));
		scrollElementIntoView(elem);
		((JavascriptExecutor) DriverFactory.getDeviceDriver()).executeScript("arguments[0].click();", elem);
	}

	public boolean verifyButtonByText(String buttonName) {
		WebElement elem = smallWait.get()
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[contains(.,'" + buttonName
						+ "')]|//a[contains(@class,'button') and contains(.,'" + buttonName + "')]")));
		return elem != null;
	}

	public void clickButtonByText(String buttonName) {
		WebElement elem = mediumWait.get()
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[contains(.,'" + buttonName
						+ "')]|//*[@class='container']//a[contains(.,'" + buttonName
						+ "')]|//a[contains(@class,'button') and contains(.,'" + buttonName + "')]|//input[@type='image']|//input[@type='button']")));
		scrollElementIntoView(elem);
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", elem);
	}

	public boolean verifytheLinkButtonIsDisplayed(String className, String text) throws InterruptedException {
		boolean displayed = false;
		Thread.sleep(500);
		List<WebElement> elems = mediumWait.get()
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.className(className)));
		for (WebElement elem : elems) {
			if (elem.getText().equals(text)) {
				displayed = true;
				break;
			}
		}
		return displayed;
	}

	public boolean verifytheInputButtonIsDisplayed(String buttontext) {
		boolean displayed = false;
		List<WebElement> elems = mediumWait.get()
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//input[@type='submit']")));
		for (WebElement elem : elems) {
			if (elem.getAttribute("value").equals(buttontext)) {
				displayed = true;
				break;
			}
		}
		return displayed;
	}

	public boolean clickElementByClassNameAndText(String className, String text) {

		boolean isClicked = false;
		try {
			List<WebElement> elems = mediumWait.get()
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.className(className)));
			for (WebElement elem : elems) {
				if (elem.getText().contains(text)) {
					elem.click();
					isClicked = true;
					break;
				}
			}
		} catch (Exception e) {
			isClicked = false;
		}
		return isClicked;
	}

	public void handleSecurityQuestionWithAnswer() throws Exception {

		String SecurityQtn = mediumWait.get()
				.until(ExpectedConditions.presenceOfElementLocated(By.id("authQuestiontextLabelId"))).getText();
		WebElement answerField = mediumWait.get()
				.until(ExpectedConditions.presenceOfElementLocated(By.id("challengeQuestionList[0].userAnswer")));
		answerField.clear();
		// Small pause to resolve intermittent clearing of input field from page
		// update
		Thread.sleep(1000);
		if (SecurityQtn.contains("number")) {
			answerField.sendKeys("number1");
		} else if (SecurityQtn.contains("name")) {
			answerField.sendKeys("name1");
		} else if (SecurityQtn.contains("color")) {
			answerField.sendKeys("color1");
		} else {
			throw new Exception("unknown challenge " + SecurityQtn);
		}
		clickTab();
		mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.id("continueSubmitButton"))).click();
	}

	public void switchToFrameByNameOrId(String frameNameOrId) {
		driver.switchTo().frame(frameNameOrId);
	}

	public void switchToDefaultContent() {
		driver.switchTo().defaultContent();
	}

	public String getCurrentPageUrl() {
		waitForPageLoad(driver);
		waitForJavascriptToLoad(10000, 2000);
		return driver.getCurrentUrl();
	}

	public String getPagelinkFromTestDataXMLFile(String pageName, String linkName) {
		return ReadXMLData.getTestData(DataStorage.getPortalName() + "/Link",
				pageName.replace(" ", "") + "." + linkName.replace(" ", "")).trim();
	}

	public WebElement getAnchorElementByText(String anchorText) {
		WebElement webElement = null;
		List<WebElement> elems = mediumWait.get()
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.tagName("a")));
		for (WebElement elem : elems) {
			if (elem.getText().equals(anchorText)) {
				webElement = elem;
				break;
			}
		}
		return webElement;
	}

	public boolean verifyLinkEnabled(String linkText) {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(linkText))).isEnabled();
	}

	public void closeCurrentWindowOfheBrowser() {
		driver.close();
	}

	public void scrollthePageUp() {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("scroll(0, -250);");
	}

	public void scrollthePageDown() {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("scroll(0, 600);");
	}

	public void deleteCookies() {
		driver.manage().deleteAllCookies();
	}

	public boolean verifythePageHeadingByH1Tag(String expectedSubHeading) {
		List<WebElement> subHeadings = mediumWait.get()
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.tagName("h1")));
		String pageHeading = null;
		for (WebElement actualPageHeading : subHeadings) {
			String textContent = actualPageHeading.getText().trim().replaceAll(String.valueOf((char)160)," ");
			if (textContent.contains(expectedSubHeading)) {
				pageHeading = actualPageHeading.getText();
				break;
			}
		}
		return pageHeading != null;
	}

	public boolean verifytheSubHeadingByH2Tag(String expectedSubHeading) {
		List<WebElement> subHeadings = mediumWait.get()
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.tagName("h2")));
		String h2subHeading = null;
		for (WebElement actualSubHeading : subHeadings) {
			if (actualSubHeading.getText().contains(expectedSubHeading)) {
				h2subHeading = actualSubHeading.getText();
			}
		}
		return h2subHeading != null;
	}

	public boolean verifytheSubHeadingByH3Tag(String expectedSubHeading) {
		List<WebElement> subHeadings = mediumWait.get()
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.tagName("h3")));
		String h3subHeading = null;
		for (WebElement actualSubHeading : subHeadings) {
			if (actualSubHeading.getText().contains(expectedSubHeading)) {
				h3subHeading = actualSubHeading.getText();
			}
		}
		return h3subHeading != null;
	}

	public boolean verifytheSubHeadingByPTag(String expectedSubHeading) {
		// Wait for <p> element containing expected SubHeading text
		By selector = By.xpath("//p[contains(.,'" + expectedSubHeading + "')]");
		try {
			List<WebElement> subHeadings = mediumWait.get()
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(selector));
			for (WebElement actualSubHeading : subHeadings) {
				if (actualSubHeading.isDisplayed()) {
					return true;
				}
			}
			// None of the found elements are displayed, return false
			return false;
		} catch (TimeoutException e) {
			return false;
		}
	}

	public boolean verifytheSubHeadingByspan(String expectedSubHeading) {
		List<WebElement> subHeadings = mediumWait.get()
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.tagName("span")));
		String h2subHeading = null;
		for (WebElement actualSubHeading : subHeadings) {
			if (actualSubHeading.getText().contains(expectedSubHeading)) {
				h2subHeading = actualSubHeading.getText();
			}
		}
		return h2subHeading != null;
	}

	/**
	 * Given a WebElement, scroll that element into view and execute a mouseOver on
	 * it
	 * 
	 * @param elem
	 */
	protected void mouseHoverOnElement(WebElement elem) {

		// perform click to dismiss any current tooltip
		// driver.findElement(By.xpath("//body")).click();

		scrollElementIntoView(elem);

		/*
		 * CNYE: FF52 on SauceLabs does not support the moveToElement() action method
		 * Actions action = new Actions(driver); action.moveToElement( mediumWait.get()
		 * .until(ExpectedConditions.presenceOfElementLocated(
		 * By.xpath("//*[@class='tooltip']/*[contains(.,'" + message + "')]/i"))))
		 * .build().perform();
		 * 
		 */

		// COPIED FROM: http://codoid.com/webdriver-mouseover/
		// The below JavaScript code creates, initializes and dispatches mouse
		// event to an object on fly.
		String strJavaScript = "var mouseEventObj = document.createEvent('MouseEvents');"
				+ "mouseEventObj.initEvent( 'mouseover', true, true );" + "arguments[0].dispatchEvent(mouseEventObj);";

		// Then JavascriptExecutor class is used to execute the script to
		// trigger the dispatched event.
		((JavascriptExecutor) driver).executeScript(strJavaScript, elem);
	}

	public boolean verifyFieldNameAndAssociatedTextBox(String spanTagText, String followingSiblingInputId) {

		WebElement elem = mediumWait.get().until(
				ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(@class,'strong') and contains(.,'"
						+ spanTagText + "')]/following-sibling::input[@id='" + followingSiblingInputId + "']")));

		return elem != null;
	}

	public boolean verifyCheckboxAndAssociatedLabel(String labelText, String inputId) {
		// Finds <input> element having given inputId that also has a sibling element
		// containing spanTagText
		WebElement elem = null;

		try {
			elem = mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
					By.xpath("//label[contains(.,'" + labelText + "')]/../input[@id='" + inputId + "']")));
		} catch (Exception e) {
			DataStorage.setCustomErrmsg(
					"Failed to find input element with id [" + inputId + "] next to label [" + labelText + "]");
		}
		return elem != null;
	}

	public int returnNumberOfRulesMarkedAsGreenInTooltip() {
		List<WebElement> elems = mediumWait.get().until(ExpectedConditions.presenceOfAllElementsLocatedBy(
				By.xpath("//div[@class='tooltip-content ruletip']//span[@class='icon-checkmark_filled ng-scope']")));
		return elems.size();
	}

	public String returnToolTipRulesMarkedAsGreen() {
		String rulesContent = "";
		List<WebElement> elems = mediumWait.get().until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(
				"//div[@class='tooltip-content ruletip']//span[@class='icon-checkmark_filled ng-scope']/parent::p")));
		for (WebElement element : elems) {
			rulesContent = rulesContent + element.getText();
		}
		return rulesContent;
	}

	public void clickByJavaScript(WebElement element) {
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", element);
	}

	public boolean verifyPopUpContent(String message) throws InterruptedException {
		Thread.sleep(2000);
		waitForJavascriptToLoad(10000, 1000);
		WebElement confirmPopUpContent = mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.xpath(
				"//*[contains(@class,'modal__content')]|//*[contains(@class,'modal-body modal-body--hidescroll')]")));
		return confirmPopUpContent.getText().contains(message);
	}

	public void openNewTabAndClosePreviousTab() {
		int expectedNumberOfWindows = driver.getWindowHandles().size() + 1;
		((JavascriptExecutor)driver).executeScript("window.open()");
		mediumWait.get().until(ExpectedConditions.numberOfWindowsToBe(expectedNumberOfWindows));
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(0));
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "w");
		driver.switchTo().window(tabs.get(1));
	}

	public boolean verifytheInputOfTypeButtonIsDisplayed(String buttontext) {
		boolean displayed = false;
		List<WebElement> elems = mediumWait.get()
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//input[@type='button']")));
		for (WebElement elem : elems) {
			if (elem.getAttribute("value").equals(buttontext)) {
				displayed = true;
				break;
			}
		}
		return displayed;
	}

	public void waitTime(String timeInSeconds) throws InterruptedException {
		Thread.sleep(Integer.parseInt(timeInSeconds) * 1000);
	}

	public String getURLAssociatedWithLink(String linkName) {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.linkText(linkName)))
				.getAttribute("href");
	}

	public List<WebElement> getRecaptchPrivacyPolicyURL() {
		List<WebElement> privacyPolicy = mediumWait.get().until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.partialLinkText("Privacy Policy")));
		return privacyPolicy;
	}

	public String getRecaptchaTermsOfServiceURL() {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText("Terms of Service"))).getAttribute("href");
	}

	/**
	 *Convert date from MM/DD/YYYY to YYYY-MM-DD
	 * @return String
	 */
	public static String getDateInYYYY_MM_DDFormat(String date) {
		Assert.assertTrue("Date passed is not in MM/DD/YYYY format",date.length() == 10 && date.indexOf('/') == 2 && date.lastIndexOf('/') == 5);

		String[] initialDate = date.split("/");
		String finalDate = initialDate[2] + "-" + initialDate[0] + "-" + initialDate[1];
		return finalDate;
	}
//	public static String getDateInDDDD_MM_DDFormat(String date) {
//
//		Assert.assertTrue("Date passed is not in MM/DD/YYYY format",date.length() == 10 && date.indexOf('/') == 2 && date.lastIndexOf('/') == 5);
//
//		String[] initialDate = date.split("/");
//		String finalDate = initialDate[2] + "-" + initialDate[0] + "-" + initialDate[1];
//		return finalDate;
//	}
	public boolean isAccessbilityUHCUrlDisplayed() {
		return longWait.get().until(ExpectedConditions.visibilityOf((accessbilityStatement))).getAttribute("href").equals(ReadXMLData.getTestData(DataStorage.getPortalName(), "AccessbilityStatementURL-UHC"));
	}

	public boolean isAccessbilityUrlDisplayed() {
		return longWait.get().until(ExpectedConditions.visibilityOf((accessbilityStatement))).getAttribute("href").equals(ReadXMLData.getTestData(DataStorage.getPortalName(), "AccessbilityStatementURL"));
	}

	public boolean isHSIDErrorPage() {
        try{
            boolean isErrorPage = mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@class='linksholder']| //p[contains(.,\"don't have access\")] |//script[contains(.,'SigninError1')]"))).isDisplayed();
        }catch (Exception e){
            // No error page found
            return false;
        }
        try {
            boolean isHSIDErrorPage = smallWait.get().until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@class='linksholder']"))).isDisplayed();
            boolean isHSIDTitle = getPageTitle().trim().equalsIgnoreCase("HealthSafe ID®");
            return isHSIDErrorPage && isHSIDTitle;
        } catch (TimeoutException e){
            DataFailureStatus.set(1);
            return false;
        }
	}

	public String getParentPortal(String portalName) {

		switch (portalName) {
			case "AHC":
			case "CAP":
			case "PHP":
			case "PAI":
			case "TCC":
			case "PHS":
			case "BAZ":
			case "BSCA":
			case "LAWW":
			case "BRIOVARX":
				return portalName;
			case "SERVEYOU":
				return "ServeYou";
			case "OPTUMRX":
			case "OPTUMRX-AARP":
			case "OPTUMRX-BCBSSC":
			case "OPTUMRX-AHA":
			case "OPTUMRX-AMERIHEALTH":	
				return "OptumRx";
			case "MYUHC":
			case "MYUHC-COMMUNITYPLAN":
				return "MyUHC";
			case "MNR-MEDICARE":
			case "MNR-MEDICA":
			case "MNR-RETIREE":
			case "MNR-PCP":
			case "MNR-AARP":
				return "MNR";
			case "BANK-CAP":
			case "BANK-AARP":
			case "BANK-UHCHA":
			case "BANK-UHCRA":
			case "BANK-DISNEY":
				return "CAP";
			case "MYOPTUM":
				return "MyOptum";
			case "SSOMYUHC":
			case "HARVARDPILGRIMSSO":
				return "SSOMYUHC";
			case "RAILROADSSO":
				return "RailRoadSSO";

			default:
				Assert.fail("Incorrect portal name passed: "+portalName);
				return null;

		}

	}

	public void openLogoutURLInBrowser(String pageType, String portalName) {
		String logoutURL = null;
		portalName = portalName.toUpperCase();
		if(pageType.equalsIgnoreCase("PortalPage"))
			logoutURL = ReadXMLData.getTestData(getParentPortal(portalName), portalName+"LogoutURL");
		else
			logoutURL = ReadXMLData.getTestData(getParentPortal(portalName), portalName+"HSIDPageLogoutURL");

		if(logoutURL != null)
		driver.get(logoutURL);
		else Assert.fail(DataStorage.getSubPortalName()+"LogoutURL is null");
	}

	public boolean isLanguageAssistanceURLDisplayed() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(languageAssistance)).getAttribute("href").equals(ReadXMLData.getTestData(DataStorage.getPortalName(),DataStorage.getSubPortalName()+"LanguageAssistanceURL"));
	}

    public String getPortalURL(String portalName) {
		String url = null;
		portalName = portalName.toUpperCase();
		switch (portalName) {
			case "AHC":
				url = ReadXMLData.getTestData("AHC", "AppURL");
				break;
			case "BANK":
				url = ReadXMLData.getTestData("CAP", "OptumBankURL");
				break;
			case "BANK-AARP":
				url = ReadXMLData.getTestData("CAP", "BankAARPURL");
				break;
			case "BANK-DISNEY":
				url = ReadXMLData.getTestData("CAP", "DisneyURL");
				break;
			case "BANK-UHCHA":
				url = ReadXMLData.getTestData("CAP", "UHCHAURL");
				break;
			case "BANK-UHCRA":
				url = ReadXMLData.getTestData("CAP", "UHCRAURL");
				break;
			case "BAZ":
				url = ReadXMLData.getTestData("BAZ", "AppURL");
				break;
			case "BRIOVARX":
				url = ReadXMLData.getTestData("BRIOVARX", "BriovaRxHSIDRegisterURL");
				break;
			case "BSCA":
				url = ReadXMLData.getTestData("BSCA", "AppURL");
				break;
			case "LAWW":
				url = ReadXMLData.getTestData("LAWW", "AppURL");
				break;
			case "MNR":
				url = ReadXMLData.getTestData("MNR", "MedicarePortalURL");
				break;
			case "MNR-AARP":
				url = ReadXMLData.getTestData("MNR", "AarpPortalURL");
				break;
			case "MNR-MEDICA":
				url = ReadXMLData.getTestData("MNR", "MedicaPortalURL");
				break;
			case "MNR-PCP":
				url = ReadXMLData.getTestData("MNR", "PcpPortalURL");
				break;
			case "MNR-RETIREE":
				url = ReadXMLData.getTestData("MNR", "RetireePortalURL");
				break;
			case "MYOPTUM":
				url = ReadXMLData.getTestData("MyOptum", "AppURL");
				break;
			case "COMMUNITYPLAN":
				url = ReadXMLData.getTestData("MyUHC", "CommunityAndStateURL");
				break;
			case "OPTUMRX":
				url = ReadXMLData.getTestData("OptumRx", "OptumRxHSIDRegisterURL");
				break;
			case "PAI":
				url = ReadXMLData.getTestData("PAI", "AppURL");
				break;
			case  "PHP":
				url = ReadXMLData.getTestData("PHP", "AppURL");
				break;
			case "PHS":
				url = ReadXMLData.getTestData("PHS", "AppURL");
				break;
			case "PHS-OPTUM":
				url = ReadXMLData.getTestData("PHS", "PHSOPTUMAPPURL");
				break;
			case "SERVEYOU":
				url = ReadXMLData.getTestData("ServeYou", "AppURL");
				break;
			case "TCC":
				url = ReadXMLData.getTestData("TCC", "AppURL");
				break;
			case "OPTUMRX-AARP":
				url = ReadXMLData.getTestData("OptumRx", "OptumRxAARPURL");
				break;
			case "AHA":
				url = ReadXMLData.getTestData("OptumRx", "AHAURL");
				break;
			case "AMERIHEALTH":
				url = ReadXMLData.getTestData("OptumRx", "AMERIHEALTHURL");
				break;
			case "WHUHC":
				//doesn't have any APP URL, So storing nothing into url
				break;
			case "WHOPTUM":
				//doesn't have any APP URL, So storing nothing into url
				break;
			case "BCBSSC":
				//doesn't have any APP URL, So storing nothing into url
				break;
			case "RALLYDHP":
				//doesn't have any APP URL, So storing nothing into url
				break;
			case "IBX":
				url = ReadXMLData.getTestData("OptumRx", "IBXURL");
				break;
			default:
				Assert.fail(portalName+" portal name is not correct");
		}
		return url;
	}

	public String[]getPortalAndSubportalName(String portalName){
		portalName = portalName.toUpperCase();
		String[] portalAndSubPortal = new String[2];
		switch (portalName) {
			case "AHC":
				portalAndSubPortal[0] = "AHC";
				portalAndSubPortal[1] = "AHC";
				break;
			case "BANK":
			case "CAP":
				portalAndSubPortal[0] = "CAP";
				portalAndSubPortal[1] = "CAP";
				break;
			case "BANK-AARP":
				portalAndSubPortal[0] = "CAP";
				portalAndSubPortal[1] = "BANK-AARP";
				break;
			case "BANK-DISNEY":
				portalAndSubPortal[0] = "CAP";
				portalAndSubPortal[1] = "Disney";
				break;
			case "BANK-UHCHA":
				portalAndSubPortal[0] = "CAP";
				portalAndSubPortal[1] = "UHCHA";
				break;
			case "BANK-UHCRA":
				portalAndSubPortal[0] = "CAP";
				portalAndSubPortal[1] = "UHCRA";
				break;
			case "BAZ":
				portalAndSubPortal[0] = "BAZ";
				portalAndSubPortal[1] = "BAZ";
				break;
			case "BRIOVARX":
				portalAndSubPortal[0] = "BRIOVARX";
				portalAndSubPortal[1] = "BriovaRx";
				break;
			case "BSCA":
				portalAndSubPortal[0] = "BSCA";
				portalAndSubPortal[1] = "BSCA";
				break;
			case "LAWW":
				portalAndSubPortal[0] = "LAWW";
				portalAndSubPortal[1] = "LAWW";
				break;
			case "MNR":
				portalAndSubPortal[0] = "MNR";
				portalAndSubPortal[1] = "Medicare";
				break;
			case "MNR-AARP":
				portalAndSubPortal[0] = "MNR";
				portalAndSubPortal[1] = "MNR-AARP";
				break;
			case "MNR-MEDICA":
				portalAndSubPortal[0] = "MNR";
				portalAndSubPortal[1] = "Medica";
				break;
			case "MNR-PCP":
				portalAndSubPortal[0] = "MNR";
				portalAndSubPortal[1] = "PCP";
				break;
			case "MNR-RETIREE":
				portalAndSubPortal[0] = "MNR";
				portalAndSubPortal[1] = "Retiree";
				break;
			case "HARVARDPILGRIMSSO":
				portalAndSubPortal[0] = "SSOMYUHC";
				portalAndSubPortal[1] = "HARVARDPILGRIMSSO";
				break;
			case "RAILROADSSO":
				portalAndSubPortal[0] = "RailRoadSSO";
				portalAndSubPortal[1] = "RailRoadSSO";
				break;				
			case "MYOPTUM":
				portalAndSubPortal[0] = "MyOptum";
				portalAndSubPortal[1] = "MyOptum";
				break;
			case "COMMUNITYPLAN":
				portalAndSubPortal[0] = "MyUHC";
				portalAndSubPortal[1] = "CommunityAndState";
				break;
			case "OPTUMRX":
				portalAndSubPortal[0] = "OptumRx";
				portalAndSubPortal[1] = "OptumRx";
				break;
			case "OPTUMRX-AARP":
				portalAndSubPortal[0] = "OptumRx";
				portalAndSubPortal[1] = "OptumRx-AARP";
				break;
			case "AHA":
				portalAndSubPortal[0] = "OptumRx";
				portalAndSubPortal[1] = "AHA";
				break;
			case "AMERIHEALTH":
				portalAndSubPortal[0] = "OptumRx";
				portalAndSubPortal[1] = "AMERIHEALTH";
				break;
			case "IBX":
				portalAndSubPortal[0] = "OptumRx";
				portalAndSubPortal[1] = "IBX";
				break;
			case "PAI":
				portalAndSubPortal[0] = "PAI";
				portalAndSubPortal[1] = "PAI";
				break;
			case  "PHP":
				portalAndSubPortal[0] = "PHP";
				portalAndSubPortal[1] = "PHP";
				break;
			case "PHS":
				portalAndSubPortal[0] = "PHS";
				portalAndSubPortal[1] = "PHS";
				break;
			case "PHS-OPTUM":
				portalAndSubPortal[0] = "PHS";
				portalAndSubPortal[1] = "PHS-OPTUM";
				break;
			case "SERVEYOU":
				portalAndSubPortal[0] = "ServeYou";
				portalAndSubPortal[1] = "ServeYou";
				break;
			case "TCC":
				portalAndSubPortal[0] = "TCC";
				portalAndSubPortal[1] = "TCC";
				break;
			case "MYUHC":
				portalAndSubPortal[0] = "MyUHC";
				portalAndSubPortal[1] = "MyUHC";
				break;
			case "BCBSSC":
				portalAndSubPortal[0] = "OptumRx";
				portalAndSubPortal[1] = "BCBSSC";
				break;
			case "RALLYDHP":
				portalAndSubPortal[0] = "RallyDhp";
				portalAndSubPortal[1] = "RallyDhp";
				break;
			case "WHUHC":
				portalAndSubPortal[0] = "WomensHealth";
				portalAndSubPortal[1] = "WomensHealth-UHC";
				break;
			case "WHOPTUM":
				portalAndSubPortal[0] = "WomensHealth";
				portalAndSubPortal[1] = "WomensHealth-OPTUM";
				break;
			case "SSOMYUHC":
				portalAndSubPortal[0] = "SSOMYUHC";
				portalAndSubPortal[1] = "SSOMYUHC";
				break;
			default:
				Assert.fail(portalName+" portal name is not correct");
		}
		return portalAndSubPortal;
	}

    public void verifyClickableLinkWithValidURL(String partialLinkName, String pageNodeName) {
        String urlNodeName = null;
        String sectionName = null;
        List<WebElement> linkList = mediumWait.get()
                .until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//a")));
        WebElement linkElem = null;
        for (WebElement link : linkList) {
            String linkText = link.getText().trim().replaceAll(String.valueOf((char)160)," ");
            if(linkText.contains(partialLinkName)) {
                linkElem = link;
                //check if link is clickable
                mediumWait.get().until(ExpectedConditions.elementToBeClickable(link));
                //find node in test data.xml for URL
                sectionName = DataStorage.getPortalName() + "/LinkURLs";
                if (partialLinkName.contains("Accessibility")) {
                    urlNodeName = DataStorage.getSubPortalName() + "AccessbilityStatementURL";
                } else if (partialLinkName.contains("Language Assistance")) {
                    urlNodeName = DataStorage.getSubPortalName() + "LanguageAssistanceURL";
                } else {
                    //breadcrumb link and return to home link on RBA page
                    String newLink = partialLinkName.trim().replaceAll("\\s", "_");
                    newLink = newLink.replaceAll("[^a-zA-Z_]", ""); //remove unwanted character like ?
                    urlNodeName = DataStorage.getSubPortalName() + pageNodeName + "_" + newLink + "_URL";
                }
                String expectedURL =  ReadXMLData.getTestData(sectionName, urlNodeName);
                String actualURL = link.getAttribute("href");
                DataStorage.setCustomErrmsg("Expected URL for link ["+partialLinkName+"] is "+expectedURL);
                DataStorage.setCustomErrmsg("Actual URL for link ["+partialLinkName+"] is "+actualURL);
                Assert.assertEquals(partialLinkName + " link URL: " + link.getAttribute("href") + "\ndoes not match from test data file", expectedURL, actualURL);
                break;
            }
        }
        if(linkElem == null) {
            throw new org.openqa.selenium.ElementNotVisibleException(
                    "Failed to find visible element located by partialLinkText(" + partialLinkName + ")");
        }
    }
	//@Todo: Refactor out contentType parameter, no longer used
	public static String getAEMContent(String portalName, String contentType, String key) {
		DataStorage.setContentWithDynamicValue("");
		String value;

		if ("RBAContent".equalsIgnoreCase(contentType)) {
			FileInputStream fis = null;
			Properties props = null;
			String file = "";

			file = "AEMContent/" + DataStorage.getLanguage() + "_RBAContent.properties";
			try {
				fis = new FileInputStream(file);
				props = new Properties();
				props.load(fis);
			} catch (IOException e) {
				PageObjectBase.printDebugInformation(e);
				new PageObjectBase().isOtherFailure.set(true);
				Assert.fail(e.toString());
			}

			value = props.getProperty(key);
		} else {
			value = contentCache.get(portalName, key);

			if (value == null) {
				value = key;
				DataStorage.setCustomErrmsg("AEM key -[" + key + "] not present in file for the portal- " + portalName + "\nIt is OK if it's not an AEM key");
			} else if (value.isEmpty()) {
				new PageObjectBase().isOtherFailure.set(true);
				Assert.fail("AEM content not found for the key -" + key + " for portal- " + portalName);
			}

			String jsonString = "{ \"" + key + "\" : \"" + value + "\"}";
			org.json.simple.JSONObject json = stringToJsonObject(jsonString);

			AEMJsonReader jsonReader = new AEMJsonReader();
			try {            	value = jsonReader.getJSONObjectValue(json);
			} catch (ParseException e) {
				PageObjectBase.printDebugInformation(e);
			}
		}

		value = value.replaceAll("Opens in a new window or tab", "").trim();

		value = StringUtils.normalizeSpace(value);
		value = StringUtils.normalizeSpace(value);
		return value;
	}
	public static void printDebugInformation(Exception e) {
		System.out.println("::::DEBUG INFORMATION START::::");
		e.printStackTrace();
		System.out.println("::::DEBUG INFORMATION END::::\n\n");
	}
	public static org.json.simple.JSONObject stringToJsonObject(String jsonString) {
		try {
			JSONParser parser = new JSONParser();
			org.json.simple.JSONObject json = null;
			try {
				json = (org.json.simple.JSONObject) parser.parse(jsonString);
			} catch (ParseException e) {
				e.printStackTrace();
				Assert.fail("String to JSON object parsing error");
			}
			return json;
		} catch (Exception | AssertionError e) {
			System.out.println("::::DEBUG INFORMATION START::::");
			e.printStackTrace();
			System.out.println("::::DEBUG INFORMATION END::::");
			new PageObjectBase().isOtherFailure.set(true);
			Assert.fail("Error in String to JSON conversion");
			return null;
		}
	}
	public static String getPortalSpecificValueFromFile(String portalName, String key) {
		try {
			System.out.println("HI....Enter");
			String value = portalSpecificContentCache.get(portalName, key);

			if (value == null || value.isEmpty()) {
				Assert.fail(key + ": is retrieved as null/empty. Ensure to add Key and value in PortalSpecificContent/" + portalName + "/" + DataStorage.getLanguage() + "_PortalSpecific_Content.properties");
			}
			return value;
		} catch (Exception | AssertionError e) {
			System.out.println("::::DEBUG INFORMATION START::::");
			e.printStackTrace();
			System.out.println("::::DEBUG INFORMATION END::::");
			new PageObjectBase().isOtherFailure.set(true);
			Assert.fail("Error in getting Portal specific value from file");
			return null;
		}
	}

	public static String getPortalConfig(String portalName, String dataKey) {
		return getPortalConfig(portalName, dataKey, true);
	}
	public boolean clickElementByXpath(String xpath) {
		try {
			waitForJavascriptToLoad(10000, 2000);
			WebElement elem = smallWait.get().until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));
			scrollElementIntoView(elem);
			((JavascriptExecutor) DriverFactory.getDeviceDriver()).executeScript("arguments[0].click();", elem);
			return true;
		} catch (Exception e) {
			PageObjectBase.printDebugInformation(e);
			isLocatorFailure.set(true);
			Assert.fail("Error in clicking the element by xPath: "+xpath);
			return false;
		}
	}
	public boolean verifySubHeadingByH2Tag(String expectedSubHeading) {
		List<WebElement> subHeadings = mediumWait.get()
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.tagName("h2")));
		String h2subHeading = null;
		for (WebElement actualSubHeading : subHeadings) {
			if (actualSubHeading.getText().contains(expectedSubHeading)) {
				h2subHeading = actualSubHeading.getText();
			}
		}
		return h2subHeading != null;
	}
	public boolean verifyPageHeadingByH1Tag(String expectedSubHeading) {
		List<WebElement> subHeadings = mediumWait.get()
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.tagName("h1")));
		String pageHeading = null;
		for (WebElement actualPageHeading : subHeadings) {
			if (actualPageHeading.getText().contains(expectedSubHeading)) {
				pageHeading = actualPageHeading.getText();
				break;
			}
		}
		return pageHeading != null;
	}
	public boolean verifyPageHeadingByH1newTag(String expectedSubHeading) {
		try {
			List<WebElement> subHeadings = mediumWait.get()
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.tagName("h1new")));

			String pageHeading = null;
			for (WebElement actualPageHeading : subHeadings) {
				if (actualPageHeading.getText().contains(expectedSubHeading)) {
					pageHeading = actualPageHeading.getText();
					break;
				}
			}
			return pageHeading != null;
		}catch (Exception e){
			return false;
		}
	}
	public boolean verifyRememberMeSection(String pageName) {
		try {
			SignInPageStepDefinition signInStepDef = new SignInPageStepDefinition();
			CommonStepDefinition commonStepDef = new CommonStepDefinition();
			SigninAndSecuritySettingsStepDefinition SNSStepDef = new SigninAndSecuritySettingsStepDefinition();

			signInStepDef.i_should_see_the_label("TxtRememberMe");
			signInStepDef.iShouldSeeTheRemembermeCheckbox();
			signInStepDef.iClickOnRemembermeCheckbox();

			if (!pageName.equalsIgnoreCase("RBA"))//This label will not be displayed for RBA page
				signInStepDef.i_should_see_the_label("TxtRememberMeNotice");

			//trusted device link validation
			commonStepDef.verifyWebElementText("trusted device", "Link");
			commonStepDef.clickWebElement("trusted device", "Link");
			commonStepDef.i_should_see_a_modal_dialog();
			commonStepDef.i_should_see_the_modal_heading("HdrTrustedDevice");

			if (pageName.equalsIgnoreCase("RBA"))
				commonStepDef.i_click_button("trusted-device-modal_closeButton");
			else
				SNSStepDef.iClickOnCloseButtonOnModelView();
			return true;
		} catch (Exception e) {
			PageObjectBase.printDebugInformation(e);
			isOtherFailure.set(true);
			Assert.fail("Error in verifying remember me section");
			return false;
		}
	}
	public static String getPortalConfig(String portalName, String dataKey, boolean failIfNull) {
		String dataValue = null;

		try {
			dataValue = configCache.get(portalName, dataKey);

			if (failIfNull && (dataValue == null || dataValue.isEmpty())) {
				new PageObjectBase().isDataFailure.set(true);
				Assert.fail("Value for the key[" + dataKey + "] is retrieved as empty or null for portal: " + portalName);
			}
		} catch (Exception | AssertionError e) {
			System.out.println("::::DEBUG INFORMATION START::::");
			e.printStackTrace();
			System.out.println("::::DEBUG INFORMATION END::::");
			new PageObjectBase().isOtherFailure.set(true);
			Assert.fail("Value for the key[" + dataKey + "] is retrieved as empty or null for portal: " + portalName);
		}
		return dataValue;
	}
}
