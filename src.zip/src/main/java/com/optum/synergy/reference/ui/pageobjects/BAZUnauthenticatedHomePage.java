package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.optum.synergy.reference.ui.utility.ReadXMLData;

public class BAZUnauthenticatedHomePage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//*[contains(text(),'Welcome')]")
	private WebElement welcometoBAZ;

	public void openBAZHomePage() {
		String page_url= ReadXMLData.getTestData("BAZ", "AppURL");
		openPage(page_url);
	}

	public boolean isPageLoaded() {
		return longWait.get().until(ExpectedConditions.visibilityOf((welcometoBAZ))).isDisplayed();
	}

}
