package com.optum.synergy.reference.ui.stepDefinitions;

import cucumber.api.java.en.When;
import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.BriovaRxUnauthenticatedHomePage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.Given;


public class BriovaRxUnauthenticatedHomePageStepDefinition {

	private BriovaRxUnauthenticatedHomePage page;
	
	public BriovaRxUnauthenticatedHomePageStepDefinition() {
		page = new BriovaRxUnauthenticatedHomePage();
	}
	
	@Given("^I am at BriovaRx unauthenticated home page$")
	public void i_am_at_BriovaRx_unauthenticated_home_page() {
		page.openBriovaRxHomePage();
	    Assert.assertTrue("Issue while loading the BriovaRx Unauthenticated page", page.isPageLoaded());
	}
	
	@Then("^I should be at BriovaRx unauthenticated home page$")
	public void iShouldBeAtBriovaRxUnauthenticatedHomePage() {
		Assert.assertTrue("Issue while loading the BriovaRx Unauthenticated page", page.isPageLoaded());
	}

	@When("^I click on \"([^\"]*)\" link under \"([^\"]*)\" drop down$")
	public void iClickOnLinkUnderDropDown(String childLinkValue, String dropDownLinkValue) throws Throwable {
		page.clickLinkUnderDropDown(childLinkValue, dropDownLinkValue);
	}

}
