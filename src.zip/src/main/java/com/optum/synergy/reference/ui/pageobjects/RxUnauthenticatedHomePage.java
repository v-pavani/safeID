package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.optum.synergy.reference.ui.utility.ReadXMLData;

public class RxUnauthenticatedHomePage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//*[@id='welcome_component']//h1[contains(text(),'Welcome')]")
	private WebElement welcomeToOptumRx;
	
	@FindBy(how = How.XPATH, using = "//*[@id='loginWelcome' and contains(text(),'Welcome to OptumRx')]")
	private WebElement mobileWelcomeToOptumRx;

	@FindBy(how = How.XPATH, using = "//*[@name='personalInfo']|//div[@id='bigFive_page']")
	private WebElement personalInfoSection;

	public void openRXHomePage() {
		String page_url = ReadXMLData.getTestData("OptumRx", "OptumRxHSIDRegisterURL");
		openPage(page_url);
	}

	public boolean verifyIfPageLoaded() {
		try {
			waitForJavascriptToLoad(25000, 1000);
			longWait.get().until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(personalInfoSection)));
			return true;
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public void openORXAARPHomePage() {
		String page_url = ReadXMLData.getTestData("OptumRx", "OptumRxAARPURL");
		openPage(page_url);
	}

	public WebElement getOptumRxUnauthenticatedPageelement() {
		waitForPageLoad(driver);
		waitForJavascriptToLoad(60000, 500);
		WebElement ele = mediumWait.get().until(ExpectedConditions.visibilityOf(welcomeToOptumRx));
		try {
			smallWait.get()
					.until(ExpectedConditions
							.visibilityOfElementLocated(By.xpath("//*[starts-with(@class,'QSIPopOver SI')]//div[2]")))
					.click();
		} catch (Exception e) {
		}
		return ele;
	}

	public WebElement getRxPortalsReturnToLoginPageElement(String portalText) {
		waitForPageLoad(driver);
		waitForJavascriptToLoad(60000, 3000);
		return longWait.get().until(ExpectedConditions.visibilityOf((driver.findElement(By.xpath("//*[contains(text(),'"+portalText+"')]")))));
	}
	
	public void openRXMobileHomePage() {
		String page_url = ReadXMLData.getTestData("OptumRx", "MobileAppURL");
		openPage(page_url);
	}
	
	public boolean getRxMobileWelcomeMessage() {
		try {
			mediumWait.get().until(ExpectedConditions.visibilityOf(mobileWelcomeToOptumRx));
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	
	
}
