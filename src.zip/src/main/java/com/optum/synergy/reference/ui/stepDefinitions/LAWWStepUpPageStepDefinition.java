package com.optum.synergy.reference.ui.stepDefinitions;

import com.optum.synergy.reference.ui.pageobjects.LAWWStepUpPage;
import cucumber.api.java.en.Then;
import org.junit.Assert;

public class LAWWStepUpPageStepDefinition {
    private LAWWStepUpPage page;

    public LAWWStepUpPageStepDefinition() {
        page = new LAWWStepUpPage();
    }

    @Then("^I click on Benefits & Claims$")
    public void iClickOnBenefitsClaims() {
        page.benefitsAndClaimsClick();
    }

    @Then("^I click on View Claim Status link$")
    public void iClickOnViewClaimStatusLink() {
        page.viewClaimsStatusClick();
    }

    @Then("^I should be at We need you to verify your information page$")
    public void iShouldBeAtWeNeedYouToVerifyYourInformationPage() {
        page.verifyIfPageLoaded();
    }

    @Then("^I should see an error message \"([^\"]*)\" $")
    public void iShouldSeeAnErrorMessage(String message) {
        Assert.assertTrue("Error content not found on the page", page.verifyErrorMessageOnAccessNotConfirmed(message));

    }

}
