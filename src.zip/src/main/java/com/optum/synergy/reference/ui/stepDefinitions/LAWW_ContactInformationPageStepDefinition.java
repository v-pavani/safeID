package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;
import com.optum.synergy.reference.ui.pageobjects.LAWW_ContactInformationPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class LAWW_ContactInformationPageStepDefinition {
	private LAWW_ContactInformationPage page;

	public LAWW_ContactInformationPageStepDefinition() {
		page = new LAWW_ContactInformationPage();
	}

	@Given("^I should see the \"([^\"]*)\" label in contact information page$")
	public void iShouldSeeTheLabelInContactInformationPage(String label) throws Throwable {
		Thread.sleep(4000);
		page.switchToContentFrame();
		Assert.assertEquals(true, page.getContactInformation().contains(label));
		page.switchToDefaultContent();
	}

	@When("^I click on Email addresses box in contact information page$")
	public void iClickOnEmailAddressesBoxInContactInformationPage() {
		page.switchToContentFrame();
		page.getEmailBox().click();
		page.switchToDefaultContent();
	}

	@When("^I should see a \"([^\"]*)\" link in contact information page$")
	public void iShouldSeeALinkInContactInformationPage(String linkName) {
		page.switchToContentFrame();
		Assert.assertEquals(page.findPartialLinkText(linkName), true);
		page.switchToDefaultContent();
	}
	
	@When("^I click on \"([^\"]*)\" link in contact information page$")
	public void iClickOnLinkInContactInformationPage(String linkName) {
		page.scrollthePageDown();
		page.switchToContentFrame();
		page.clickLink(linkName);
		page.switchToDefaultContent();
	}
}
