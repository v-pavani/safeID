package com.optum.synergy.reference.ui.stepDefinitions;

import com.optum.synergy.reference.ui.pageobjects.BSCAAuthenticatedHomePage;
import cucumber.api.java.en.Then;
import org.junit.Assert;

public class BSCAAuthenticatedHomePageStepDefinition {
	
	private BSCAAuthenticatedHomePage page;
	
	public BSCAAuthenticatedHomePageStepDefinition(){
		page= new BSCAAuthenticatedHomePage();
	}
		
	@Then("^I should be at BSCA authenticated home page$")
	public void iShouldBeAtBSCAAuthenticatedHomePage() {
		Assert.assertTrue("Issue while loading the BSCA authenticated page", page.verifyIfHomePageContentIsDisplayed());
		//TODO: Page title sometimes returns as "Welcome to myuhc.com", allowing either for now.
		String pageTitle = page.getPageTitle();
		Assert.assertTrue("Unexpected page title [" + pageTitle + "]", 
				pageTitle.equals("bsca Home") 
					|| pageTitle.equals("Welcome to yourdentalplan.com")
					|| pageTitle.equals("Dental Portal Home")
					|| pageTitle.equalsIgnoreCase("Welcome to myuhc.com")
				);
	}

}