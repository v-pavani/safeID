package com.optum.synergy.reference.ui.pageobjects;

import com.optum.synergy.reference.ui.utility.ReadXMLData;


public class BriovaRxUnauthenticatedHomePage extends PageObjectBase {
	
	public void openBriovaRxHomePage() {
		String page_url = ReadXMLData.getTestData("BRIOVARX", "BriovaRxHSIDSignInURL");
		openPage(page_url);
	}

	public boolean isPageLoaded() {
		return getPageTitle().equalsIgnoreCase("HealthSafe ID - Sign in to Optum Specialty Pharmacy") && verifyButtonByText("Sign in");
	}

	public void clickLinkUnderDropDown(String childLinkValue, String dropDownLinkValue) throws Exception {
		/*Actions action = new Actions(driver);
		Consumer<By> hover = (By by) -> {
			action.moveToElement(driver.findElement(by)).perform();
		};
		hover.accept(By.linkText(dropDownLinkValue));
		driver.findElement(By.partialLinkText(childLinkValue)).click();*/

		clickButtonByText(dropDownLinkValue);
		Thread.sleep(1000);
		clickPartialLink(childLinkValue);
	}

}
