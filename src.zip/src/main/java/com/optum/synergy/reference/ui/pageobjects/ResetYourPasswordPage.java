package com.optum.synergy.reference.ui.pageobjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class ResetYourPasswordPage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//*[@name='accountInfo']|//*[@class='ng-scope']")
	private WebElement resetYourPasswordForm;
   
	@FindBy(how = How.NAME, using = "sqForm")
	private WebElement securityQuestionForm;
	
	@FindBy(how = How.XPATH, using = "//*[@name='phoneInfoForm']|//*[contains(@ng-if,'recoveryOptionPhone')]")
	private WebElement PhoneForm;	
	
	@FindBy(how = How.XPATH, using = "//flex-content[@id='Logo']/p/a/img[@src='https://myoptum-stage.optum.com/content/dam/OptumDashboard/ad-box/logos/optum-logo.png']"
			+ "|//img[contains(@src,'optum-logo.png')]"
			+ "|//img[contains(@src,'OPTUM_RGB.png')]"
			+ "|//img[@src='https://globalnav-stage.optum.com/ognui20/modules/core/img/brand/optum-logo.png']|//*[@id='Logo']//img[contains(@src,'OPTUM.gif')]"
			+ "|//*[contains(@class,'optum-logo')]//img[contains(@src,'logo.png')]" + "|//img[contains(@src,'logo.png')]")
	private WebElement optumLogo;
	
	@FindBy(how = How.XPATH, using = "//input[@id='answer-0']")
	private WebElement securityAnswer1TextBox;
	
	@FindBy(how = How.XPATH, using = "//input[@id='answer-1']")
	private WebElement securityAnswer2TextBox;
	
	@FindBy(how = How.XPATH, using = "//label[@for='answer-0']/span[1]")
	private WebElement securityQuestion1Label;
	
	@FindBy(how = How.XPATH, using = "//label[@for='answer-1']/span[1]")
	private WebElement securityQuestion2Label;
	
	@FindBy(how = How.ID, using = "password")
	private WebElement passwordTextBox;

	@FindBy(how = How.ID, using = "confirmPassword")
	private WebElement confirmPasswordTextBox;
		
	@FindBy(how = How.XPATH, using = "//flex-content[contains(@class,'center-align')]//*[@ng-if='!errElementId']|//div[@id='pageErrors']")
	private WebElement accountLockedErrorMessage;
	
	@FindBy(how = How.CLASS_NAME, using = "icon-sms_text")
	private WebElement textMeLink;

	@FindBy(how=How.XPATH, using ="//*[@ng-show='answerErrors[0]']/span")
	private WebElement errMsgForAnswer1;
	
	@FindBy(how=How.XPATH, using ="//*[@ng-show='answerErrors[1]']/span")
	private WebElement errMsgForAnswer2;
	
	@FindBy(how=How.XPATH, using ="//*[@ng-if='errElementId']|//*[@ng-if='!errElementId']")
	private WebElement aggregateErrMsgForAnswer;
	
	@FindBy(how=How.XPATH, using ="//*[@for='password']/span")
	private WebElement newPasswordLabel;
	
	@FindBy(how=How.XPATH, using ="//*[@ng-show='passwordError']")
	private WebElement errMsgForNewPassword;
	
	@FindBy(how=How.XPATH, using ="//*[@ng-show='confirmPasswordError']")
	private WebElement errMsgForReEnterNewPassword;
	
	@FindBy(how = How.XPATH, using = "//*[@id='pageErrors']|//span[starts-with(@ng-if,'!errElementId')]|//span[starts-with(@ng-if,'!errElementId')]")
	private WebElement errorMsg;
	
	@FindBy(how = How.XPATH, using = "//span[@class='strong error']/parent::p[contains(string(), 'Error:')][contains(string(), 'We')][contains(string(),'unable to reset' )]|//span[@class='ng-scope']")
	private WebElement errorText;
	
	@FindBy(how = How.XPATH, using = "//p[starts-with(@ng-if,'pageMessages')]")
	private WebElement successMessageAfterResetPassword;
	
	@FindBy(how = How.XPATH, using = "//input[@id='username']")
	private WebElement userNameTextBox1;
	
	@FindBy(how = How.XPATH, using = "//div[@ng-show='formDesc']")
	private WebElement errorMessageRecoverPassword;
	
	
	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			return longWait.get().until(ExpectedConditions.visibilityOf(resetYourPasswordForm)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public boolean verifyIfSecurityQuestionPageLoaded() {
		try {
			waitForPageLoad(driver);
			return longWait.get().until(ExpectedConditions.visibilityOf(securityQuestionForm)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public boolean verifyIfPhonePageLoaded() {
		try {
			waitForPageLoad(driver);
			return longWait.get().until(ExpectedConditions.visibilityOf(PhoneForm)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public boolean verifyForPageHeader(String header) {
		List<WebElement> elems = smallWait.get()
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//*[@id='header']")));
		for (WebElement elem : elems) {
			if (elem.getText().trim().equals(header)) {
				return true;
			}
		}
		return false;
	}

	public boolean verifyForUserNameTextBoxWithHeading(String heading) {
		return mediumWait.get()
				.until(ExpectedConditions.visibilityOfElementLocated(
						By.xpath("//input[@id='username']/preceding-sibling::span[contains(.,'" + heading + "')]")))
				.isDisplayed();
	}
	
	public boolean verifyForTheOptumLogo() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(optumLogo)).isDisplayed();
	}

	public String getHeaderTextOfHeadingsAlongWithSteps(String stepNumber){
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath( "//*[contains(@class,'circle') and contains(text(),'"+stepNumber+"')]/parent::p/parent::flex-content/following-sibling::flex-content/h2"))).getText().trim();
	}

	public String getCSSValueIfHeaderBoldOrNotOfHeadingsAlongWithSteps(String stepNumber){
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath( "//*[contains(@class,'circle') and contains(text(),'"+stepNumber+"')]/parent::p/parent::flex-content/following-sibling::flex-content/h2"))).getCssValue("font-weight");
	}
	
	public void enterPassword(String password) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(passwordTextBox));
		passwordTextBox.clear();
		passwordTextBox.sendKeys(password);
	}

	public void enterConfirmPassword(String password) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(confirmPasswordTextBox));
		confirmPasswordTextBox.clear();
		confirmPasswordTextBox.sendKeys(password);
	}
	
	public String verifySuccessMessageAfterResetPassword(String text) {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@class='ng-binding']/span[contains(.,'"+text+"')]|//*[@id='hsid-commonError']/p/span[2]|//*[@id='hsid-wdgt-commonError']/p/span[2]"))).getText();
	}
	
	public String verifyAccountLockedErrorMessage()	{
		waitForPageLoad(driver);
		waitForJavascriptToLoad(30000, 3000);
		return smallWait.get().until(ExpectedConditions.visibilityOf(accountLockedErrorMessage)).getText();
	}
	
	public boolean verifyTextMeLink() {
		waitForPageLoad(driver);
		waitForJavascriptToLoad(30000, 3000);
		mediumWait.get().until(ExpectedConditions.visibilityOf(textMeLink));
		return textMeLink.isDisplayed();
	}
	
	public void clickTextMeLink() {
		waitForPageLoad(driver);
		waitForJavascriptToLoad(30000, 3000);
		mediumWait.get().until(ExpectedConditions.visibilityOf(textMeLink));
		textMeLink.click();
	}
	
	public void enterValidSecurityAnsweOnResetYourPasswordPage() throws Exception {
		Thread.sleep(2000);
		waitForJavascriptToLoad(10000, 1000);
		for(int i=0; i<2; i++){
		String SecurityQtn = mediumWait.get()
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='sqForm']/div/label[@for='answer-"+i+"']/span[1]"))).getText();
		WebElement answerField = mediumWait.get()
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='answer-"+i+"']")));
		answerField.clear();
		
		if (SecurityQtn.contains("number")) {
			answerField.sendKeys("number1");
		} else if (SecurityQtn.contains("name")) {
			answerField.sendKeys("name1");
		} else if (SecurityQtn.contains("team")) {
			answerField.sendKeys("team1");
		} else if (SecurityQtn.contains("color")) {
			answerField.sendKeys("color1");
		} else {
			throw new Exception("unknown challenge " + SecurityQtn);
		}
		}
	}
	
	public Boolean verifyLabels(String field){
		switch(field) {
		case "securityanswer1": if(mediumWait.get().until(ExpectedConditions.visibilityOf(securityAnswer1TextBox)).isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(securityQuestion1Label)).isDisplayed();
		case "securityanswer2": if(securityAnswer2TextBox.isDisplayed()) return mediumWait.get().until(ExpectedConditions.visibilityOf(securityQuestion2Label)).isDisplayed();
		default: return false;
		}
	}
	
	public Boolean enterValuesintoFieldsOnResetPasswordPage(String field, String value){
		switch(field) {
		case "securityanswer1": mediumWait.get().until(ExpectedConditions.visibilityOf(securityAnswer1TextBox)).clear(); securityAnswer1TextBox.sendKeys(value); return true;
		case "securityanswer2": mediumWait.get().until(ExpectedConditions.visibilityOf(securityAnswer2TextBox)).clear(); securityAnswer2TextBox.sendKeys(value); return true;
		case "newpassword": mediumWait.get().until(ExpectedConditions.visibilityOf(passwordTextBox)).clear(); passwordTextBox.sendKeys(value); return true;
		case "reEnterNewPassword": mediumWait.get().until(ExpectedConditions.visibilityOf(confirmPasswordTextBox)).clear(); confirmPasswordTextBox.sendKeys(value); return true;

		default: return false;
		}
	}
	
	public String getErrMsgForResetAccountPage(String field){
		switch(field) {
		case "securityanswer1": return mediumWait.get().until(ExpectedConditions.visibilityOf(errMsgForAnswer1)).getText();
		case "securityanswer2":return mediumWait.get().until(ExpectedConditions.visibilityOf(errMsgForAnswer2)).getText();
		case "newpassword":return mediumWait.get().until(ExpectedConditions.visibilityOf(errMsgForNewPassword)).getText();
		case "reEnterNewPassword":return mediumWait.get().until(ExpectedConditions.visibilityOf(errMsgForReEnterNewPassword)).getText();	
		default: return "Either field or label not present.";
		}
	}
	
	public String getaggregateErrMsgForAnswer() {
		try {
			return mediumWait.get().until(ExpectedConditions.visibilityOf(aggregateErrMsgForAnswer)).getText(); //mediumWait for Update PW Errors
		} catch (Exception e) {}
		return null;
	}
	
	public boolean enterValidSQA(String field) throws Exception{
		switch(field) {
		case "securityanswer1":
		String SecurityQtn = mediumWait.get()
				.until(ExpectedConditions.visibilityOf(securityQuestion1Label)).getText();
		WebElement answerField = mediumWait.get().until(ExpectedConditions.visibilityOf(securityAnswer1TextBox)); 
		answerField.clear();

		if (SecurityQtn.contains("number")) {
			answerField.sendKeys("number1");
		} else if (SecurityQtn.contains("name")) {
			answerField.sendKeys("name1");
		} else if (SecurityQtn.contains("team")) {
			answerField.sendKeys("team1");
		} else if (SecurityQtn.contains("color")) {
			answerField.sendKeys("color1");
		} else {
			throw new Exception("unknown challenge " + SecurityQtn);
		}
		return true;
		case "securityanswer2": 
		 SecurityQtn = mediumWait.get()
				.until(ExpectedConditions.visibilityOf(securityQuestion2Label)).getText();
		 answerField = mediumWait.get().until(ExpectedConditions.visibilityOf(securityAnswer2TextBox)); 
		 answerField.clear();

		if (SecurityQtn.contains("number")) {
			answerField.sendKeys("number1");
		} else if (SecurityQtn.contains("name")) {
			answerField.sendKeys("name1");
		} else if (SecurityQtn.contains("team")) {
			answerField.sendKeys("team1");
		} else if (SecurityQtn.contains("color")) {
			answerField.sendKeys("color1");
		} else {
			throw new Exception("unknown challenge " + SecurityQtn);
		}
		return true;
		
		default: return false;
		}
	}
	
	public boolean verifyLabelsAndFieldForNewPasswordField(){
		mediumWait.get().until(ExpectedConditions.visibilityOf(newPasswordLabel)).isDisplayed();
		return mediumWait.get().until(ExpectedConditions.visibilityOf(passwordTextBox)).isDisplayed();
	}
	
	public boolean verifyNoErrorMessageOnPasswordField(String field) {
		switch(field) {
		case "newpassword": 
			try {
				return !smallWait.get().until(ExpectedConditions.visibilityOf(errMsgForNewPassword)).isDisplayed();
			} catch (TimeoutException e) {
				return true;
			}		
		case "reEnterNewPassword": 
			try {
				return !smallWait.get().until(ExpectedConditions.visibilityOf(errMsgForReEnterNewPassword)).isDisplayed();
			} catch (TimeoutException e) {
				return true;
			}		
		default: return false;
		}
	}
	
	public boolean verifytextOnResetyourPasswordPhoneStep2Page(String message) {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//*[@id='phoneInfoForm']//p[contains(.,'"+message + "')]|//span[contains(.,'"+message + "')]|//*[@id='phoneInfoForm']//p[contains(@class,'strong')]/a/span|//button[contains(.,'"+message + "')]|//p[contains(.,'"+message+"')]|//div[contains(@ng-include,'callAfterConfirmModal.html')]//p[contains(.,'"+message + "')]"))).isDisplayed();
	}
	
	public boolean verifyGreencheckMarkandHeading(String stepLabel) {
		return mediumWait.get()
				.until(ExpectedConditions.presenceOfElementLocated(By
						.xpath("//*[contains(@src,'check-mark.png')]/../../../following-sibling::flex-content[contains(.,'"+ stepLabel +"')]"))).isDisplayed();
	}
	
	public WebElement getAccountLockedErrorMessage() {
		return longWait.get().until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(errorMsg)));
	}
	
	public WebElement getWebElementOnSuccessMessageAfterResetPassword() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(successMessageAfterResetPassword));
	}
	
	public WebElement getErrorMessage() {
		return longWait.get().until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(errorText)));
	}
	
	public void enterUserName(String username) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(userNameTextBox1));
		userNameTextBox1.clear();
		userNameTextBox1.sendKeys(username);
	}

	public WebElement getErrorMessageElement() {
		waitForJavascriptToLoad(10000, 1000);
		return mediumWait.get().until(ExpectedConditions.visibilityOf(errorMessageRecoverPassword));
	}
}

