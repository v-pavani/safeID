package com.optum.synergy.reference.ui.stepDefinitions;

import java.util.List;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.NoAccessPage;

import cucumber.api.java.en.Then;

public class NoAccessPageStepDefinition {
	private NoAccessPage page;

	public NoAccessPageStepDefinition() {
		page = new NoAccessPage();
	}

	@Then("^I should be at No-Access page$")
	public void iShouldBeAtNoAccessPage() {
		Assert.assertTrue("Failed to load No Access Page", page.verifyIfPageLoaded());
	}

	@Then("^I should see the following error messages in No-Access page$")
	public void iShouldSeeTheFollowingErrorMessagesInNoAccessPage(List<String> errMsgs) {
		for (String errMsg : errMsgs) {
			Assert.assertTrue("Content comparison failure: \nExpected: "+errMsg+"\nActual: "+page.getErrorMsg(), page.getErrorMsg().contains(errMsg));
		}
	}

	@Then("^I should see the \"([^\"]*)\" error message in No-Access page$")
	public void iShouldSeeTheFollowingErrorMessageInNoAccessPage(String errMsg) {
		Assert.assertEquals(errMsg, page.getNoAccessErrorMessage());
	}

	@Then("^I should see the following error messages on No-Access page after Sign in$")
	public void iShouldSeeTheFollowingErrorMessagesOnNoAccessPageAfterSignIn(List<String> errMsgs) {
		String errorMessage = "";
		boolean firstIteration = true;
		for (String errMsg : errMsgs) {
			if (firstIteration) {
				errorMessage = errMsg;
				firstIteration = false;
			} else {
				errorMessage = errorMessage + "\n" + errMsg;
			}
		}
		Assert.assertEquals(errorMessage, page.getNoAccessPageErrorMessageElementAfterSignin().getText());
	}
	
	@Then("^I should see \"([^\"]*)\" mark in circle with heading \"([^\"]*)\"$")
	public void iShouldSeeAnMarkInCircleOnErrorPage(String step, String header){
		Assert.assertEquals("Help content is displayed",header,page.getStepAndHeading(step));
	}

}
