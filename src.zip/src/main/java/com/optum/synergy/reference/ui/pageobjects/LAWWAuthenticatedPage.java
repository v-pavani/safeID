package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LAWWAuthenticatedPage extends PageObjectBase {

    @FindBy(how = How.XPATH, using = "//*[@id='global-profile-container']|//*[@id='usermenu']")
    private WebElement globalNavUserMenu;

    @FindBy(how = How.XPATH, using = "//*[@class='rallyredirectmesseage']")
    private WebElement EAPPopUp;

    public boolean verifyIfUserMenuDisplayedOnGlobalNav() {
        waitForPageLoad(driver);
        waitForJavascriptToLoad(30000, 3000);
        return longWait.get().until(ExpectedConditions.visibilityOf(globalNavUserMenu)).isDisplayed();
    }

    public boolean verifyEAPPopUpDisplayed() {
        try {
            return longWait.get().until(ExpectedConditions.visibilityOf(EAPPopUp)).isDisplayed();
        }
        catch(Exception e){
            return false;
        }
    }
}
