package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

public class OptumRx_RequestaCallBackModalPage extends PageObjectBase {

	@FindBy(how = How.ID, using = "phoneNumber")
	private WebElement phoneTextBox;

	@FindBy(how = How.ID, using = "cnfPhoneNumber")
	private WebElement confirmPhoneTextBox;

	@FindBy(how = How.XPATH, using = "//select[@id='callMe']")
	private WebElement bestTimeToCallDropdown;

	@FindBy(how = How.XPATH, using = "//label[@for='phoneNumber']")
	private WebElement phoneNumberLabel;

	@FindBy(how = How.XPATH, using = "//label[@for='cnfPhoneNumber']")
	private WebElement confirmPhoneNumberLabel;

	@FindBy(how = How.XPATH, using = "//label[@for='callMe']")
	private WebElement bestTimeToCallLabel;

	public WebElement getPhoneNumber() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(phoneTextBox));
	}

	public WebElement getConfirmPhoneNumber() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmPhoneTextBox));
	}

	public void selectCallMeType(String dropDownValue) {
		mediumWait.get().until(ExpectedConditions.textToBePresentInElement(bestTimeToCallDropdown, dropDownValue));
		Select dropdown = new Select(bestTimeToCallDropdown);
		dropdown.selectByVisibleText(dropDownValue);
	}

	public WebElement getPhoneNumberLabel() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(phoneNumberLabel));
	}

	public WebElement getConfirmPhoneNumberLabel() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(confirmPhoneNumberLabel));
	}

	public WebElement getBestTimeToCallLabel() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(bestTimeToCallLabel));
	}
}
