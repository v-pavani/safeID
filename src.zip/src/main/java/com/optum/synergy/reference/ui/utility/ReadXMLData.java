package com.optum.synergy.reference.ui.utility;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.junit.Assert;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

/**
 * @author rtripa1
 *
 */
public class ReadXMLData {
	public static String getTestData(String SectionName, String NodeName) {
		String env= System.getProperty("ExecutionEnv");
		
		SectionName = "Project/"+env+"/"+ SectionName+ "/" + NodeName;				
		File fXmlFile = new File("TestData.xml");
		String foundData = null;
		
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		NodeList nodeList;
		Document doc;

		try {
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			javax.xml.xpath.XPath xPath = XPathFactory.newInstance().newXPath();			
			nodeList = (NodeList) xPath.compile(SectionName).evaluate(doc, XPathConstants.NODESET);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Exception reading TestData.xml [" + e.getMessage()
					+ "]\n[" + e.getStackTrace().toString() + "]");
			return null;
		}
		for (int temp = 0; temp < nodeList.getLength(); temp++) {

			org.w3c.dom.Node nNode = nodeList.item(temp);
			if (nNode.getNodeName().equals(NodeName)) {
				foundData = nNode.getTextContent().trim();
			}
		}
		
		
		Assert.assertNotNull("Failed to find data in TestData.xml for [" + SectionName + "]", foundData);
		String[] tagData = foundData.split("::");
		switch ( tagData[0] ) {
		case "SYSTEM_PROP":
			foundData = System.getProperty(tagData[1]);
			Assert.assertNotNull("Failed to find value for property [" + tagData[1] + "]", foundData);
			break;
		case "SYSTEM_ENV":
			foundData = System.getenv(tagData[1]);
			Assert.assertNotNull("Failed to find value for env variable [" + tagData[1] + "]", foundData);
			break;
		}
		
		return foundData;
	}

	/**
	 * Returns list of nodes matching NodeName within SectionName
	 * 
	 * @param SectionName
	 * @param NodeName
	 * @return
	 */
	public static List<String> getTestDataList(String SectionName, String NodeName) {
		
		SectionName = "Project/" + SectionName+ "/" + NodeName;				
		File fXmlFile = new File("TestData.xml");
		List<String> returnedList = new ArrayList<String>();
		
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		NodeList nodeList;
		Document doc;
	
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			javax.xml.xpath.XPath xPath = XPathFactory.newInstance().newXPath();			
			nodeList = (NodeList) xPath.compile(SectionName).evaluate(doc, XPathConstants.NODESET);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		for (int temp = 0; temp < nodeList.getLength(); temp++) {
	
			org.w3c.dom.Node nNode = nodeList.item(temp);
			if (nNode.getNodeName().equals(NodeName)) {
				returnedList.add( nNode.getTextContent().trim() );
			}
		}
		return returnedList;
	}

	public static List<String> getNodeList(String SectionName, String NodeName) {
		String env= System.getProperty("ExecutionEnv");
		//String env="Stage";

		SectionName = "Project/"+env+"/"+ SectionName+ "/" + NodeName;
		File fXmlFile = new File("TestData.xml");
		List<String> returnedList = new ArrayList<String>();

		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		NodeList nodeList1,nodeList2;
		Document doc;

		try {
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			javax.xml.xpath.XPath xPath = XPathFactory.newInstance().newXPath();
			nodeList1 = (NodeList) xPath.compile(SectionName).evaluate(doc, XPathConstants.NODESET);
			org.w3c.dom.Node nNode = nodeList1.item(0);
			nodeList2 = nNode.getChildNodes();
			for (int i = 0;i < nodeList2.getLength(); i++) {
				org.w3c.dom.Node node = nodeList2.item(i);
				if (node.getNodeType() == org.w3c.dom.Node.ELEMENT_NODE) {
					returnedList.add(node.getNodeName());
					System.out.println(node.getNodeName());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Exception reading TestData.xml [" + e.getMessage()
					+ "]\n[" + e.getStackTrace().toString() + "]");
			return null;
		}
		return returnedList;
	}
}
