package com.optum.synergy.reference.ui.stepDefinitions;

import com.optum.synergy.reference.ui.pageobjects.UserMenuDropdownWindowPage;

import cucumber.api.java.en.When;

public class UserMenuDropdownWindowPageStepDefinition {
	private UserMenuDropdownWindowPage page;

	public UserMenuDropdownWindowPageStepDefinition() {
       page = new UserMenuDropdownWindowPage();
    }

    @When("^I click on Sign out button on Usermenu dropdown$")
    public void i_click_on_Sign_out_button_on_Usermenu_dropdown() {
        page.clickSignoutButton();
    }
}
