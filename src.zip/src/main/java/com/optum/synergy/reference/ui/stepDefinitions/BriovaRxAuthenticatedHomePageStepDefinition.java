package com.optum.synergy.reference.ui.stepDefinitions;

import com.optum.synergy.reference.ui.pageobjects.BriovaRxAuthenticatedHomePage;

import cucumber.api.java.en.Then;
import org.junit.Assert;

public class BriovaRxAuthenticatedHomePageStepDefinition {
	
	private BriovaRxAuthenticatedHomePage page;

	public BriovaRxAuthenticatedHomePageStepDefinition() {
		page = new BriovaRxAuthenticatedHomePage();
	}
	
	@Then("^I should be at BriovaRx authenticated home page$")
	public void i_should_be_at_BriovaRx_authenticated_home_page() {
		Assert.assertTrue("Issue while loading the BriovaRx Unauthenticated page", page.verifyIfHomePageContentIsDisplayed());
	}

}
