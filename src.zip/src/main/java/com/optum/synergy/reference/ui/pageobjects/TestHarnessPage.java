package com.optum.synergy.reference.ui.pageobjects;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.optum.synergy.reference.ui.utility.ReadXMLData;

public class TestHarnessPage extends PageObjectBase {

	public static String page_url;

	public void openPage() throws FileNotFoundException, IOException, ParseException {
		page_url= ReadXMLData.getTestData("TestHarness", "LoginUrl");
		openPage(page_url);
	}

	@FindBy(how = How.ID, using = "HTTP_TARGETPORTAL_INPUT")
	private WebElement targetPortal;

	@FindBy(how = How.XPATH, using = "//*[@id='HTTP_ACTION_INPUT']")
	private WebElement userAction;
	
	@FindBy(how = How.XPATH, using = "//select[@id='RX_WHITELABEL_SITE']")
	private WebElement rxWhiteLabelSite;

	@FindBy(how = How.XPATH, using = "//select[@id='CAP_MARKETING_SITE_INPUT']")
	private WebElement capMarketingSite;

	@FindBy(how = How.XPATH, using = "//*[@id='HTTP_ELIGIBILITY_INPUT']")
	private WebElement userEligibility;

	@FindBy(how = How.XPATH, using = "//*[@id='HTTP_LANGUAGE_INPUT']")
	private WebElement userLanguage;

	@FindBy(how = How.XPATH, using = "//*[@id='HTTP_ACCESSTYPE_INPUT']")
	private WebElement accessType;

	@FindBy(how = How.ID, using = "authQuestionSubmitButton")
	private WebElement clickHarnessSubmit;

	@FindBy(how = How.LINK_TEXT, using = "Register")
	private WebElement registerLink;
	
	@FindBy(how = How.XPATH, using = "//*[@id='HTTP_TARGETURL_INPUT']")
	private WebElement HTTPtargetURLField;
	
	@FindBy(how = How.ID, using = "HTTP_SITEURL_INPUT")
	private WebElement siteURLField;
	
	@FindBy(how = How.XPATH, using = "//*[@id='PHS_SUBPORTAL_INPUT']")
	private WebElement selectphsSPortal;
	
	@FindBy(how = How.XPATH, using = "//*[@id='WH_SUBPORTAL_INPUT']")
	private WebElement selectWhSPortal;

	@FindBy(how = How.ID, using = "HTTP_GRADIENTCOLOR1_INPUT")
	private WebElement gradientColor1;

	@FindBy(how = How.ID, using = "HTTP_GRADIENTCOLOR2_INPUT")
	private WebElement gradientColor2;
	
	public void enterTargetPortal(String tPortal) {
		Select targetDropdown = new Select(mediumWait.get().until(ExpectedConditions.visibilityOf(targetPortal)));
		targetDropdown.selectByVisibleText(tPortal);
	}

	public void enterTargetAction(String tAction) {
		Select actionDropdown = new Select(mediumWait.get().until(ExpectedConditions.visibilityOf(userAction)));
		actionDropdown.selectByVisibleText(tAction);
	}
	
	public void enterRxWhiteLabelSite(String tWhiteLabelSite) {
		Select whiteLabelDropdown = new Select(mediumWait.get().until(ExpectedConditions.visibilityOf(rxWhiteLabelSite)));
		whiteLabelDropdown.selectByVisibleText(tWhiteLabelSite);
	}

	public void enterEligibility(String tEligibility) {
		Select eligibilityDropdown = new Select(mediumWait.get().until(ExpectedConditions.visibilityOf(userEligibility)));
		eligibilityDropdown.selectByVisibleText(tEligibility);
	}

	public void enterLanguage(String tLanguage) {
		Select languageDropdown = new Select(mediumWait.get().until(ExpectedConditions.visibilityOf(userLanguage)));
		languageDropdown.selectByVisibleText(tLanguage);
	}

	public void enterAccessType(String tAccesType) {
		Select accessTypeDropdown = new Select(mediumWait.get().until(ExpectedConditions.visibilityOf(accessType)));
		accessTypeDropdown.selectByVisibleText(tAccesType);
	}
	
	public void enterHTTPTargetURL(String targetportal) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(HTTPtargetURLField)).clear();
		HTTPtargetURLField.sendKeys(ReadXMLData.getTestData(targetportal, "AppURL"));
	}
	
	public void disableCaptcha() {
		String oldText = mediumWait.get().until(ExpectedConditions.visibilityOf(HTTPtargetURLField)).getAttribute("value");
		HTTPtargetURLField.clear();
		HTTPtargetURLField.sendKeys(oldText + "&USE_TEST_RECAPTCHA=true");
	}

	public void submitTestHarness() {
		clickHarnessSubmit.click();
	}

	public void enterCapMarketingSite(String capMarketSite) {
		Select whiteLabelDropdown = new Select(
				mediumWait.get().until(ExpectedConditions.visibilityOf(capMarketingSite)));
		whiteLabelDropdown.selectByVisibleText(capMarketSite);
	}

	public void openPage_stageB() throws FileNotFoundException, IOException, ParseException {
		page_url = ReadXMLData.getTestData("TestHarness", "LoginUrl_StageB");
		openPage(page_url);
	}

	public void enterSiteURL(String targetportal) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(siteURLField)).clear();
		siteURLField.sendKeys(ReadXMLData.getTestData(targetportal, "SiteURL"));
	}
	
	public void selectPhsSubPortal(String subPortal) {
		Select eligibilityDropdown = new Select(mediumWait.get().until(ExpectedConditions.visibilityOf(selectphsSPortal)));
		eligibilityDropdown.selectByVisibleText(subPortal);
	}
	
	public void selectWhSubPortal(String subPortal) {
		Select eligibilityDropdown = new Select(mediumWait.get().until(ExpectedConditions.visibilityOf(selectWhSPortal)));
		eligibilityDropdown.selectByVisibleText(subPortal);
	}

	public void enterSubPortal(String portal,String subPortal) {
		if(portal.equalsIgnoreCase("RX")){
			enterRxWhiteLabelSite(subPortal);
		}else if(portal.equalsIgnoreCase("PHS")){
			selectPhsSubPortal(subPortal);
		}else if(portal.equalsIgnoreCase("WOMENSHEALTH")){
			selectWhSubPortal(subPortal);
		}else if(portal.equalsIgnoreCase("CAP")){
			enterCapMarketingSite(subPortal);
		}else{
			Assert.fail("please check if selected portal "+portal+" is correct and has its subportal field");
		}
	}

	public void enterGradientColor(String gradientColorField, String gradientColor) {
		if(gradientColorField.equals("GRADIENTCOLOR1")){
			mediumWait.get().until(ExpectedConditions.visibilityOf(gradientColor1)).clear();
			gradientColor1.sendKeys(gradientColor);
		}else if(gradientColorField.equals("GRADIENTCOLOR2")){
			mediumWait.get().until(ExpectedConditions.visibilityOf(gradientColor2)).clear();
			gradientColor2.sendKeys(gradientColor);
		}else{
			Assert.fail("Invalid gradient color code field");
		}
	}
}
