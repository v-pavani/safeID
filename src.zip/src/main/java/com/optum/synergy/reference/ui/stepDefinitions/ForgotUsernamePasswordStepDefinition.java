package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.ForgotUsernamePasswordPage;
import com.optum.synergy.reference.ui.utility.DataStorage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ForgotUsernamePasswordStepDefinition { 
	private ForgotUsernamePasswordPage page;
	
	public ForgotUsernamePasswordStepDefinition() {
		page = new ForgotUsernamePasswordPage();
	}
	
	@When("^I enter username with \"([^\"]*)\"$")
	public void i_enter_username_with(String username) {
		 page.enterUserName(username);
		 page.clickResetPasswordInfoForm();
	}
	
	@Then("^I enter valid username into Username field on Reset Your Password Page$")
	public void i_enter_valid_username_into_Username_field() {
		page.enterUserName(DataStorage.getUserName());
		DataStorage.setCustomErrmsg("username:::"+ DataStorage.getUserName());
	}
	
	@Then("^I should see an error message \"([^\"]*)\" for username$")
	public void i_should_see_an_error_message_for_username(String message) {
		Assert.assertTrue(page.verifyErrorMessageOnUsername(message));
	}
	
	@Then("^I should not see any error message for username$")
	public void i_should_not_see_any_error_message_for_username() {
		Assert.assertTrue(page.verifyNoErrorMessageOnUsername());
	}
	
	@Then("^I should not see any error message for Phonenumber$")
	public void i_should_not_see_any_error_message_for_phonenumber() {
		Assert.assertTrue(page.verifyNoErrorMessageOnPhonenumber());
	}

	@Then("^I should see an error message \"([^\"]*)\" for captcha$")
	public void i_should_see_an_error_message_for_captcha(String message) {
		Assert.assertTrue(page.verifyErrorMessageOnCaptcha(message));
	}
	
	@Then("^I should not see any error message for captcha$")
	public void i_should_not_see_any_error_message_for_captcha() {
		Assert.assertTrue(page.verifyNoErrorMessageOnCaptcha());
	}

	@Then("^I should see an error message \"([^\"]*)\" for Usercaptcha$")
	public void i_should_see_an_error_message_for_Usercaptcha(String message) {
		Assert.assertTrue(page.verifyErrorMessageOnCaptcha(message));
	}
	
	@When("^I enter email with \"([^\"]*)\"$")
	public void i_enter_email_with(String emailAddress) {
	   page.clearEmailField();
	   page.enterEmail(emailAddress);
	   page.clickRecoverUsernameInfoForm();
	}

	@Then("^I should not see any error message for email$")
	public void i_should_not_see_any_error_message_for_email() {
		Assert.assertTrue(page.verifyNoErrorMessageOnEnterEmail()); 
	}
	
	@Then("^I should see an error message \"([^\"]*)\" for email$")
	public void i_should_see_an_error_message_for_email(String message) {
		Assert.assertTrue(page.verifyErrorMessageOnEnterEmail(message));
	}
	
	@Then("^I should see \"([^\"]*)\" error message for lost flow$")
	public void iShouldSeeErrorMessageforLostFlow(String content) {
		Assert.assertTrue("Error message is not displaying",page.getWebElementOfErrorMessageForLostFlows().getText().contains(content));
	}
	
	@When("^I should see error message \"([^\"]*)\"$")
	public void i_see_an_error_message(String messageText) {
		Assert.assertTrue("Error message does not match",page.verifyErrorMsg(messageText));
	}
	
	@When("^I should see \"([^\"]*)\" green check mark$")
	public void i_should_see_green_check_mark(String feature) {
		Assert.assertTrue("Green check mark icon is not displayed for "+feature,page.getPasswordResetConfirmationIcon().isDisplayed());
	}
	
	@Then("^I should see the confirm password value visible")
	public void iShouldSeeConfimrPasswordValueVisible() {
		Assert.assertEquals("text", page.getConfirmPasswordField().getAttribute("type"));
	}
	
	@Then("^I should see the confirm password value masked")
	public void iShouldSeeTheConfirmPasswordValueMasked() {
		Assert.assertEquals("password", page.getConfirmPasswordField().getAttribute("type"));
	}
	
	@Then("^I click on show password in confirm password field")
	public void iClickShowPasswordInConfirmPassword() {
		page.getConfirmPasswordShowPassword().click();
	}
	
	@Then("^I click on \"([^\"]*)\" link in \"([^\"]*)\" portal in mobile$")
	public void iClickShowPasswordInConfirmPassword(String linkName, String portalName) {
		page.clickForgotUsernamePasswordMobile(linkName, portalName);
	}
	
}
