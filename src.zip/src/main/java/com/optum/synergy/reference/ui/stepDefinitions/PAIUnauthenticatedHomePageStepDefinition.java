package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;
import com.optum.synergy.reference.ui.pageobjects.PAIUnauthenticatedHomePage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class PAIUnauthenticatedHomePageStepDefinition {
	private PAIUnauthenticatedHomePage page;

	public PAIUnauthenticatedHomePageStepDefinition() {
		page = new PAIUnauthenticatedHomePage();
	}

	@Given("^I am at PAI unauthenticated home page$")
	public void i_am_at_PAI_unauthenticated_home_page() {
		page.openPaiHomePage();
		Assert.assertTrue("Issue while loading the PAI Unauthenticated page", page.isPageLoaded());
	}

	@Then("^I should be at PAI unauthenticated home page$")
	public void iShouldBeAtPaiUnauthenticatedHomePage() {
		Assert.assertTrue("Issue while loading PAI unauthenticated page", page.isPageLoaded());
	}

	@Given("I should see an PAI logo")
	public void iShouldSeeAnPaiLogo() {
		Assert.assertTrue("Issue displaying PAI Logo", page.getPaiLogo().isDisplayed());
	}
}
