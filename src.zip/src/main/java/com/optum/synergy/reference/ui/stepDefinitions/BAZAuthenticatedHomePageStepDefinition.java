package com.optum.synergy.reference.ui.stepDefinitions;

import com.optum.synergy.reference.ui.pageobjects.BAZAuthenticatedHomePage;
import cucumber.api.java.en.Then;
import org.junit.Assert;

public class BAZAuthenticatedHomePageStepDefinition {

	private BAZAuthenticatedHomePage page;

	public BAZAuthenticatedHomePageStepDefinition() {
		page = new BAZAuthenticatedHomePage();
	}

	@Then("^I should be at BAZ authenticated home page$")
	public void iShouldBeAtBAZAuthenticatedHomePage() {
		Assert.assertTrue("Issue while loading the BAZ authenticated page",
				page.verifyIfAuthPageContentIsDisplayed());
		
		
		}
	
	

}