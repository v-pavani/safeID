package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class HealthSafeIDLearnMorePage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//*[@class='learnmore__content']|//*[@class='center-align learnmore__content']|//*[@id='modal-content']|//*[@title='Create your HealthSafe ID']")
	private WebElement learnmoreFormContent;

	@FindBy(how = How.XPATH, using = "//*[@id='hsid-myModal-learnmore']/*[@class='modal-content']"
			+	"|//*[@id='modal-content']"
			+	"|//*[contains(@class,'optum-purified___typography')]"
			+	"|//*[@class='learnmore__content']")
	private WebElement learnmoreModalContent;

	@FindBy(how = How.XPATH, using = "//*[@id='learnMore__modalHeader']/h1"
			+	"|//*[@id='learnmore']/h1"
			+	"|//*[@id='header']/h1[contains(text(),'One username')]"
			+	"|//*[@id='header']/h1[contains(.,'One username')]"
			+	"|//*[@id='openModal']"
			+	"|//*[@id='hsid-wdgt-title-learnmore']")
	private WebElement learnmoreModalHeader;


	public boolean verifyIfPageLoaded() {
		try {
			waitForJavascriptToLoad(15000, 1000);
			return mediumWait.get().until(ExpectedConditions.visibilityOf(learnmoreFormContent)).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}

	public WebElement getLearnmoreFormContent() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(learnmoreFormContent));
	}

	public WebElement getLearnmoreModalContent() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(learnmoreModalContent));
	}

	public WebElement getLearnmoreModalHeader() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(learnmoreModalHeader));
	}

}
