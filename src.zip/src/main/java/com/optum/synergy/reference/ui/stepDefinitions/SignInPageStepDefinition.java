package com.optum.synergy.reference.ui.stepDefinitions;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import cucumber.api.java.en.And;
import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.PageObjectBase;
import com.optum.synergy.reference.ui.pageobjects.SignInPage;
import com.optum.synergy.reference.ui.utility.DataStorage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SignInPageStepDefinition {

	private SignInPage page;

	public SignInPageStepDefinition() {
		page = new SignInPage();
	}

	@Then("^I enter valid \"([^\"]*)\" into Username or email address field in Sign In page$")
	public void i_enter_valid_into_Username_or_email_address_field_in_Login_section(String username) {
		page.enterUserName(username);
	}

	@Then("^I enter invalid \"([^\"]*)\" into Username or email address field in Sign In page$")
	public void i_enter_invalid_into_Username_or_email_address_field_in_Login_section(String username) {
		page.enterUserName(username);
	}

	@Then("^I enter valid username into Username or email address field in Sign In page$")
	public void i_enter_valid_username_into_Username_or_email_address_field_in_Login_section() {
		page.enterUserName(DataStorage.getUserName());
	}

	@Then("^I enter valid emailId into Username or email address field in Sign In page$")
	public void i_enter_valid_emailId_into_Username_or_email_address_field_in_Login_section() {
		page.enterUserName(DataStorage.getEmailId());
	}

	@Then("^I enter valid \"([^\"]*)\" into Password field in Sign In page$")
	public void i_enter_valid_into_Password_field_in_Login_section(String password) {
		page.enterPassword(password);
	}

	@Then("^I enter valid password into Password field in Sign In page$")
	public void iEnterValidPasswordIntoPasswordFieldInSignInPage() {
		page.enterPassword(DataStorage.getPassword());
	}

	@Then("^I should see the password value visible")
	public void iShouldSeeThePasswordValueVisible() {
		Assert.assertEquals("text", page.getPasswordType());
	}

	@Then("^I should see the password value masked")
	public void iShouldSeeThePasswordValueMasked() {
		Assert.assertEquals("password", page.getPasswordType());
	}

	@Then("^I should see the \"([^\"]*)\" label$")
	public void i_should_see_the_label(String expectedLabel) {
		if("LAWW".equalsIgnoreCase(DataStorage.getPortalName())){
			String expectedLabel1 = PageObjectBase.getAEMContent(DataStorage.getPortalName(), "PageContent", expectedLabel);
			String actualLabel = page.getContentLabel();

			Assert.assertTrue("Failed to find the label\nExpected Label: [" + expectedLabel1 + "]\nActual Label: [" + actualLabel + "]", actualLabel.contains(expectedLabel1));
		}else {
			Assert.assertTrue("Failed to find [" + expectedLabel + "] label", page.verifyContentLabel(expectedLabel));
		}
	}
//This is for Sign in security new ui page for Railroad
	@Then("^I should see the \"([^\"]*)\" label displayed on the page$")
	public void i_should_see_the_label_displayed_on_the_page(String expectedLabel) {
		String actualLabel = page.getContentLabel();
		Assert.assertTrue("Failed to find the label\nExpected Label: [" +expectedLabel+ "]\nActual Label: ["+ actualLabel +"]", actualLabel.contains(expectedLabel));
	}
	@Then("^I click on Live and work well image$")
	public void i_click_on_Live_and_work_well_image() {
		page.clickImg();
	}
	
	@Then("I click on User menu$")
	public void I_click_on_User_menu() {
		page.userMenuClick();
	}

	@Then("I enter \"([^\"]*)\" access code$")
	public void I_enter_access_code(String text) {
		page.enterAccessCode(text);
	}

	@Then("I should see confirmIdentity \"([^\"]*)\" message$")
	public void I_should_see_confirmIdentity_message(String text) {
		Assert.assertTrue(text + " does not exist in confirmIdentity message ", page.verifyConfirmIdentity(text));
	}

	@Then("I should see confirmIdentity \"([^\"]*)\" alert message$")
	public void I_should_see_confirmIdentity_alert_message(String text) {
		Assert.assertTrue(text + " does not exist in alert message ", page.verifyAlertMessage(text));
	}

	@Then("I should see confirmIdentity \"([^\"]*)\" secure message$")
	public void I_should_see_confirmIdentity_secure_message(String text) {
		Assert.assertTrue(text + " does not exist in secure message ", page.verifysecureMessage(text));
	}

	@Then("I should see the Security answer text field$")
	public void I_should_see_the_Security_answer_text_field() {
		Assert.assertTrue("Security text field", page.securityAnswerTextField());
	}

	@Then("I should see security question$")
	public void I_should_see_security_question() {
		Assert.assertTrue("Security text label does not exist", page.securityAnswerLabel());
	}

	@Then("I should see confirmIdentity \"([^\"]*)\" question message$")
	public void I_should_see_confirmIdentity_question_message(String text) {
		Assert.assertTrue(text + " confirm identity text does not exist ", page.verifyConfirmIdentity(text));
	}

	@Then("^I should see the email confirmation message \"([^\"]*)\" in Sign In form$")
	public void i_should_see_the_email_confirmation_message_in_Sign_In_form(String message) {
		Assert.assertTrue(message + " is not displaying on the sign in page",
				page.verifyForConfimationMessage(message));
	}

	@Then("^I should see the MyUhc Sign in error message \"([^\"]*)\" in Sign In form$")
	public void i_should_see_the_MyUhc_SignIn_error_message_in_Sign_In_form(String message) {
		Assert.assertTrue(message + " is not displaying on the sign in page",
				page.verifyForConfimationMessage(message));
	}

	@Then("^I should see the error message \"([^\"]*)\" in Sign In form$")
	public void i_should_see_the_error_message_in_Sign_In_form(String message) {
		Assert.assertTrue(message + " is not displaying on the sign in page",
				page.verifyForConfimationMessage(message));
	}

	@Then("^I should see a Username or email address label with textbox in Sign In page$")
	public void i_should_see_a_Username_or_email_address_label_with_textbox_in_Sign_In_page() {
		Assert.assertTrue("Issue in displaying the Username or email address label with textbox",
				page.verifyIfUsernameOrEmailAddressLabelExistWithTextbox());
	}

	@Then("^I should see a Password label with textbox Sign In page$")
	public void i_should_see_a_Password_label_with_textbox_Sign_In_page() {
		Assert.assertTrue("Issue in displaying the Password label with textbox",
				page.verifyPasswordLableExistWithTextbox());
	}

	@Then("^I should see a Sign In error message \"(.*)\"$")
	public void iShouldSeeAnErrorMessage(String expectedMsg) {
		String textContent = page.getSignInErrorMessage().getText().trim().replaceAll(String.valueOf((char)160)," ");
		Assert.assertTrue("FAIL: Did not find expected error message:\nExpected: "+expectedMsg+"\nActual:"+textContent, textContent.contains(expectedMsg));
	}

	@Then("^I should see an account lock error message \"(.*)\"$")
	public void iShouldSeeAnAccountLockErrorMessage(String expectedMsg) {
		Assert.assertEquals("FAIL: Did not find expected error message", expectedMsg,
				page.getAccountLockErrorMessage().getText());
	}

	@Then("^I should not see alert message for username as \"[^\"]*\"$")
	public void ishouldnotseealertmsgforusername() {
		Assert.assertEquals(page.getErrorMsgForUserNamefield(), null);
	}

	@Then("^I should not see alert message for password as \"[^\"]*\"$")
	public void ishouldnotseealertmsgforpwd() {
		Assert.assertEquals(page.getErrorMsgForPasswordfield(), null);
	}

	@Then("^I should see alert message for username as \"([^\"]*)\"$")
	public void ishouldseealertmsgforusername(String arg1) {
		Assert.assertEquals(arg1, page.getErrorMsgForUserNamefield());
	}

	@Then("^I should see alert message for password as \"([^\"]*)\"$")
	public void ishouldseealertmsgforpwd(String arg1) {
		Assert.assertEquals(arg1, page.getErrorMsgForPasswordfield());
	}

	@Then("^I should see the firstname in page heading$")
	public void iShouldSeeTheFirstnameInPageHeading() {
		String expected = DataStorage.getFirstName().toUpperCase();
		String actual = page.getFirstNameFromPageHeader().toUpperCase();
		Assert.assertTrue("Expected: [" + expected + "] actual: [" + actual + "]", actual.contains(expected));
	}

	@Then("^I click on Show Password button$")
	public void iClickOnShowPasswordButton() {
		page.clickShowPasswordButton();
	}

	@Then("^I should see Username field is not prepopulated$")
	public void iShouldSeeuserNameFieldisNotPrepopulated() {
		Assert.assertEquals("Username field is not null", "", page.getUserNameFieldValue());
	}

	@Then("^I should see Sign In error message \"(.*)\"$")
	public void iShouldSeeErrorMessage(String expectedMsg) {
		String text = page.getSignInErrorMessage().getText().trim().replaceAll(String.valueOf((char)160)," ");
		Assert.assertTrue(
				"FAIL: Did not find expected error message -" + expectedMsg + "Actual message -" + text,
				text.contains(expectedMsg));
	}

	@Then("^I click on Rememberme checkbox$")
	public void iClickOnRemembermeCheckbox() {
		page.clickRememberMeCheckBox();
	}

	@Then("^I deselect Rememberme checkbox")
	public void iDeselectRemembermeCheckbox() {
		page.clickRememberMeCheckBox();
	}

	@Then("^I should see the Username field is prepopulated in signin page")
	public void iShouldSeeTheUsernameFieldIsPrepopulatedInSigninPage() {
		String uname = DataStorage.getUserName();
		Pattern p = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
		Matcher m = p.matcher(uname);
		if (m.find()) {
			String[] sp = uname.split("@");
			char un[] = sp[0].toCharArray();
			for (int i = 2; i < sp[0].length(); i++)
				un[i] = '*';
			String p1 = new String(un);
			String masked1 = new String(p1 + "@" + sp[1]);
			Assert.assertEquals("Expected username is not found", masked1,
					page.getUserNameTextBoxMasked().getAttribute("placeholder"));
		} else {
			char c[] = uname.toCharArray();
			int n = c.length - 2;
			for (int i = 2; i < n; i++)
				c[i] = '*';
			String masked = new String(c);
			Assert.assertEquals("Expected username is not found", masked,
					page.getUserNameTextBoxMasked().getAttribute("placeholder"));
		}
	}

	@Then("^I should see the Username field is not prepopulated in signin page")
	public void iShouldSeeTheUsernameFieldIsNotPrepopulatedInSigninPage() {
		Assert.assertEquals("Username is not empty", "", page.getUserNameTextBoxMasked().getAttribute("placeholder"));
	}

	@Then("^I verify Rememberme is checked")
	public void iVerifyRemembermeIsChecked() {
		Assert.assertTrue("Remember Me is not checked", page.verifyForRememberMeCheckBoxSelected());
	}

	@Then("^I verify Rememberme is not checked")
	public void iVerifyRemembermeIsNotChecked() {
		Assert.assertFalse("Remember Me is checked", page.verifyForRememberMeCheckBoxSelected());
	}

	@Then("^I Should see the Rememberme checkbox")
	public void iShouldSeeTheRemembermeCheckbox() {
		Assert.assertTrue("RememberMe is Not displayed", page.verifyForRememberMeCheckBoxDisplayed());
	}
	
	@Then("^I should see Visual indicator for \"([^\"]*)\"link$")
	public void iShouldSeeVisualIndicatorForLink(String linkName) {
		Assert.assertTrue("Visual indicator not found in recaptcha text", page.verifyVisualIndicator(linkName));
	}
	
	@Then("^I Should see \"([^\"]*)\" in Username textbox")
	public void iShouldSeeInUsernameTextbox(String arg1) {
		Assert.assertEquals(arg1, page.getUserNameFieldValue());
	}
	
	@Then("^I should not see the \"([^\"]*)\" text$")
	public void iShouldNotSeeTheText(String text){
		Assert.assertFalse("\"" + text + "\" content is displaying on right side content", page.verifyContentLabel(text));
	}

	@When("^I should be at HSID sign in page$")
	public void iShouldBeAtHSIDSignInPage() {
		Assert.assertTrue("Issue loading in HSID sign in page",page.isHSIDSignPageDisplayed());
	}

	@Then("^I should see Password field on UI$")
	public void i_should_see_password_textbox() {
		Assert.assertTrue("Expected username is not found",page.getPasswordTextBox().isDisplayed());
	}
	@And("^I should see the phone number is masked as \\+1 \\(xxx\\) xxx -$")
	public void iShouldSeeThePhoneNumberIsMasked() {
		String maskedNumber = "+1 (xxx) xxx";
		String actualLabel = page.getContentLabel();
		Assert.assertTrue("Failed to find the label\nExpected Label: [" + maskedNumber + "]\nActual Label: [" + actualLabel + "]", actualLabel.contains(maskedNumber) || actualLabel.contains(maskedNumber.toUpperCase()));
	}
}