package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class GlobalNavPage extends PageObjectBase{

	@FindBy(how = How.XPATH, using = "//*[@id='global-profile-container']//a|//*[@id='usermenu']//a|//*[@id='profileDropdown']")
	private WebElement userNameMenu;
	
	@FindBy(how = How.XPATH, using = "//*[@class='portal-title']")
	private WebElement portalTitle;
	
	public boolean verifyUserNameMenuDropDownDisplayed() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(userNameMenu)).isDisplayed();
	}
	
	public void clickOnUserMenuDropDown(){
		smallWait.get().until(ExpectedConditions.visibilityOf(userNameMenu));
		userNameMenu.click();
	}
	
	public WebElement getPortalNameonGlobalNav(String portalName) {
		return longWait.get().until(ExpectedConditions.visibilityOfElementLocated((By.xpath("//div[@class='navbar-header optum-logo']//*[contains(.,'"+portalName+"')]|//div[@class='portal-title' and contains(text(),'"+portalName+"')]"))));
	}
	
	public WebElement getGradientBarElement(String rgbColor1, String rgbColor2) {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@class='gradientBorder' and contains(@style,'"+rgbColor1+", "+rgbColor2+"')]")));
	}
	
	public WebElement getPortalTitle(){
		return mediumWait.get().until(ExpectedConditions.visibilityOf(portalTitle));
	}

	public WebElement getGradientBarGN(String rgbColor1, String rgbColor2) {
		return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"global-nav-header-component\"]//*[@class='gradientBorder' and contains(@style,'"+rgbColor1+", "+rgbColor2+"')]")));
	}
	
	public WebElement getGradientBarElementforSignAndSecurity(String rgbColor1, String rgbColor2) {
        return mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//*[@class='gradientBorder' and contains(@style,'"+rgbColor1+", "+rgbColor2+"')])[2]")));
	}
	
}
