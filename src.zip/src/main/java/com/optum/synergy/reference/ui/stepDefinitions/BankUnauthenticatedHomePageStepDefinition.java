package com.optum.synergy.reference.ui.stepDefinitions;

import com.optum.synergy.reference.ui.pageobjects.Registration_PersonalInformationSectionPage;
import com.optum.synergy.reference.ui.utility.ReadXMLData;
import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.BankUnauthenticatedHomePage;
import com.optum.synergy.reference.ui.pageobjects.SignInPage;
import com.optum.synergy.reference.ui.utility.DataStorage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

import static com.optum.synergy.reference.ui.pageobjects.PageObjectBase.mediumWait;

public class BankUnauthenticatedHomePageStepDefinition {

	private BankUnauthenticatedHomePage page;
	private SignInPage pages;

	public BankUnauthenticatedHomePageStepDefinition() {
		page = new BankUnauthenticatedHomePage();
		pages = new SignInPage();
	}
	
	@Given("^I am at (Disney|UHCHA|UHCRA|OptumBank|Bank-AARP) Unauthenticated home page$")
	public void iAmAtBankUnauthenticatedHomePage(String portalName) {
		if(portalName.equals("Disney"))
		page.openDisneyHomePage();
		else if(portalName.equals("UHCHA"))
			page.openUHCHAHomePage();
		else if(portalName.equals("UHCRA"))
			page.openUHCRAHomePage();
		else if(portalName.equals("OptumBank"))
			page.openBankHomePage();
		else
			page.openBankAARPHomePage();
		Assert.assertTrue("Issue loading "+portalName+" Unauthenticated home page", pages.isHSIDSignPageDisplayed());
	}
	
	@Then("^I should be at Bank Signout page$")
	public void iShouldBeAtBankSognoutHomePage() {
		Assert.assertTrue("Issue while loading signout page", pages.isSignoutPageLoaded());
	}
	
	@Given("^I am at OptumBank Unauthenticated home page in production$")
	public void i_am_at_OptumBank_Unauthenticated_home_page_production() {
		page.openBankHomePage();
		Assert.assertTrue("Issue loading OptumBank Unauthenticated home page", page.verifyIfUnauthBankPageLoadedInProduction());
	}

	@Given("^I am at Bank-Disney unauthenticated home page in production$")
	public void i_am_at_Disney_Unauthenticated_In_production() {
		page.openDisneyHomePage();
		Assert.assertTrue("Issue loading Bank-Disney unauthenticated home page", page.verifyIfUnauthBankDisneyPageLoadedInProduction());
	}

	@Given("^I am at Bank-UHCRA unauthenticated home page in production$")
	public void i_am_at_UHCRA_Unauth_Page_In_production() {
		page.openUHCRAHomePage();
		Assert.assertTrue("Issue loading Bank-UHCRA unauthenticated home page", page.verifyIfUnauthBankUHCRAPageLoadedInProduction());
	}

	@Given("^I am at Bank-UHCHA unauthenticated home page in production$")
	public void i_am_at_UHCHA_Unauth_Page_In_production() {
		page.openUHCHAHomePage();
		Assert.assertTrue("Issue loading Bank-UHCHA unauthenticated home page", page.verifyIfUnauthBankUHCHAPageLoadedInProduction());
	}

	@Given("^I am at Bank-AARP unauthenticated home page in production$")
	public void i_am_at_BankAARP_Unauth_Page_In_production() {
		page.openBankAARPHomePage();
		Assert.assertTrue("Issue loading Bank-AARP unauthenticated home page", page.verifyIfUnauthBankAARPPageLoadedInProduction());
	}

	@Then("^I select \"([^\"]*)\" from \"([^\"]*)\" dropdown$")
	public void iClickOnOnTermsAndConditionsPage(String value, String dropdown) {
		page.selectSignInOption(value);
	}


	/**
	 * Method specific to OptumBank portal for production environment
	 * @param pageName
	 */
	@Given("^I navigate to HSID (SignIn|Registration) page for OptumBank$")
	public void iNavigateToHSIDSignInPage(String pageName) {
		if(pageName.equalsIgnoreCase("SignIn")) {
			try {
				page.clickPartialLink("Sign in");
				Thread.sleep(5000);
				mediumWait.get().until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a/span[contains(text(),'Sign in to your online account')]"))).click();
				new CommonStepDefinition().i_should_see_a_new_tab_opened_and_switch_to_it();
			} catch (Exception | AssertionError e) {
				String URL = ReadXMLData.getTestData("CAP", DataStorage.getSubPortalName() + "HSIDSignInURL");
				page.openPage(URL);
			}
			Assert.assertTrue("Issue in loading HSID sign in page", pages.isHSIDSignPageDisplayed());
		} else {
			try {
				page.clickPartialLink("Register for");
			} catch (Exception | AssertionError e) {
				String URL = ReadXMLData.getTestData("CAP", DataStorage.getSubPortalName() + "HSIDRegisterURL");
				page.openPage(URL);
			}
			Assert.assertTrue("Issue in loading HSID Registration page", new Registration_PersonalInformationSectionPage().verifyIfPageLoaded());
		}
	}

}