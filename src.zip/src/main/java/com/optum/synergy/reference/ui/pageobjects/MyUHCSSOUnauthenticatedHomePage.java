package com.optum.synergy.reference.ui.pageobjects;
import com.optum.synergy.reference.ui.utility.DataStorage;
import com.optum.synergy.reference.ui.utility.ReadXMLData;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.Select;

public class MyUHCSSOUnauthenticatedHomePage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//form[@name='suLoginForm']")
	private WebElement superUserLoginView;

	@FindBy(how = How.XPATH, using = "//form[@name='ssoin']")
	private WebElement memberView;

	@FindBy(how = How.NAME, using = "racfid")
	private WebElement racfId;
	
	@FindBy(how = How.NAME, using = "password")
	private WebElement racfIdPassword;

	@FindBy(how = How.XPATH, using = "//form[@name='sso']")
	private WebElement superUserUnauthenticatedView;

    @FindBy(how = How.XPATH, using = "//form[@name='suLoginUserForm']|//form[@name='suHsidLoginUserForm']|//form[@name='suLoginForm']")
    private WebElement preLoginView;

	@FindBy(how = How.NAME, using = "bypassping")
	private WebElement federate;
	
	@FindBy(how = How.XPATH, using = "//td[text()='MyUHC SSO Method: ']/following-sibling::td/select")
	private WebElement MyUHCSSOMethod;

	@FindBy(how = How.XPATH, using = "//form[@name='ssoInForm']")
	private WebElement detailsView;

	@FindBy(how = How.XPATH, using = "//input[@value='MM/DD/YYYY']|//input[@value='EmpDateOfBirth']/../following-sibling::td/input|//input[@name='dob']")
	private WebElement dateOfBirth;

	@FindBy(how = How.XPATH, using = "//input[@value='sso@uhc.com']")
	private WebElement email;

	@FindBy(how = How.XPATH, using = "//select[@name='deeplink']")
	private WebElement deepLinkSelect;
	
	@FindBy(how = How.XPATH, using = "//input[@value='UniqueID']/../following-sibling::td/input|//input[@name='uniqueId']")
	private WebElement UniqueIDTextBox;
	
	@FindBy(how = How.XPATH, using = "//input[@value='SiteURL']/../following-sibling::td/input|//input[@name='ssoSiteUrl']")
	private WebElement SiteURLTextBox;

	@FindBy(how = How.XPATH, using = "//input[@name='TARGET']")
	private WebElement targetPortalTextBox;

	@FindBy(how = How.XPATH, using = "//input[@name='idType']")
	private WebElement idTypeTextBox;

	@FindBy(how = How.XPATH, using = "//input[@name='idValue']")
	private WebElement idValueTextBox;
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'prelogin') and //img[contains(@src,'HarvardPilgrimHealthcarelogo.gif')]]")
	private WebElement HPlogoutForm;
	
	public void enterUniqueID(String UniqueID) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(UniqueIDTextBox));
		UniqueIDTextBox.clear();
		UniqueIDTextBox.sendKeys(UniqueID);
	}
	public void enterSiteURL(String SiteURL) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(SiteURLTextBox));
		SiteURLTextBox.clear();
		SiteURLTextBox.sendKeys(SiteURL);
	}

	public void openHomePage() {
		String page_url = ReadXMLData.getTestData("SSOMYUHC", "AppURL");
		openPage(page_url);
	}

	public void enterRacfId() {
		racfId.sendKeys(ReadXMLData.getTestData("SSOMYUHC", "RacfId"));
	}

	public boolean verifyIfSuperUserLoginPageLoaded() {
		try {
			return mediumWait.get().until(ExpectedConditions.visibilityOf(superUserLoginView)).isDisplayed();
		} 
		catch (Exception e) {
			return false;
		}
	}

	public void openSSOHomePage() {
		String page_url = ReadXMLData.getTestData("SSOMYUHC", "SSOURL");
		openPage(page_url);
	}

	public void federateSelect(String selectYesNo) {
		Select choose = new Select(federate);
		choose.selectByVisibleText(selectYesNo);
	}

	public void selectMyUHCSSOMethod(String selectData) {
		Select choose = new Select(MyUHCSSOMethod);
		choose.selectByVisibleText(selectData);
	}
	
	public boolean verifyIfPreLoginSSOLoaded() {
		try 
		{
			return mediumWait.get().until(ExpectedConditions.visibilityOf(preLoginView)).isDisplayed();
		} 
		catch (Exception e)
		{
			return false;
		}
	}

	public boolean verifyIfPreSSOUnauthenticatedPageLoaded(){
		try
		{
			return mediumWait.get().until(ExpectedConditions.visibilityOf(detailsView)).isDisplayed();
		} 
		catch (Exception e)
		{
				return false;
		}
	}

	public void enterDateOfBirth(String dob) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(dateOfBirth));
		dateOfBirth.clear();
		dateOfBirth.sendKeys(dob);
	}

	public void deeplinkSelect(String selectDeepLink) {
		Select chooseID = new Select(deepLinkSelect);
		chooseID.selectByVisibleText(selectDeepLink);
	}

	public boolean verifyIfsuperuserPageLoaded() {
		try	{
			return mediumWait.get().until(ExpectedConditions.visibilityOf(superUserUnauthenticatedView)).isDisplayed();
		}
		catch(Exception e) {
			return false;
		}
	}

	public boolean verifyIfInBoundPageLoaded() {
		try {
			return mediumWait.get().until(ExpectedConditions.visibilityOf(memberView)).isDisplayed();
		} 
		catch(Exception e)	{
			return false;
		}
	}

	public void openSSOTestHarnessPage() {
		String sso_page_url = ReadXMLData.getTestData("SSOMYUHC", "LoginSSOUrl");
		openPage(sso_page_url);
	}

	public void enterTarget() {
		String targetURL = ReadXMLData.getTestData(DataStorage.getPortalName(), DataStorage.getSubPortalName()+"TargetURL");
		mediumWait.get().until(ExpectedConditions.visibilityOf(targetPortalTextBox));
		targetPortalTextBox.clear();
		targetPortalTextBox.sendKeys(targetURL);
	}

	public void enterIdType(String idType) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(idTypeTextBox));
		idTypeTextBox.clear();
		idTypeTextBox.sendKeys(idType);
	}

	public void enterIdValue(String idvalue) {
		mediumWait.get().until(ExpectedConditions.visibilityOf(idValueTextBox));
		idValueTextBox.clear();
		idValueTextBox.sendKeys(idvalue);
	}
	
	public boolean verifyIfHPLogoutPageLoaded() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf((HPlogoutForm))).isDisplayed();
	}

	public void emailClear() {
		email.clear();
	}

	public void enterRacfIdPassword() {
		racfIdPassword.sendKeys(ReadXMLData.getTestData("SSOMYUHC", "RacfIdPassword"));
	}

}
