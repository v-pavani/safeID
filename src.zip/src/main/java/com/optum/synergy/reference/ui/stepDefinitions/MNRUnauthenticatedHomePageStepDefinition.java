package com.optum.synergy.reference.ui.stepDefinitions;

import com.optum.synergy.reference.ui.pageobjects.MNRUnauthenticatedHomePage;
import com.optum.synergy.reference.ui.pageobjects.Registration_PersonalInformationSectionPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.junit.Assert;

public class MNRUnauthenticatedHomePageStepDefinition {

    private MNRUnauthenticatedHomePage page;

    public MNRUnauthenticatedHomePageStepDefinition() {
        page = new MNRUnauthenticatedHomePage();
    }


    @Given("^I am at MNR-AARP unauthenticated home page$")
    public void iAmAtMnrAarpUnauthenticatedHomePage() {
        page.openAarpHomePage();
        Assert.assertTrue("Issue while loading the MNR-AARP Unathenticated page", page.verifyIfPageLoaded() && new Registration_PersonalInformationSectionPage().verifyAarpLogo());
    }

    @Given("^I am at MNR-MEDICARE unauthenticated home page$")
    public void iAmAtMnrMedicareUnauthenticatedHomePage() {
        page.openMedicareHomePage();
        Assert.assertTrue("Issue while loading the MNR-MEDICARE Unathenticated page", page.verifyIfPageLoaded());
    }

    @Given("^I am at MNR-RETIREE unauthenticated home page$")
    public void iAmAtMnrRetireeUnauthenticatedHomePage() {
        page.openRetireeHomePage();
        Assert.assertTrue("Issue while loading the MNR-RETIREE Unathenticated page", page.verifyIfPageLoaded());
    }

    @Given("^I am at MNR-MEDICA unauthenticated home page$")
    public void iAmAtMnrMedicaUnauthenticatedHomePage() {
        page.openMedicaHomePage();
        Assert.assertTrue("Issue while loading the MNR-MEDICA Unathenticated page", page.verifyIfPageLoaded());
    }

    @Given("^I am at MNR-PCP unauthenticated home page$")
    public void iAmAtMnrPcpUnauthenticatedHomePage() {
        page.openPcpHomePage();
        Assert.assertTrue("Issue while loading the MNR-PCP Unathenticated page", page.verifyIfPageLoaded());
    }

    @Then("^I should be at \"([^\"]*)\" unauthenticated home page$")
    public void i_should_be_at_MNR_AARP_unauthenticated_home_page(String portalName) {
        Assert.assertTrue("Issue while loading the " + portalName + " Unauthenticated page", page.verifyIfPageLoaded());
    }

    @Then("^I should be at MNR-MEDICARE unauthenticated home page$")
    public void iShouldBeAtMNRMEDICAREUnauthenticatedHomePage() {
        Assert.assertTrue("Issue while loading the MNR-MEDICARE Unauthenticated page", page.verifyIfPageLoaded() && new Registration_PersonalInformationSectionPage().verifyUhcLogo());
    }

    @Then("^I should be at MNR-RETIREE unauthenticated home page$")
    public void i_should_be_at_MNR_RETIREE_unauthenticated_home_page() {
        Assert.assertTrue("Issue while loading the MNR-Retiree Unauthenticated page", page.verifyIfPageLoaded() && new Registration_PersonalInformationSectionPage().verifyRetireeLogo());
    }

    @Then("^I should be at MNR-PCP unauthenticated home page$")
    public void i_should_be_at_MNR_PCP_unauthenticated_home_page() {
        Assert.assertTrue("Issue while loading the MNR-PCP Unauthenticated page", page.verifyIfPageLoaded() && new Registration_PersonalInformationSectionPage().verifyPcpLogo());
    }

    @Then("^I should be at MNR-MEDICA unauthenticated home page$")
    public void i_should_be_at_MNR_MEDICA_unauthenticated_home_page() {
        Assert.assertTrue("Issue while loading the MNR-Medica Unauthenticated page", page.verifyIfPageLoaded() && new Registration_PersonalInformationSectionPage().verifyMedicaLogo());
    }

    @Then("^I should be at MNR-AARP unauthenticated home page$")
    public void i_should_be_at_MNR_AARP_unauthenticated_home_page() {
        Assert.assertTrue("Issue while loading the MNR-AARP Unauthenticated page", page.verifyIfPageLoaded() && new Registration_PersonalInformationSectionPage().verifyAarpLogo());
    }

}