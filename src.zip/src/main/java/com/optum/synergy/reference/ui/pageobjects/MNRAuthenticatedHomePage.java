package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class MNRAuthenticatedHomePage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//*[@id='hello-person']|//*[contains(text(),'Account / Profile')]")
	private WebElement personHeader;

	public boolean verifyIfAuthPageContentIsDisplayed() {
		waitForPageLoad(driver);
		waitForJavascriptToLoad(15000, 5000);
		return mediumWait.get().until(ExpectedConditions.visibilityOf(personHeader)).isDisplayed();
	}

}