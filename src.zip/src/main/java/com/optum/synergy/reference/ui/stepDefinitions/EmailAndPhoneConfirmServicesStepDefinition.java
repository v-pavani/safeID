package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.EmailAndPhoneConfirmServices;

/**
 * @author vchaube1
 *
 */

import cucumber.api.java.en.When;

public class EmailAndPhoneConfirmServicesStepDefinition {

	private EmailAndPhoneConfirmServices page;

	public EmailAndPhoneConfirmServicesStepDefinition() {
		page = new EmailAndPhoneConfirmServices();

	}
	
	@When("^I confirm the Email for the user$")
	public void iConfirmTheEmailForTheUser() {
		Assert.assertTrue("Issue in execution of the confirm email API", page.activateEmail() == 200);
	}

}
