package com.optum.synergy.reference.ui.stepDefinitions;

import com.optum.synergy.reference.ui.pageobjects.PageObjectBase;
import com.optum.synergy.reference.ui.pageobjects.MyUHCAuthenticatedHomePage;

import com.optum.synergy.reference.ui.pageobjects.Registration_PersonalInformationSectionPage;
import cucumber.api.java.en.Then;
import org.junit.Assert;

public class myUHCAuthenticatedHomePageStepDefinition {
	
	private MyUHCAuthenticatedHomePage page;
	
	public myUHCAuthenticatedHomePageStepDefinition(){
		page= new MyUHCAuthenticatedHomePage();
	}
		
	@Then("^I should be at myUHC authenticated home page$")
	public void iShouldBeAtMyUHCAuthenticatedHomePage() {
		Assert.assertTrue("Issue while loading the myUHC authenticated page", page.verifyIfHomePageContentIsDisplayed());
		//TODO: Page title sometimes returns as "Welcome to myuhc.com", allowing either for now.
		String pageTitle = page.getPageTitle();
		Assert.assertTrue("Unexpected page title [" + pageTitle + "]", 
				pageTitle.equals("myuhc Home") 
				|| pageTitle.equals("Welcome to myuhc.com")
				|| pageTitle.contains("UnitedHealthcare"));
	}
	
	@Then("^I should be at myUHC community plan home authenticated home page$")
    public void iShouldBeAtMyUHCCommunityPlanHomeAuthenticatedHomePage() {
	    Assert.assertTrue("Issue while loading the myUHC community plan home authenticated page", page.verifyIfHomePageContentIsDisplayed());
	    String authPageTitle = page.getMyUHCAuthenticatedPageTitle();
	    Assert.assertTrue("Found unexpected page title [" + authPageTitle + "]", 
	    		authPageTitle.equals("myuhc Community Plan Home") 
	    		|| authPageTitle.equals("Welcome to myuhc.com")
	    		|| authPageTitle.equals("Home | UnitedHealthcare"));
	}
	
	@Then("^I manage the MyUHC plan selection page$")
    public void iManageTheMyUHCPlanSelectionPage() {
            if(page.verifyMyUHCPlanSelectionPageLoaded()) {
                    	page.SelectFirstMyUHCPlan(); 
                    	page.clickContinueButton();                      
             }  else if(page.verifyMyUHCPlanSelectionNewPageLoaded())
               	page.SelectFirstMyUHCPlanNew();   
    }
	
	@Then("^I manage the Review Coordination Of Benefits page$")
    public void iManageTheReviewCoordinationOfBenefitsPage() {
            if(page.verifyUpdateLaterButtonDisplayed()) {
            	page.clickUpdateLaterButton(); //The button may/may not be displayed depending on data
             }   
    }
	
	@Then("^I manage the Video Prompt Of Benefits page$")
    public void iManageTheVideoPromptOfBenefitsPage() {
            if(page.verifyCrossButtoninVideoPromptDisplayed()) {
            	page.clickCrossButtoninVideoPrompt(); //The button may/may not be displayed depending on data
             }   
    }

	@Then("^I sign out of authenticated home page$")
	public void iSignOutOfAuthenticatedHomePage() throws Throwable{
		page.signOut();
	}

	@Then("^I manage Dental EOB form at myUHC authenticated home page$")
	public void iManageDentalEOBAtMyUHCAuthenticatedHomePage() {
		 if(page.verifyIfDentalEOBFormIsDisplayed()) {
			 new PageObjectBase().clickPartialLink("Continue"); 
		 }   
		
	}
}
