package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class UserMenuDropdownWindowPage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//a[@id='gnav-profile-signout']|//a[contains(@class,'signout') and contains(.,'Sign out')]|//a[contains(@class,'dropdown-item') and contains(.,'Sign out')]")
	private WebElement signOutButton;

	public void clickSignoutButton() {
		waitForPageLoad(driver);
		mediumWait.get().until(ExpectedConditions.visibilityOf(signOutButton));
		signOutButton.click();
	}
}
