package com.optum.synergy.reference.ui.utility;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Assert;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;

/**
 * @author rtripa1
 *
 */
public class DataStorage {
	private static ThreadLocal<String> portalName = new ThreadLocal<String>();		// Name of portal under test
	private static ThreadLocal<String> subPortalName = new ThreadLocal<String>();	// name of sub-portal (ex CommunityPlan under MyUhc)
	private static ThreadLocal<String> UserName = new ThreadLocal<String>();
	private static ThreadLocal<String> confirmregistrationurl = new ThreadLocal<String>();
	private static ThreadLocal<String> EmailSubject = new ThreadLocal<String>();
	private static ThreadLocal<String> customErrmsg = new ThreadLocal<String>();
	private static ThreadLocal<String> EmailContent = new ThreadLocal<String>();
	private static ThreadLocal<String> emailid = new ThreadLocal<String>();
	private static ThreadLocal<String> ScenarioName = new ThreadLocal<String>();
	private static ThreadLocal<String> emailIDtoFetchOTP = new ThreadLocal<String>();
	private static ThreadLocal<String> phoneNumber = new ThreadLocal<String>();
	private static ThreadLocal<Integer> portalNumber = new ThreadLocal<Integer>();
	private static ThreadLocal<String> userRootNode = new ThreadLocal<String>();
	private static ThreadLocal<String> previousEmailId = new ThreadLocal<String>();
	private static ThreadLocal<String> tagName = new ThreadLocal<String>();         // smoke or regression tags
	private static ThreadLocal<String> uniqueIDSSO = new ThreadLocal<String>();
	private static ThreadLocal<String> siteURLSSO = new ThreadLocal<String>();
	private static ResourcePool<String> phoneNumberPool = new ResourcePool<String>(ReadXMLData.getTestDataList("phoneNumbers", "phoneNumber"));
	public static ThreadLocal<String> contentWithDynamicValue = new ThreadLocal<String>();

	private static ResourcePool<String> emailIdPool = new ResourcePool<String>(
			ReadXMLData.getTestDataList("emailAddresses", "emailAddress"));

	private static ResourcePool<String> emailIdPoolSmoke = new ResourcePool<String>(
			ReadXMLData.getTestDataList("emailAddressesSmoke", "emailAddress"));

	private static  ThreadLocal<HashMap<String, String>> userdetails = new ThreadLocal<HashMap<String, String>>() {
		@Override
		protected HashMap<String, String> initialValue() {
			return new HashMap<>();
		}
	};

	public static void setTagName(String tag){
		tagName.set(tag);
	}

	public static String getTagName(){
		return tagName.get();
	}
	public static void setEmailId(String newEmailId) {
		userdetails.get().put("Email", newEmailId);
		emailid.set(newEmailId);
	}

	public static String getEmailId() {
		String currEmail = emailid.get();
		if (currEmail == null) {
				if (getTagName()!= null && getTagName().equals("@HSID11_SMOKE"))
					currEmail = emailIdPoolSmoke.getResource();
				else
					currEmail = emailIdPool.getResource();
			if (currEmail == null) {
				setCustomErrmsg("ERROR::DataStorage::No available email ID in resource pool");
				Assert.fail("ERROR::DataStorage::No available email ID in resource pool");
			}
			String currUsername = UserName.get();
			if (currUsername != null) {
				emailIdPool.returnResource(currEmail);
				emailIdPoolSmoke.returnResource(currEmail);
				currEmail = currEmail.replaceAll("@", "+" + stripEmailSpecialChars(currUsername) + "@");
				setCustomErrmsg("Unique tagged email address [" + currEmail + "]");

			}
			setEmailId(currEmail);

		}
		return currEmail;
	}

	private static String stripEmailSpecialChars(String input) {
		String strippedString = input;
		// List of characters that may be in username but are not valid for an
		// email address
		String[] specialChars = { "@", "!", "%", "=", ">", "<", "/" };
		// List of regular expression characters that need to be escaped during
		// replaceAll
		String[] regexSpecial = { "{", "}", "+", "$", "[", "]", "?", "^", "." };
		for (String i : specialChars) {
			strippedString = strippedString.replaceAll(i, "");
		}

		for (String j : regexSpecial) {
			strippedString = strippedString.replaceAll("\\" + j, "");
		}

		return strippedString;
	}

	public static void resetEmailId() {

		String currEmailId = emailid.get();
		String emailRegex = "HSIDAUTO[0-9]*@GMAIL.COM";
		String emailSmokeRegex = "HSIDAUTOSMOKE[0-9]*@GMAIL.COM$";
		// Only return email to pool IF:
		// * not null
		// * does not have the "unique tagging" with "+{UserID}"
		// * matches regular expression of pooled addresses
		// * not already in the pool
		if (currEmailId != null && !currEmailId.contains("+") && currEmailId.toUpperCase().matches(emailRegex)
				&& !emailIdPool.contains(currEmailId)) {
			emailIdPool.returnResource(currEmailId);
		}
        if (currEmailId != null && !currEmailId.contains("+") && currEmailId.toUpperCase().matches(emailSmokeRegex)
                && !emailIdPoolSmoke.contains(currEmailId)) {
            emailIdPoolSmoke.returnResource(currEmailId);
        }
		emailid.set(null);
	}

	public static void resetAllDataStorage() {
		resetCustomErrmsg();
		resetEmail();
		resetEmailId();
		resetPortalName();
		resetSubPortalName();
		resetuserdetails();
		resetusername();
		resetScenarioName();
		resetPhoneNumber();
		resetUniqueIDSSO();
		resetSiteURLSSO();
	}

	public static void resetuserdetails() {
		userdetails.get().clear();
	}

	/**
	 * Generic storage function into userdetails Map
	 * 
	 * @param key
	 * @param value
	 */
	public static void setUserDetails(String key, String value) {
		userdetails.get().put(key, value);
	}

	/**
	 * Generic retrieval function into userdetails Map WARNING: Will return null
	 * if 'key' has not been previously stored
	 * 
	 * @param key
	 */
	public static String getUserDetails(String key) {
		return userdetails.get().get(key);
	}

	public static void setFirstName(String frstname) {
		setUserDetails("FirstName", frstname);
	}

	public static String getFirstName() {
		return userdetails.get().get("FirstName");
	}

	public static void setFirstName_Alias(String frstname_alias) {
		setUserDetails("FirstName_Alias", frstname_alias);
	}

	public static String getFirstName_Alias() {
		return userdetails.get().get("FirstName_Alias");
	}

	public static void setFirstName_Prtl(String frstname_prtl) {
		setUserDetails("FirstName_Prtl", frstname_prtl);
	}

	public static String getFirstName_Prtl() {	return userdetails.get().get("FirstName_Prtl");	}

	public static void setLastName(String lastname) {
		setUserDetails("LastName", lastname);
	}

	public static String getLastName() {
		return userdetails.get().get("LastName");
	}

	public static void setLastName_Alias(String lastName_alias) {
		setUserDetails("LastName_Alias", lastName_alias);
	}

	public static String getLastName_Alias() {
		return userdetails.get().get("LastName_Alias");
	}

	public static void setLastName_Prtl(String lastName_prtl) {
		setUserDetails("LastName_Prtl", lastName_prtl);
	}

	public static String getLastName_Prtl() {
		return userdetails.get().get("LastName_Prtl");
	}

	public static void setDOB(String dob) {
		setUserDetails("DOB", dob);
	}

	public static String getDOB() {
		return userdetails.get().get("DOB");
	}

	public static void setDOB1(String dob1) {
		setUserDetails("DOB1", dob1);
	}

	public static String getDOB1() {
		return userdetails.get().get("DOB1");
	}

	public static void setSSN(String ssn) {
		setUserDetails("SSN", ssn);
	}

	public static String getSSN() {
		return userdetails.get().get("SSN");
	}

	public static void setSSNPDB(String ssn){setUserDetails("SSNPDB",ssn);}

	public static String getSSNPDB() {return userdetails.get().get("SSNPDB");}

	public static void setSubscriberID(String subscriberid) {
		setUserDetails("SubscriberID", subscriberid);
	}

	public static String getSubscriberID() {
		return userdetails.get().get("SubscriberID");
	}
	
	public static void setCareGiverAccessCode(String accesscode) {
		setUserDetails("CareGiverAccessCode", accesscode);
	}
	
	public static String getCareGiverAccessCode() {
		return userdetails.get().get("CareGiverAccessCode");
	}

	public static void setUniqueID(String uniqueId) {
		setUserDetails("UniqueID", uniqueId);
	}

	public static String getUniqueID() {
		return userdetails.get().get("UniqueID");
	}
	public static void setSiteURL(String siteurl) {
		setUserDetails("SiteURL", siteurl);
	}
	public static String getSiteURL() {
		return userdetails.get().get("SiteURL");
	}
	public static void setUniqueIDSSO(String uniqueId){ uniqueIDSSO.set(uniqueId);}

	public static String getUniqueIDSSO(){
		if(uniqueIDSSO.get()!=null) {
			return uniqueIDSSO.get();
		}
		else{
			DateFormat dateFormat = new SimpleDateFormat("yyMMddHHmmss");
			Date date = new Date();

			// For multithreaded execution, timestamp with seconds is not granular enough.
			//  Include random suffix
			String rndSuffix = Integer.toString(new Random().nextInt(1000));
			String appndTxt = dateFormat.format(date) + rndSuffix;

			uniqueIDSSO.set(appndTxt);
			return uniqueIDSSO.get();
		}
	}

	public static void setSiteURLSSO(String url){
		siteURLSSO.set(url);
	}

	public static String getSiteURLSSO(){
		if(siteURLSSO.get()!=null){
			return siteURLSSO.get();
		}else {
			String protocol = "https";
			String hostName = "://www."+getFirstName()+getLastName()+"sso.org/";
			String path = RandomStringUtils.random(10,true,true);
			siteURLSSO.set(protocol+hostName+path);
			return siteURLSSO.get();
		}
	}

	public static void setRgstPrtlID(String rgstPrtlID) {
		setUserDetails("RgstPrtlID", rgstPrtlID);
	}

	public static String getRgstPrtlID() {
		return userdetails.get().get("RgstPrtlID");
	}
	
	public static void setBriovaRxPrescriptionNumber(String briovarxprescriptionnumber) { setUserDetails("BriovaRxPrescriptionNumber", briovarxprescriptionnumber);	}

	public static String getPrescriptionNo() {	return userdetails.get().get("BriovaRxPrescriptionNumber");	}
	
	public static void setCardholderID(String cardholderId) {
		setUserDetails("CardholderID", cardholderId);
	}

	public static String getCardholderID() {
		return userdetails.get().get("CardholderID");
	}
	
	public static void setGender(String Gender) {
		setUserDetails("Gender", Gender);
	}

	public static String getGender() {
		return userdetails.get().get("Gender");
	}
	
	public static void setAddressLine(String AddressLine) {
		setUserDetails("AddressLine", AddressLine);
	}

	public static String getAddressLine() {
		return userdetails.get().get("AddressLine");
	}

	public static void setCity(String City) {
		setUserDetails("City", City);
	}

	public static String getCity() {
		return userdetails.get().get("City");
	}

	public static void setState(String State) {
		setUserDetails("State", State);
	}

	public static String getState() {
		return userdetails.get().get("State");
	}

	public static void setPhone(String Phone) {
		setUserDetails("Phone", Phone);
	}

	public static String getPhone() {
		return userdetails.get().get("Phone");
	}

	public static void setGroupNumber(String groupNum) {
		setUserDetails("GroupNumber", groupNum);
	}

	public static String getGroupNumber() {
		return userdetails.get().get("GroupNumber");
	}
	
	public static void setGroupNumber1(String groupNum1) {
		setUserDetails("GroupNumber1", groupNum1);
	}
	
	public static String getGroupNumber1() {
		return userdetails.get().get("GroupNumber1");
	}

	public static void setAltId(String altid) {
		userdetails.get().put("AltId", altid);
	}

	public static String getAltId() {
		return userdetails.get().get("AltId");
	}

	public static void setUUID(String uuid) {
		setUserDetails("UUID", uuid);
	}

	public static String getUUID() {
		return userdetails.get().get("UUID");
	}

	public static void setZip(String zip) {
		setUserDetails("Zip", zip);
	}

	public static void setZip1(String zip1) {
		setUserDetails("Zip1", zip1);
	}
	
	public static String getZip() {
		return userdetails.get().get("Zip");
	}
	
	public static String getZip1() {
		return userdetails.get().get("Zip1");
	}
	
	public static void setPNumber(String pnumber) {
		setUserDetails("PNumber", pnumber);
	}
	
	public static void setAccountNumber(String accnum){
		setUserDetails("AccountNumber", accnum);
	}
	
	public static String getPNumber() {
		return userdetails.get().get("PNumber");
	}

	public static void setCustomerId(String customerId) {
		setUserDetails("customerId", customerId);
	}

	public static String getcustomerId() {return userdetails.get().get("customerId"); }

	public static void setNewSubscriberID(String newsubscriberID) {
		setUserDetails("NewSubscriberID", newsubscriberID);
	}

	public static String getNewSubscriberID() {
		return userdetails.get().get("NewSubscriberID");
	}

	public static void setPortalNumber(int number) {
		DataStorage.portalNumber.set(number);
	}

	public static int getPortalNumber(){
		return DataStorage.portalNumber.get();
	}

	public static void setEID(String eID) {
		setUserDetails("EID",eID);
	}

	public static String getEID() {
		return userdetails.get().get("EID");
	}

	public static void setMDMSubId(String mDMSubId) {
		setUserDetails("MDMSubId",mDMSubId);
	}

	public static String getMDMSubId() {
		return userdetails.get().get("MDMSubId");
	}

	public static void setirisid(String irisid) { setUserDetails("irisid",irisid); }

	public static String getirisId() {
		return userdetails.get().get("irisid");
	}

	public static void setFaroId(String FaroId) { setUserDetails("FaroId",FaroId);	}

	public static String getFaroId() {
		return userdetails.get().get("FaroId");
	}

	public static void setId(String Id) { setUserDetails("Id",Id);	}

	public static String getId() {	return userdetails.get().get("Id");	}

	public static void setpatientId(String patientId) {	setUserDetails("patientId",patientId);	}

	public static String getpatientId() {
		return userdetails.get().get("patientId");
	}

	public static void setmigrationFlag(String migrationFlag) {	setUserDetails("migrationFlag",migrationFlag);	}

	public static String getmigrationFlag() {
		return userdetails.get().get("migrationFlag");
	}

	public static void setHealthSafeIdFlag(String healthSafeIdFlag) { setUserDetails("HealthSafeIdFlag",healthSafeIdFlag); }

	public static String getHealthSafeIdFlag() {
		return userdetails.get().get("HealthSafeIdFlag");
	}

	public static void setsourceCd(String sourceCd) { setUserDetails("sourceCd",sourceCd); }

	public static String getsourceCd() {
		return userdetails.get().get("sourceCd");
	}

	public static void setAccount(String account) {	setUserDetails("Account",account);	}

	public static String getAccount() {
		return userdetails.get().get("Account");
	}

	public static void setcarrier(String carrier) {	setUserDetails("carrier",carrier);	}

	public static String getcarrier() {
		return userdetails.get().get("carrier");
	}

	public static void setAccountHolderId(String accountHolderId) {	setUserDetails("AccountHolderId",accountHolderId);	}

	public static String getAccountHolderId() {
		return userdetails.get().get("AccountHolderId");
	}

	public static void setPrtlSubId(String prtlSubId) {
		setUserDetails("PrtlSubId",prtlSubId);
	}

	public static void setPrtlSubId1(String prtlSubId) {
		setUserDetails("PrtlSubId1",prtlSubId);
	}

	public static String getPrtlSubId() {
		return userdetails.get().get("PrtlSubId");
	}

	public static String getPrtlSubId1() {
		return userdetails.get().get("PrtlSubId1");
	}

	public static void setuserRootNode(String nodeName) {
		DataStorage.userRootNode.set(nodeName);
	}

	public static String getuserRootNode() {
		return DataStorage.userRootNode.get();
	}

	public static void setindividualId_Gps(String individualId_Gps) { setUserDetails("individualId_Gps",individualId_Gps); }

	public static String getIndividualId_Gps() {
		return userdetails.get().get("individualId_Gps");
	}

	public static void sethouseholdId_Gps(String householdId_Gps) {
		setUserDetails("householdId_Gps",householdId_Gps);
	}

	public static String getHouseholdId_Gps() {
		return userdetails.get().get("householdId_Gps");
	}

	public static void setindividualId_Compass(String individualId_Compass) {	setUserDetails("individualId_Compass",individualId_Compass); }

	public static String getIndividualId_Compass() {
		return userdetails.get().get("individualId_Compass");
	}

	public static void setRecType(String recType) {	setUserDetails("RecType",recType);	}

	public static String getRecType() {
		return userdetails.get().get("RecType");
	}

	public static void setPreviousEmailId(String prevEmail) {
		DataStorage.previousEmailId.set(prevEmail);
	}

	public static String getPreviousEmailId() {
		return DataStorage.previousEmailId.get();
	}

	public static void setPortalIndicator(String PortalIndicator) { setUserDetails("PortalIndicator", PortalIndicator); }

	public static String getPortalIndicator() {
		return userdetails.get().get("PortalIndicator");
	}

	public static void setSurrogateKey(String SurrogateKey) {
		setUserDetails("SurrogateKey", SurrogateKey);
	}

	public static String getSurrogateKey() {
		return userdetails.get().get("SurrogateKey");
	}
	
	public static void setActiveFlag(String activeFlag) { setUserDetails("activeFlag", activeFlag); }
	
	public static String getactiveFlag() {
		return userdetails.get().get("activeFlag");
	}	
	
	public static void setGroupName(String groupName) { setUserDetails("groupName", groupName); }
	
	public static String getgroupName() {
		return userdetails.get().get("groupName");
	}

	public static void setSSOID(String SSOID) { setUserDetails("SSOID", SSOID); }

	public static String getSSOID() {
		return userdetails.get().get("SSOID");
	}
		
	public static String getUserName() {

		if (UserName.get() != null) {
			return UserName.get();
		}

		DateFormat dateFormat = new SimpleDateFormat("yyMMddHHmmss");
		Date date = new Date();

		// For multithreaded execution, timestamp with seconds is not granular
		// enough. Include random suffix
		String rndSuffix = Integer.toString(new Random().nextInt(1000));
		String appndTxt = dateFormat.format(date) + "_" + rndSuffix;

		UserName.set("Auto" + appndTxt);
		return UserName.get();

	}

	public static void setCustomErrmsg(String customErrmsg) {
		if (DataStorage.customErrmsg.get() != null) {
			DataStorage.customErrmsg.set(DataStorage.customErrmsg.get() + "\n" + customErrmsg);
		} else {
			DataStorage.customErrmsg.set(customErrmsg);
		}
	}

	public static void resetCustomErrmsg() {
		DataStorage.customErrmsg.set("");
	}

	public static String getCustomErrmsg() {
		return DataStorage.customErrmsg.get();
	}

	public static String getEmailSubject() {
		if (EmailSubject.get() == null) {
			try {
				String username = (DataStorage.getEmail() == null) ? DataStorage.getEmailId() : DataStorage.getEmail();
				ReadEmail.retrieveMessage(username, "");
			}
			catch (Exception e) {
				DataStorage.setCustomErrmsg("EXCEPTION [" + e + "] IN getEmailSubject::for [" + emailid.get() + "]");
				Assert.fail("EXCEPTION [" + e + "] IN getEmailSubject::for [" + emailid.get() + "]");
			}
		}
		return EmailSubject.get();
	}

	public static String getEmailContent() {
		return EmailContent.get();
	}

	public static void setUserName(String username) {
		UserName.set(username);
	}

	public static void resetusername() {
		UserName.set(null);
	}

	public static String getConfirmregistrationurl() {

		if (confirmregistrationurl.get() != null) {
			return confirmregistrationurl.get();
		} else if ( EmailContent.get() != null ) {
			String[] tmparray = EmailContent.get().split("href=\"");
			String[] tmparr_2 = tmparray[1].split("\""); 
			confirmregistrationurl.set(tmparr_2[0]);
		} else {

			try {
				String[] tmparr = ReadEmail.getConfirmRegistrationURLWithSubjectandEmailContent();
				confirmregistrationurl.set(tmparr[0]);
				EmailSubject.set(tmparr[1]);
				EmailContent.set(tmparr[2]);
				setCustomErrmsg("confirmRegistrationUrl::[" + tmparr[0]	+ "]");
			} catch (Exception e) {
				Assert.fail("exception in getConfirmregistrationurl() [" + e.getMessage() + "]");
			}
		}
		return confirmregistrationurl.get();
	}
	
	public static void setConfirmregistrationurl(String Confirmregistrationurl) {
		confirmregistrationurl.set(Confirmregistrationurl);
	}
	
	public static void resetEmail() {
		confirmregistrationurl.set(null);
		EmailSubject.set(null);
		EmailContent.set(null);
	}

	public static void setPortalName(String portalname) {
		DataStorage.portalName.set(portalname);
	}

	public static String getPortalName() {
		return portalName.get();
	}

	public static void resetPortalName() {
		DataStorage.portalName.set(null);
	}

	public static void setSubPortalName(String subPortalname) {
		DataStorage.subPortalName.set(subPortalname);
	}

	public static String getSubPortalName() {
		return subPortalName.get();
	}

	public static void resetSubPortalName() {
		DataStorage.subPortalName.set(null);
	}

	public static void setU_FirstName(String frstname) {
		setUserDetails("FirstName", frstname);
	}

	public static void setU_LastName(String lastname) {
		setUserDetails("LastName", lastname);
	}

	public static void setU_DOB(String dob) {
		setUserDetails("DOB", dob);
	}

	public static void setU_SSN(String ssn) {
		setUserDetails("SSN", ssn);
	}

	public static void setU_Zip(String zip) {
		setUserDetails("Zip", zip);
	}


	/** ------------- Below methods related to Optum Id ------------------ */
	public static void setYearOfBirth(String yoB) {
		userdetails.get().put("YearOfBirth", yoB);
	}

	public static String getYearOfBirth() {
		return userdetails.get().get("YearOfBirth");
	}

	public static void setEmail(String email) {
		userdetails.get().put("Email", email);
		if ( emailid.get() == null ) {
			// Keep emailId and Email in sync 
			// unless emailId already set
			emailid.set(email);
		}
	}

	public static String getEmail() {
		return userdetails.get().get("Email");
	}
	
	public static void setPassword(String pwd) {
		userdetails.get().put("Password", pwd);
	}

	public static String getPassword() {
		return userdetails.get().get("Password");
	}
	
	public static String getAccountNumber() {
		return userdetails.get().get("AccountNumber");
	}	

	public static String getScenarioName() {
		return DataStorage.ScenarioName.get();
	}

	public static void setScenarioName(String name) {
		DataStorage.ScenarioName.set(name);
	}

	public static void resetScenarioName() {
		DataStorage.ScenarioName.set(null);
	}
	
	public static String getPhoneNumber(){
		return DataStorage.phoneNumber.get();
	}
	
	public static String getOrSetPhoneNumber(){
		String currPhno = DataStorage.phoneNumber.get();
		if (currPhno == null) {
			String poolresource = phoneNumberPool.getResource();
			if (poolresource == null) {
				setCustomErrmsg("ERROR::DataStorage::No available google voice number in resource pool");
				Assert.fail("ERROR::DataStorage::No available google voice number in resource pool");
			}
			
			String[] tmpArr = poolresource.split(":");
			currPhno=tmpArr[0];
			
			setPhoneNumber(currPhno);
			setEmailIDtoFetchOTP(tmpArr[1]);
			setCustomErrmsg("Setting google voice to " + currPhno + " from resource pool");
			setCustomErrmsg("Setting emailbox for text messages to " + tmpArr[1] + " from resource pool");
			
		}	
		return currPhno;
	}

	public static String getEmailIDtoFetchOTP() {
		return DataStorage.emailIDtoFetchOTP.get();
	}
	
	public static String getOrSetEmailIDtoFetchOTP() {
		String currEmailidtoFetchOTP = DataStorage.emailIDtoFetchOTP.get();
		if (currEmailidtoFetchOTP == null) {
			String poolresource = phoneNumberPool.getResource();
			if (poolresource == null) {
				setCustomErrmsg("ERROR::DataStorage::No available google voice number in resource pool");
				Assert.fail("ERROR::DataStorage::No available google voice number in resource pool");
			}
			
			String[] tmpArr = poolresource.split(":");
			setPhoneNumber(tmpArr[0]);
			currEmailidtoFetchOTP=tmpArr[1];
			setCustomErrmsg("Setting google voice to " + tmpArr[0] + " from resource pool");
			setCustomErrmsg("Setting emailbox for text messages to " + tmpArr[1] + " from resource pool");
			
		}
		return currEmailidtoFetchOTP;
	}

	public static void setEmailIDtoFetchOTP(String emailIDtoFetchOTP) {
		DataStorage.emailIDtoFetchOTP.set(emailIDtoFetchOTP);
	}
	
	public static void setEmailContent(String emailContent) {
		DataStorage.EmailContent.set(emailContent);
	}
	
	public static void setEmailSubject(String emailSubject) {
		DataStorage.EmailSubject.set(emailSubject);
	}

	public static void setPhoneNumber(String phoneNumber) {
		DataStorage.phoneNumber.set(phoneNumber);
	}
	
	public static void resetPhoneNumber(){
		if (DataStorage.phoneNumber!=null && !phoneNumberPool.contains(phoneNumber.get()+":"+emailIDtoFetchOTP.get())){
			
			phoneNumberPool.returnResource(phoneNumber.get()+":"+emailIDtoFetchOTP.get());
		}
		phoneNumber.set(null);
		emailIDtoFetchOTP.set(null);	
	}
	public static void setAccountId(String accountId) {
		setUserDetails("AccountId",accountId);	
		}

	public static String getAccountId() {
		return userdetails.get().get("AccountId");
	}

	public static void setIndividualId(String individualId) {	
		setUserDetails("IndividualId",individualId);	
		}

	public static String getIndividualId() {
		return userdetails.get().get("IndividualId");
	}

	public static void setBusinessType(String businessType) {	
		setUserDetails("BusinessType",businessType);	
		}
	public static String getBusinessType() {
		return userdetails.get().get("BusinessType");
	}

	public static void setIdValue(String idvalue) {
		setUserDetails("IdValue", idvalue);
	}

	public static String getIdValue() {
		return userdetails.get().get("IdValue");
	}

	public static void setPrtlSSN(String prtlSSN) {
		setUserDetails("PrtlSSN", prtlSSN);
	}

	public static String getPrtlSSN() {
		return userdetails.get().get("PrtlSSN");
	}

	public static void resetUniqueIDSSO(){
		uniqueIDSSO.set(null);
	}

	public static void resetSiteURLSSO(){
		siteURLSSO.set(null);
	}
	public static String getIndRelCode() {
		return userdetails.get().get("IndRelCode");
	}

	public static void setIndRelCode(String indRelCode) {
		setUserDetails("IndRelCode", indRelCode );
	}

	public static void setContentWithDynamicValue(String text) {
		contentWithDynamicValue.set(text);
	}

	public static String getContentWithDynamicValue() {
		return contentWithDynamicValue.get();
	}
	public static void setLanguage(String language) {
		setUserDetails("Language", language);
	}

	public static String getLanguage() {
		return userdetails.get().get("Language");
	}
}
	
