package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;
import com.optum.synergy.reference.ui.pageobjects.TCCUnauthenticatedHomePage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class TCCUnauthenticatedHomePageStepDefinition {
	private TCCUnauthenticatedHomePage page;

	public TCCUnauthenticatedHomePageStepDefinition() {
		page = new TCCUnauthenticatedHomePage();
	}

	@Given("^I am at TCC unauthenticated home page$")
	public void i_am_at_TCC_unauthenticated_home_page() {
		page.openTccHomePage();
		Assert.assertTrue("Issue while loading the TCC Unauthenticated page", page.isPageLoaded());
	}

	@Then("^I should be at TCC unauthenticated home page$")
	public void iShouldBeAtTccUnauthenticatedHomePage() {
		Assert.assertTrue("Issue while loading TCC unauthenticated page", page.isPageLoaded());
	}

	@Given("I should see an TCC logo")
	public void iShouldSeeATccLogo() {
		Assert.assertTrue("Issue displaying TCC Logo", page.getTccLogo().isDisplayed());
	}
}