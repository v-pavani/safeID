package com.optum.synergy.reference.ui.utility;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

public class UtilityReport {

	public static String testResultTextFile = "target/testResultsForReport.txt";

	public static void main(String[] args) throws IOException {

		String htmlReportOutputFile = "target/dashboard.html";
		// Read testResultTextFile, build Map of modules with pass/fail
		// array
	
		File scf = new File(testResultTextFile);
		Scanner scan = null;
		try {
			scan = new Scanner(scf);
		} catch (FileNotFoundException e) {
			// Jenkins runs have different working directory, hack workaround
			scf = new File("synergy_proj/" + testResultTextFile);
			htmlReportOutputFile = "synergy_proj/" + htmlReportOutputFile;
			scan = new Scanner(scf);
		}
		
		TreeMap<String, String> resultsMap = new TreeMap<String, String>();
		boolean firstLine = true;
		while (scan.hasNextLine()) {
			String line = scan.nextLine();

			if (firstLine) {
				// Skip first line
				firstLine = false;
				continue;
			}
			String[] tmparr = line.split(",");
			
			String currModuleResult = resultsMap.get(tmparr[0]);
			
			// If nothing exists in map for key or if maps's stored result
			// is "Pass", replace with result read from file
			if ( currModuleResult == null || currModuleResult.equalsIgnoreCase("PASS")) {
				resultsMap.put(tmparr[0], tmparr[1]);
			} 
			// Implied else: map's stored result is "FAIL", leave it failed
			
		}

		scan.close();
		File dashboard = new File(htmlReportOutputFile);
		dashboard.createNewFile();
		PrintWriter dashboardwriter = new PrintWriter(dashboard);
		dashboardwriter.println("<html><head><style>table, th, td {border: 1px solid black;}</style></head><body>");
		dashboardwriter.println("<table><thead><th>Module</th><th>HealthStatus</th></thead><tbody>");

		Set<Entry<String, String>> kyset = resultsMap.entrySet();
		for (Entry<String, String> m : kyset) {
			//
			String status = m.getValue();

			String colorcode = null;

			if (status.equalsIgnoreCase("PASS")) {
				colorcode = "\"#00FF00\"";
			} else if (status.equalsIgnoreCase("FAIL")) {
				colorcode = "\"#FF0000\"";
			}

			dashboardwriter
					.println("<tr><td>" + m.getKey() + "</td>" + "</td><td bgcolor=" + colorcode + ">" + "</td></tr>");
		}
		dashboardwriter.println("</tbody></table><br></br></body></html>");

		dashboardwriter.close();

	}

}
