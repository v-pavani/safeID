package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class BAZAuthenticatedHomePage extends PageObjectBase{
	
	@FindBy(how = How.XPATH, using = "//*[contains(text(),'Welcome')]")
	private WebElement welcomeToBAZ;
	
	@FindBy(how = How.XPATH, using = "//a[contains(@link-id,'_signout')]")
	private WebElement signOutLink;
	
	@FindBy(how = How.XPATH, using = "//img[@alt='BAZ Logo']")
	private WebElement bazLogo;
	
	public boolean isPageLoaded() {
		return longWait.get().until(ExpectedConditions.visibilityOf((welcomeToBAZ))).isDisplayed();
	}
	
	public WebElement getBAZLogo() {
		return mediumWait.get().until(ExpectedConditions.visibilityOf(bazLogo));
	}
	
	public boolean isSignOutLinkLoaded() {
		return longWait.get().until(ExpectedConditions.visibilityOf((signOutLink))).isDisplayed();
	}

	public boolean verifyIfAuthPageContentIsDisplayed() {
		waitForPageLoad(driver);
		waitForJavascriptToLoad(30000, 3000);

		return (getBAZLogo().isDisplayed() && isSignOutLinkLoaded());
	}	
}
