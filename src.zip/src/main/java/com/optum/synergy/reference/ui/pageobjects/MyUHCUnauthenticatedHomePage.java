package com.optum.synergy.reference.ui.pageobjects;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.optum.synergy.reference.ui.utility.ReadXMLData;

public class MyUHCUnauthenticatedHomePage extends PageObjectBase {

	@FindBy(how = How.XPATH, using = "//div[@class='login']")
	private WebElement loginForm;
	
	@FindBy(how = How.XPATH, using = "//div[starts-with(@ng-show,'ldapLocked')]/span/p|//p[starts-with(@ng-if,'isPageErrorExistent')]/span[3]")
	private WebElement userLockErrorMessage;

	public boolean verifyIfPageLoaded() {
		try {
			waitForPageLoad(driver);
			waitForJavascriptToLoad(15000, 3000);
			return longWait.get().until(ExpectedConditions.visibilityOf((loginForm))).isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}

	public void openCommunityAndStateURLHomePage() {
		String page_url= ReadXMLData.getTestData("MyUHC", "CommunityAndStateURL");
		openPage(page_url);
	}
	public void openmyUHCHomePage() {
		String page_url= ReadXMLData.getTestData("MyUHC", "AppURL");
		openPage(page_url);
	}

	public String getErrorMessagewhenuserisLDAPLocked() {
		 String message=mediumWait.get().until(ExpectedConditions.visibilityOf(userLockErrorMessage)).getText();
		if(message.contains("Error: ")){
		 String arrEle[]=message.split("Error: ");
		
			  return arrEle[1].replaceAll("\\s+", ""); 
		}
		return message.replaceAll("\\s+", ""); 
		}

}
