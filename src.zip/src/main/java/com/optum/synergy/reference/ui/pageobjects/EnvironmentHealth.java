package com.optum.synergy.reference.ui.pageobjects;

import java.io.BufferedReader;
import java.io.FileReader;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.ws.rs.core.MediaType;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.json.JSONObject;
import org.junit.Assert;

import com.optum.synergy.reference.ui.utility.DataStorage;
import com.optum.synergy.reference.ui.utility.ReadXMLData;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class EnvironmentHealth {

	public int getStatusCodeFromLAWWEligibilityService() {

		Client client = createClient();

		WebResource webResource = client.resource(ReadXMLData.getTestData("Services/LAWWEligibility", "endPoint"));

		String accessToken = getAccessTokenRxLAWW(client);
		String authorization = "Bearer " + accessToken;
		String actor = "sbh";
		String scope = "read";

		String data = "{\n   \"subscriberId\": \"003700551\"," + "\n   \"firstName\": \"PETER\","
				+ "\n   \"lastName\": \"WASHBURN\"," + "\n   \"dob\": \"07/15/1971\"\n}";

		String path = ReadXMLData.getTestData("Services/LAWWEligibility", "path");

		ClientResponse response = webResource.path(path).accept(MediaType.APPLICATION_JSON)
				.type(MediaType.APPLICATION_JSON).header("scope", scope).header("actor", actor)
				.header("Authorization", authorization).post(ClientResponse.class, data);

		int status = response.getStatus();

		return status;

	}

	public int getStatusCodeFromOptumRxEligibilityService() {

		Client client = createClient();

		WebResource webResource = client.resource(ReadXMLData.getTestData("Services/OptumRxEligibility", "endPoint"));

		String accessToken = getAccessTokenRxLAWW(client);
		String authorization = "Bearer " + accessToken;

		String scope = ReadXMLData.getTestData("Services/OptumRxEligibility/getUserDetailsService/Headers", "scope");
		String actor = ReadXMLData.getTestData("Services/OptumRxEligibility/getUserDetailsService/Headers", "actor");
		String userid = ReadXMLData.getTestData("Services/OptumRxEligibility/getUserDetailsService/Headers", "userid");
		String path = ReadXMLData.getTestData("Services/OptumRxEligibility", "path");

		ClientResponse response = webResource.path(path).header("scope", scope).header("actor", actor)
				.header("Authorization", authorization).header("userid", userid).get(ClientResponse.class);

		int status = response.getStatus();
		return status;

	}

	public int getStatusCodeFromOptumRxFindmemberService() {

		Client client = createClient();

		WebResource webResource = client.resource(ReadXMLData.getTestData("Services/OptumRxEligibility", "endPoint"));

		String accessToken = getAccessTokenRxLAWW(client);
		String authorization = "Bearer " + accessToken;

		String scope = ReadXMLData.getTestData("Services/OptumRxEligibility/getUserDetailsService/Headers", "scope");
		String actor = ReadXMLData.getTestData("Services/OptumRxEligibility/getUserDetailsService/Headers", "actor");
		String userid = ReadXMLData.getTestData("Services/OptumRxEligibility/getUserDetailsService/Headers", "userid");
		String path = "/rx/common/capability/v2.0/hsid/findmember.json";
		String payload = "{\"FindMemberRequest\":{\"members\":"
				+ "[{\"firstName\":\"jada\",\"lastName\":\"Matthew\",\"dob\":\"1981-01-30\",\"gender\":\"F\","
				+ "\"phone\":\"111-111-1111\",\"email\":\"test@hsid.com\",\"memberId\":\"9948677134\","
				+ "\"address1\":\"569-7682 Habitant Rd.\",\"address2\":\"\",\"city\":\"Huntsville\",\"state\":\"AL\",\"zip\":\"35486\"}]}}";

		ClientResponse response = webResource.path(path).header("scope", scope).header("actor", actor)
				.header("Authorization", authorization).header("userid", userid)
				.header("Content-type", "application/json").post(ClientResponse.class, payload);

		int status = response.getStatus();
		return status;

	}

	public int getStatusCodeFromMDMService() throws Exception {

		String webServiceURL1 = ReadXMLData.getTestData("Services", "MDM");
		String requestXMLPath1 = "./MDM_Services_Request_Body.xml";

		int methresponse = invokeWebService(webServiceURL1, requestXMLPath1);
		DataStorage.setCustomErrmsg("response from MDM service: [" + methresponse + "]");
		return methresponse;
	}

	public static int invokeWebService(String webServiceURL, String requestXMLPath)
			throws Exception {
		PostMethod post = null;
		HttpClient client = new HttpClient();

		try {
			// Read the SOAP request from the file
			StringBuffer requestFileContents = new StringBuffer();
			@SuppressWarnings("resource")
			BufferedReader bufferedReader = new BufferedReader(new FileReader(requestXMLPath));
			String line = null;

			while ((line = bufferedReader.readLine()) != null) {
				requestFileContents.append(line);
			}

			post = new PostMethod(webServiceURL);
			post.setRequestHeader("SOAPAction", "");

			// Request content will be retrieved directly from the input stream
			RequestEntity entity = new StringRequestEntity(requestFileContents.toString(), "text/xml", "utf-8");
			post.setRequestEntity(entity);

			// Returns a number indicating the status of response
			int result = client.executeMethod(post);
			return result;
		}

		finally {
			post.releaseConnection();
		}
	}

	public int getStatusCodeFromMyUHCligibilityService() {

		Client client = createClient();

		WebResource webResource = client.resource(ReadXMLData.getTestData("Services/MyUHCEligibility", "endPoint"));

		String accessToken = getAccessToken(client);
		String authorization = "Bearer " + accessToken;
		String actor = "Myuhc";
		String scope = "read";

		String data ="{\"lastName\":\"DWPTI\",\"dob\":\"07/07/1942\",\"plansInfo\":[{\"memberId\":\"00944276967\",\"groupId\":\"0701558\"}],\"portalIndicator\":\"MYUHC\",\"debug\":\"true\",\"firstName\":\"PIBFUHU\"}";		
		String path = ReadXMLData.getTestData("Services/MyUHCEligibility", "path");

		ClientResponse response = webResource.path(path).accept(MediaType.APPLICATION_JSON)
				.type(MediaType.APPLICATION_JSON).header("scope", scope).header("actor", actor)
				.header("Authorization", authorization).post(ClientResponse.class, data);

		int status = response.getStatus();
		return status;

	}

	private String getAccessToken(Client client) {

		WebResource webResource_clientToken = client
				.resource(ReadXMLData.getTestData("Services/Layer7Services", "endPoint"));
		String clientId = ReadXMLData.getTestData("Services/Layer7Services/getAuthTokenService/Headers", "client_id");
		String grantType = ReadXMLData.getTestData("Services/Layer7Services/getAuthTokenService/Headers", "grant_type");
		String clientSecrete = ReadXMLData.getTestData("Services/Layer7Services/getAuthTokenService/Headers",
				"client_secret");

		String path = ReadXMLData.getTestData("Services/Layer7Services/getAuthTokenService", "path");
		String data = "grant_type=" + grantType + "&client_id=" + clientId + "&client_secret=" + clientSecrete;
		ClientResponse response_clientToken = webResource_clientToken.path(path)
				.type("application/x-www-form-urlencoded").accept("application/json").post(ClientResponse.class, data);
		int status_clientToken = response_clientToken.getStatus();
		Assert.assertEquals(status_clientToken + " is not the expected status", 200, status_clientToken);
		String output_clientToken = response_clientToken.getEntity(String.class);
		JSONObject jobj_clientToken = new JSONObject(output_clientToken);
		String accessToken = jobj_clientToken.getString("access_token");
		DataStorage.setCustomErrmsg("Client access token: " + accessToken);
		return accessToken;
	}
	
	private String getAccessTokenRxLAWW(Client client) {

		WebResource webResource_clientToken = client
				.resource(ReadXMLData.getTestData("Services/Layer7Services", "endPointToken"));
		String clientId = ReadXMLData.getTestData("Services/Layer7Services/getAuthTokenService/Headers", "client_idTokenRxLAWW");
		String grantType = ReadXMLData.getTestData("Services/Layer7Services/getAuthTokenService/Headers", "grant_type");
		String clientSecrete = ReadXMLData.getTestData("Services/Layer7Services/getAuthTokenService/Headers",
				"client_secretTokenRxLAWW");

		String path = ReadXMLData.getTestData("Services/Layer7Services/getAuthTokenService", "path");
		String data = "grant_type=" + grantType + "&client_id=" + clientId + "&client_secret=" + clientSecrete;
		ClientResponse response_clientToken = webResource_clientToken.path(path)
				.type("application/x-www-form-urlencoded").accept("application/json").post(ClientResponse.class, data);
		int status_clientToken = response_clientToken.getStatus();
		Assert.assertEquals(status_clientToken + " is not the expected status", 200, status_clientToken);
		String output_clientToken = response_clientToken.getEntity(String.class);
		JSONObject jobj_clientToken = new JSONObject(output_clientToken);
		String accessToken = jobj_clientToken.getString("access_token");
		DataStorage.setCustomErrmsg("Client access token: " + accessToken);
		return accessToken;
	}

	private Client createClient() {
		Client client = Client.create();

		// Install the all-trusting trust manager
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			public X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			public void checkClientTrusted(X509Certificate[] certs, String authType) {
			}

			public void checkServerTrusted(X509Certificate[] certs, String authType) {
			}
		} };

		try {
			SSLContext sc = SSLContext.getInstance("TLSv1.2");
			sc.init(null, trustAllCerts, new SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		} catch (Exception e) {
			;
		}
		return client;
	}

	public String getStatusMessageFromESSOServices() {
		Client client = createClient();
		WebResource webResource = client.resource(ReadXMLData.getTestData("Services/EssoServices", "endPoint"));
		ClientResponse response = webResource.get(ClientResponse.class);
		return response.getEntity(String.class);
	}

	public String getStatusMessageFromRBAServices() {
		Client client = createClient();
		WebResource webResource = client.resource(ReadXMLData.getTestData("Services/RbaServices", "endPoint"));
		ClientResponse response = webResource.get(ClientResponse.class);
		return response.getEntity(String.class);
	}

	public int getStatusCodeFromSSOService() {

		Client client = createClient();

		WebResource webResource = client.resource(ReadXMLData.getTestData("Services/SSOService", "endPoint"));

		String accessToken = getAccessToken(client);
		String authorization = "Bearer " + accessToken;
		String actor = "actor";
		String scope = "read";

		String data = "{\n \"firstName\": \"Ashley\"," + "\n \"lastName\": \"KAIHARA\" ,"
				+ " \n \"id\": \"212345746\", " + " \n \"idType\": \"SSOID\"," + "\n \"targetPortal\": \"GEHUB\", "
				+ " \n \"email\":\"chaitanya.sbs@optum.com\"," + " \n\"customer\":\"GE\"\n}";

		String path = ReadXMLData.getTestData("Services/SSOService", "path");

		ClientResponse response = webResource.path(path).accept(MediaType.APPLICATION_JSON)
				.type(MediaType.APPLICATION_JSON).header("scope", scope).header("actor", actor)
				.header("Authorization", authorization).post(ClientResponse.class, data);

		int status = response.getStatus();
		return status;

	}

}
