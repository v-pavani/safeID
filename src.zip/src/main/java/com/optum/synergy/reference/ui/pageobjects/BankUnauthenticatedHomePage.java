package com.optum.synergy.reference.ui.pageobjects;

import org.junit.Assert;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.optum.synergy.reference.ui.utility.ReadXMLData;
import org.openqa.selenium.support.ui.Select;

public class BankUnauthenticatedHomePage extends PageObjectBase {
	
	@FindBy(how = How.XPATH, using = "//*[@id='main-content']")
	private WebElement bankPage;

	@FindBy(how = How.XPATH, using = "//*[@id='sl__list']")
	private WebElement signInDropdown;

	public void openDisneyHomePage() {
		String page_url = ReadXMLData.getTestData("CAP", "DisneyURL");
		openPage(page_url);
	}
	
	public void openUHCHAHomePage() {
		String page_url = ReadXMLData.getTestData("CAP", "UHCHAURL");
		openPage(page_url);
 	}
	
	public void openUHCRAHomePage() {
		String page_url = ReadXMLData.getTestData("CAP", "UHCRAURL");
		openPage(page_url);
	}
	
	public void openBankHomePage() {
		String page_url = ReadXMLData.getTestData("CAP", "OptumBankURL");
		openPage(page_url);
	}

	public void openBankAARPHomePage() {
		String page_url = ReadXMLData.getTestData("CAP", "BankAARPURL");
		openPage(page_url);
	}
	
	public boolean verifyIfUnauthBankPageLoadedInProduction() {
		String signInLink = "SIGN IN";
		String browser = System.getProperty("BrowserType");

		if(browser.equalsIgnoreCase("Safari"))
			signInLink = "Sign in";
		try {
			waitForJavascriptToLoad(25000, 1000);
			Assert.assertTrue("Issue with Bank unauthenticated page display",mediumWait.get().until(ExpectedConditions.visibilityOf(bankPage)).isDisplayed());
			findPartialLinkText(signInLink);
			Assert.assertTrue("Issue with the Brand logo",new Registration_PersonalInformationSectionPage().getOptumBankLogo().isDisplayed());
			Assert.assertTrue("Issue with the page title of the Bank unauth home page",getPageTitle().equalsIgnoreCase("Financial Products & Health Savings Accounts from Optum Bank"));

			return true;

		} catch (TimeoutException e) {
			return false;
		}

	}

	public boolean verifyIfUnauthBankDisneyPageLoadedInProduction() {
		String signInLink = "Sign in";

		try {
			waitForJavascriptToLoad(25000, 1000);
			return getPageTitle().equalsIgnoreCase("Disney") && findPartialLinkText(signInLink);
		} catch (TimeoutException e) {
			return false;
		}
	}

	public boolean verifyIfUnauthBankUHCRAPageLoadedInProduction() {
		try {
			waitForJavascriptToLoad(25000, 1000);
			return getPageTitle().equalsIgnoreCase("UHC Retiree Accounts | Optum Financial") && verifyElementById("main-content");
		} catch (TimeoutException e) {
			return false;
		}
	}

	public boolean verifyIfUnauthBankUHCHAPageLoadedInProduction() {

			waitForJavascriptToLoad(25000, 1000);
		try {
				Assert.assertTrue("Webpage title mismatch ", getPageTitle().trim().equalsIgnoreCase("UnitedHealthAccounts.com"));
				findPartialLinkText("Sign-in");
				return true;
			} catch (Exception e) {
				System.err.println("Exception message:: " + e.getMessage());
				return false;
			}
	}

	public boolean verifyIfUnauthBankAARPPageLoadedInProduction() {

		waitForJavascriptToLoad(25000, 1000);
		try {
			Assert.assertTrue("Webpage title mismatch ", getPageTitle().equalsIgnoreCase("AARP"));
			findPartialLinkText("SIGN IN");
			return true;
		} catch (Exception e) {
			System.err.println("Exception message:: " + e.getMessage());
			return false;
		}
	}

	public void selectSignInOption(String value) {
		Select signIn = new Select(mediumWait.get().until(ExpectedConditions.visibilityOf(signInDropdown)));
		signIn.selectByVisibleText(value);
	}
	
}
