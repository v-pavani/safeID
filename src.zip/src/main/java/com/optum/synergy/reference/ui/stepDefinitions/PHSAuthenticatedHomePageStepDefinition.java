package com.optum.synergy.reference.ui.stepDefinitions;

import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.PHSAuthenticatedHomePage;
import cucumber.api.java.en.Then;

public class PHSAuthenticatedHomePageStepDefinition {
	private PHSAuthenticatedHomePage page;

	public PHSAuthenticatedHomePageStepDefinition() {
		page = new PHSAuthenticatedHomePage();
	}

	@Then("^I should be at PHS authenticated home page$")
	public void iShouldBeAtPHSAuthenticatedHomePage() {
		Assert.assertTrue("Issue while loading the PHS authenticated home page", page.isPageLoaded());
	}
}