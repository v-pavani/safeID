package com.optum.synergy.reference.ui.stepDefinitions;


import org.junit.Assert;

import com.optum.synergy.reference.ui.pageobjects.MyUHCUnauthenticatedHomePage;
import com.optum.synergy.reference.ui.pageobjects.Registration_PersonalInformationSectionPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class MyUHCUnauthenticatedHomePageStepDefinition {
	private MyUHCUnauthenticatedHomePage page;
	
	public MyUHCUnauthenticatedHomePageStepDefinition() {
		page = new MyUHCUnauthenticatedHomePage();
	}

	@Given("^I am at myUHC unauthenticated home page$")
	public void iAmAtMyUHCUnauthenticatedHomePage() {
		page.openmyUHCHomePage();
		Assert.assertTrue("Issue while loading the myUHC Unathenticated page", page.verifyIfPageLoaded());
	}
	
	@Given("^I am at myUHC-CommunityAndState unauthenticated home page$")
	public void iAmAtMyUHCCommunityAndStateUnauthenticatedHomePage() {
		page.openCommunityAndStateURLHomePage();
		Assert.assertTrue("Issue while loading the MyUHC-Communityplan unauthenticated page", page.verifyIfPageLoaded() && new Registration_PersonalInformationSectionPage().verifyMyUhcCommunityPlanLogo());
	}
	
	@Then("^I should be at myUHC unauthenticated sign in page$")
	public void iAmAtMyUHCUnauthenticatedSignInPage() {
		Assert.assertTrue("Issue while loading the myUHC unauthenticated page", page.verifyIfPageLoaded());
	}
	
	@Then("^I should be at \"([^\"]*)\" unauthenticated page$")
	public void iAmAtUnauthenticatedPage(String portalName) {
		Assert.assertTrue("Issue while loading the "+portalName+" unauthenticated page", page.verifyIfPageLoaded());
	}
	
	@Then("^I should see an error message \"(.*)\" when user is LDAP locked$")
	public void iShouldSeeAnErrorMessageWhenUserisLDAPLocked(String expectedMessage ) {
		Assert.assertEquals("FAIL: Did not find expected error message",expectedMessage.replaceAll("\\s+", ""), page.getErrorMessagewhenuserisLDAPLocked());
	}

	@Then("^I should be at MyUHC-Communityplan unauthenticated page$")
	public void iAmAtCommunityplanUnauth() {
		Assert.assertTrue("Issue while loading the MyUHC-Communityplan unauthenticated page", page.verifyIfPageLoaded() && new Registration_PersonalInformationSectionPage().verifyMyUhcCommunityPlanLogo());
	}
}
