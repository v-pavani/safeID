package com.optum.synergy.reference.ui.pageobjects;

import static io.restassured.RestAssured.given;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.Assert;

import com.optum.synergy.reference.ui.utility.DataStorage;
import com.optum.synergy.reference.ui.utility.ReadXMLData;

import io.restassured.response.Response;

/**
 * @author vchaube1
 *
 */
public class EmailAndPhoneConfirmServices {

	private final String username = ReadXMLData.getTestData("Services/EmailConfirmService", "Username");
	private final String password = ReadXMLData.getTestData("Services/EmailConfirmService", "Password");

	public String getEmailVerificationCode() {
		
		String endPointURL = ReadXMLData.getTestData("Services/EmailConfirmService", "VerificationCodeServiceEndPoint");

		Response response = given()
				.relaxedHTTPSValidation()
				.auth().basic(username, password)
				.queryParam("userid", DataStorage.getUserName())
				.queryParam("to", DataStorage.getEmail()).

				when().get(endPointURL);

		String responseBody = response.asString();

		String verificationCode = "";
		Pattern p = Pattern.compile("(\\d{10})");
		Matcher m = p.matcher(responseBody);
		while (m.find()) {
			verificationCode = m.group(0);
		}		
		
		if(!responseBody.contains("SUCCESS"))
			Assert.fail("Confirm email Service execution failure. Response Body::["+responseBody+"]");
		return verificationCode;

	}

	public int activateEmail() {
		
		String endPointURL = ReadXMLData.getTestData("Services/EmailConfirmService", "ActivateEmailServiceEndPoint");

		Response response = given()
				.relaxedHTTPSValidation()
				.auth().basic(username, password)
				.queryParam("token", getEmailVerificationCode())
				.accept("application/json").

				when().get(endPointURL);
		
		String responseBody = response.asString();
		
		if(!responseBody.contains("SUCCESS"))
			Assert.fail("Activate email Service execution failure. Response Body::["+responseBody+"]");

		return response.getStatusCode();

	}

}
